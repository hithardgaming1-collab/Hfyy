# Critter Quest: The Silence of the Heart Bell

Full story mode for Critter Quest: 15 maps, 50+ characters, 30+ trainer battles, a party system, evolution, saving, an ending and credits.
**Spoilers below.** Maps and their coordinates are in `MAPS.md`.

## How to play

| Control | Remote / keyboard | Touch |
|---|---|---|
| Walk | D-pad / arrows / WASD | on-screen pad |
| Talk, read, use | OK / Enter / Space | tap OK |
| Menu (Resume, Journal, Save, Quit) | BACK / Esc / Menu | MENU |

- **Rest Stones** (glowing stones in every town and on the long routes) and **your bed / Mom's cooking** fully heal your whole party and save the game. The pause menu can also save anywhere.
- **Blackout**: if your whole party faints you wake up at the last Rest Stone, fully healed. You lose nothing, so train in tall grass and try again.
- **Battles work like the classic handheld RPGs.** Every critter knows up to **4 moves** (each with a type, power, accuracy and PP), learns new ones as it levels (a full moveset asks which move to forget), and has six stats (HP, Attack, Defense, Sp. Atk, Sp. Def, Speed). The faster critter moves first. Moves of the critter's own type get a 1.5x bonus, and critters can be **dual-typed**. There are **14 types** (Normal, Fire, Water, Leaf, Electric, Ice, Fighting, Poison, Ground, Flying, Psychic, Bug, Rock, Ghost); the full chart, all 98 moves and all 38 species are in `CRITTERS.md`.
- **Status and stat moves**: burn, poison, paralysis, sleep and freeze, plus moves that raise or lower Attack, Defense, Speed, accuracy and so on. Status wears off when the fight ends.
- **Catching**: in wild fights choose **Catch** to throw a Critter Orb (you get 8 per trip; Rest Stones refill them). The lower a critter's HP, and the more it is asleep, frozen, burned, poisoned or paralysed, the better your odds. Your party holds 6; extras go to **Mom's critter box** at home (talk to Mom > *Open the critter box*) where you can swap them in and out. The Journal shows your Critterdex count.
- **Party**: you start with two critters (the third starter orb is given to you), and each Warden gives you one of their critters with their Sigil. Choose **Swap** in battle (costs a turn; if your critter faints you pick the next for free).
- **XP**: the critter in front gets full XP, the rest of the party shares half. Starters evolve at level 10; many wild critters evolve too (Wrigglet becomes Cocovex at 6, then Glimmerwing at 10; Flopfin turns into a very different Tempestail at 15).
- **Rest** in battle heals 40% and cures status (limited uses per trip, refilled at Rest Stones; each trainer win gives one back). **Run** works against wild critters.
- The **Journal** (BACK > Journal) always shows your current chapter and goal.

## Story

**Prologue: A Silent Bell.** The Heart Bell of Mossbrook, whose chime calms every critter in the Critterlands, has been silent for three days. Wild critters are restless. Mom sends you to Professor Fern, where you and your rival Kit receive partners. Kit always takes the critter your partner beats, and challenges you to a friendly spar. Fern explains the three Warden Sigils that open the Shrine Gate to the Hollow Keep, where the Bell hangs.

**Chapter 1: Whisper Meadow / Briar Hollow (Leaf).** Cross the tall grass to Briar Hollow, where a Hollow Guild grunt blocks the Leaf Shrine. Beat the disciples and Warden Willow. She reveals the villain: Baron Gloam, an old Shrine student who believed critters should be *commanded*.

**Chapter 2: Saltwind Shore / Tidewatch Harbor (Tide).** Warden Marina reveals the Bell is not broken, its **Chime Core** was stolen. She also notices something odd: if Gloam wanted the Sigils, why only frighten the Wardens instead of taking them? Kit catches up for a rematch.

**Chapter 3: Ashen Trail / Cinderpeak (Ember).** Warden Cinder tells Gloam's story: his partner Wick vanished the night the Bell once stuttered, and he never forgave it. Ask her to bring him back from the dark.

**Chapter 4: Gloam Pass.** Kit waits for one last friendly fight. At the Shrine Gate the three Sigils fly out of your pack and open it, and Gloam appears: the Sigils can only be *given*, so he provoked the Wardens until they chose a champion. You carried the key to his door.

**Chapter 5: The Hollow Keep.** Guild grunts, a Rest Stone halfway, and Lieutenant Vex guarding the Heart Chamber door.

**Finale: The Heart Chamber.** Gloam holds the Core and wants the Sigils to reforge the Bell into a tool of command. Beat his three elder-form critters (one of each type) and the Core floats to the Bell, the Sigils lock in, and it rings across the whole region. Gloam realises Wick was running *toward* the Bell, not away. The Wardens, Fern and Kit arrive, Cinder sentences Gloam to tend the Bell, and the credits roll.

**Epilogue.** You return to Mossbrook as Champion. Characters have new lines, the Guild has disbanded, and Kit offers a hard rematch (three critters at level 30).

## Cast

You, Mom, **Kit** (rival, 4 fights), **Professor Fern**, Elder Moss, Pip, Gardener Wren, Hiker Bram, Herbalist Hazel, Woodcutter Garn, Sailor Finn, Fisher Odo, Dockhand Rusty, Net-mender Sal, Smith Forge, Cook Spice, Ranger Ash, trainers and disciples of each shrine, the **Wardens Willow, Marina and Cinder**, **Lieutenant Vex**, and **Baron Gloam**.

## Levels at a glance

| Fight | Foe levels |
|---|---|
| Kit (lab spar) | 5 |
| Route 1 trainers | 4 to 5 |
| Warden Willow | 8 and 9 |
| Warden Marina | 14 and 15 |
| Warden Cinder | 18 and 19 |
| Lieutenant Vex | 23 and 23 |
| Baron Gloam | 27, 27 and 28 |

A **Water** starter has the hardest opening (the first Warden is Leaf type): expect to grind a few levels on Route 1.

## Verified automatically

`tools/story_check/run.sh` (needs `kotlinc`) validates all maps (rows, warps, reachability, NPC placement), runs every NPC and cut-scene script under thousands of random story states, and **plays the whole game with a bot** for all three starters, from the first line to the credits, the save/load round trip and the post-game rematch. `./run.sh maps` re-renders `docs/maps/*.png` and `MAPS.md`.

## Editing the story

All text lives in two files:

- `Cast.kt`: every person. Add one to the `NPCS` list:
  ```kotlin
  talker("sailor2", "route2", 14, 6, "Old Sailor", lk(Color.rgb(200,200,200), Color.rgb(60,90,160), Color.rgb(50,60,90)), DOWN) {
      if (f("sigil_tide")) listOf("The tide listens to you now.") else listOf("Marina can calm any storm.")
  }
  ```
  Trainers use `tnpc(...)` with a `Trainer(id, name, team = team(AQUAFIN to 12))`. `f("flag")` checks story flags.
- `Story.kt`: opening, starter choice, Shrine Gate twist, finale triggers, Journal text.
- `Maps.kt`: edit the ASCII maps, warps, wild critter tables and sign texts.

Level and difficulty numbers are the `team(...)` values in `Cast.kt`.
