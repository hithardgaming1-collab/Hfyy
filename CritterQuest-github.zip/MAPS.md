# Critter Quest - World Maps

Every map is plain ASCII art in `app/src/main/java/com/example/critterquest/Maps.kt`. Row 0 / column 0 is the top-left tile. Previews below are rendered by the game's own drawing code (`tools/story_check`).

![World overview](docs/world_overview.png)

## World layout

```
  Your House <-> Mossbrook <-> Fern's Lab
          |  east (needs a partner)
  Whisper Meadow (Route 1)
          |  east
  Briar Hollow <-> Leaf Shrine            Warden Willow  -> Leaf Sigil
          |  south
  Saltwind Shore (Route 2)
          |  south
  Tidewatch Harbor <-> Tide Shrine        Warden Marina  -> Tide Sigil
          |  east
  Ashen Trail (Route 3)
          |  east
  Cinderpeak <-> Ember Shrine             Warden Cinder  -> Ember Sigil
          |  north (needs the Ember Sigil)
  Gloam Pass (Route 4)
          |  Shrine Gate (needs all 3 Sigils)
  Hollow Keep
          |  door guarded by Lieutenant Vex
  Heart Chamber                           Baron Gloam, the Heart Bell
```

## Tile legend

| Char | Tile | Walkable | Notes |
|---|---|---|---|
| `.` | ground | yes | themed ground |
| `,` | path | yes | path |
| `;` | tall | yes | tall grass - wild critters appear here |
| `#` | tree | no | tree / cliff / rock wall |
| `~` | water | no | water |
| `=` | bridge | yes | bridge over water |
| `^` | roof | no | roof |
| `h` | wall | no | house wall |
| `D` | door | yes | door (needs a warp entry) |
| `*` | flower | yes | flowers |
| `f` | fence | no | fence |
| `s` | sign | no | sign - press OK (text comes from the map's `notes`) |
| `R` | rock | no | boulder |
| `L` | lava | no | lava |
| `b` | sand | yes | sand |
| `_` | floor | yes | indoor floor |
| `W` | iwall | no | indoor wall |
| `T` | table | no | table (can have a note) |
| `B` | bed | no | bed - rest and save |
| `P` | stone | no | Rest Stone - heal and save |
| `G` | gate | no | Shrine Gate - solid until all 3 Sigils are used |
| `c` | crystal | no | crystal / pillar |
| `r` | rug | yes | rug |
| `K` | shelf | no | shelf (can have a note) |
| `1` | orb1 | no | starter orb 1 (Emberpup) |
| `2` | orb2 | no | starter orb 2 (Aquafin) |
| `3` | orb3 | no | starter orb 3 (Sproutle) |
| `Q` | bell | no | the Heart Bell (2 tiles wide) |

## 1. Your House  (`home`, 10x8, indoor)

![Your House](docs/maps/home.png)

**Warps**

| Step on (x,y) | Goes to | Arrives at | Condition |
|---|---|---|---|
| 4,7 | Mossbrook | 5,5 |  |

**People**

| Who | Tile | Facing | Role |
|---|---|---|---|
| Mom | 4,3 | down | talks |

**Signs / things to read**

- (1,1) A shelf of dusty almanacs. One is titled 'Critterlands Type Chart for the Curious': Fire beats Leaf, Leaf beats Water, Water beats Fire.
- (2,1) Mom's cookbooks. Half the pages are stuck together with berry jam.
- (6,1) A framed picture of you and Mom on your first day of school.
- (2,3) Mom's famous berry pancakes. They smell amazing.

```
WWWWWWWWWW
WKK___TTBW
W________W
W_TT_____W
W__rrrr__W
W__rrrr__W
W________W
WWWWDWWWWW
```

## 2. Mossbrook  (`mossbrook`, 24x16, meadow)

![Mossbrook](docs/maps/mossbrook.png)

**Warps**

| Step on (x,y) | Goes to | Arrives at | Condition |
|---|---|---|---|
| 5,4 | Your House | 4,6 |  |
| 17,4 | Fern's Lab | 5,7 |  |
| 23,7 to 23,8 | Whisper Meadow | 1,6 | Professor Fern is waiting for you at the lab! You can't go out into th |

**People**

| Who | Tile | Facing | Role |
|---|---|---|---|
| Kit | 6,6 | left | talks |
| Elder Moss | 10,9 | right | talks |
| Pip | 19,6 | down | talks |
| Gardener Wren | 9,12 | down | talks |
| Kit | 12,7 | left | talks |

**Signs / things to read**

- (8,6) MOSSBROOK  -  Village of the Heart Bell's first keepers.
- (13,5) FERN'S CRITTER LAB  -  Visitors welcome. Please knock first!

```
########################
#......................#
#..^^^^^......^^^^^^^..#
#..hhhhh......hhhhhhh..#
#..hhDhh......hhhDhhh..#
#*...,.......s...,..*..#
#....,..s........,..*..#
#,,,,,,,,,,,,,,,,,,,,,,,
#,,,,,,,,,,,,,,,,,,,,,,,
#..^^^^^.....ffffffffff#
#..hhhhh..***f~~~~~~~~.#
#..hhhhh...P.f~~~~~~~~.#
#........****f~~~~~~~~.#
#.*.....*....f~~~~~~~~.#
#......................#
########################
```

## 3. Fern's Lab  (`lab`, 12x9, indoor)

![Fern's Lab](docs/maps/lab.png)

**Warps**

| Step on (x,y) | Goes to | Arrives at | Condition |
|---|---|---|---|
| 5,8 | Mossbrook | 17,5 |  |

**People**

| Who | Tile | Facing | Role |
|---|---|---|---|
| Prof. Fern | 6,2 | down | talks |
| Kit | 9,4 | left | talks |

**Signs / things to read**

- (1,1) Research notes: 'The Heart Bell chimes at dawn and dusk. Its sound calms every critter that hears it.'
- (2,1) Research notes: 'Critters grow stronger by battling. Rest Stones restore them and record your journey.'
- (3,1) Research notes: 'Elder forms appear when a partner reaches level 10. Their power is remarkable.'
- (8,1) A shelf of critter field guides. Every page about the Hollow Keep has been torn out.
- (10,1) Old Warden records: 'Leaf, Tide and Ember Sigils together open the Shrine Gate on Gloam Pass.'
- (4,3) A long table covered in notes and half-finished sketches of critters.

```
WWWWWWWWWWWW
WKKK____KKKW
W__________W
W___T123___W
W__________W
W___rrrr___W
W___rrrr___W
W__________W
WWWWWDWWWWWW
```

## 4. Whisper Meadow  (`route1`, 30x14, meadow)

![Whisper Meadow](docs/maps/route1.png)

**Warps**

| Step on (x,y) | Goes to | Arrives at | Condition |
|---|---|---|---|
| 0,6 to 0,7 | Mossbrook | 22,7 |  |
| 29,6 to 29,7 | Briar Hollow | 1,7 |  |

**Wild critters** (14% per step in tall grass)

| Critter | Levels | Weight |
|---|---|---|
| Nibblet | 3-5 | 4 |
| Pipwing | 3-5 | 4 |
| Wrigglet | 3-5 | 3 |
| Budling | 4-5 | 1 |

**People**

| Who | Tile | Facing | Role |
|---|---|---|---|
| Scout Tobi | 9,5 | down | trainer: Nibblet Lv4, Wrigglet Lv4 (sees 2 tiles) |
| Picnicker Pia | 20,8 | up | trainer: Pipwing Lv4, Budling Lv5 (sees 2 tiles) |
| Hiker Bram | 16,5 | down | talks |

**Signs / things to read**

- (2,5) WHISPER MEADOW  -  Wild critters hide in the tall grass. Briar Hollow lies to the east.
- (23,8) BRIAR HOLLOW  -  Home of Warden Willow and the Leaf Shrine. Keep going east!

```
##############################
#*.#...*......~~~...##.......#
#....;;;;;....~~~...;;;;;;*..#
#....;;;;;#...~~~...;;;;;;...#
#.#..;;;;;.....~...*;;;;;;...#
#.s...........P.*...;;;;;;...#
,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
##..#................*.s....##
#..;;;;.*...;;;;;;;...*...##.#
#..;;;;.#...;;;;;;;....*#...##
#*.;;;;.....;;;;;;;..........#
#...........;;;;;;;.......#..#
##############################
```

## 5. Briar Hollow  (`briar`, 26x16, forest)

![Briar Hollow](docs/maps/briar.png)

**Warps**

| Step on (x,y) | Goes to | Arrives at | Condition |
|---|---|---|---|
| 0,7 to 0,8 | Whisper Meadow | 28,6 |  |
| 12,15 to 13,15 | Saltwind Shore | 10,1 |  |
| 13,4 | Leaf Shrine | 5,10 |  |

**People**

| Who | Tile | Facing | Role |
|---|---|---|---|
| Guild Grunt | 13,5 | down | trainer: Hissle Lv6 (sees 3 tiles) |
| Herbalist Hazel | 20,6 | down | talks |
| Woodcutter Garn | 7,9 | down | talks |

**Signs / things to read**

- (9,6) BRIAR HOLLOW  -  A town grown between the roots of the Great Elm.
- (15,6) LEAF SHRINE  -  Warden Willow tests all who seek the Leaf Sigil.

```
##########################
##.......*..#..#......##.#
#..^^^^^#.^^^^^^^..^^^^^.#
#..hhhhh..hhhhhhh#.hhhhh.#
#..hhhhh#.hhhDhhh..hhhhh.#
#....,...*...,.......,...#
#....,...s...,.s.....,..##
,,,,,,,,,,,,,,,,,,,,,,,,,,
,,,,,,,,,,,,,,,,,,,,,,,,,,
#.....#....#,,...#.......#
#**^^^^^...*,,#..P.*****.#
#..hhhhh....,,.....******#
#..hhhhh....,,#.#..*****.#
#....#.##...,,..#.....#..#
#...........,,..#.#......#
############,,############
```

## 6. Leaf Shrine  (`leafshrine`, 12x12, indoor)

![Leaf Shrine](docs/maps/leafshrine.png)

**Warps**

| Step on (x,y) | Goes to | Arrives at | Condition |
|---|---|---|---|
| 5,11 | Briar Hollow | 13,5 |  |

**People**

| Who | Tile | Facing | Role |
|---|---|---|---|
| Disciple Clover | 8,7 | left | trainer: Budling Lv6 (sees 3 tiles) |
| Disciple Bramble | 3,4 | right | trainer: Sproutle Lv7, Hivelet Lv7 (sees 3 tiles) |
| Warden Willow | 6,2 | down | boss/trainer (smart AI): Budling Lv7, Thornpaw Lv8 (sees 3 tiles) |

```
WWWWWWWWWWWW
W__________W
W_c__rr__c_W
W____rr____W
W____rr____W
W_c__rr__c_W
W____rr____W
W____rr____W
W_c__rr__c_W
W____rr____W
W__________W
WWWWWDWWWWWW
```

## 7. Saltwind Shore  (`route2`, 22x22, shore)

![Saltwind Shore](docs/maps/route2.png)

**Warps**

| Step on (x,y) | Goes to | Arrives at | Condition |
|---|---|---|---|
| 10,0 to 11,0 | Briar Hollow | 12,14 |  |
| 10,21 to 11,21 | Tidewatch Harbor | 12,1 |  |

**Wild critters** (14% per step in tall grass)

| Critter | Levels | Weight |
|---|---|---|
| Flopfin | 8-10 | 3 |
| Aquafin | 8-10 | 2 |
| Pipwing | 8-10 | 2 |
| Hivelet | 8-10 | 2 |
| Cocovex | 8-10 | 2 |
| Zapling | 9-10 | 1 |
| Dustpup | 9-10 | 1 |

**People**

| Who | Tile | Facing | Role |
|---|---|---|---|
| Sailor Finn | 8,9 | right | trainer: Aquafin Lv9, Pipwing Lv9 (sees 3 tiles) |
| Swimmer Lyra | 12,13 | left | trainer: Aquafin Lv10 (sees 2 tiles) |
| Fisher Odo | 9,16 | down | talks |

**Signs / things to read**

- (9,2) SALTWIND SHORE  -  Follow the shell path south to Tidewatch Harbor.
- (12,20) Mind the tide! The bridge is slippery at night.

```
##########,,##########
#bbbbbbbbb,,bR~~~~~~~#
#*R*bRbbbs,,bb~~~~~~~#
#bb;;;;;bb,,bb~~~~~~~#
#bb;;;;;bb,,bb~~~~~~~#
#bb;;;;;bb,,Rb~~~~~~~#
#bR;;;;;bb,,bb~~~~~~~#
#bb*bbbRbb,,Rb~~~~~~~#
#b;;;;bbbb,,*b~~~~~~~#
#b;;;;bbbb,,bf~~~~~~~#
#b;;;;bbbb,,bbbbbbbbb#
#bbb*bbRbb,,b;;;;;;bb#
#~~~~~~~~b,,b;;;;;;bb#
#~~~~~~~~b,,b;;;;;;bb#
#~~~~~~~~b,,P;;;;;;bb#
#~~~~~~~~b,,bbbbbbRbb#
#~~~~~~~~b,,bbbbbbbbb#
#~~~~~~~~~==~~~~~~~~~#
#~~~~~~~~~==~~~~~~~~~#
#~~~~~~~~~==~~~~~~~~~#
#~~~~~~~~~,,s~~~~~~~~#
##########,,##########
```

## 8. Tidewatch Harbor  (`tidewatch`, 26x16, shore)

![Tidewatch Harbor](docs/maps/tidewatch.png)

**Warps**

| Step on (x,y) | Goes to | Arrives at | Condition |
|---|---|---|---|
| 12,0 to 13,0 | Saltwind Shore | 10,20 |  |
| 25,8 to 25,9 | Ashen Trail | 1,6 |  |
| 20,4 | Tide Shrine | 5,10 |  |

**People**

| Who | Tile | Facing | Role |
|---|---|---|---|
| Guild Grunt | 20,5 | down | trainer: Hissle Lv10, Nibblet Lv10 (sees 3 tiles) |
| Dockhand Rusty | 6,6 | down | talks |
| Net-mender Sal | 9,6 | down | talks |
| Kit | 19,6 | left | talks |

**Signs / things to read**

- (10,7) TIDEWATCH HARBOR  -  Fresh catch daily! The Ashen Trail leads east.
- (15,7) TIDE SHRINE  -  Warden Marina welcomes all who respect the sea.

```
############,,############
#b*bbbbbbbbb,,bbbbbR*bbbb#
#bb^^^^^bbbb,,bbb^^^^^^^*#
#bbhhhhhRbbb,,bbbhhhhhhhb#
#bbhhhhhb*bb,,*bbhhhDhhhb#
#bbbb,bbbbbb,,bbbbRb,bbRb#
#bbbb,bbbbbb,,bbbbbb,bbbR#
#bbbb,bbbbsb,,bsbbb*,bbbb#
#,,,,,,,,,,,,,,,,,,,,,,,,,
#,,,,,,,,,,,,,,,,,,,,,,,,,
#bbbbbbbPbbbbRbbbbbbbbbbb#
#~~~===~~~===~~~~~===~~~~#
#~~~===~~~===~~~~~===~~~~#
#~~~===~~~===~~~~~===~~~~#
#~~~===~~~===~~~~~===~~~~#
##########################
```

## 9. Tide Shrine  (`tideshrine`, 12x12, indoor)

![Tide Shrine](docs/maps/tideshrine.png)

**Warps**

| Step on (x,y) | Goes to | Arrives at | Condition |
|---|---|---|---|
| 5,11 | Tidewatch Harbor | 20,5 |  |

**People**

| Who | Tile | Facing | Role |
|---|---|---|---|
| Diver Nerio | 3,7 | right | trainer: Aquafin Lv12 (sees 3 tiles) |
| Diver Coral | 8,4 | left | trainer: Aquafin Lv12, Tidalon Lv12 (sees 3 tiles) |
| Warden Marina | 6,2 | down | boss/trainer (smart AI): Aquafin Lv13, Tidalon Lv14 (sees 3 tiles) |

```
WWWWWWWWWWWW
W~~~~__~~~~W
W_~__rr__~_W
W~~~_rr_~~~W
W____rr____W
W_~__rr__~_W
W~~~_rr_~~~W
W____rr____W
W_~__rr__~_W
W~~~_rr_~~~W
W__________W
WWWWWDWWWWWW
```

## 10. Ashen Trail  (`route3`, 30x14, ash)

![Ashen Trail](docs/maps/route3.png)

**Warps**

| Step on (x,y) | Goes to | Arrives at | Condition |
|---|---|---|---|
| 0,6 to 0,7 | Tidewatch Harbor | 24,8 |  |
| 29,6 to 29,7 | Cinderpeak | 1,8 |  |

**Wild critters** (14% per step in tall grass)

| Critter | Levels | Weight |
|---|---|---|
| Cinderfoal | 12-14 | 3 |
| Pebblit | 12-14 | 3 |
| Dustpup | 12-14 | 2 |
| Hissle | 12-14 | 2 |
| Scrappit | 12-14 | 2 |
| Swoopwing | 13-15 | 1 |
| Blazehorn | 13-15 | 1 |

**People**

| Who | Tile | Facing | Role |
|---|---|---|---|
| Hiker Brock | 11,5 | down | trainer: Pebblit Lv13, Blazehorn Lv13 (sees 2 tiles) |
| Hotshot Rye | 21,8 | up | trainer: Cinderfoal Lv14 (sees 2 tiles) |
| Guild Grunt Vik | 25,5 | down | trainer: Hissle Lv14, Wispet Lv14 (sees 2 tiles) |
| Ranger Ash | 16,5 | down | talks |

**Signs / things to read**

- (3,5) ASHEN TRAIL  -  Cinderpeak lies to the east. Keep clear of the lava!

```
##############################
#.....LLLLLL....R....LLLL.R..#
#.R...LLLLLL.;;;;;;..LLLL...R#
#...R.LLLLLL.;;;;;;..LLLL..R.#
#.....LLLLLL.;;;;;;..........#
#..s...........P.............#
,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
#...R..........R..R......R...#
#RLLLLL.;;;;;;R.LLLLLLLL.;;;;#
#.LLLLL.;;;;;;..LLLLLLLL.;;;;#
#RLLLLL.;;;;;;.RLLLLLLLL.;;;;#
#...............LLLLLLLLR..R.#
##############################
```

## 11. Cinderpeak  (`cinder`, 26x16, ash)

![Cinderpeak](docs/maps/cinder.png)

**Warps**

| Step on (x,y) | Goes to | Arrives at | Condition |
|---|---|---|---|
| 0,8 to 0,9 | Ashen Trail | 28,6 |  |
| 9,3 | Ember Shrine | 5,10 |  |
| 12,0 to 13,0 | Gloam Pass | 10,20 | The road to Gloam Pass is sealed by an old Warden barrier. Only someon |

**People**

| Who | Tile | Facing | Role |
|---|---|---|---|
| Guild Grunt | 9,4 | down | trainer: Hissle Lv16, Wispet Lv16 (sees 3 tiles) |
| Smith Forge | 4,6 | down | talks |
| Cook Spice | 20,6 | down | talks |

**Signs / things to read**

- (10,7) CINDERPEAK  -  Forged in fire, tempered by trust. Ember Shrine: north.

```
############,,############
#.......^^^R,,.........R.#
#.......hhh.,,.........R.#
#..^^^^^hDhR,,..R^^^^^^..#
#..hhhhh.,..,,...hhhhhh..#
#..hhhhh.,.R,,...hhhhhh..#
#....,...,..,,..R..,.....#
#....,...,s.,,.P...,.....#
,,,,,,,,,,,,,,,,,,,,,,,,,#
,,,,,,,,,,,,,,,,,,,,,,,,,#
#........^^^^^^^.........#
#........hhhhhhh..LLLLLLL#
#LLLLLLL.hhhhhhh..LLLLLLL#
#LLLLLLL...R......LLLLLLL#
#LLLLLLL..........LLLLLLL#
##########################
```

## 12. Ember Shrine  (`embershrine`, 12x12, indoor)

![Ember Shrine](docs/maps/embershrine.png)

**Warps**

| Step on (x,y) | Goes to | Arrives at | Condition |
|---|---|---|---|
| 5,11 | Cinderpeak | 9,4 |  |

**People**

| Who | Tile | Facing | Role |
|---|---|---|---|
| Torchbearer Ash | 3,7 | right | trainer: Cinderfoal Lv16 (sees 3 tiles) |
| Torchbearer Flint | 8,4 | left | trainer: Cinderfoal Lv16, Blazehorn Lv16 (sees 3 tiles) |
| Warden Cinder | 6,2 | down | boss/trainer (smart AI): Cinderfoal Lv17, Blazehorn Lv18 (sees 3 tiles) |

```
WWWWWWWWWWWW
W__________W
W_L__rr__L_W
W____rr____W
W____rr____W
W_L__rr__L_W
W____rr____W
W____rr____W
W_L__rr__L_W
W____rr____W
W__________W
WWWWWDWWWWWW
```

## 13. Gloam Pass  (`route4`, 22x22, keep)

![Gloam Pass](docs/maps/route4.png)

**Warps**

| Step on (x,y) | Goes to | Arrives at | Condition |
|---|---|---|---|
| 10,21 to 11,21 | Cinderpeak | 12,1 |  |
| 9,1 to 12,1 | Hollow Keep | 8,22 | all 3 Sigils (cut-scene) |

**Wild critters** (14% per step in tall grass)

| Critter | Levels | Weight |
|---|---|---|
| Gnawfang | 16-18 | 3 |
| Swoopwing | 16-18 | 2 |
| Wispet | 16-18 | 2 |
| Mindle | 16-18 | 2 |
| Frostkit | 16-18 | 2 |
| Zapling | 16-18 | 2 |
| Stingmaw | 16-18 | 2 |
| Glimmerwing | 16-18 | 1 |
| Fluffnap | 17-18 | 1 |

**People**

| Who | Tile | Facing | Role |
|---|---|---|---|
| Kit | 10,12 | down | talks |
| Guild Grunt | 13,8 | left | trainer: Bloomfang Lv18 (sees 3 tiles) |
| Guild Grunt | 8,6 | right | trainer: Coilfang Lv18, Wispet Lv18 (sees 3 tiles) |
| Baron Gloam | 11,1 | down | talks |

**Signs / things to read**

- (9,20) GLOAM PASS  -  Beyond the Shrine Gate lies the Hollow Keep. Only bearers of all three Sigils may enter.

```
######################
#........GGGGR.c.R..R#
#.........,,.....R...#
#.........,,.........#
#..R....R.,,...R.....#
#.;;;;;R.R,,.c.R....R#
#.;;;;;...,,R........#
#.;;;;;...,,R.......R#
#R;;;;;...,,.........#
#R.....R..,,...;;;;;.#
#.........,,c..;;;;;.#
#.........,,...;;;;;.#
#.R...c...,,...;;;;;.#
#.........,,.........#
#..;;;;;..,,.........#
#..;;;;;..,,.........#
#..;;;;;..,,..R......#
#..;;;;;..,,P........#
#.........,,.........#
#.........,,.R.......#
#..c.....s,,......c..#
##########,,##########
```

## 14. Hollow Keep  (`keep`, 20x24, keep)

![Hollow Keep](docs/maps/keep.png)

**Warps**

| Step on (x,y) | Goes to | Arrives at | Condition |
|---|---|---|---|
| 9,23 to 10,23 | Gloam Pass | 10,3 |  |
| 9,0 | Heart Chamber | 6,10 |  |

**People**

| Who | Tile | Facing | Role |
|---|---|---|---|
| Guild Grunt | 5,18 | right | trainer: Coilfang Lv19 (sees 5 tiles) |
| Guild Grunt | 14,14 | left | trainer: Bloomfang Lv19, Wispet Lv19 (sees 5 tiles) |
| Guild Grunt | 6,10 | right | trainer: Stingmaw Lv20 (sees 4 tiles) |
| Guild Grunt | 13,5 | left | trainer: Coilfang Lv20, Mindle Lv20 (sees 4 tiles) |
| Lieutenant Vex | 9,1 | down | boss/trainer (smart AI): Bloomfang Lv23, Coilfang Lv23 (sees 4 tiles) |

```
WWWWWWWWWDWWWWWWWWWW
W________rr________W
W________rr________W
W________rr________W
W____c___rr___c____W
W________rr________W
W________rr________W
W________rr________W
WWWWWW___rr___WWWWWW
W________rr________W
W__P_____rr_____c__W
W________rr________W
W____c___rr___c____W
WWWWWWW__rr__WWWWWWW
W________rr________W
W________rr________W
W____c___rr___c____W
W________rr________W
W________rr________W
W________rr________W
W____c___rr___c____W
W_______rrrr_______W
W_______rrrr_______W
WWWWWWWWWDDWWWWWWWWW
```

## 15. Heart Chamber  (`heart`, 14x12, keep)

![Heart Chamber](docs/maps/heart.png)

**Warps**

| Step on (x,y) | Goes to | Arrives at | Condition |
|---|---|---|---|
| 6,11 | Hollow Keep | 9,1 |  |

**People**

| Who | Tile | Facing | Role |
|---|---|---|---|
| Baron Gloam | 6,4 | down | boss/trainer (smart AI): Blazehorn Lv27, Tidalon Lv27, Thornpaw Lv28 (sees 5 tiles) |
| Warden Willow | 4,9 | right | talks |
| Warden Marina | 9,9 | left | talks |
| Warden Cinder | 4,7 | right | talks |
| Prof. Fern | 9,7 | left | talks |
| Kit | 8,10 | up | talks |

```
WWWWWWWWWWWWWW
W_____QQ_____W
W_____rr_____W
W_c___rr___c_W
W_____rr_____W
W_____rr_____W
W_c___rr___c_W
W_____rr_____W
W_____rr_____W
W_c__rrrr__c_W
W____________W
WWWWWWDWWWWWWW
```

