package com.example.critterquest

import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import kotlin.math.*

// ---- speed settings for weak TVs (see README, "Performance") ----
/** Drawing heights tried in order. The game is drawn at most this tall and scaled up to the screen; a slow device steps down. */
private val RENDER_HEIGHTS = intArrayOf(540, 360)
/** Redraw at most every FRAME_MS (about 30 fps). Movement and animation use the clock, so this only saves work. */
private const val FRAME_MS = 33L
/** Frames slower than SLOW_MS, SLOW_FRAMES in a row, make the game step down to the next RENDER_HEIGHTS entry. */
private const val SLOW_MS = 50L
private const val SLOW_FRAMES = 150

/**
 * Draws the game and turns remote / gamepad / touch input into actions.
 * Game rules live in Game.kt and Battle.kt, the world in Maps.kt, the story in Story.kt and Cast.kt.
 */
class GameView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.DEFAULT_BOLD }
    private val path = Path()
    private val bmps = HashMap<Int, Bitmap?>()
    private val spritePaint = Paint().apply { isAntiAlias = false; isFilterBitmap = false; isDither = false }
    private val srcR = Rect()
    private val dstR = RectF()
    private val art = Art(p)
    private val show = DEX.map { Mon(it, 5) }
    private val prefs = ctx.getSharedPreferences("critterquest", Context.MODE_PRIVATE)
    private var bgs: Map<Theme, Shader> = emptyMap()
    private var nightBg: Shader? = null

    // Everything is drawn into a small bitmap (lw x lh, "logical" pixels) and that is scaled to the screen in one go.
    // All draw code and all touch boxes work in logical pixels. Two bitmaps take turns so one is never drawn while it is shown.
    private var tier = prefs.getInt("render_tier", 0).coerceIn(0, RENDER_HEIGHTS.size - 1)
    private var viewW = 0; private var viewH = 0
    private var lw = 0; private var lh = 0
    private val frames = arrayOfNulls<Bitmap>(2)
    private val frameCanvases = arrayOfNulls<Canvas>(2)
    private var flip = 0
    private val blitPaint = Paint().apply { isAntiAlias = false; isDither = false }
    private val blitDst = Rect()
    private var lastFrameAt = 0L; private var slowRun = 0

    // The map is drawn once into `layer`; only animated ("live") tiles are redrawn each frame (see Art.isLive).
    private var layer: Bitmap? = null
    private var layerMap: GameMap? = null
    private var layerTs = 0
    private var liveX = IntArray(0); private var liveY = IntArray(0); private var liveGrass = BooleanArray(0); private var liveN = 0
    private val grassPics = arrayOfNulls<Bitmap>(Theme.values().size * 3 * GRASS_STEPS)
    private var grassTs = 0
    private var bgBmp: Bitmap? = null; private var bgCan: Canvas? = null; private var bgKey: Shader? = null
    private val seen = ArrayList<Npc>()
    private var lastBattleTick = 0L

    private val TITLE = 0; private val WORLD = 1; private val BATTLE = 2; private val CREDITS = 3
    private var scene = TITLE
    private var game = Game()
    private var battle: Battle? = null
    private var hasSave = prefs.contains("save")
    private var titleSel = 0
    private var held = -1
    private var lastMapId = ""
    private var fadeAt = 0L
    private var flashAt = 0L
    private var battleLast = 0L
    private var pauseSel = -1
    private var journal = false
    private var toast = ""; private var toastAt = 0L
    private var touchMode = false
    private var padPointer = -1; private var padDir = -1
    private var creditsT0 = 0L
    private val boxes = ArrayList<Pair<RectF, () -> Unit>>()

    // dialogue box state
    private var dlgFor: Step? = null
    private var dlgPages: List<List<String>> = emptyList()
    private var dlgPage = 0
    private var dlgT0 = 0L
    private var askSel = 0

    init { isFocusable = true; isFocusableInTouchMode = true; requestFocus() }

    private fun now() = SystemClock.uptimeMillis()

    private fun fresh(): Game = Game().also { g -> g.saveHook = { s -> prefs.edit().putString("save", s).apply(); hasSave = true } }

    // =============================================================================================
    //  update
    // =============================================================================================
    private fun update() {
        val t = now()
        when (scene) {
            WORLD -> updateWorld(t)
            BATTLE -> updateBattle(t)
        }
    }

    private fun updateWorld(t: Long) {
        game.tick(t)
        if (game.cur != null) held = -1
        if (game.cur !== dlgFor) buildDialogue(game.cur, t)
        if (game.battleReq != null) { startBattle(t); return }
        if (game.map.id != lastMapId) { lastMapId = game.map.id; fadeAt = t }
        if (game.endingPending && game.scriptDone) { startCredits(t); return }
        if (held >= 0 && pauseSel < 0 && !journal) game.step(held, t)
    }

    private fun startBattle(t: Long) {
        val req = game.battleReq ?: return
        val team = if (req.trainer != null) req.trainer.team(game).map { Mon(DEX[it.first], it.second) } else listOf(req.wild!!)
        (game.party + team).forEach { it.shown = it.hp.toFloat(); bmp(it.s.front); bmp(it.s.back) } // load sprites now, not mid-fight
        lastBattleTick = t
        battle = Battle(game.party, team, req.trainer, game.heals, game.orbs, { now() })
        scene = BATTLE; battleLast = t; flashAt = t; held = -1
    }

    private fun updateBattle(t: Long) {
        val b = battle ?: return
        val dt = (t - lastBattleTick).coerceIn(1L, 100L); lastBattleTick = t
        val k = 1f - 0.92f.pow(dt / 16.667f) // 0.08 per frame at 60 fps, the same speed at any frame rate
        for (m in b.party) m.shown += (m.hp - m.shown) * k
        for (m in b.team) m.shown += (m.hp - m.shown) * k
        if (b.over != 0) { if (t - battleLast >= 1000) endBattle(t, b); return }
        if (b.menuOn || t - battleLast < 1000) return
        b.pump(); battleLast = t
    }

    private fun endBattle(t: Long, b: Battle) {
        game.heals = b.heals; game.orbs = b.orbs
        battle = null; scene = WORLD; held = -1; fadeAt = t
        game.battleDone(b.over, b.caught)
    }

    private fun startCredits(t: Long) { scene = CREDITS; creditsT0 = t; held = -1 }

    // =============================================================================================
    //  input
    // =============================================================================================
    private fun mapKey(k: Int): Int = when (k) {
        KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_S -> DOWN
        KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_A -> LEFT
        KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_D -> RIGHT
        KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_W -> UP
        KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER, KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_SPACE -> 4
        KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_BUTTON_B, KeyEvent.KEYCODE_ESCAPE, KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_BUTTON_START -> 5
        else -> -1
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        val a = mapKey(keyCode)
        if (a < 0 || (a == 5 && scene == TITLE)) return super.onKeyDown(keyCode, event)
        if ((event?.repeatCount ?: 0) == 0) onAction(a)
        return true
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        val a = mapKey(keyCode)
        if (a < 0 || (a == 5 && scene == TITLE)) return super.onKeyUp(keyCode, event)
        if (a == held) held = -1
        return true
    }

    /** 0 down, 1 left, 2 right, 3 up, 4 OK, 5 back / menu */
    private fun onAction(a: Int) {
        when (scene) {
            TITLE -> titleInput(a)
            WORLD -> worldInput(a)
            BATTLE -> battleInput(a)
            CREDITS -> if (a == 4 && now() - creditsT0 > creditsLength()) finishCredits()
        }
    }

    private fun titleInput(a: Int) {
        val n = if (hasSave) 2 else 1
        when (a) { UP -> titleSel = (titleSel + n - 1) % n; DOWN -> titleSel = (titleSel + 1) % n; 4 -> titleOk() }
    }

    private fun titleOk() {
        val item = if (hasSave && titleSel == 0) "Continue" else "New Game"
        val g = fresh(); g.clock = now()
        if (item == "Continue") {
            if (!g.load(prefs.getString("save", "") ?: "")) { hasSave = false; titleSel = 0; return }
        } else g.newGame()
        game = g; enterWorld()
    }

    private fun enterWorld() {
        scene = WORLD; held = -1; battle = null; pauseSel = -1; journal = false; dlgFor = null
        lastMapId = ""; fadeAt = now()
    }

    private fun worldInput(a: Int) {
        if (journal) { if (a == 4 || a == 5) journal = false; return }
        if (pauseSel >= 0) {
            when (a) { UP -> pauseSel = (pauseSel + 3) % 4; DOWN -> pauseSel = (pauseSel + 1) % 4; 4 -> pauseOk(); 5 -> pauseSel = -1 }
            return
        }
        val cur = game.cur
        if (cur != null) { dialogueInput(a, cur); return }
        when (a) {
            in 0..3 -> held = a
            4 -> game.interact(now())
            5 -> if (game.idle(now())) pauseSel = 0
        }
    }

    private fun pauseOk() {
        when (pauseSel) {
            0 -> pauseSel = -1
            1 -> { pauseSel = -1; journal = true }
            2 -> { game.save(); toast = "Journey saved!"; toastAt = now(); pauseSel = -1 }
            3 -> { game.save(); scene = TITLE; titleSel = 0; pauseSel = -1; hasSave = prefs.contains("save") }
        }
    }

    private fun dialogueInput(a: Int, cur: Step) {
        if (dlgPages.isEmpty()) return
        val page = dlgPages[dlgPage]
        val full = ((now() - dlgT0) / 22).toInt() >= page.sumOf { it.length }
        val last = dlgPage >= dlgPages.size - 1
        when (a) {
            4 -> if (!full) dlgT0 = now() - 100000
            else if (!last) { dlgPage++; dlgT0 = now() }
            else if (cur is Step.Ask) game.advance(askSel) else game.advance()
            UP, DOWN -> if (cur is Step.Ask && last && full) askSel = (askSel + (if (a == DOWN) 1 else cur.opts.size - 1)) % cur.opts.size
        }
    }

    private fun buildDialogue(cur: Step?, t: Long) {
        dlgFor = cur; dlgPage = 0; dlgT0 = t; askSel = 0; dlgPages = emptyList()
        val text = when (cur) { is Step.Say -> cur.text; is Step.Ask -> cur.text; else -> return }
        if (lw == 0) return
        p.typeface = Typeface.DEFAULT_BOLD; p.textSize = lh * 0.046f
        dlgPages = wrap(text, lw * 0.94f * 0.9f).chunked(3)
    }

    private fun wrap(s: String, maxW: Float): List<String> {
        val lines = ArrayList<String>(); var cur = ""
        for (w in s.split(' ')) {
            val t = if (cur.isEmpty()) w else "$cur $w"
            if (p.measureText(t) <= maxW || cur.isEmpty()) cur = t else { lines.add(cur); cur = w }
        }
        if (cur.isNotEmpty()) lines.add(cur)
        return lines
    }

    private fun battleInput(a: Int) {
        val b = battle ?: return
        if (b.learnFor != null) { // "forget a move?" prompt: 0..3 = the old moves, 4 = keep them all
            when (a) {
                UP -> b.learnSel = (b.learnSel + 4) % 5
                DOWN -> b.learnSel = (b.learnSel + 1) % 5
                4 -> { b.answerLearn(b.learnSel); battleLast = 0 }
                5 -> { b.answerLearn(-1); battleLast = 0 }
            }
            return
        }
        if (b.fighting && !b.swapping) { // the move list (2 x 2)
            val n = b.me.moves.size
            when (a) {
                UP -> if (b.moveSel >= 2) b.moveSel -= 2
                DOWN -> if (b.moveSel + 2 < n) b.moveSel += 2
                LEFT -> if (b.moveSel % 2 == 1) b.moveSel--
                RIGHT -> if (b.moveSel % 2 == 0 && b.moveSel + 1 < n) b.moveSel++
                4 -> if (b.me.moves[b.moveSel].pp > 0) b.fightWith(b.moveSel)
                5 -> b.closeFight()
            }
            return
        }
        if (b.swapping) {
            when (a) {
                UP -> moveSwap(b, -1); DOWN -> moveSwap(b, 1)
                4 -> b.swap(b.swapSel); 5 -> b.closeSwap()
            }
            return
        }
        if (!b.menuOn) { if (a == 4) battleLast = 0; return }
        val n = b.items
        when (a) {
            UP -> b.menu = if (b.menu >= 2) b.menu - 2 else b.menu + 2 * ((n - 1 - b.menu) / 2)
            DOWN -> b.menu = if (b.menu + 2 < n) b.menu + 2 else b.menu % 2
            LEFT, RIGHT -> if ((b.menu xor 1) < n) b.menu = b.menu xor 1
            4 -> chooseMenu(b, b.menu)
        }
    }

    private fun chooseMenu(b: Battle, i: Int) {
        if (!b.menuEnabled(i)) return
        b.menu = i; b.use(i)
    }

    private fun moveSwap(b: Battle, dir: Int) {
        var s = b.swapSel; var n = 0
        do { s = (s + dir + b.party.size) % b.party.size; n++ } while ((b.party[s].hp <= 0 || s == b.cur) && n < 12)
        if (b.party[s].hp > 0 && s != b.cur) b.swapSel = s
    }

    private fun finishCredits() { game.finishGame(); enterWorld() }

    // ---- touch: menus register tap boxes while drawing; an on-screen pad appears while walking ----
    private fun hit(x: Float, y: Float, w: Float, h: Float, a: () -> Unit) { boxes.add(RectF(x, y, x + w, y + h) to a) }

    private fun padCenterX() = lw * 0.13f
    private fun padCenterY() = lh * 0.76f
    private fun padRadius() = lh * 0.17f
    private fun inCircle(x: Float, y: Float, cx: Float, cy: Float, r: Float) = (x - cx) * (x - cx) + (y - cy) * (y - cy) <= r * r
    private fun padDirAt(x: Float, y: Float): Int {
        val dx = x - padCenterX(); val dy = y - padCenterY(); val r = padRadius()
        if (dx * dx + dy * dy > r * r * 1.5f || dx * dx + dy * dy < r * r * 0.05f) return -1
        return if (abs(dx) > abs(dy)) (if (dx < 0) LEFT else RIGHT) else (if (dy < 0) UP else DOWN)
    }
    private fun touchPadVisible() = touchMode && scene == WORLD && game.cur == null && pauseSel < 0 && !journal

    private fun lx(v: Float) = if (viewW > 0) v * lw / viewW else v
    private fun ly(v: Float) = if (viewH > 0) v * lh / viewH else v

    override fun onTouchEvent(e: MotionEvent): Boolean {
        touchMode = true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex; val x = lx(e.getX(i)); val y = ly(e.getY(i))
                for (k in boxes.indices.reversed()) if (boxes[k].first.contains(x, y)) { boxes[k].second(); return true }
                if (touchPadVisible()) {
                    val d = padDirAt(x, y)
                    if (d >= 0) { padPointer = e.getPointerId(i); padDir = d; onAction(d); return true }
                    if (inCircle(x, y, lw * 0.9f, lh * 0.78f, lh * 0.1f)) { onAction(4); return true }
                    if (inCircle(x, y, lw * 0.78f, lh * 0.88f, lh * 0.075f)) { onAction(5); return true }
                    return true
                }
                if (scene == TITLE) { return true }
                onAction(4)
            }
            MotionEvent.ACTION_MOVE -> if (padPointer >= 0) {
                val i = e.findPointerIndex(padPointer)
                if (i >= 0) { val d = padDirAt(lx(e.getX(i)), ly(e.getY(i))); if (d != padDir) { padDir = d; held = d } }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                if (padPointer >= 0 && (e.actionMasked == MotionEvent.ACTION_CANCEL || e.getPointerId(e.actionIndex) == padPointer)) { padPointer = -1; padDir = -1; held = -1 }
            }
        }
        return true
    }

    // =============================================================================================
    //  drawing helpers (sprites and panels from the original game)
    // =============================================================================================
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { viewW = w; viewH = h; setupFrame() }

    /** (Re)creates the small drawing bitmaps, gradients and caches for the current screen size and speed tier. */
    private fun setupFrame() {
        if (viewW <= 0 || viewH <= 0) return
        lh = min(viewH, RENDER_HEIGHTS[tier]); lw = max(1, (viewW * lh / viewH.toFloat()).roundToInt())
        for (i in 0..1) {
            val b = Bitmap.createBitmap(lw, lh, Bitmap.Config.ARGB_8888); b.setHasAlpha(false) // every scene paints a full opaque background first
            frames[i] = b; frameCanvases[i] = Canvas(b)
        }
        bgBmp = Bitmap.createBitmap(lw, lh, Bitmap.Config.ARGB_8888).also { it.setHasAlpha(false); bgCan = Canvas(it) }; bgKey = null
        blitDst.set(0, 0, viewW, viewH)
        blitPaint.isFilterBitmap = viewH % lh != 0 // whole-number zoom (540 -> 1080, 4K) stays sharp; otherwise smooth it
        layer?.recycle(); layer = null; layerMap = null
        grassPics.fill(null); grassTs = 0
        dlgPages = emptyList() // text is wrapped for the old size: rebuild
        fun g(a: Int, b: Int) = LinearGradient(0f, 0f, 0f, lh.toFloat(), a, b, Shader.TileMode.CLAMP)
        bgs = mapOf(
            Theme.MEADOW to g(Color.rgb(135, 206, 235), Color.rgb(200, 235, 160)),
            Theme.FOREST to g(Color.rgb(120, 180, 150), Color.rgb(110, 170, 90)),
            Theme.SHORE to g(Color.rgb(135, 206, 235), Color.rgb(236, 224, 190)),
            Theme.ASH to g(Color.rgb(170, 120, 104), Color.rgb(110, 98, 100)),
            Theme.KEEP to g(Color.rgb(80, 56, 124), Color.rgb(44, 36, 70)),
            Theme.INDOOR to g(Color.rgb(228, 198, 152), Color.rgb(176, 132, 90))
        )
        nightBg = g(Color.rgb(14, 12, 40), Color.rgb(60, 40, 90))
    }

    /** A full-screen gradient. It is painted into a bitmap once and copied afterwards (a shader costs a lot per pixel on weak CPUs). */
    private fun backdrop(c: Canvas, sh: Shader?, w: Float, h: Float) {
        val bb = bgBmp; val bc = bgCan
        if (sh == null || bb == null || bc == null) { c.drawColor(Color.BLACK); return }
        if (bgKey !== sh) { p.style = Paint.Style.FILL; p.shader = sh; bc.drawRect(0f, 0f, w, h, p); p.shader = null; bgKey = sh }
        c.drawBitmap(bb, 0f, 0f, null)
    }

    /** The still part of map [m] drawn once at tile size [ts]; null if memory ran out (the caller then draws every tile each frame). */
    private fun mapLayer(m: GameMap, ts: Int): Bitmap? {
        if (layerMap === m && layerTs == ts) return layer
        layer?.recycle(); layer = null; layerMap = m; layerTs = ts; liveN = 0
        try {
            val bm = Bitmap.createBitmap(m.w * ts, m.h * ts, Bitmap.Config.ARGB_8888); bm.setHasAlpha(false)
            val lc = Canvas(bm); val tsf = ts.toFloat()
            val xs = IntArray(m.w * m.h); val ys = IntArray(m.w * m.h); val gs = BooleanArray(m.w * m.h)
            var n = 0; var grass = false
            for (y in 0 until m.h) for (x in 0 until m.w) {
                art.drawStill(lc, game, m, x, y, x * tsf, y * tsf, tsf)
                val tl = m.tile(x, y)
                if (art.isLive(tl)) { xs[n] = x; ys[n] = y; gs[n] = tl == Tl.TALL; if (tl == Tl.TALL) grass = true; n++ }
            }
            if (grass) for (hv in 0..2) for (st in 0 until GRASS_STEPS) grassPic(m.theme, hv, st, ts)
            liveX = xs; liveY = ys; liveGrass = gs; liveN = n; layer = bm
        } catch (e: OutOfMemoryError) { layer = null; liveN = 0 }
        return layer
    }

    /** One pre-drawn picture of swaying tall grass (theme x blade pattern x sway step). */
    private fun grassPic(th: Theme, hv: Int, step: Int, ts: Int): Bitmap {
        if (grassTs != ts) { grassPics.fill(null); grassTs = ts }
        val i = (th.ordinal * 3 + hv) * GRASS_STEPS + step
        var b = grassPics[i]
        if (b == null) {
            b = Bitmap.createBitmap(ts, ts, Bitmap.Config.ARGB_8888); b.setHasAlpha(false)
            art.tallGrass(Canvas(b), th, hv, (step + 0.5f) * 6.2831855f / GRASS_STEPS, 0f, 0f, ts.toFloat())
            grassPics[i] = b
        }
        return b
    }

    /** If the game keeps running slower than about 20 fps, draw smaller (and remember that for the next start). */
    private fun watchSpeed(t0: Long) {
        val dt = t0 - lastFrameAt; lastFrameAt = t0
        if ((scene != WORLD && scene != BATTLE) || dt <= SLOW_MS || dt > 400) { slowRun = 0; return }
        if (++slowRun >= SLOW_FRAMES && tier < RENDER_HEIGHTS.size - 1) {
            slowRun = 0; tier++; prefs.edit().putInt("render_tier", tier).apply(); setupFrame()
        }
    }

    private fun txt(c: Canvas, s: String, x: Float, y: Float, size: Float, col: Int = Color.rgb(30, 40, 80), al: Paint.Align = Paint.Align.CENTER) {
        p.style = Paint.Style.FILL; p.typeface = Typeface.DEFAULT_BOLD
        p.textSize = size; p.color = col; p.textAlign = al; c.drawText(s, x, y, p)
    }

    private fun tri(c: Canvas, a: Float, b: Float, d: Float, e: Float, f: Float, g: Float) {
        path.reset(); path.moveTo(a, b); path.lineTo(d, e); path.lineTo(f, g); path.close(); c.drawPath(path, p)
    }

    private fun bmp(id: Int): Bitmap? {
        if (!bmps.containsKey(id)) {
            bmps[id] = try {
                BitmapFactory.decodeResource(resources, id, BitmapFactory.Options().apply { inScaled = false })
            } catch (e: Exception) { null }
        }
        return bmps[id]
    }

    // Pixel-art sprite (64x64). Own critter is seen from behind, wild critters and menus show the front.
    private fun creature(c: Canvas, m: Mon, cx: Float, gy: Float, r0: Float, dir: Int, lunge: Long, hurt: Long, t: Float, back: Boolean = false) {
        val b = bmp(if (back) m.s.back else m.s.front)
        if (b == null) { creatureProcedural(c, m, cx, gy, r0, dir, lunge, hurt, t); return }
        val n = now()
        if (n - hurt < 400 && (n / 60) % 2L == 0L) return
        val r = r0 * m.s.scale
        val ld = n - lunge
        val x = cx + if (ld < 350) sin(ld / 350f * PI.toFloat()) * r * dir else 0f
        val bob = sin(t * 3f) * r * 0.03f
        val sc = r * 2.9f / 64f
        val px = if (sc >= 1f) max(1, sc.roundToInt()).toFloat() else sc // whole-pixel scale keeps the pixel art crisp (small icons may shrink)
        val size = 64f * px
        val left = (x - size / 2f).roundToInt().toFloat()
        val top = (gy + r * 0.1f + bob - size * 62f / 64f).roundToInt().toFloat()
        srcR.set(0, 0, b.width, b.height)
        dstR.set(left, top, left + size, top + size)
        c.drawBitmap(b, srcR, dstR, spritePaint)
    }

    // Fallback "model" built from shapes, used only if a sprite fails to load.
    private fun creatureProcedural(c: Canvas, m: Mon, cx: Float, gy: Float, r0: Float, dir: Int, lunge: Long, hurt: Long, t: Float) {
        val n = now()
        if (n - hurt < 400 && (n / 60) % 2L == 0L) return
        val r = r0 * m.s.scale
        val ld = n - lunge
        val x = cx + if (ld < 350) sin(ld / 350f * PI.toFloat()) * r * dir else 0f
        val y = gy - r * 0.8f + sin(t * 3f) * r * 0.03f
        val d = dir.toFloat()
        val body = m.s.body
        val dark = Color.rgb(Color.red(body) * 7 / 10, Color.green(body) * 7 / 10, Color.blue(body) * 7 / 10)
        p.style = Paint.Style.FILL
        // tail
        val tx = x - d * r
        if (m.s.type == T.FIRE) {
            p.color = Color.rgb(255, 170, 40)
            tri(c, x - d * r * 0.7f, y + r * 0.2f, tx - d * r * 0.2f, y - r * 0.9f, x - d * r * 0.4f, y - r * 0.3f)
        } else {
            p.color = if (m.s.type == T.WATER) Color.rgb(150, 210, 245) else Color.rgb(90, 190, 80)
            c.save(); c.rotate(-d * 35f, tx, y)
            c.drawOval(tx - r * 0.2f, y - r * 0.55f, tx + r * 0.2f, y + r * 0.55f, p); c.restore()
        }
        // body, belly, feet
        p.color = body; c.drawOval(x - r, y - r * 0.7f, x + r, y + r * 0.8f, p)
        p.color = Color.rgb(255, 236, 200); c.drawOval(x - r * 0.55f, y - r * 0.1f, x + r * 0.55f, y + r * 0.7f, p)
        p.color = dark
        c.drawOval(x - r * 0.7f, y + r * 0.55f, x - r * 0.15f, y + r * 0.9f, p)
        c.drawOval(x + r * 0.15f, y + r * 0.55f, x + r * 0.7f, y + r * 0.9f, p)
        // head crest by type
        val hx = x + d * r * 0.45f; val hy = y - r * 0.75f; val hr = r * 0.62f
        when (m.s.type) {
            T.FIRE -> {
                p.color = Color.rgb(255, 120, 30); tri(c, hx - hr * 0.4f, hy - hr * 0.7f, hx, hy - hr * 1.9f, hx + hr * 0.4f, hy - hr * 0.7f)
                p.color = Color.rgb(255, 220, 80); tri(c, hx - hr * 0.2f, hy - hr * 0.7f, hx, hy - hr * 1.4f, hx + hr * 0.2f, hy - hr * 0.7f)
            }
            T.WATER -> { p.color = Color.rgb(150, 210, 245); tri(c, hx - hr * 0.5f, hy - hr * 0.6f, hx - d * hr * 0.3f, hy - hr * 1.7f, hx + hr * 0.3f, hy - hr * 0.8f) }
            T.LEAF -> {
                p.color = Color.rgb(90, 190, 80)
                for (s in intArrayOf(-1, 1)) {
                    c.save(); c.rotate(s * 35f, hx, hy - hr * 0.9f)
                    c.drawOval(hx - hr * 0.15f, hy - hr * 1.8f, hx + hr * 0.15f, hy - hr * 0.9f, p); c.restore()
                }
            }
            else -> { p.color = m.s.type.col; tri(c, hx - hr * 0.4f, hy - hr * 0.7f, hx, hy - hr * 1.6f, hx + hr * 0.4f, hy - hr * 0.7f) }
        }
        if (m.s.scale > 1f) { // evolved forms get horns
            p.color = Color.rgb(250, 240, 210)
            for (s in intArrayOf(-1, 1)) tri(c, hx + s * hr * 0.35f, hy - hr * 0.7f, hx + s * hr * 0.75f, hy - hr * 1.5f, hx + s * hr * 0.8f, hy - hr * 0.5f)
        }
        p.color = body; c.drawCircle(hx, hy, hr, p)
        // face
        for (k in 0..1) {
            val ex = hx + d * hr * (0.55f - 0.55f * k); val ey = hy - hr * 0.1f
            p.color = Color.WHITE; c.drawCircle(ex, ey, hr * 0.26f, p)
            p.color = Color.BLACK; c.drawCircle(ex + d * hr * 0.08f, ey, hr * 0.13f, p)
        }
        p.color = Color.argb(160, 255, 120, 140); c.drawCircle(hx + d * hr * 0.1f, hy + hr * 0.4f, hr * 0.15f, p)
        p.color = dark; c.drawCircle(hx + d * hr * 0.9f, hy + hr * 0.15f, hr * 0.1f, p)
    }

    private fun panel(c: Canvas, m: Mon, x: Float, y: Float, w: Float, h: Float, showHp: Boolean) {
        p.style = Paint.Style.FILL
        p.color = Color.argb(225, 255, 250, 235); c.drawRoundRect(x, y, x + w, y + h, 24f, 24f, p)
        txt(c, "${m.s.name}  Lv${m.lvl}", x + w * 0.05f, y + h * 0.4f, h * 0.3f, Color.rgb(40, 40, 60), Paint.Align.LEFT)
        m.status?.let { chip(c, it.tag, it.col, x + w * 0.95f, y + h * 0.06f, h * 0.17f, true) }
        val f = (m.shown / m.maxHp).coerceIn(0f, 1f)
        p.color = Color.rgb(60, 60, 70); c.drawRoundRect(x + w * 0.05f, y + h * 0.55f, x + w * 0.95f, y + h * 0.75f, 12f, 12f, p)
        p.color = if (f > 0.5f) Color.rgb(70, 200, 90) else if (f > 0.2f) Color.rgb(240, 200, 50) else Color.rgb(230, 70, 60)
        c.drawRoundRect(x + w * 0.05f, y + h * 0.55f, x + w * (0.05f + 0.9f * f), y + h * 0.75f, 12f, 12f, p)
        var tx = x + w * 0.05f
        for (ty in m.s.types) tx += chip(c, ty.label, ty.col, tx, y + h * 0.79f, h * 0.17f) + w * 0.02f
        if (showHp) txt(c, "${m.hp}/${m.maxHp}", x + w * 0.95f, y + h * 0.95f, h * 0.2f, Color.rgb(40, 40, 60), Paint.Align.RIGHT)
    }

    /** A small coloured label (a type or a status); returns its width. [right] = x is the right edge. */
    private fun chip(c: Canvas, label: String, col: Int, x: Float, y: Float, fs: Float, right: Boolean = false): Float {
        p.textSize = fs; p.typeface = Typeface.DEFAULT_BOLD
        val tw = p.measureText(label) + fs * 0.9f
        val left = if (right) x - tw else x
        p.style = Paint.Style.FILL
        p.color = col; c.drawRoundRect(left, y, left + tw, y + fs * 1.25f, fs * 0.4f, fs * 0.4f, p)
        txt(c, label, left + tw / 2, y + fs * 0.98f, fs, Color.WHITE)
        return tw
    }

    private fun pips(c: Canvas, mons: List<Mon>, x: Float, y: Float, r: Float) {
        p.style = Paint.Style.FILL
        for ((i, m) in mons.withIndex()) { p.color = if (m.hp > 0) Color.rgb(250, 250, 240) else Color.argb(110, 30, 30, 40); c.drawCircle(x + i * r * 2.6f, y, r, p) }
    }

    // =============================================================================================
    //  onDraw
    // =============================================================================================
    override fun onDraw(canvas: Canvas) {
        val t0 = now()
        val fb = frames[flip]; val c = frameCanvases[flip]
        if (fb == null || c == null) { postInvalidateDelayed(FRAME_MS); return }
        flip = flip xor 1
        update()
        boxes.clear()
        val w = lw.toFloat(); val h = lh.toFloat(); val t = t0 / 1000f
        p.style = Paint.Style.FILL
        when (scene) {
            TITLE -> drawTitle(c, w, h, t)
            WORLD -> drawWorld(c, w, h, t)
            BATTLE -> drawBattle(c, w, h, t)
            CREDITS -> drawCredits(c, w, h, t)
        }
        canvas.drawBitmap(fb, null, blitDst, blitPaint)
        watchSpeed(t0)
        postInvalidateDelayed(max(1L, FRAME_MS - (now() - t0)))
    }

    private fun drawTitle(c: Canvas, w: Float, h: Float, t: Float) {
        backdrop(c, bgs[Theme.MEADOW], w, h)
        txt(c, "CRITTER QUEST", w / 2, h * 0.24f, h * 0.13f)
        txt(c, "The Silence of the Heart Bell", w / 2, h * 0.32f, h * 0.045f, Color.rgb(70, 80, 130))
        for (i in 0..2) creature(c, show[i], w * (0.25f + 0.25f * i), h * 0.64f, h * 0.1f, 1, 0, 0, t)
        val items = if (hasSave) listOf("Continue", "New Game") else listOf("New Game")
        for ((i, s) in items.withIndex()) {
            val y = h * (0.78f + 0.08f * i); val sel = i == titleSel
            if (sel) { p.color = Color.argb(150, 255, 255, 255); c.drawRoundRect(w * 0.36f, y - h * 0.055f, w * 0.64f, y + h * 0.02f, 24f, 24f, p) }
            txt(c, (if (sel) "> " else "") + s, w / 2, y, h * 0.055f, if (sel) Color.rgb(200, 70, 40) else Color.rgb(30, 40, 80))
            hit(w * 0.3f, y - h * 0.06f, w * 0.4f, h * 0.085f) { titleSel = i; titleOk() }
        }
        txt(c, "D-pad: move    OK: select / talk    BACK: menu", w / 2, h * 0.97f, h * 0.03f, Color.rgb(70, 80, 130))
    }

    // ---------------------------------------------------------------------------------------------
    private fun drawWorld(c: Canvas, w: Float, h: Float, t: Float) {
        val g = game; val m = g.map; val nowMs = now()
        val ts = floor(h / 9f)
        val prog = ((nowMs - g.moveT0) / MOVE_MS.toFloat()).coerceIn(0f, 1f)
        val fx = g.fromX + (g.px - g.fromX) * prog; val fy = g.fromY + (g.py - g.fromY) * prog
        val mw = m.w * ts; val mh = m.h * ts
        var camX = fx * ts + ts / 2 - w / 2; var camY = fy * ts + ts / 2 - h / 2
        camX = if (mw <= w) -(w - mw) / 2 else camX.coerceIn(0f, mw - w)
        camY = if (mh <= h) -(h - mh) / 2 else camY.coerceIn(0f, mh - h)
        camX = camX.roundToInt().toFloat(); camY = camY.roundToInt().toFloat()
        c.drawColor(Color.rgb(10, 10, 18))
        val x0 = max(0, floor(camX / ts).toInt()); val x1 = min(m.w - 1, ceil((camX + w) / ts).toInt())
        val y0 = max(0, floor(camY / ts).toInt()); val y1 = min(m.h - 1, ceil((camY + h) / ts).toInt())
        val ti = ts.toInt()
        val lyr = if (ti > 0) mapLayer(m, ti) else null
        if (lyr != null) { // fast path: copy the cached map, then redraw only the animated tiles that are on screen
            c.drawBitmap(lyr, -camX, -camY, null)
            for (k in 0 until liveN) {
                val lx = liveX[k]; val ly = liveY[k]
                if (lx < x0 || lx > x1 || ly < y0 || ly > y1) continue
                val ox = lx * ts - camX; val oy = ly * ts - camY
                if (liveGrass[k]) c.drawBitmap(grassPic(m.theme, art.grassVariant(lx, ly), art.grassStep(lx, t), ti), ox, oy, null)
                else art.drawLive(c, g, m, lx, ly, ox, oy, ts, t)
            }
        } else {
            for (y in y0..y1) for (x in x0..x1) art.tile(c, g, m, x, y, x * ts - camX, y * ts - camY, ts, t)
        }
        // people, drawn back to front
        seen.clear()
        for (n in g.npcs()) if (n.x in x0 - 1..x1 + 1 && n.y in y0 - 2..y1 + 1) {
            var i = seen.size; while (i > 0 && seen[i - 1].y > n.y) i--; seen.add(i, n) // insertion by row, keeps equal rows in order
        }
        val npcs = seen
        var playerDrawn = false
        fun drawPlayer() {
            art.person(c, PLAYER_LOOK, fx * ts - camX + ts / 2, fy * ts - camY + ts * 0.94f, ts, g.face, prog < 1f, prog, t)
            playerDrawn = true
        }
        for (n in npcs) {
            if (!playerDrawn && n.y > fy) drawPlayer()
            val cx = n.x * ts - camX + ts / 2; val by = n.y * ts - camY + ts * 0.94f
            art.person(c, n.look, cx, by, ts, g.npcFacing(n), false, 0f, t)
            if (g.alert === n) art.alert(c, cx, by, ts)
        }
        if (!playerDrawn) drawPlayer()
        // light dusk tint inside the Keep for mood
        if (m.theme == Theme.KEEP && m.id != "route4") { p.color = Color.argb(40, 40, 20, 80); c.drawRect(0f, 0f, w, h, p) }

        drawBanner(c, w, h, nowMs)
        if (nowMs - toastAt < 1800 && toast.isNotEmpty()) { p.color = Color.argb(200, 20, 20, 40); c.drawRoundRect(w * 0.03f, h * 0.9f, w * 0.03f + h * 0.4f, h * 0.97f, 20f, 20f, p); txt(c, toast, w * 0.03f + h * 0.2f, h * 0.947f, h * 0.04f, Color.WHITE) }
        game.cur?.let { drawDialogue(c, w, h, it, nowMs) }
        if (pauseSel >= 0) drawPause(c, w, h)
        if (journal) drawJournal(c, w, h)
        if (touchPadVisible()) drawTouch(c, w, h)
        val fa = 1f - (nowMs - fadeAt) / 450f
        if (fa > 0f) { p.color = Color.argb((fa * 255).toInt(), 0, 0, 0); c.drawRect(0f, 0f, w, h, p) }
    }

    private fun drawBanner(c: Canvas, w: Float, h: Float, nowMs: Long) {
        val age = nowMs - game.bannerAt
        if (age > 2600 || game.bannerName.isEmpty() || game.cur != null) return
        val a = if (age < 300) age / 300f else if (age > 2100) (2600 - age) / 500f else 1f
        p.textSize = h * 0.055f; p.typeface = Typeface.DEFAULT_BOLD
        val tw = p.measureText(game.bannerName) + h * 0.1f
        p.color = Color.argb((200 * a).toInt(), 20, 22, 46); c.drawRoundRect(w / 2 - tw / 2, h * 0.04f, w / 2 + tw / 2, h * 0.04f + h * 0.085f, 24f, 24f, p)
        txt(c, game.bannerName, w / 2, h * 0.04f + h * 0.06f, h * 0.055f, Color.argb((255 * a).toInt(), 255, 236, 170))
    }

    private fun drawDialogue(c: Canvas, w: Float, h: Float, cur: Step, nowMs: Long) {
        val who: String; val portrait: Int
        when (cur) { is Step.Say -> { who = cur.who; portrait = cur.portrait }; is Step.Ask -> { who = cur.who; portrait = cur.portrait }; else -> return }
        if (dlgPages.isEmpty()) { buildDialogue(cur, nowMs); if (dlgPages.isEmpty()) return }
        hit(0f, 0f, w, h) { dialogueInput(4, cur) } // any tap advances the text (registered first = lowest priority)
        val bx = w * 0.03f; val bw = w * 0.94f; val by = h * 0.72f; val bh = h * 0.25f
        val fs = h * 0.046f
        if (portrait in DEX.indices) {
            val px = w * 0.86f
            p.color = Color.argb(215, 255, 250, 235); c.drawRoundRect(px - h * 0.17f, by - h * 0.36f, px + h * 0.17f, by - h * 0.02f, 30f, 30f, p)
            creature(c, show[portrait], px, by - h * 0.07f, h * 0.08f, -1, 0, 0, nowMs / 1000f)
        }
        p.color = Color.argb(238, 28, 30, 58); c.drawRoundRect(bx, by, bx + bw, by + bh, 30f, 30f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 4f; p.color = Color.rgb(160, 170, 230); c.drawRoundRect(bx, by, bx + bw, by + bh, 30f, 30f, p); p.style = Paint.Style.FILL
        if (who.isNotEmpty()) {
            p.textSize = fs * 0.85f; val tw = p.measureText(who) + fs
            p.color = Color.rgb(250, 214, 100); c.drawRoundRect(bx + 24f, by - fs * 0.95f, bx + 24f + tw, by + fs * 0.3f, 18f, 18f, p)
            txt(c, who, bx + 24f + fs * 0.5f, by - fs * 0.05f, fs * 0.85f, Color.rgb(50, 36, 20), Paint.Align.LEFT)
        }
        val page = dlgPages[min(dlgPage, dlgPages.size - 1)]
        var shown = ((nowMs - dlgT0) / 22).toInt()
        val total = page.sumOf { it.length }
        for ((i, line) in page.withIndex()) {
            val n = min(line.length, max(0, shown)); shown -= line.length
            txt(c, line.substring(0, n), bx + bw * 0.05f, by + fs * 1.45f + i * fs * 1.3f, fs, Color.WHITE, Paint.Align.LEFT)
        }
        val full = ((nowMs - dlgT0) / 22).toInt() >= total
        val last = dlgPage >= dlgPages.size - 1
        if (full && !(last && cur is Step.Ask)) {
            val bob = sin(nowMs / 200f) * fs * 0.12f
            p.color = Color.rgb(250, 214, 100)
            tri(c, bx + bw - fs * 1.4f, by + bh - fs * 0.9f + bob, bx + bw - fs * 0.6f, by + bh - fs * 0.9f + bob, bx + bw - fs, by + bh - fs * 0.35f + bob)
        }
        if (cur is Step.Ask && last && full) {
            val rowH = fs * 1.5f; val ow = w * 0.3f; val oh = rowH * cur.opts.size + fs * 0.6f
            val ox = bx + bw - ow; val oy = by - oh - fs * 0.4f
            p.color = Color.argb(240, 28, 30, 58); c.drawRoundRect(ox, oy, ox + ow, oy + oh, 24f, 24f, p)
            for ((i, o) in cur.opts.withIndex()) {
                val ry = oy + fs * 0.3f + i * rowH
                if (i == askSel) { p.color = Color.argb(70, 250, 214, 100); c.drawRoundRect(ox + 10f, ry, ox + ow - 10f, ry + rowH, 16f, 16f, p) }
                txt(c, (if (i == askSel) "> " else "   ") + o, ox + fs * 0.5f, ry + rowH * 0.7f, fs * 0.9f, if (i == askSel) Color.rgb(250, 214, 100) else Color.WHITE, Paint.Align.LEFT)
                hit(ox, ry, ow, rowH) { askSel = i; game.advance(i) }
            }
        }
    }

    private fun drawPause(c: Canvas, w: Float, h: Float) {
        val items = listOf("Resume", "Journal", "Save", "Quit to Title")
        hit(0f, 0f, w, h) { pauseSel = -1 }
        val x = w * 0.04f; val y = h * 0.1f; val pw = w * 0.26f; val ph = h * 0.46f
        p.color = Color.argb(235, 28, 30, 58); c.drawRoundRect(x, y, x + pw, y + ph, 30f, 30f, p)
        for ((i, s) in items.withIndex()) {
            val ry = y + h * 0.1f + i * h * 0.1f; val sel = i == pauseSel
            if (sel) { p.color = Color.argb(70, 250, 214, 100); c.drawRoundRect(x + 12f, ry - h * 0.06f, x + pw - 12f, ry + h * 0.03f, 16f, 16f, p) }
            txt(c, (if (sel) "> " else "   ") + s, x + pw * 0.1f, ry, h * 0.05f, if (sel) Color.rgb(250, 214, 100) else Color.WHITE, Paint.Align.LEFT)
            hit(x, ry - h * 0.065f, pw, h * 0.095f) { pauseSel = i; pauseOk() }
        }
    }

    private fun drawJournal(c: Canvas, w: Float, h: Float) {
        p.color = Color.argb(245, 236, 224, 196); c.drawRoundRect(w * 0.05f, h * 0.05f, w * 0.95f, h * 0.95f, 36f, 36f, p)
        val ink = Color.rgb(60, 44, 30); val fs = h * 0.04f
        txt(c, "JOURNAL", w * 0.5f, h * 0.13f, h * 0.06f, ink)
        txt(c, game.chapter(), w * 0.09f, h * 0.2f, fs * 1.1f, Color.rgb(150, 60, 40), Paint.Align.LEFT)
        p.textSize = fs; p.typeface = Typeface.DEFAULT_BOLD
        val lines = wrap("Goal: " + game.objective(), w * 0.8f)
        for ((i, l) in lines.withIndex()) txt(c, l, w * 0.09f, h * 0.27f + i * fs * 1.25f, fs, ink, Paint.Align.LEFT)
        // sigils
        val sy = h * 0.4f
        txt(c, "Sigils", w * 0.09f, sy, fs, ink, Paint.Align.LEFT)
        val flags = listOf("sigil_leaf" to Color.rgb(70, 190, 100), "sigil_tide" to Color.rgb(70, 150, 240), "sigil_ember" to Color.rgb(250, 110, 50))
        for ((i, f) in flags.withIndex()) {
            p.color = if (game.f(f.first)) f.second else Color.argb(70, 60, 44, 30); c.drawCircle(w * (0.22f + i * 0.07f), sy - fs * 0.3f, fs * 0.8f, p)
        }
        // party
        txt(c, "Party", w * 0.09f, h * 0.5f, fs, ink, Paint.Align.LEFT)
        val rowH = h * 0.075f
        for ((i, m) in game.party.withIndex()) {
            val col = i % 2; val row = i / 2
            val x = w * (0.09f + col * 0.43f); val y = h * 0.53f + row * rowH
            creature(c, m, x + rowH * 0.5f, y + rowH * 0.9f, h * 0.022f, 1, 0, 0, 0f)
            txt(c, "${m.s.name}  Lv${m.lvl}", x + rowH * 1.1f, y + rowH * 0.4f, fs * 0.85f, ink, Paint.Align.LEFT)
            txt(c, "${m.s.typeLabel}   HP ${m.hp}/${m.maxHp}", x + rowH * 1.1f, y + rowH * 0.8f, fs * 0.65f, m.s.type.col, Paint.Align.LEFT)
        }
        txt(c, "Critterdex ${game.dexCaught.size}/${DEX.size}     Orbs ${game.orbs}     At Mom's ${game.box.size}", w * 0.5f, h * 0.86f, fs * 0.8f, ink)
        txt(c, "OK / BACK to close", w * 0.5f, h * 0.92f, fs * 0.8f, Color.rgb(120, 100, 80))
        hit(0f, 0f, w, h) { journal = false }
    }

    private fun drawTouch(c: Canvas, w: Float, h: Float) {
        p.style = Paint.Style.FILL
        val cx = padCenterX(); val cy = padCenterY(); val r = padRadius()
        p.color = Color.argb(55, 255, 255, 255); c.drawCircle(cx, cy, r, p)
        p.color = Color.argb(120, 255, 255, 255)
        tri(c, cx, cy - r * 0.9f, cx - r * 0.3f, cy - r * 0.5f, cx + r * 0.3f, cy - r * 0.5f)
        tri(c, cx, cy + r * 0.9f, cx - r * 0.3f, cy + r * 0.5f, cx + r * 0.3f, cy + r * 0.5f)
        tri(c, cx - r * 0.9f, cy, cx - r * 0.5f, cy - r * 0.3f, cx - r * 0.5f, cy + r * 0.3f)
        tri(c, cx + r * 0.9f, cy, cx + r * 0.5f, cy - r * 0.3f, cx + r * 0.5f, cy + r * 0.3f)
        p.color = Color.argb(70, 255, 255, 255); c.drawCircle(w * 0.9f, h * 0.78f, h * 0.1f, p); c.drawCircle(w * 0.78f, h * 0.88f, h * 0.075f, p)
        txt(c, "OK", w * 0.9f, h * 0.78f + h * 0.02f, h * 0.06f, Color.argb(200, 255, 255, 255))
        txt(c, "MENU", w * 0.78f, h * 0.88f + h * 0.015f, h * 0.04f, Color.argb(200, 255, 255, 255))
    }

    // ---------------------------------------------------------------------------------------------
    private fun drawBattle(c: Canvas, w: Float, h: Float, t: Float) {
        val b = battle ?: return
        val me = b.me; val foe = b.foe
        backdrop(c, bgs[game.map.theme] ?: bgs[Theme.MEADOW], w, h)
        p.color = Color.argb(90, 40, 60, 40)
        c.drawOval(w * 0.55f, h * 0.33f, w * 0.9f, h * 0.42f, p)
        c.drawOval(w * 0.1f, h * 0.62f, w * 0.46f, h * 0.72f, p)
        if (foe.hp > 0) creature(c, foe, w * 0.725f, h * 0.375f, h * 0.1f, -1, b.lungeFoe, b.hitFoe, t)
        if (me.hp > 0) creature(c, me, w * 0.28f, h * 0.67f, h * 0.15f, 1, b.lungeMe, b.hitMe, t, back = true)
        panel(c, foe, w * 0.05f, h * 0.07f, w * 0.38f, h * 0.15f, false)
        panel(c, me, w * 0.57f, h * 0.5f, w * 0.38f, h * 0.17f, true)
        if (b.trainer != null) pips(c, b.team, w * 0.07f, h * 0.245f, h * 0.012f)
        pips(c, b.party, w * 0.59f, h * 0.69f, h * 0.012f)
        p.color = Color.rgb(35, 35, 60); c.drawRoundRect(w * 0.03f, h * 0.76f, w * 0.97f, h * 0.97f, 30f, 30f, p)
        if (b.menuOn && b.fighting && !b.swapping) drawMoves(c, w, h, b)
        else txt(c, b.text, w * 0.06f, h * 0.86f, h * 0.05f, Color.WHITE, Paint.Align.LEFT)
        if (b.menuOn && !b.swapping && !b.fighting) {
            for (i in 0 until b.items) {
                val x = w * (0.5f + 0.22f * (i % 2)); val y = h * (0.83f + 0.055f * (i / 2))
                val dim = !b.menuEnabled(i)
                txt(c, (if (i == b.menu) "> " else "   ") + b.menuLabel(i), x, y, h * 0.042f,
                    if (i == b.menu) Color.YELLOW else if (dim) Color.GRAY else Color.WHITE, Paint.Align.LEFT)
                hit(x - w * 0.01f, y - h * 0.045f, w * 0.21f, h * 0.055f) { chooseMenu(b, i) }
            }
        } else if (!b.menuOn) hit(0f, 0f, w, h) { battleLast = 0 }
        if (b.swapping) drawSwap(c, w, h, b, t)
        if (b.learnFor != null) drawLearn(c, w, h, b)
        if (now() - flashAt < 350) { p.color = Color.argb((255 * (1f - (now() - flashAt) / 350f)).toInt(), 255, 255, 255); c.drawRect(0f, 0f, w, h, p) }
    }

    /** The move list: four moves in a 2 x 2 grid, with the type, power, accuracy and PP of the highlighted one. */
    private fun drawMoves(c: Canvas, w: Float, h: Float, b: Battle) {
        val sel = b.me.moves.getOrNull(b.moveSel)
        if (sel != null) {
            val mo = sel.move
            txt(c, mo.type.label, w * 0.06f, h * 0.83f, h * 0.045f, mo.type.col, Paint.Align.LEFT)
            txt(c, mo.info, w * 0.06f, h * 0.89f, h * 0.036f, Color.WHITE, Paint.Align.LEFT)
            txt(c, "PP ${sel.pp}/${mo.pp}", w * 0.06f, h * 0.945f, h * 0.036f,
                if (sel.pp == 0) Color.rgb(240, 90, 80) else Color.rgb(200, 210, 240), Paint.Align.LEFT)
        }
        for ((i, ms) in b.me.moves.withIndex()) {
            val x = w * (0.34f + 0.31f * (i % 2)); val y = h * (0.835f + 0.075f * (i / 2))
            val on = i == b.moveSel
            txt(c, (if (on) "> " else "   ") + ms.move.name, x, y, h * 0.042f,
                if (on) Color.YELLOW else if (ms.pp <= 0) Color.GRAY else Color.WHITE, Paint.Align.LEFT)
            hit(x - w * 0.01f, y - h * 0.05f, w * 0.30f, h * 0.07f) { b.moveSel = i; if (ms.pp > 0) b.fightWith(i) }
        }
        txt(c, "Back", w * 0.945f, h * 0.805f, h * 0.034f, Color.rgb(170, 180, 220), Paint.Align.RIGHT)
        hit(w * 0.86f, h * 0.77f, w * 0.1f, h * 0.06f) { b.closeFight() }
    }

    /** "Forget a move to learn a new one?" - shown when a critter that knows four moves levels into a fifth. */
    private fun drawLearn(c: Canvas, w: Float, h: Float, b: Battle) {
        val m = b.learnFor ?: return; val nw = b.learnMove ?: return
        val x = w * 0.2f; val y = h * 0.04f; val pw = w * 0.6f; val rowH = h * 0.095f
        p.style = Paint.Style.FILL
        p.color = Color.argb(245, 28, 30, 58); c.drawRoundRect(x, y, x + pw, y + h * 0.2f + rowH * 5 + h * 0.02f, 30f, 30f, p)
        txt(c, "${m.s.name} wants to learn ${nw.name}!", x + pw / 2, y + h * 0.065f, h * 0.045f, Color.rgb(250, 214, 100))
        txt(c, "${nw.type.label}   ${nw.info}", x + pw / 2, y + h * 0.12f, h * 0.036f, nw.type.col)
        txt(c, "Forget which move?", x + pw / 2, y + h * 0.17f, h * 0.036f, Color.WHITE)
        for (i in 0..4) {
            val ry = y + h * 0.2f + i * rowH
            if (i == b.learnSel) { p.color = Color.argb(80, 250, 214, 100); c.drawRoundRect(x + 14f, ry, x + pw - 14f, ry + rowH - 6f, 20f, 20f, p) }
            val col = if (i == b.learnSel) Color.YELLOW else Color.WHITE
            if (i < m.moves.size) {
                val mo = m.moves[i].move
                txt(c, mo.name, x + pw * 0.06f, ry + rowH * 0.62f, h * 0.042f, col, Paint.Align.LEFT)
                txt(c, mo.type.label + "  " + mo.info, x + pw * 0.95f, ry + rowH * 0.62f, h * 0.032f, mo.type.col, Paint.Align.RIGHT)
            } else txt(c, "Keep my old moves", x + pw * 0.06f, ry + rowH * 0.62f, h * 0.042f, col, Paint.Align.LEFT)
            hit(x, ry, pw, rowH) { b.learnSel = i; b.answerLearn(i); battleLast = 0 }
        }
    }

    private fun drawSwap(c: Canvas, w: Float, h: Float, b: Battle, t: Float) {
        if (!b.text.startsWith("Choose")) hit(0f, 0f, w, h) { b.closeSwap() }
        val x = w * 0.2f; val y = h * 0.08f; val pw = w * 0.6f; val rowH = h * 0.105f
        p.color = Color.argb(240, 28, 30, 58); c.drawRoundRect(x, y, x + pw, y + h * 0.1f + rowH * b.party.size + h * 0.03f, 30f, 30f, p)
        txt(c, if (b.text.startsWith("Choose")) "Choose your next critter!" else "Swap to which critter?", x + pw / 2, y + h * 0.07f, h * 0.045f, Color.rgb(250, 214, 100))
        for ((i, m) in b.party.withIndex()) {
            val ry = y + h * 0.1f + i * rowH; val dead = m.hp <= 0; val out = i == b.cur && !dead; val sel = i == b.swapSel
            if (sel && !dead && !out) { p.color = Color.argb(80, 250, 214, 100); c.drawRoundRect(x + 14f, ry, x + pw - 14f, ry + rowH - 6f, 20f, 20f, p) }
            if (!dead) creature(c, m, x + rowH * 0.7f, ry + rowH * 0.92f, h * 0.024f, 1, 0, 0, t)
            val col = if (dead || out) Color.GRAY else Color.WHITE
            txt(c, "${m.s.name}  Lv${m.lvl}" + if (out) "  (out)" else if (dead) "  (fainted)" else "", x + rowH * 1.5f, ry + rowH * 0.42f, h * 0.04f, col, Paint.Align.LEFT)
            txt(c, m.s.typeLabel, x + pw - rowH * 0.4f, ry + rowH * 0.42f, h * 0.034f, m.s.type.col, Paint.Align.RIGHT)
            val f = (m.hp.toFloat() / m.maxHp).coerceIn(0f, 1f)
            p.color = Color.rgb(60, 60, 70); c.drawRoundRect(x + rowH * 1.5f, ry + rowH * 0.58f, x + pw - rowH * 0.4f, ry + rowH * 0.72f, 8f, 8f, p)
            p.color = if (f > 0.5f) Color.rgb(70, 200, 90) else if (f > 0.2f) Color.rgb(240, 200, 50) else Color.rgb(230, 70, 60)
            c.drawRoundRect(x + rowH * 1.5f, ry + rowH * 0.58f, x + rowH * 1.5f + (pw - rowH * 1.9f) * f, ry + rowH * 0.72f, 8f, 8f, p)
            if (!dead && !out) hit(x, ry, pw, rowH) { b.swapSel = i; b.swap(i) }
        }
    }

    // ---------------------------------------------------------------------------------------------
    private val creditLines = listOf(
        "CRITTER QUEST", "", "The Silence of the Heart Bell", "", "~", "",
        "The Heart Bell rings again.", "The Wardens keep their Sigils.", "Baron Gloam tends the Bell at dawn and dusk.", "",
        "Somewhere on the Ashen Trail,", "a lonely critter is running home.", "", "~", "",
        "STARRING", "You", "Professor Fern", "Kit, the Rival", "Mom", "",
        "WARDENS", "Willow of Leaf", "Marina of Tide", "Cinder of Ember", "",
        "THE HOLLOW GUILD", "Baron Gloam", "Lieutenant Vex", "and a lot of grunts", "",
        "CRITTERS", "Emberpup  Blazehorn", "Aquafin  Tidalon", "Sproutle  Thornpaw", "", "~", "",
        "Thank you for playing!"
    )
    private fun creditsLength() = ((0.6f + (creditLines.size - 1) * 0.075f) / 0.07f * 1000f).toLong() + 1500L

    private fun drawCredits(c: Canvas, w: Float, h: Float, t: Float) {
        backdrop(c, nightBg, w, h)
        p.color = Color.argb(200, 255, 255, 230)
        for (i in 0 until 60) { val sx = ((i * 7919) % 1000) / 1000f * w; val sy = ((i * 104729) % 700) / 1000f * h; c.drawCircle(sx, sy, h * 0.003f * (1 + (i % 3)) * (0.7f + 0.3f * sin(t * 2 + i)), p) }
        val el = (now() - creditsT0) / 1000f
        val speed = h * 0.07f; val lineH = h * 0.075f
        for ((i, s) in creditLines.withIndex()) {
            val y = h * 1.05f + i * lineH - el * speed
            if (y < -lineH || y > h + lineH) continue
            val head = s == "CRITTER QUEST"; val sub = s.isNotEmpty() && s == s.uppercase() && !head && s != "~"
            txt(c, if (s == "~") "* * *" else s, w / 2, y, if (head) h * 0.11f else if (sub) h * 0.05f else h * 0.042f, if (head) Color.rgb(255, 224, 120) else if (sub) Color.rgb(160, 190, 255) else Color.WHITE)
        }
        for (i in 0..5) creature(c, show[i], (w * (0.1f + 0.18f * i) + el * 40f) % (w * 1.1f), h * 0.97f, h * 0.05f, 1, 0, 0, t + i)
        if (now() - creditsT0 > creditsLength() && (t * 2).toInt() % 2 == 0) txt(c, "Press OK", w / 2, h * 0.88f, h * 0.05f, Color.rgb(255, 224, 120))
        hit(0f, 0f, w, h) { onAction(4) }
    }
}
