package com.example.critterquest

import android.graphics.Color

// ---------------------------------------------------------------------------------------------
// Types, the type chart, status conditions and every move in the game.
// Pure Kotlin (no drawing code besides colours) so tools/story_check can run it headless.
// ---------------------------------------------------------------------------------------------

/**
 * The 14 critter types. [special] follows the old handheld rule: moves of Fire, Water, Leaf, Electric, Ice and
 * Psychic type use Sp. Atk / Sp. Def; every other type uses Attack / Defense.
 */
enum class T(val label: String, val col: Int, val special: Boolean) {
    FIRE("Fire", Color.rgb(230, 90, 40), true),
    WATER("Water", Color.rgb(40, 130, 230), true),
    LEAF("Leaf", Color.rgb(40, 150, 60), true),
    NORMAL("Normal", Color.rgb(150, 150, 120), false),
    ELECTRIC("Electric", Color.rgb(226, 178, 20), true),
    ICE("Ice", Color.rgb(90, 190, 210), true),
    FIGHTING("Fighting", Color.rgb(190, 60, 50), false),
    POISON("Poison", Color.rgb(160, 70, 180), false),
    GROUND("Ground", Color.rgb(190, 150, 70), false),
    FLYING("Flying", Color.rgb(120, 140, 230), false),
    PSYCHIC("Psychic", Color.rgb(235, 90, 150), true),
    BUG("Bug", Color.rgb(150, 170, 30), false),
    ROCK("Rock", Color.rgb(160, 140, 80), false),
    GHOST("Ghost", Color.rgb(100, 80, 160), false)
}

/** Attacking type -> (defending types it hits for 2x, defending types it hits for 0.5x, defending types it cannot hurt). */
private class Row(val strong: Set<T>, val weak: Set<T>, val none: Set<T> = emptySet())

private val CHART: Map<T, Row> = mapOf(
    T.NORMAL to Row(emptySet(), setOf(T.ROCK), setOf(T.GHOST)),
    T.FIRE to Row(setOf(T.LEAF, T.ICE, T.BUG), setOf(T.FIRE, T.WATER, T.ROCK)),
    T.WATER to Row(setOf(T.FIRE, T.GROUND, T.ROCK), setOf(T.WATER, T.LEAF)),
    T.LEAF to Row(setOf(T.WATER, T.GROUND, T.ROCK), setOf(T.FIRE, T.LEAF, T.POISON, T.FLYING, T.BUG)),
    T.ELECTRIC to Row(setOf(T.WATER, T.FLYING), setOf(T.ELECTRIC, T.LEAF), setOf(T.GROUND)),
    T.ICE to Row(setOf(T.LEAF, T.GROUND, T.FLYING), setOf(T.FIRE, T.WATER, T.ICE)),
    T.FIGHTING to Row(setOf(T.NORMAL, T.ICE, T.ROCK), setOf(T.POISON, T.FLYING, T.PSYCHIC, T.BUG), setOf(T.GHOST)),
    T.POISON to Row(setOf(T.LEAF), setOf(T.POISON, T.GROUND, T.ROCK, T.GHOST)),
    T.GROUND to Row(setOf(T.FIRE, T.ELECTRIC, T.POISON, T.ROCK), setOf(T.LEAF, T.BUG), setOf(T.FLYING)),
    T.FLYING to Row(setOf(T.LEAF, T.FIGHTING, T.BUG), setOf(T.ELECTRIC, T.ROCK)),
    T.PSYCHIC to Row(setOf(T.FIGHTING, T.POISON), setOf(T.PSYCHIC)),
    T.BUG to Row(setOf(T.LEAF, T.PSYCHIC), setOf(T.FIRE, T.FIGHTING, T.POISON, T.FLYING, T.GHOST)),
    T.ROCK to Row(setOf(T.FIRE, T.ICE, T.FLYING, T.BUG), setOf(T.FIGHTING, T.GROUND)),
    T.GHOST to Row(setOf(T.GHOST, T.PSYCHIC), emptySet(), setOf(T.NORMAL))
)

/** Type multiplier of one attacking type against one defending type: 0, 0.5, 1 or 2. */
fun typeMult(a: T, d: T): Float {
    val r = CHART.getValue(a)
    return when (d) { in r.none -> 0f; in r.strong -> 2f; in r.weak -> 0.5f; else -> 1f }
}

// ---- status conditions and stat stages ---------------------------------------------------------

enum class St(val tag: String, val col: Int) {
    BRN("BRN", Color.rgb(230, 100, 40)), PSN("PSN", Color.rgb(160, 70, 180)), PAR("PAR", Color.rgb(226, 178, 20)),
    SLP("SLP", Color.rgb(130, 130, 150)), FRZ("FRZ", Color.rgb(90, 190, 210))
}

const val ATK = 0; const val DEF = 1; const val SPA = 2; const val SPD = 3; const val SPE = 4; const val ACC = 5; const val EVA = 6
val STAT_NAMES = listOf("Attack", "Defense", "Sp. Atk", "Sp. Def", "Speed", "accuracy", "evasiveness")

// ---- moves ----------------------------------------------------------------------------------------

/**
 * One move. [power] 0 = a status move. [acc] 0 = never misses. [chance] is the % chance of the extra effect on a damaging
 * move (status moves always apply theirs when they hit). Extra effects: inflict [status], change a stat by [stages]
 * (on the user if [self], else on the target), [flinch] chance, [drain] half the damage back, [recoil] a quarter of it,
 * [heal] half your HP (status move), [levelDmg] damage equal to the user's level.
 */
class Move(
    val name: String, val type: T, val power: Int, val acc: Int, val pp: Int,
    val prio: Int = 0, val crit: Boolean = false,
    val status: St? = null, val stat: Int = -1, val stages: Int = 0, val self: Boolean = false, val chance: Int = 100,
    val flinch: Int = 0, val drain: Boolean = false, val recoil: Boolean = false, val heal: Boolean = false,
    val levelDmg: Boolean = false
) {
    val damaging get() = power > 0 || levelDmg
    /** One-line description for the move list. */
    val info: String get() = when {
        damaging -> "Pow ${if (levelDmg) "Lv" else power.toString()}  Acc ${if (acc == 0) "--" else acc.toString()}"
        else -> "Status  Acc ${if (acc == 0) "--" else acc.toString()}"
    }
}

val STRUGGLE = Move("Struggle", T.NORMAL, 50, 0, 1, recoil = true)

val MOVES: List<Move> = listOf(
    // ---- Normal
    Move("Tackle", T.NORMAL, 40, 100, 35),
    Move("Scratch", T.NORMAL, 40, 100, 35),
    Move("Pound", T.NORMAL, 40, 100, 35),
    Move("Quick Attack", T.NORMAL, 40, 100, 30, prio = 1),
    Move("Gnaw", T.NORMAL, 60, 100, 25, flinch = 30),
    Move("Headbutt", T.NORMAL, 70, 100, 15, flinch = 30),
    Move("Slash", T.NORMAL, 70, 100, 20, crit = true),
    Move("Slam", T.NORMAL, 80, 75, 20),
    Move("Strength", T.NORMAL, 80, 100, 15),
    Move("Body Slam", T.NORMAL, 85, 100, 15, status = St.PAR, chance = 30),
    Move("Take Down", T.NORMAL, 90, 85, 20, recoil = true),
    Move("Double-Edge", T.NORMAL, 120, 100, 15, recoil = true),
    Move("Swift", T.NORMAL, 60, 0, 20),
    Move("Growl", T.NORMAL, 0, 100, 40, stat = ATK, stages = -1),
    Move("Tail Whip", T.NORMAL, 0, 100, 30, stat = DEF, stages = -1),
    Move("Leer", T.NORMAL, 0, 100, 30, stat = DEF, stages = -1),
    Move("Screech", T.NORMAL, 0, 85, 40, stat = DEF, stages = -2),
    Move("Smokescreen", T.NORMAL, 0, 100, 20, stat = ACC, stages = -1),
    Move("Harden", T.NORMAL, 0, 0, 30, stat = DEF, stages = 1, self = true),
    Move("Swords Dance", T.NORMAL, 0, 0, 20, stat = ATK, stages = 2, self = true),
    Move("Double Team", T.NORMAL, 0, 0, 15, stat = EVA, stages = 1, self = true),
    Move("Recover", T.NORMAL, 0, 0, 10, heal = true),
    // ---- Fire
    Move("Ember", T.FIRE, 40, 100, 25, status = St.BRN, chance = 10),
    Move("Flame Burst", T.FIRE, 55, 100, 20, status = St.BRN, chance = 10),
    Move("Fire Punch", T.FIRE, 75, 100, 15, status = St.BRN, chance = 10),
    Move("Flamethrower", T.FIRE, 95, 100, 15, status = St.BRN, chance = 10),
    Move("Inferno", T.FIRE, 105, 85, 5, status = St.BRN, chance = 30),
    Move("Will-O-Wisp", T.FIRE, 0, 75, 15, status = St.BRN),
    // ---- Water
    Move("Bubble", T.WATER, 20, 100, 30, stat = SPE, stages = -1, chance = 10),
    Move("Water Gun", T.WATER, 40, 100, 25),
    Move("Aqua Jet", T.WATER, 40, 100, 20, prio = 1),
    Move("Bubble Beam", T.WATER, 65, 100, 20, stat = SPE, stages = -1, chance = 10),
    Move("Waterfall", T.WATER, 80, 100, 15, flinch = 20),
    Move("Surf", T.WATER, 95, 100, 15),
    Move("Tidal Crash", T.WATER, 105, 85, 5),
    Move("Withdraw", T.WATER, 0, 0, 40, stat = DEF, stages = 1, self = true),
    // ---- Leaf
    Move("Absorb", T.LEAF, 20, 100, 20, drain = true),
    Move("Vine Whip", T.LEAF, 45, 100, 25),
    Move("Mega Drain", T.LEAF, 40, 100, 10, drain = true),
    Move("Razor Leaf", T.LEAF, 55, 95, 25, crit = true),
    Move("Giga Drain", T.LEAF, 60, 100, 5, drain = true),
    Move("Thorn Storm", T.LEAF, 105, 90, 5),
    Move("Poison Powder", T.LEAF, 0, 75, 35, status = St.PSN),
    Move("Stun Spore", T.LEAF, 0, 75, 30, status = St.PAR),
    Move("Sleep Powder", T.LEAF, 0, 75, 15, status = St.SLP),
    Move("Growth", T.LEAF, 0, 0, 20, stat = SPA, stages = 1, self = true),
    // ---- Electric
    Move("Thunder Shock", T.ELECTRIC, 40, 100, 30, status = St.PAR, chance = 10),
    Move("Spark", T.ELECTRIC, 65, 100, 20, status = St.PAR, chance = 30),
    Move("Thunderbolt", T.ELECTRIC, 95, 100, 15, status = St.PAR, chance = 10),
    Move("Thunder", T.ELECTRIC, 115, 70, 10, status = St.PAR, chance = 30),
    Move("Thunder Wave", T.ELECTRIC, 0, 100, 20, status = St.PAR),
    // ---- Ice
    Move("Powder Snow", T.ICE, 40, 100, 25, status = St.FRZ, chance = 10),
    Move("Ice Shard", T.ICE, 40, 100, 30, prio = 1),
    Move("Icy Wind", T.ICE, 55, 95, 15, stat = SPE, stages = -1),
    Move("Aurora Beam", T.ICE, 65, 100, 20, stat = ATK, stages = -1, chance = 10),
    Move("Ice Beam", T.ICE, 95, 100, 10, status = St.FRZ, chance = 10),
    Move("Blizzard", T.ICE, 115, 70, 5, status = St.FRZ, chance = 10),
    // ---- Fighting
    Move("Karate Chop", T.FIGHTING, 50, 100, 25, crit = true),
    Move("Mach Punch", T.FIGHTING, 40, 100, 30, prio = 1),
    Move("Brick Break", T.FIGHTING, 75, 100, 15),
    Move("Submission", T.FIGHTING, 80, 80, 25, recoil = true),
    Move("Cross Chop", T.FIGHTING, 100, 80, 5, crit = true),
    // ---- Poison
    Move("Poison Sting", T.POISON, 15, 100, 35, status = St.PSN, chance = 30),
    Move("Acid", T.POISON, 40, 100, 30, stat = SPD, stages = -1, chance = 10),
    Move("Sludge", T.POISON, 65, 100, 20, status = St.PSN, chance = 30),
    Move("Sludge Bomb", T.POISON, 90, 100, 10, status = St.PSN, chance = 30),
    Move("Toxic", T.POISON, 0, 85, 10, status = St.PSN),
    // ---- Ground
    Move("Sand Toss", T.GROUND, 0, 100, 15, stat = ACC, stages = -1),
    Move("Mud Shot", T.GROUND, 55, 95, 15, stat = SPE, stages = -1),
    Move("Bone Smash", T.GROUND, 65, 85, 20, flinch = 10),
    Move("Burrow Strike", T.GROUND, 80, 100, 10),
    Move("Earthquake", T.GROUND, 100, 100, 10),
    // ---- Flying
    Move("Peck", T.FLYING, 35, 100, 35),
    Move("Gust", T.FLYING, 40, 100, 35),
    Move("Wing Attack", T.FLYING, 60, 100, 35),
    Move("Aerial Ace", T.FLYING, 60, 0, 20),
    Move("Drill Peck", T.FLYING, 80, 100, 20),
    Move("Sky Dive", T.FLYING, 90, 95, 15),
    // ---- Psychic
    Move("Confusion", T.PSYCHIC, 50, 100, 25),
    Move("Psybeam", T.PSYCHIC, 65, 100, 20),
    Move("Psychic", T.PSYCHIC, 90, 100, 10, stat = SPD, stages = -1, chance = 10),
    Move("Hypnosis", T.PSYCHIC, 0, 60, 20, status = St.SLP),
    Move("Agility", T.PSYCHIC, 0, 0, 30, stat = SPE, stages = 2, self = true),
    Move("Barrier", T.PSYCHIC, 0, 0, 30, stat = DEF, stages = 2, self = true),
    Move("Amnesia", T.PSYCHIC, 0, 0, 20, stat = SPD, stages = 2, self = true),
    // ---- Bug
    Move("String Shot", T.BUG, 0, 95, 40, stat = SPE, stages = -1),
    Move("Bug Bite", T.BUG, 60, 100, 20),
    Move("Leech Life", T.BUG, 20, 100, 15, drain = true),
    Move("Twin Sting", T.BUG, 45, 100, 20, status = St.PSN, chance = 20),
    Move("Megahorn", T.BUG, 115, 85, 10),
    // ---- Rock
    Move("Rock Throw", T.ROCK, 50, 90, 15),
    Move("Rock Tomb", T.ROCK, 50, 80, 10, stat = SPE, stages = -1),
    Move("Rock Slide", T.ROCK, 75, 90, 10, flinch = 30),
    Move("Stone Edge", T.ROCK, 100, 80, 5, crit = true),
    // ---- Ghost
    Move("Lick", T.GHOST, 20, 100, 30, status = St.PAR, chance = 30),
    Move("Night Shade", T.GHOST, 0, 100, 15, levelDmg = true),
    Move("Shadow Claw", T.GHOST, 70, 100, 15, crit = true),
    Move("Shadow Ball", T.GHOST, 80, 100, 15, stat = SPD, stages = -1, chance = 20)
)

private val MOVE_BY_NAME: Map<String, Move> = MOVES.associateBy { it.name }

/** Look a move up by name (learnsets and saves refer to moves by name, so adding moves never breaks old saves). */
fun mv(name: String): Move = MOVE_BY_NAME[name] ?: error("unknown move '$name'")
fun mvOrNull(name: String): Move? = MOVE_BY_NAME[name]
