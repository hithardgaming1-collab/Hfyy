package com.example.critterquest

import android.graphics.Color

// ---------------------------------------------------------------------------------------------
// The cast: every person and trainer in the Critterlands, with their lines.
// To add someone: create an Npc(...) below and put it in NPCS. The talk block returns the steps to play.
// ---------------------------------------------------------------------------------------------

private val SK1 = Color.rgb(244, 208, 170)
private val SK2 = Color.rgb(222, 170, 130)
private val SK3 = Color.rgb(150, 104, 76)
private fun lk(hair: Int, top: Int, legs: Int, kind: Int = K_PLAIN, skin: Int = SK1) = Look(skin, hair, top, legs, kind)
private val GUILD = lk(Color.rgb(60, 60, 70), Color.rgb(84, 84, 104), Color.rgb(46, 46, 60), K_HOOD)

val PLAYER_LOOK = lk(Color.rgb(70, 45, 30), Color.rgb(220, 60, 60), Color.rgb(50, 60, 110), K_CAP)

// Kit always picks the starter your partner beats, and keeps a second critter that beats yours.
fun Game.kitMine() = kitMineFor(starter)
fun kitMineFor(i: Int) = when (i) { 0 -> SPROUTLE; 1 -> EMBERPUP; else -> AQUAFIN }
fun Game.kitCounter() = when (starter) { 0 -> AQUAFIN; 1 -> SPROUTLE; else -> EMBERPUP }
fun evoOf(i: Int) = if (DEX[i].evo >= 0) DEX[i].evo else i

private const val KIT = "Kit"
private const val FERN = "Prof. Fern"
private const val GLOAM = "Baron Gloam"
private const val WILLOW = "Warden Willow"
private const val MARINA = "Warden Marina"
private const val CINDER = "Warden Cinder"

// ---- trainers ---------------------------------------------------------------------------------
val T_KIT1 = Trainer("kit1", KIT) { listOf(kitMine() to 5) }
val T_KIT2 = Trainer("kit2", KIT) { listOf(evoOf(kitMine()) to 11, kitCounter() to 10) }
val T_KIT3 = Trainer("kit3", KIT) { listOf(evoOf(kitMine()) to 20, evoOf(kitCounter()) to 19) }
val T_KIT4 = Trainer("kit4", KIT, true) { listOf(evoOf(kitMine()) to 30, evoOf(kitCounter()) to 30, evoOf(starter) to 30) }

val T_TOBI = Trainer("tobi", "Scout Tobi", team = team(NIBBLET to 4, WRIGGLET to 4))
val T_PIA = Trainer("pia", "Picnicker Pia", team = team(PIPWING to 4, BUDLING to 5))
val T_GBRIAR = Trainer("g_briar", "Guild Grunt", team = team(HISSLE to 6))
val T_CLOVER = Trainer("clover", "Disciple Clover", team = team(BUDLING to 6))
val T_BRAMBLE = Trainer("bramble", "Disciple Bramble", team = team(SPROUTLE to 7, HIVELET to 7))
val T_WILLOW = Trainer("willow", WILLOW, true, team(BUDLING to 7, THORNPAW to 8))

val T_FINN = Trainer("finn", "Sailor Finn", team = team(AQUAFIN to 9, PIPWING to 9))
val T_LYRA = Trainer("lyra", "Swimmer Lyra", team = team(AQUAFIN to 10))
val T_GTIDE = Trainer("g_tide", "Guild Grunt", team = team(HISSLE to 10, NIBBLET to 10))
val T_NERIO = Trainer("nerio", "Diver Nerio", team = team(AQUAFIN to 12))
val T_CORAL = Trainer("coral", "Diver Coral", team = team(AQUAFIN to 12, TIDALON to 12))
val T_MARINA = Trainer("marina", MARINA, true, team(AQUAFIN to 13, TIDALON to 14))

val T_BROCK = Trainer("brock", "Hiker Brock", team = team(PEBBLIT to 13, BLAZEHORN to 13))
val T_RYE = Trainer("rye", "Hotshot Rye", team = team(CINDERFOAL to 14))
val T_VIK = Trainer("vik", "Guild Grunt Vik", team = team(HISSLE to 14, WISPET to 14))
val T_GCINDER = Trainer("g_cinder", "Guild Grunt", team = team(HISSLE to 16, WISPET to 16))
val T_ASH = Trainer("ash", "Torchbearer Ash", team = team(CINDERFOAL to 16))
val T_FLINT = Trainer("flint", "Torchbearer Flint", team = team(CINDERFOAL to 16, BLAZEHORN to 16))
val T_CINDER = Trainer("cinder", CINDER, true, team(CINDERFOAL to 17, BLAZEHORN to 18))

val T_GPASS1 = Trainer("g_pass1", "Guild Grunt", team = team(BLOOMFANG to 18))
val T_GPASS2 = Trainer("g_pass2", "Guild Grunt", team = team(COILFANG to 18, WISPET to 18))
val T_GKEEP1 = Trainer("g_keep1", "Guild Grunt", team = team(COILFANG to 19))
val T_GKEEP2 = Trainer("g_keep2", "Guild Grunt", team = team(BLOOMFANG to 19, WISPET to 19))
val T_GKEEP3 = Trainer("g_keep3", "Guild Grunt", team = team(STINGMAW to 20))
val T_GKEEP4 = Trainer("g_keep4", "Guild Grunt", team = team(COILFANG to 20, MINDLE to 20))
val T_VEX = Trainer("vex", "Lieutenant Vex", true, team(BLOOMFANG to 23, COILFANG to 23))
val T_GLOAM = Trainer("gloam", GLOAM, true, team(BLAZEHORN to 27, TIDALON to 27, THORNPAW to 28))

// ---- Mom's critter box: extra critters you catch wait here (the party holds 6) ----------------
private const val BOX_PAGE = 4

fun Game.boxHome(): List<Step> = listOf(ask("Mom", "I look after your extra critters. (Party ${party.size}/$MAX_PARTY, box ${box.size})",
    listOf("Take one with me", "Leave one here", "Done")) {
    when (it) { 0 -> boxTake(0); 1 -> boxLeave(); else -> listOf(say("Mom", "They're happy here. Come back any time!")) }
})

private fun Game.boxTake(page: Int): List<Step> {
    if (box.isEmpty()) return listOf(say("Mom", "The box is empty right now, dear.")) + boxHome()
    if (party.size >= MAX_PARTY) return listOf(say("Mom", "Your party is full! Leave one of them with me first.")) + boxHome()
    val lo = page * BOX_PAGE
    val shown = box.drop(lo).take(BOX_PAGE)
    val more = lo + BOX_PAGE < box.size
    val opts = shown.map { "${it.s.name} Lv${it.lvl}" } + (if (more) listOf("More...") else emptyList()) + "Back"
    return listOf(ask("Mom", "Who should come with you?", opts) { c ->
        when {
            c < shown.size -> { val m = shown[c]; withdraw(box.indexOf(m)); listOf(narr("${m.s.name} joined your party!", DEX.indexOf(m.s))) + boxHome() }
            c == shown.size && more -> boxTake(page + 1)
            else -> boxHome()
        }
    })
}

private fun Game.boxLeave(): List<Step> {
    if (party.size <= 1) return listOf(say("Mom", "You can't leave your only partner, silly!")) + boxHome()
    val opts = party.map { "${it.s.name} Lv${it.lvl}" } + "Back"
    return listOf(ask("Mom", "Who needs a rest at home?", opts) { c ->
        if (c < party.size) { val m = party[c]; deposit(c); listOf(narr("${m.s.name} will stay with Mom.", DEX.indexOf(m.s))) + boxHome() } else boxHome()
    })
}

/** A trainer with pre-fight, win and after-defeat lines. [then] runs after the win lines. */
private fun tnpc(
    id: String, map: String, x: Int, y: Int, tr: Trainer, look: Look, face: Int, sight: Int,
    pre: List<String>, won: List<String>, post: List<String>,
    show: Game.() -> Boolean = { true }, then: List<Step> = emptyList()
) = Npc(id, map, x, y, tr.name, look, face, sight, tr, show) {
    val n = tr.name
    val l = ArrayList<Step>()
    if (f("t_" + tr.id)) post.forEach { l.add(say(n, it)) }
    else {
        pre.forEach { l.add(say(n, it)) }
        val after = ArrayList<Step>(); won.forEach { after.add(say(n, it)) }; after.addAll(then)
        l.add(fight(tr, after))
    }
    l
}

/** A plain talker: first matching condition wins. */
private fun talker(id: String, map: String, x: Int, y: Int, name: String, look: Look, face: Int = DOWN,
                   show: Game.() -> Boolean = { true }, lines: Game.() -> List<String>) =
    Npc(id, map, x, y, name, look, face, 0, null, show) { lines().map { say(name, it) } }

private val guildGone: Game.() -> Boolean = { !f("ending") }

// ---- the Wardens' victories ---------------------------------------------------------------
private fun sigilScene(flag: String, name: String, speaker: String, gift: Int, lines: List<String>): List<Step> {
    val l = ArrayList<Step>()
    l.add(say(speaker, "Magnificent. Your bond with your partners is real. Take this."))
    l.add(act { set(flag) })
    l.add(narr("You received the $name Sigil!  (All 3 are needed to open the Shrine Gate.)"))
    l.add(say(speaker, "And take one of my own critters with you. ${DEX[gift].name} will fight at your side.", gift))
    l.add(act {
        val lvl = maxOf(5, party.maxOf { it.lvl } - 2)
        addToParty(gift, lvl)
        play(listOf(narr("${DEX[gift].name} (Lv$lvl) joined your party!", gift)))
        save()
    })
    lines.forEach { l.add(say(speaker, it)) }
    return l
}

fun gloamAfter(): List<Step> = listOf(
    say(GLOAM, "...Calm. They are calm. Not a single critter of yours was afraid of me."),
    narr("The Chime Core slips from Gloam's hand and floats upward, glowing softly."),
    narr("The three Sigils rise from your pack and spin into the Bell's cradle, locking around the Core."),
    narr("DONNNNG..."),
    narr("The Heart Bell rings. Its chime rolls through the Keep, over Gloam Pass and out across the whole of the Critterlands."),
    act { set("heart_crowd") },
    say(GLOAM, "That sound... That is what Wick heard that night. All these years I believed he ran away from the dark."),
    say(GLOAM, "I think... he was running toward the Bell."),
    say(WILLOW, "The Bell! Marina, do you hear it? Every critter in the Critterlands just breathed out."),
    say(MARINA, "We felt the Sigils leave us and we ran. Are you hurt? Is he...?"),
    say(CINDER, "Gloam. Look at me. You nearly broke everything we swore to protect."),
    say(GLOAM, "I know. Do what you must."),
    say(CINDER, "Then hear this: you will tend the Bell. Every dawn, every dusk, until you remember what it is for."),
    say(GLOAM, "...Yes. I would like that."),
    say(FERN, "My dear champion! You carried three Sigils, a silent Bell and an entire region on your shoulders."),
    say(KIT, "I knew you'd do it! Okay, I knew you'd do it *eventually*. Rematch in Mossbrook, any time you like!"),
    narr("Weeks later. In Mossbrook, the Heart Bell rings at dawn once more, and the village sleeps a little easier."),
    narr("And far away on the Ashen Trail, a lonely critter lifts its head at the sound of the chime... and begins to run home."),
    act { set("ending"); endingPending = true }
)


/** Kit waits at the foot of Gloam Pass for one last friendly fight (also fired by a trigger in Story.kt). */
fun kit3Scene(): List<Step> = listOf(
    say(KIT, "There you are! I got here first, for once."),
    say(KIT, "The Gate opens for whoever carries the three Sigils. Willow says that's you, not me."),
    say(KIT, "I'm not jealous! ...Okay, I'm a little jealous. One last battle before you go in!"),
    fight(T_KIT3,
        listOf(say(KIT, "That's... that's my best, and you still won. You're really something."),
            say(KIT, "Go. I'll hold off the Guild down here. Bring the Bell back!")),
        listOf(say(KIT, "I won?! Whoa. ...Rest at the stone, then come back and win it properly."), act { set("t_kit3") })))

// ---- everybody ---------------------------------------------------------------------------------
val NPCS: List<Npc> = listOf(
    // ===== Your house / Mossbrook =====
    Npc("mom", "home", 4, 3, "Mom", lk(Color.rgb(120, 70, 40), Color.rgb(236, 150, 176), Color.rgb(110, 90, 130)), DOWN) {
        when {
            !f("starter") -> listOf(
                say("Mom", "Professor Fern's lab is the big building on the right. She's waiting for you, sweetheart!"),
                say("Mom", "And don't worry about the Bell. I'm sure it's just... resting."))
            f("ending") -> listOf(
                say("Mom", "The Bell rang again this morning. I cried into the pancakes."),
                say("Mom", "Whatever you did out there, I'm so proud of you, Champion."),
                ask("Mom", "Want to look at your critter box?", listOf("Yes", "No thanks")) { if (it == 0) boxHome() else emptyList() })
            else -> listOf(
                say("Mom", when {
                    !f("sigil_leaf") -> "Be careful out there! Briar Hollow is a long walk. Take lots of breaks."
                    !f("sigil_ember") -> "You're getting famous, you know. Even the postman asks about you."
                    else -> "Those grey-hooded people... please promise me you'll be careful."
                }),
                ask("Mom", "Hungry? I'll make you and ${me.s.name} something to eat.", listOf("Yes please!", "Open the critter box", "Not now")) {
                    when (it) {
                        0 -> listOf(narr("Mom serves a huge plate of berry pancakes."), act { restHere() },
                            say("Mom", "There! Fully refreshed, and I've written down your journey so far."), narr("Journey saved!"))
                        1 -> boxHome()
                        else -> listOf(say("Mom", "Come back whenever you're hungry."))
                    }
                })
        }
    },

    Npc("kit_m", "mossbrook", 6, 6, KIT, lk(Color.rgb(40, 170, 200), Color.rgb(250, 200, 50), Color.rgb(70, 70, 90)), LEFT,
        show = { !f("kit_in_lab") && !f("starter") }) {
        listOf(say(KIT, "Hurry up! Fern's waiting at the lab - the big building on the right!"))
    },
    talker("moss", "mossbrook", 10, 9, "Elder Moss", lk(Color.rgb(230, 230, 230), Color.rgb(90, 140, 90), Color.rgb(90, 140, 90), K_ROBE, SK2), RIGHT) {
        when {
            f("ending") -> listOf("I heard the Bell this morning. I'm too old to dance, but my heart did.")
            f("sigil_leaf") -> listOf("Willow's Sigil! The Wardens do not trust easily. Keep earning it.",
                "Three Sigils, three Wardens, one gate. That is how our ancestors locked away the Bell's greatest power.")
            else -> listOf("Ah, young one. The Heart Bell has rung every dawn since before my grandmother's grandmother was born.",
                "Its chime lives in every critter's heart. Three days of silence... I have never known such a thing.",
                "Fern means to send you to the Wardens. Listen to them. They guard more than Sigils.")
        }
    },
    talker("pip", "mossbrook", 19, 6, "Pip", lk(Color.rgb(200, 100, 40), Color.rgb(90, 190, 130), Color.rgb(70, 90, 140))) {
        when {
            f("ending") -> listOf("I heard the Bell and my hair stood up! Does that mean you won?")
            f("starter") -> listOf("Your partner is so cool! A move hits twice as hard on a type it beats...",
                "...and a critter hits harder with moves of its own type! I read that in a book.")
            else -> listOf("I'm going to have a critter someday! Did you know? Fire beats Leaf, Leaf beats Water, Water beats Fire!")
        }
    },
    talker("wren", "mossbrook", 9, 12, "Gardener Wren", lk(Color.rgb(150, 90, 60), Color.rgb(240, 220, 120), Color.rgb(90, 110, 70), skin = SK2)) {
        listOf("That glowing stone in the garden is a Rest Stone. They were here long before Mossbrook.",
            "Touch one and your critter is fully healed. It even remembers your journey, in case you black out later.")
    },

    // ===== Fern's lab =====
    Npc("fern", "lab", 6, 2, FERN, lk(Color.rgb(200, 200, 210), Color.rgb(246, 246, 250), Color.rgb(80, 80, 110), K_COAT, SK2), DOWN) {
        when {
            !f("starter") -> listOf(say(FERN, "Choose your partner from the three orbs on the table. Walk up to one and press OK."))
            f("ending") -> listOf(say(FERN, "The Bell rings, the critters are calm, and I finally have time to catalogue my notes. Thank you."))
            !f("sigil_leaf") -> listOf(say(FERN, "Briar Hollow lies east, through Whisper Meadow. Warden Willow is expecting a challenger."),
                say(FERN, "Press BACK any time to open your Journal. It always tells you where to go next."))
            !f("gate_open") -> listOf(say(FERN, "You carry ${sigils} of the 3 Sigils. Write to me, won't you? And rest properly!"))
            else -> listOf(say(FERN, "The Keep! Be brave, and don't forget to rest at the stone inside."))
        }
    },
    Npc("kit_l", "lab", 9, 4, KIT, lk(Color.rgb(40, 170, 200), Color.rgb(250, 200, 50), Color.rgb(70, 70, 90)), LEFT,
        show = { f("kit_in_lab") && !f("t_kit1") }) {
        listOf(say(KIT, "Go on, pick one! ...Not the one I want, though."))
    },

    // ===== Route 1: Whisper Meadow =====
    tnpc("tobi", "route1", 9, 5, T_TOBI, lk(Color.rgb(90, 60, 30), Color.rgb(230, 150, 60), Color.rgb(80, 70, 60)), DOWN, 2,
        listOf("Hey, you! Got a critter? Then let's battle!"),
        listOf("Ow! My Emberpup's all toasted..."),
        listOf("Pia is tougher than me. She's in the grass to the east.")),
    tnpc("pia", "route1", 20, 8, T_PIA, lk(Color.rgb(230, 190, 70), Color.rgb(120, 190, 240), Color.rgb(200, 90, 100)), UP, 2,
        listOf("Stop right there! Picnic's over - it's battle time!"),
        listOf("My sandwiches! My critters! Oh, you're good."),
        listOf("The Warden in Briar Hollow is way stronger than me. Good luck!")),
    talker("bram", "route1", 16, 5, "Hiker Bram", lk(Color.rgb(120, 80, 50), Color.rgb(200, 120, 60), Color.rgb(70, 80, 60), skin = SK2)) {
        if (f("sigil_leaf")) listOf("Willow gave you her Sigil? Lucky. All she ever gave me was 'nice shoes'.")
        else listOf("Tall grass hides wild critters. Beat them to grow stronger, but don't push your luck!",
            "In battle, 'Rest' heals you a bit - the foe still gets a swing, though. You get a few per trip.",
            "There's a Rest Stone right here. And I saw grey-hooded folks heading to Briar Hollow. Gave me the creeps.")
    },

    // ===== Briar Hollow =====
    tnpc("g_briar", "briar", 13, 5, T_GBRIAR, GUILD, DOWN, 3,
        listOf("Halt! The Leaf Shrine is closed by order of the Hollow Guild.",
            "Run along, kid. Unless you want to learn why Baron Gloam's name makes Wardens nervous?"),
        listOf("What?! Beaten by a kid?", "Tch. The Baron said a challenger might turn up. ...Fine. Go in.", "Don't think this changes anything. Hmph!"),
        listOf("..."), show = { !f("t_g_briar") }),
    talker("hazel", "briar", 20, 6, "Herbalist Hazel", lk(Color.rgb(60, 120, 60), Color.rgb(170, 220, 150), Color.rgb(100, 80, 60))) {
        if (f("sigil_leaf")) listOf("You beat Willow! Those leaf critters nibble my herbs, so thank you for being gentle.")
        else listOf("Welcome to Briar Hollow! I brew tonics from moss and glowberries.",
            "A tip: Leaf critters beat Water types. But Fire critters beat Leaf - mind your partner!")
    },
    talker("garn", "briar", 7, 9, "Woodcutter Garn", lk(Color.rgb(140, 70, 40), Color.rgb(200, 60, 60), Color.rgb(70, 70, 80), skin = SK2)) {
        if (f("t_g_briar")) listOf("You chased off that Guild thug?! The whole Hollow owes you a drink!")
        else listOf("Warden Willow hasn't left her shrine since the Bell went quiet.",
            "Then grey-hooded thugs showed up and blocked the door. Nobody can get near!")
    },

    // ===== Leaf Shrine =====
    tnpc("clover", "leafshrine", 8, 7, T_CLOVER, lk(Color.rgb(90, 160, 70), Color.rgb(120, 190, 100), Color.rgb(90, 80, 70), K_ROBE), LEFT, 3,
        listOf("The Leaf Shrine tests every visitor. I'm Clover - first test!"),
        listOf("Roots and rain... you've got real heart."),
        listOf("Bramble guards the way ahead. He's sneakier than he looks.")),
    tnpc("bramble", "leafshrine", 3, 4, T_BRAMBLE, lk(Color.rgb(100, 60, 30), Color.rgb(120, 190, 100), Color.rgb(90, 80, 70), K_ROBE), RIGHT, 3,
        listOf("You got past Clover? Impressive. I am Bramble. Let's see how you handle two critters!"),
        listOf("Thorny... Go on. Warden Willow is waiting."),
        listOf("Warden Willow only duels those who are not afraid. Are you?")),
    Npc("willow", "leafshrine", 6, 2, WILLOW, lk(Color.rgb(40, 110, 60), Color.rgb(80, 170, 100), Color.rgb(60, 90, 60), K_ROBE, SK2), DOWN, 3, T_WILLOW) {
        if (f("sigil_leaf")) listOf(say(WILLOW, "The Leaf Sigil suits you. Go south, along Saltwind Shore to Tidewatch Harbor. Marina holds the Tide Sigil."))
        else listOf(
            say(WILLOW, "So. You are the one who sent that Guild thug packing. I watched from my window."),
            say(WILLOW, "I am Willow, Warden of Leaf. My Sigil is not given to the strong... only to the trusted."),
            say(WILLOW, "Show me the bond between you and your partner!"),
            fight(T_WILLOW, sigilScene("sigil_leaf", "Leaf", WILLOW, SPROUTLE, listOf(
                "You came because of the silent Bell, yes? Then you should know who is behind it.",
                "The Hollow Guild answers to Baron Gloam. He studied with Marina, Cinder and me - brilliant, and always afraid.",
                "He believed critters should be commanded, not befriended. We cast him out. If the Guild is on the move, he wants something at the Heart Bell.",
                "Go south to Tidewatch Harbor. Marina holds the Tide Sigil. Be careful - the Guild knows your face now."))))
    },

    // ===== Route 2: Saltwind Shore =====
    tnpc("finn", "route2", 8, 9, T_FINN, lk(Color.rgb(230, 230, 230), Color.rgb(250, 250, 250), Color.rgb(40, 60, 120), skin = SK2), RIGHT, 3,
        listOf("Ahoy, landlubber! Nobody walks my shore without a battle!"),
        listOf("Shiver me timbers! You sank my fleet!"),
        listOf("Tidewatch is straight south over the bridge. Mind the tide!")),
    tnpc("lyra", "route2", 12, 13, T_LYRA, lk(Color.rgb(30, 30, 60), Color.rgb(60, 180, 220), Color.rgb(60, 180, 220), skin = SK3), LEFT, 2,
        listOf("Splash! You've wandered into my swimming spot. Battle me!"),
        listOf("Glub... Okay, okay, you can pass."),
        listOf("The water's lovely, but even the fish seem nervous lately.")),
    talker("odo", "route2", 9, 16, "Fisher Odo", lk(Color.rgb(200, 200, 200), Color.rgb(220, 190, 80), Color.rgb(60, 90, 70), skin = SK2)) {
        listOf("Fishing's been awful. Even the fish are on edge since the Bell went quiet.",
            "Tidewatch is just across the bridge. Water critters beat Fire, but Leaf beats them. Remember that!")
    },

    // ===== Tidewatch Harbor =====
    tnpc("g_tide", "tidewatch", 20, 5, T_GTIDE, GUILD, DOWN, 3,
        listOf("This harbor is under Guild protection now. The Tide Shrine is closed.", "Nobody sees Warden Marina without going through me!"),
        listOf("Gah! Another one?! The Baron really did predict you...", "Fine, fine. Marina is all yours. Not that it'll help."),
        listOf("..."), show = { !f("t_g_tide") }),
    talker("rusty", "tidewatch", 6, 6, "Dockhand Rusty", lk(Color.rgb(110, 60, 30), Color.rgb(90, 130, 170), Color.rgb(70, 70, 70), skin = SK3)) {
        listOf("Guild ships docked here two nights ago. Unloaded crates and left without a word.",
            "The crates hummed. I swear it! Like a bell... but wrong.")
    },
    talker("sal", "tidewatch", 9, 6, "Net-mender Sal", lk(Color.rgb(230, 130, 90), Color.rgb(240, 200, 140), Color.rgb(100, 90, 120))) {
        if (f("sigil_tide")) listOf("You won against Marina? She trained those divers herself! Respect.")
        else listOf("Warden Marina's been training divers all week. They say the sea speaks to her.",
            "There's a Rest Stone by the water. Use it before you challenge anyone.")
    },
    Npc("kit_t", "tidewatch", 19, 6, KIT, lk(Color.rgb(40, 170, 200), Color.rgb(250, 200, 50), Color.rgb(70, 70, 90)), LEFT,
        show = { f("sigil_tide") && !f("t_kit2") }) {
        listOf(
            say(KIT, "Hey! There you are! You beat Marina too?!"),
            say(KIT, "Willow gave me a lecture instead of a Sigil. She says I'm not ready... so battle me! I'll show her!"),
            fight(T_KIT2,
                listOf(say(KIT, "Wow. Okay, you're ahead. But I'm catching up!"),
                    say(KIT, "I'm going to scout Gloam Pass. Be careful - Guild people are everywhere.")),
                listOf(say(KIT, "Ha! I win this round! Don't worry, rest up and find me again."), act { set("t_kit2") })))
    },

    // ===== Tide Shrine =====
    tnpc("nerio", "tideshrine", 3, 7, T_NERIO, lk(Color.rgb(20, 20, 40), Color.rgb(50, 130, 200), Color.rgb(50, 130, 200), K_ROBE, SK3), RIGHT, 3,
        listOf("The tide tests before it lets anyone pass. I'm Nerio!"),
        listOf("You flow like water! Impressive."),
        listOf("Coral is stronger than me. She always has been.")),
    tnpc("coral", "tideshrine", 8, 4, T_CORAL, lk(Color.rgb(240, 120, 150), Color.rgb(50, 130, 200), Color.rgb(50, 130, 200), K_ROBE), LEFT, 3,
        listOf("I'm Coral. Let's see if you can swim against my two critters!"),
        listOf("A perfect wave... Marina is waiting."),
        listOf("Warden Marina has a gentle voice. Don't be fooled.")),
    Npc("marina", "tideshrine", 6, 2, MARINA, lk(Color.rgb(30, 60, 130), Color.rgb(70, 140, 230), Color.rgb(50, 90, 150), K_ROBE, SK3), DOWN, 3, T_MARINA) {
        if (f("sigil_tide")) listOf(say(MARINA, "The Tide Sigil is yours. Take the Ashen Trail east to Cinderpeak. Cinder holds the last one."))
        else listOf(
            say(MARINA, "Willow's Sigil already glows in your pack. I can feel it from here."),
            say(MARINA, "I am Marina, Warden of Tide. Gloam's thugs have been circling my harbor for days. Let me see why Willow trusted you."),
            fight(T_MARINA, sigilScene("sigil_tide", "Tide", MARINA, AQUAFIN, listOf(
                "The Bell is not broken. It is missing its Chime Core - the heart of the Bell. Gloam took it three nights ago.",
                "And yet... it doesn't add up. If Gloam wanted our Sigils, why only frighten us? Why not take them?",
                "Almost as if he wanted us to *choose* someone. Be wary of the Baron's kindness, if he ever shows any.",
                "Cinder holds the last Sigil, in Cinderpeak. Follow the Ashen Trail east."))))
    },

    // ===== Route 3: Ashen Trail =====
    tnpc("brock", "route3", 11, 5, T_BROCK, lk(Color.rgb(80, 50, 30), Color.rgb(190, 110, 50), Color.rgb(70, 60, 50), skin = SK2), DOWN, 2,
        listOf("Hold it! Hikers' rules: crossing my trail means a battle!"),
        listOf("My boots! My critters! My pride!"),
        listOf("The ash is thick today. Even the Fire types are coughing.")),
    tnpc("rye", "route3", 21, 8, T_RYE, lk(Color.rgb(230, 80, 40), Color.rgb(240, 120, 60), Color.rgb(60, 50, 50)), UP, 2,
        listOf("Hot shot coming through! Name's Rye. Let's see you handle the heat!"),
        listOf("Too hot... too... you win."),
        listOf("Cinderpeak's Warden is the real fire. I'm just sparks.")),
    tnpc("vik", "route3", 25, 5, T_VIK, GUILD, DOWN, 2,
        listOf("Stop. The Hollow Guild controls this road. Turn back."),
        listOf("The Baron's plan was perfect! How are you still winning?!", "Hmph. Go on. You'd get through anyway."),
        listOf("Don't tell the Baron I let you pass."), show = guildGone),
    talker("rangerash", "route3", 16, 5, "Ranger Ash", lk(Color.rgb(160, 160, 160), Color.rgb(80, 110, 80), Color.rgb(70, 60, 50), skin = SK2)) {
        listOf("Cinderpeak lies just east. The air shimmers there - and so does the Warden's temper.",
            "I knew Cinder as a kid. Gloam too. They were inseparable until... well. Until he lost his partner.")
    },

    // ===== Cinderpeak =====
    tnpc("g_cinder", "cinder", 9, 4, T_GCINDER, GUILD, DOWN, 3,
        listOf("The Ember Shrine is off limits! Guild orders!", "One more step and I'll show you what the Baron's critters can do!"),
        listOf("Argh! You're nothing like the others..!", "The Baron said you'd be good. He didn't say you'd be THIS good."),
        listOf("..."), show = { !f("t_g_cinder") }),
    talker("forge", "cinder", 4, 6, "Smith Forge", lk(Color.rgb(60, 40, 30), Color.rgb(120, 70, 50), Color.rgb(50, 50, 50), skin = SK3)) {
        listOf("Cinderpeak's smithy has forged Warden Sigils for a thousand years.",
            "Each Sigil is tuned to a different pulse: leaf, tide, ember. Together they unlock the Shrine Gate.")
    },
    talker("spice", "cinder", 20, 6, "Cook Spice", lk(Color.rgb(230, 100, 50), Color.rgb(250, 250, 250), Color.rgb(90, 80, 70))) {
        if (f("sigil_ember")) listOf("Beat Warden Cinder! Here, have a spicy bun. Okay, no, I ate it. Sorry.")
        else listOf("Everyone's tense. The Bell's silence makes the lava bubble strangely.",
            "Rest at the stone by the road. You look like you've been walking all day.")
    },

    // ===== Ember Shrine =====
    tnpc("ash", "embershrine", 3, 7, T_ASH, lk(Color.rgb(210, 60, 30), Color.rgb(230, 100, 50), Color.rgb(60, 40, 40), K_ROBE), RIGHT, 3,
        listOf("I carry the Ember Shrine's torch. Fight me for the right to pass!"),
        listOf("My torch... still burns! But you burn brighter."),
        listOf("Flint's flames are wilder than mine. Careful.")),
    tnpc("flint", "embershrine", 8, 4, T_FLINT, lk(Color.rgb(250, 190, 60), Color.rgb(230, 100, 50), Color.rgb(60, 40, 40), K_ROBE, SK2), LEFT, 3,
        listOf("Spark and flint! Let's see if you catch fire!"),
        listOf("Burned out. Wow. Cinder's waiting."),
        listOf("The Warden tests hearts, not just strength.")),
    Npc("cinder", "embershrine", 6, 2, CINDER, lk(Color.rgb(120, 20, 20), Color.rgb(230, 90, 50), Color.rgb(90, 40, 30), K_ROBE, SK2), DOWN, 3, T_CINDER) {
        if (f("sigil_ember")) listOf(say(CINDER, "You carry all three Sigils now. Follow the road north out of Cinderpeak to Gloam Pass."))
        else listOf(
            say(CINDER, "Two Sigils already. Willow and Marina both vouched for you in letters, you know. Fast crows."),
            say(CINDER, "I am Cinder, Warden of Ember. Gloam and I were like siblings once. So I will test you harder than the others."),
            fight(T_CINDER, sigilScene("sigil_ember", "Ember", CINDER, EMBERPUP, listOf(
                "Gloam's partner Wick vanished the night the Bell stuttered, when we were kids. He never forgave the Bell for it.",
                "Don't hate him blindly. Beat him if you must, but bring him back from the dark. For me.",
                "The Pass leads to the Shrine Gate, north of town. Take the three Sigils with you. And rest first."))))
    },

    // ===== Route 4: Gloam Pass =====
    Npc("kit_p", "route4", 10, 12, KIT, lk(Color.rgb(40, 170, 200), Color.rgb(250, 200, 50), Color.rgb(70, 70, 90)), DOWN,
        show = { f("sigil_ember") }) {
        when {
            f("ending") -> listOf(say(KIT, "I stayed to hold the line. And I'd do it again!"))
            f("gate_open") -> listOf(say(KIT, "He just... let us open it? That's creepy. Go! I'll keep the Guild off your back."))
            f("t_kit3") -> listOf(say(KIT, "The gate's up ahead. I'll hold the Guild off down here. Go get him!"))
            else -> kit3Scene()
        }
    },
    tnpc("g_pass1", "route4", 13, 8, T_GPASS1, GUILD, LEFT, 3,
        listOf("You're not getting to the Gate, brat!"), listOf("Impossible!"), listOf("The Baron is waiting at the gate..."), guildGone),
    tnpc("g_pass2", "route4", 8, 6, T_GPASS2, GUILD, RIGHT, 3,
        listOf("Intruder! The Gate stays shut!"), listOf("The Baron will not be pleased..."), listOf("..."), guildGone),
    Npc("gloam_g", "route4", 11, 1, GLOAM, lk(Color.rgb(200, 200, 215), Color.rgb(60, 40, 90), Color.rgb(40, 30, 60), K_ROBE),
        DOWN, 0, null, { f("gloam_here") && !f("gloam_left") }) { listOf(say(GLOAM, "Do come in.")) },

    // ===== Hollow Keep =====
    tnpc("g_keep1", "keep", 5, 18, T_GKEEP1, GUILD, RIGHT, 5,
        listOf("Halt! Who let you in?!", "...The Baron did, I suppose. Doesn't mean I'll go easy!"), listOf("You win... again."),
        listOf("The Baron said to let you through. I didn't believe him."), guildGone),
    tnpc("g_keep2", "keep", 14, 14, T_GKEEP2, GUILD, LEFT, 5,
        listOf("This is the end of the line, kid!"), listOf("Oof. Fine, fine."), listOf("Strongest of us is Lieutenant Vex. Good luck."), guildGone),
    tnpc("g_keep3", "keep", 6, 10, T_GKEEP3, GUILD, RIGHT, 4,
        listOf("Hold! You're meant to be on our side - no, wait, you're not!"), listOf("Okay, you ARE good."),
        listOf("There's a Rest Stone right here. Don't tell the Baron I mentioned it."), guildGone),
    tnpc("g_keep4", "keep", 13, 5, T_GKEEP4, GUILD, LEFT, 4,
        listOf("You came all this way for nothing. The Bell belongs to the Baron!"), listOf("The Bell belongs... to everyone?"),
        listOf("Vex is right up ahead. I'd turn back."), guildGone),
    Npc("vex", "keep", 9, 1, "Lieutenant Vex", lk(Color.rgb(220, 60, 160), Color.rgb(110, 40, 90), Color.rgb(50, 30, 60), K_HOOD), DOWN, 4, T_VEX, { !f("t_vex") && !f("ending") }) {
        if (f("t_vex")) listOf(say("Lieutenant Vex", "Go. The Baron is waiting. He... I think he wants to be stopped."))
        else listOf(
            say("Lieutenant Vex", "I am Vex, the Baron's right hand. You've made it further than anyone."),
            say("Lieutenant Vex", "But the Heart Chamber door stays closed. The Baron has plans, and I'll make sure no one spoils them!"),
            fight(T_VEX, listOf(say("Lieutenant Vex", "...He said you'd win. Go. Finish this."))))
    },

    // ===== Heart Chamber =====
    Npc("gloam", "heart", 6, 4, GLOAM, lk(Color.rgb(200, 200, 215), Color.rgb(60, 40, 90), Color.rgb(40, 30, 60), K_ROBE), DOWN, 5, T_GLOAM) {
        when {
            f("ending") -> listOf(say(GLOAM, "I ring the Bell at every dawn. Perhaps Wick is listening."),
                say(GLOAM, "Thank you. Not for stopping me - for the second chance."))
            !f("t_gloam") -> listOf(say(GLOAM, "Back already? Place the Sigils in the cradle or face me again!"), fight(T_GLOAM, gloamAfter()))
            else -> emptyList()
        }
    },
    talker("w_willow", "heart", 4, 9, WILLOW, lk(Color.rgb(40, 110, 60), Color.rgb(80, 170, 100), Color.rgb(60, 90, 60), K_ROBE, SK2), RIGHT,
        show = { f("heart_crowd") && !f("champion") }) { listOf("Breathe. The Bell is ringing.") },
    talker("w_marina", "heart", 9, 9, MARINA, lk(Color.rgb(30, 60, 130), Color.rgb(70, 140, 230), Color.rgb(50, 90, 150), K_ROBE, SK3), LEFT,
        show = { f("heart_crowd") && !f("champion") }) { listOf("The sea sounds calm again.") },
    talker("w_cinder", "heart", 4, 7, CINDER, lk(Color.rgb(120, 20, 20), Color.rgb(230, 90, 50), Color.rgb(90, 40, 30), K_ROBE, SK2), RIGHT,
        show = { f("heart_crowd") && !f("champion") }) { listOf("Gloam... I'm still angry. But I'm glad you're alive.") },
    talker("w_fern", "heart", 9, 7, FERN, lk(Color.rgb(200, 200, 210), Color.rgb(246, 246, 250), Color.rgb(80, 80, 110), K_COAT, SK2), LEFT,
        show = { f("heart_crowd") && !f("champion") }) { listOf("Marvelous! Simply marvelous!") },
    talker("w_kit", "heart", 8, 10, KIT, lk(Color.rgb(40, 170, 200), Color.rgb(250, 200, 50), Color.rgb(70, 70, 90)), UP,
        show = { f("heart_crowd") && !f("champion") }) { listOf("Told you! Told everyone!") },

    // ===== After the credits: peaceful Mossbrook =====
    Npc("kit_post", "mossbrook", 12, 7, KIT, lk(Color.rgb(40, 170, 200), Color.rgb(250, 200, 50), Color.rgb(70, 70, 90)), LEFT,
        show = { f("champion") }) {
        listOf(
            say(KIT, "Champion! The Bell rings every dawn and I still get goosebumps."),
            ask(KIT, "Rematch? I've been training for weeks. No holding back!", listOf("Bring it on!", "Maybe later")) {
                if (it == 0) listOf(say(KIT, "Let's go!"), fight(T_KIT4, listOf(say(KIT, "Argh! Beaten again! ...But that was my best battle ever. Thanks."))))
                else listOf(say(KIT, "I'll be here. Practising my victory pose."))
            })
    }
)

val NPC_BY_MAP: Map<String, List<Npc>> = NPCS.groupBy { it.map }
