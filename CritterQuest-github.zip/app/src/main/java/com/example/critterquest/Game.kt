package com.example.critterquest

import kotlin.math.min
import kotlin.random.Random

const val MOVE_MS = 150L       // time to walk one tile
const val MAX_HEALS = 5        // "Rest" uses per trip (refilled at Rest Stones)
const val MAX_ORBS = 8         // Critter Orbs per trip (refilled at Rest Stones)
const val WILD_RATE = 14       // % chance of a wild critter per step in tall grass

/**
 * All story/world state and rules. No Android classes in here: GameView only draws it and feeds it input,
 * which is also what lets tools/ run the whole story headless.
 */
class Game(val rnd: Random = Random.Default) {
    val flags = HashSet<String>()
    var map: GameMap = MAPS.getValue("home")
    var px = 4; var py = 6; var face = UP
    var fromX = 4; var fromY = 6; var moveT0 = -10_000L
    var stepCount = 0
    var starter = -1
    val party = ArrayList<Mon>().also { it.add(Mon(DEX[0], 5)) } // party[0] is always your first partner
    val me get() = party[0]
    var heals = MAX_HEALS
    var orbs = MAX_ORBS
    val box = ArrayList<Mon>()                 // critters waiting at Mom's (the party holds 6)
    val dexCaught = HashSet<Int>()             // DEX indices you have owned: the Critterdex count
    var restMap = "home"; var restX = 4; var restY = 6
    var clock = 0L

    // script runner
    private val queue = ArrayDeque<Step>()
    var cur: Step? = null          // the Say / Ask currently on screen
    var battleReq: BattleReq? = null
    private var fightAfter: List<Step> = emptyList()
    private var fightLose: List<Step>? = null
    private var waitUntil = 0L
    var alert: Npc? = null         // trainer that just spotted you ("!")
    var endingPending = false
    var saveHook: ((String) -> Unit)? = null
    var bannerName = ""; var bannerAt = 0L
    private var arrivePending = false
    private val npcFace = HashMap<String, Int>()

    fun f(flag: String) = flag in flags
    fun set(flag: String) { flags.add(flag) }
    val sigils get() = listOf("sigil_leaf", "sigil_tide", "sigil_ember").count { f(it) }

    // ---------------- lifecycle ----------------
    fun newGame() {
        flags.clear(); npcFace.clear(); queue.clear(); cur = null; battleReq = null; alert = null; endingPending = false
        starter = -1; party.clear(); party.add(Mon(DEX[0], 5)); heals = MAX_HEALS; orbs = MAX_ORBS
        box.clear(); dexCaught.clear()
        restMap = "home"; restX = 4; restY = 6
        enter("home", 4, 6, UP)
        play(intro())
    }

    fun chooseStarter(i: Int) {
        starter = i; party.clear(); party.add(Mon(DEX[i], 5)); heals = MAX_HEALS; orbs = MAX_ORBS; set("starter")
        dexCaught.add(i)
    }

    fun addToParty(species: Int, lvl: Int) { if (party.size < MAX_PARTY) party.add(Mon(DEX[species], lvl)); dexCaught.add(species) }
    fun healAll() { party.forEach { it.heal() }; heals = MAX_HEALS; orbs = MAX_ORBS }

    /** Mom's box: swap party member [pi] with boxed critter [bi] (either may be -1 to just deposit / withdraw). */
    fun deposit(pi: Int) { if (party.size > 1 && pi in party.indices) box.add(party.removeAt(pi).also { it.heal() }) }
    fun withdraw(bi: Int) { if (party.size < MAX_PARTY && bi in box.indices) party.add(box.removeAt(bi)) }

    fun restHere() {
        healAll()
        restMap = map.id; restX = px; restY = py
        save()
    }

    private fun blackout() {
        healAll()
        enter(restMap, restX, restY, DOWN)
        play(listOf(narr("You blacked out...  Your critter is exhausted, but safe."),
            narr("You come to at the last Rest Stone, fully rested.")))
    }

    /** Called when the credits finish: back to a peaceful Mossbrook, game saved as "Champion". */
    fun finishGame() {
        set("champion"); healAll()
        restMap = "home"; restX = 4; restY = 6
        enter("home", 4, 6, UP)
        endingPending = false
        save()
    }

    private fun enter(id: String, x: Int, y: Int, dir: Int) {
        if (id != map.id || bannerName.isEmpty()) { map = MAPS.getValue(id); bannerName = map.name; bannerAt = clock }
        px = x; py = y; fromX = x; fromY = y; face = dir; moveT0 = -10_000L; arrivePending = false
    }

    // ---------------- save / load ----------------
    fun serialize(): String = buildString {
        append("map=${map.id}\nx=$px\ny=$py\nface=$face\nstarter=$starter\n")
        append("party=${party.joinToString(";") { pack(it) }}\nheals=$heals\norbs=$orbs\n")
        append("box=${box.joinToString(";") { pack(it) }}\ndex=${dexCaught.sorted().joinToString(",")}\n")
        append("rest=$restMap:$restX:$restY\nflags=${flags.joinToString(",")}\n")
    }

    /** One critter as text: species:level:xp:hp:Move/pp,Move/pp... (moves are saved by name). */
    private fun pack(m: Mon) = "${DEX.indexOf(m.s)}:${m.lvl}:${m.xp}:${m.hp}:" + m.moves.joinToString(",") { "${it.move.name}/${it.pp}" }

    private fun unpack(e: String): Mon {
        val q = e.split(':')
        val m = Mon(DEX[q[0].toInt()], q[1].toInt())
        m.xp = q[2].toInt()
        if (q.size > 4 && q[4].isNotBlank()) {   // older saves have no moves: they keep the level's default set
            val ms = q[4].split(',').mapNotNull { p ->
                mvOrNull(p.substringBeforeLast('/'))?.let { mo -> MoveSlot(mo, p.substringAfterLast('/', "").toIntOrNull()?.coerceIn(0, mo.pp) ?: mo.pp) }
            }
            if (ms.isNotEmpty()) { m.moves.clear(); m.moves.addAll(ms.take(4)) }
        }
        m.hp = q[3].toInt().coerceIn(1, m.maxHp)
        return m
    }

    fun save() { saveHook?.invoke(serialize()) }

    fun load(s: String): Boolean {
        return try {
        val kv = s.lines().filter { '=' in it }.associate { it.substringBefore('=') to it.substringAfter('=') }
        val m = MAPS[kv["map"]] ?: return false
        flags.clear(); flags.addAll(kv["flags"].orEmpty().split(',').filter { it.isNotBlank() })
        starter = kv["starter"]!!.toInt()
        party.clear()
        for (e in kv["party"]!!.split(';')) party.add(unpack(e))
        if (party.isEmpty()) return false
        box.clear(); kv["box"].orEmpty().split(';').filter { it.isNotBlank() }.forEach { box.add(unpack(it)) }
        dexCaught.clear(); kv["dex"].orEmpty().split(',').mapNotNull { it.toIntOrNull() }.filter { it in DEX.indices }.forEach { dexCaught.add(it) }
        party.forEach { dexCaught.add(DEX.indexOf(it.s)) }; box.forEach { dexCaught.add(DEX.indexOf(it.s)) }
        heals = kv["heals"]!!.toInt()
        orbs = kv["orbs"]?.toIntOrNull() ?: MAX_ORBS
        val r = kv["rest"]!!.split(':'); restMap = r[0]; restX = r[1].toInt(); restY = r[2].toInt()
        queue.clear(); cur = null; battleReq = null; alert = null; endingPending = false; npcFace.clear()
        bannerName = ""; map = m
        var x = kv["x"]!!.toInt(); var y = kv["y"]!!.toInt()
        if (m.tile(x, y).solid) { map = MAPS.getValue(restMap); x = restX; y = restY }
        enter(map.id, x, y, kv["face"]!!.toInt())
        true
        } catch (e: Exception) { false }
    }

    // ---------------- world queries ----------------
    fun npcs(): List<Npc> = (NPC_BY_MAP[map.id] ?: emptyList()).filter { it.show(this) }
    fun npcAt(x: Int, y: Int): Npc? = npcs().firstOrNull { it.x == x && it.y == y }
    fun npcFacing(n: Npc) = npcFace[n.id] ?: n.face

    fun solid(x: Int, y: Int): Boolean {
        val t = map.tile(x, y)
        if (t == Tl.GATE) return !f("gate_open")
        return t.solid || npcAt(x, y) != null
    }

    /** No script, fight or step in progress. */
    val scriptDone get() = cur == null && queue.isEmpty() && battleReq == null && !arrivePending

    fun idle(now: Long) =
        cur == null && queue.isEmpty() && battleReq == null && !arrivePending && now - moveT0 >= MOVE_MS && now >= waitUntil

    // ---------------- input ----------------
    /** Turn / walk one tile. Returns true if the player actually started moving. */
    fun step(dir: Int, now: Long): Boolean {
        clock = now
        if (!idle(now)) return false
        face = dir
        val nx = px + DX[dir]; val ny = py + DY[dir]
        if (nx < 0 || ny < 0 || nx >= map.w || ny >= map.h) return false
        val w = map.warpAt(nx, ny)
        if (w?.need != null && !w.need.invoke(this)) { play(listOf(narr(w.deny))); return false }
        if (solid(nx, ny)) return false
        fromX = px; fromY = py; px = nx; py = ny; moveT0 = now; stepCount++; arrivePending = true
        return true
    }

    /** OK pressed in the world: talk to / read / use whatever is in front of the player. */
    fun interact(now: Long): Boolean {
        clock = now
        if (!idle(now)) return false
        val tx = px + DX[face]; val ty = py + DY[face]
        val n = npcAt(tx, ty)
        if (n != null) { npcFace[n.id] = opposite(face); play(n.talk(this)); return true }
        val s = tileScript(this, map, tx, ty, map.tile(tx, ty)) ?: return false
        play(s); return true
    }

    // ---------------- script runner ----------------
    fun play(list: List<Step>) { queue.addAll(0, list); pump() }

    /** Player pressed OK on the current Say / Ask (choice = chosen option for Ask). */
    fun advance(choice: Int = 0) {
        val s = cur ?: return
        cur = null
        if (s is Step.Ask) queue.addAll(0, s.then(this, choice))
        pump()
    }

    private fun pump() {
        if (clock >= waitUntil) alert = null
        while (cur == null && battleReq == null && clock >= waitUntil) {
            when (val s = queue.removeFirstOrNull() ?: return) {
                is Step.Say, is Step.Ask -> cur = s
                is Step.Act -> s.f(this)
                is Step.Cond -> queue.addAll(0, if (s.test(this)) s.yes else s.no)
                is Step.Alert -> { alert = NPCS.firstOrNull { it.id == s.npcId }; waitUntil = clock + 800 }
                is Step.Wait -> waitUntil = clock + s.ms
                is Step.Fight -> { battleReq = BattleReq(s.t, null); fightAfter = s.after; fightLose = s.lose }
            }
        }
    }

    /** Advance time: finish steps, fire arrival events, resume waiting scripts. */
    fun tick(now: Long) {
        clock = now
        if (arrivePending && now - moveT0 >= MOVE_MS) { arrivePending = false; onArrive() }
        if (cur == null && battleReq == null && queue.isNotEmpty() && now >= waitUntil) pump()
        else if (now >= waitUntil) alert = null
    }

    /** res: 1 = won, 2 = lost, 3 = got away, 4 = caught [caught] */
    fun battleDone(res: Int, caught: Mon? = null) {
        val req = battleReq ?: return
        battleReq = null
        party.forEach { dexCaught.add(DEX.indexOf(it.s)) } // evolutions count too
        when (res) {
            1 -> {
                if (req.trainer != null) { set("t_" + req.trainer.id); heals = min(MAX_HEALS, heals + 1) }
                queue.addAll(0, fightAfter)
            }
            4 -> if (caught != null) {
                val sp = DEX.indexOf(caught.s)
                dexCaught.add(sp)
                if (party.size < MAX_PARTY) { party.add(caught); queue.addAll(0, listOf(narr("${caught.s.name} joined your party!", sp))) }
                else { box.add(caught.also { it.heal() }); queue.addAll(0, listOf(narr("Your party is full. ${caught.s.name} was sent to Mom's box at home.", sp))) }
            }
            2 -> {
                queue.clear()
                val l = fightLose
                if (l != null) { healAll(); queue.addAll(l) } else blackout()
            }
        }
        fightAfter = emptyList(); fightLose = null
        pump()
    }

    // ---------------- arrival events ----------------
    private fun onArrive() {
        val w = map.warpAt(px, py)
        if (w != null) {
            enter(w.to, w.tx + (px - w.x0), w.ty + (py - w.y0), if (w.face >= 0) w.face else face)
        }
        if (checkTrig() || checkSight() || checkWild()) pump()
    }

    private fun checkTrig(): Boolean {
        for (t in TRIGS) if (t.at(map.id, px, py) && (t.once == null || !f(t.once)) && t.cond(this)) {
            t.once?.let { set(it) }
            play(t.script(this)); return true
        }
        return false
    }

    private fun checkSight(): Boolean {
        for (n in npcs()) {
            val tr = n.trainer ?: continue
            if (n.sight <= 0 || f("t_" + tr.id)) continue
            val nf = npcFacing(n)
            val dx = px - n.x; val dy = py - n.y
            val dist = when {
                nf == DOWN && dx == 0 && dy > 0 -> dy
                nf == UP && dx == 0 && dy < 0 -> -dy
                nf == RIGHT && dy == 0 && dx > 0 -> dx
                nf == LEFT && dy == 0 && dx < 0 -> -dx
                else -> continue
            }
            if (dist > n.sight) continue
            var clear = true
            for (i in 1 until dist) if (solid(n.x + DX[nf] * i, n.y + DY[nf] * i)) clear = false
            if (!clear) continue
            face = opposite(nf)
            play(listOf(Step.Alert(n.id)) + n.talk(this))
            return true
        }
        return false
    }

    private fun checkWild(): Boolean {
        if (map.tile(px, py) != Tl.TALL || map.wild.isEmpty() || rnd.nextInt(100) >= WILD_RATE) return false
        var r = rnd.nextInt(map.wild.sumOf { it.weight })
        for (w in map.wild) {
            r -= w.weight
            if (r < 0) {
                battleReq = BattleReq(null, Mon(DEX[w.sp], w.lo + rnd.nextInt(w.hi - w.lo + 1)))
                return true
            }
        }
        return false
    }
}
