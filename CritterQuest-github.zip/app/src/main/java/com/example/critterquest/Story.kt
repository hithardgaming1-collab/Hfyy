package com.example.critterquest

// ---------------------------------------------------------------------------------------------
// The story spine: opening scene, starter selection, cut-scene triggers, the Shrine Gate twist,
// signs/stones/beds, and the Journal text. NPC lines live in Cast.kt, maps in Maps.kt.
//
//   Prologue  The Heart Bell falls silent. Fern gives you a partner.
//   Ch. 1-3   Earn the Leaf, Tide and Ember Sigils from the three Wardens (Guild grunts in the way).
//   Ch. 4     The Shrine Gate opens... exactly as Baron Gloam planned.
//   Ch. 5     Fight through the Hollow Keep to the Heart Chamber and settle things with Gloam.
// ---------------------------------------------------------------------------------------------

private const val KIT = "Kit"
private const val FERN = "Prof. Fern"
private const val GLOAM = "Baron Gloam"

fun Game.intro(): List<Step> = listOf(
    narr("The Heart Bell of Mossbrook has not rung for three days."),
    narr("Without its chime, the wild critters of the Critterlands have grown restless and afraid."),
    say("Mom", "Good morning, sleepyhead! Did you hear it? ...No. Nothing. The Bell is still silent."),
    say("Mom", "Elder Moss says wild critters get jumpy without its chime. Everyone in the village is on edge."),
    say("Mom", "Professor Fern left a message for you. She wants to see you at her lab. Today!"),
    say("Mom", "Out you go. And remember: you can always rest in your own bed, or at any Rest Stone."),
    narr("Walk with the D-pad. Press OK to talk to people or read signs. Press BACK for the Journal.")
)

// ---- lab: choosing a partner ------------------------------------------------------------------
private fun labIntro(): List<Step> = listOf(
    act { set("kit_in_lab") },
    say(FERN, "Ah, you made it! And Kit is already here, of course."),
    say(KIT, "Told you I'd win the race!"),
    say(FERN, "Listen closely, both of you. The Critterlands are kept calm by the Heart Bell, deep inside the Hollow Keep."),
    say(FERN, "Its chime reaches every critter and soothes their hearts. For three days now, it has been silent."),
    say(FERN, "The wild critters are frightened. And I've heard that grey-hooded strangers, the Hollow Guild, are on the move."),
    say(FERN, "The Keep's gate on Gloam Pass opens only for someone carrying all three Warden Sigils: Leaf, Tide and Ember."),
    say(FERN, "I want you to earn them. Willow in Briar Hollow, Marina at Tidewatch Harbor, Cinder in Cinderpeak."),
    say(KIT, "Wardens, a gate and a mystery? I'm in!"),
    say(FERN, "But nobody travels the wilds alone. On this table are three critter orbs. Walk up to one and press OK."),
    say(FERN, "Remember the starters: Fire beats Leaf, Leaf beats Water, Water beats Fire. And every critter knows up to four moves, each with its own type.")
)

private fun labWrapUp(): List<Step> = listOf(
    say(FERN, "Well fought, both of you! Now, listen to how the road works."),
    say(FERN, "Wild critters live in tall grass. Beat them to grow stronger. At level 10 your partner evolves!"),
    say(FERN, "Take these Critter Orbs too. Weaken a wild critter, then choose Catch to throw one. A Rest Stone refills your orbs."),
    narr("Fern gave you $MAX_ORBS Critter Orbs!"),
    say(FERN, "Every critter learns new moves as it levels up, and each type has strengths and weaknesses. Experiment!"),
    say(FERN, "When you're hurt, touch a glowing Rest Stone in town. It heals you and records your journey."),
    say(FERN, "And press BACK any time to open your Journal. It always tells you where to go next."),
    say(FERN, "Your first stop is Briar Hollow: east through Whisper Meadow. Warden Willow guards the Leaf Sigil."),
    say(KIT, "I'm off! See you in Briar Hollow, slowpoke!"),
    act { set("t_kit1"); restMap = "home"; restX = 4; restY = 6; save() }
)

private fun starterChosen(idx: Int): List<Step> {
    val sp = DEX[idx]
    val km = kitMineFor(idx)
    val third = (0..2).first { it != idx && it != km }
    return listOf(
        act { chooseStarter(idx) },
        narr("You chose ${sp.name}!  Type: ${sp.typeLabel}.  Signature move: ${sp.move}.", idx),
        say(FERN, "A wonderful choice. Look after each other out there.", idx),
        say(KIT, "Then I'll take ${DEX[km].name}! It looks tough!", km),
        say(FERN, "And the last orb is for you as well. A trainer with two partners is twice as prepared!", third),
        act { addToParty(third, 5) },
        narr("You received ${DEX[third].name}, a ${DEX[third].typeLabel} critter!  You can swap partners in battle.", third),
        say(KIT, "Come on, let's test them! A friendly battle, right here, right now!"),
        say(FERN, "Not in my lab... oh, very well. But gently!"),
        fight(T_KIT1,
            listOf(say(KIT, "Whoa. You're strong!"), say(KIT, "Fine, fine. This time. Next time I'll beat you!")) + labWrapUp(),
            listOf(say(KIT, "Ha! I win! Don't worry, even Fern says first battles are rough."),
                say(KIT, "Your partner is just tired. Fern can fix that.")) + labWrapUp()))
}

// ---- the Shrine Gate (the twist) -------------------------------------------------------------
private fun gateScene(): List<Step> = listOf(
    narr("The three Sigils float out of your pack, glowing leaf green, tide blue and ember red."),
    narr("One by one they slide into the sockets. The carvings blaze with light. With a groan, the Shrine Gate swings open."),
    act { set("gate_open"); set("gloam_here") },
    say(GLOAM, "Bravo. Bravo!"),
    say(GLOAM, "Do you know how long I have waited for someone to carry all three Sigils to my door?"),
    say(GLOAM, "The Sigils cannot be stolen. They answer only to trust, freely given. So I made trouble. I let the Wardens grow afraid."),
    say(GLOAM, "And frightened people always find a champion. They found you."),
    say(GLOAM, "Thank you, truly. Now come inside. The Bell and I have a little business to finish, and I do need those Sigils."),
    narr("Baron Gloam steps back into the Keep and the shadows close around him. The Gate stands wide open."),
    act { set("gloam_left") }
)

private fun heartIntro(): List<Step> = listOf(
    narr("The Heart Chamber. A vast round hall. At its far end hangs the Heart Bell, huge and silent."),
    narr("Where its Chime Core should glow, there is only a dark hollow."),
    say(GLOAM, "Welcome, little champion. You carried them all the way here. Leaf, Tide and Ember."),
    narr("He opens his palm. A small orb of golden light pulses there: the Chime Core."),
    say(GLOAM, "The voice of the Heart Bell. I borrowed it three nights ago. Without it, the Bell can only whisper."),
    say(GLOAM, "When I was ten, the Bell stuttered for a single night. My partner, Wick, bolted into the dark. I never saw him again."),
    say(GLOAM, "Since then I have wanted one thing: a chime that never fails. One that does not merely calm critters, but commands them. No more fear. No more running."),
    say(GLOAM, "With the Core and the three Sigils, I can reforge the Bell to my will. Place them in the cradle, as a good guest should."),
    ask("", "What do you do?", listOf("Never!", "The Bell calms. It never commands.")) {
        listOf(
            say(GLOAM, if (it == 0) "Then I will take them. Even Sigils can be won!" else "Calm, command... what is the difference if no critter ever fears again?"),
            say(GLOAM, "Come, then. Let the Bell judge us both!"),
            fight(T_GLOAM, gloamAfter()))
    }
)

// ---- tiles you can press OK on -----------------------------------------------------------------
fun tileScript(g: Game, m: GameMap, x: Int, y: Int, t: Tl): List<Step>? = when (t) {
    Tl.STONE -> listOf(
        narr("A Rest Stone hums with a soft, warm light."), act { restHere() },
        narr("Your critter feels completely refreshed. Journey saved!"))
    Tl.BED -> listOf(ask("", "Sleep in your own bed for a while?", listOf("Sleep", "Not now")) {
        if (it == 0) listOf(narr("Zzz..."), act { restHere() }, narr("You wake up refreshed. Journey saved!")) else emptyList()
    })
    Tl.ORB1, Tl.ORB2, Tl.ORB3 -> {
        val idx = t.ordinal - Tl.ORB1.ordinal
        if (g.f("starter")) listOf(say(FERN, "Those orbs are for new trainers. Your partner is already by your side!"))
        else listOf(ask("", "A warm orb glows on the table. Inside sleeps ${DEX[idx].name}, a ${DEX[idx].typeLabel} critter. Choose ${DEX[idx].name}?",
            listOf("Yes", "No"), idx) {
            if (it == 0) starterChosen(idx) else listOf(say(FERN, "Take your time. It's an important choice!"))
        })
    }
    Tl.GATE -> when {
        g.f("gate_open") -> null
        g.sigils < 3 -> listOf(narr("A towering gate carved with three empty sockets: a leaf, a wave and a flame. They are cold and dark. (Sigils: ${g.sigils}/3)"))
        else -> gateScene()
    }
    Tl.BELL -> listOf(narr(if (g.f("ending")) "The Heart Bell gleams softly. Its chime fills you with calm."
        else "The Heart Bell hangs dark and silent. Something is missing from its centre."))
    else -> m.notes[x to y]?.let { listOf(narr(it)) }
}

// ---- cut-scene triggers ---------------------------------------------------------------------------
val TRIGS: List<Trig> = listOf(
    Trig("mossbrook", 5, 5, 5, 5, "kit_intro", { !f("starter") }) {
        listOf(
            say(KIT, "There you are, slowpoke! Fern has been waiting forever."),
            say(KIT, "She called us both. She's giving out critter partners today! A real adventure, finally!"),
            say(KIT, "Race you to the lab! Last one there gets the leftovers!"),
            act { set("kit_in_lab") })
    },
    Trig("lab", 5, 7, 5, 7, "lab_intro", { !f("starter") }) { labIntro() },
    Trig("tidewatch", 20, 5, 20, 5, null, { f("sigil_tide") && !f("t_kit2") }) {
        NPCS.first { it.id == "kit_t" }.talk(this)
    },
    Trig("route4", 10, 14, 11, 14, null, { f("sigil_ember") && !f("t_kit3") }) { kit3Scene() },
    Trig("keep", 8, 2, 11, 2, null, { !f("t_vex") && !f("ending") }) {
        listOf<Step>(Step.Alert("vex")) + NPCS.first { it.id == "vex" }.talk(this)
    },
    Trig("heart", 0, 9, 13, 10, "gloam_intro", { !f("t_gloam") && !f("ending") }) { heartIntro() }
)

// ---- journal ---------------------------------------------------------------------------------------
fun Game.chapter(): String = when {
    !f("starter") -> "Prologue: A Silent Bell"
    !f("sigil_leaf") -> "Chapter 1: Whisper Meadow"
    !f("sigil_tide") -> "Chapter 2: Saltwind Shore"
    !f("sigil_ember") -> "Chapter 3: The Ashen Trail"
    !f("gate_open") -> "Chapter 4: Gloam Pass"
    !f("ending") -> "Chapter 5: The Hollow Keep"
    else -> "Epilogue: The Bell Rings Again"
}

fun Game.objective(): String = when {
    !f("starter") -> "Visit Professor Fern's lab in Mossbrook and choose your partner."
    !f("sigil_leaf") -> "Follow the road east through Whisper Meadow to Briar Hollow. Earn the Leaf Sigil from Warden Willow."
    !f("sigil_tide") -> "Go south over Saltwind Shore to Tidewatch Harbor. Earn the Tide Sigil from Warden Marina."
    !f("sigil_ember") -> "Cross the Ashen Trail east to Cinderpeak. Earn the Ember Sigil from Warden Cinder."
    !f("gate_open") -> "Carry the three Sigils to the Shrine Gate at the end of Gloam Pass, north of Cinderpeak."
    !f("t_vex") -> "Fight your way through the Hollow Keep."
    !f("ending") -> "Reach the Heart Chamber and stop Baron Gloam."
    else -> "The Bell rings again! Explore, train, and rematch Kit in Mossbrook."
}
