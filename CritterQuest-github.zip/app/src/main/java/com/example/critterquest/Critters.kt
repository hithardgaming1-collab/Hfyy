package com.example.critterquest

import android.graphics.Color
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt
import kotlin.random.Random

// ---------------------------------------------------------------------------------------------
// Species ("the dex"), the Mon (one critter in play) and the battle maths.
// DEX indices are saved in save files: only ever APPEND new species at the end, never reorder.
// Moves are saved by name, so adding moves is always safe.
// ---------------------------------------------------------------------------------------------

/**
 * One kind of critter. [base] = HP, Attack, Defense, Sp. Atk, Sp. Def, Speed. [learn] = (level, move name) pairs.
 * [evo] = DEX index it evolves into at level [evoLvl]. [catchRate] 255 = very easy, 45 = hard.
 */
class Species(
    val name: String, val type: T, val type2: T?, val base: IntArray, val body: Int, val scale: Float, val sig: String,
    val front: Int, val back: Int, val learn: List<Pair<Int, String>>,
    val evo: Int = -1, val evoLvl: Int = 0, val catchRate: Int = 120
) {
    val hp get() = base[0]; val atk get() = base[1]; val def get() = base[2]
    val spa get() = base[3]; val spd get() = base[4]; val spe get() = base[5]
    val types get() = listOfNotNull(type, type2)
    val typeLabel get() = if (type2 == null) type.label else type.label + "/" + type2.label
    /** The move shown on the starter orbs. */
    val move get() = sig.ifEmpty { learn.lastOrNull { mv(it.second).damaging }?.second ?: "Tackle" }
}

const val EMBERPUP = 0
const val AQUAFIN = 1
const val SPROUTLE = 2
const val BLAZEHORN = 3
const val TIDALON = 4
const val THORNPAW = 5
const val PIPWING = 6
const val SWOOPWING = 7
const val NIBBLET = 8
const val GNAWFANG = 9
const val WRIGGLET = 10
const val COCOVEX = 11
const val GLIMMERWING = 12
const val HIVELET = 13
const val STINGMAW = 14
const val ZAPLING = 15
const val VOLTMUNK = 16
const val PEBBLIT = 17
const val BOULDERBACK = 18
const val DUSTPUP = 19
const val SANDJAW = 20
const val HISSLE = 21
const val COILFANG = 22
const val BUDLING = 23
const val BLOOMFANG = 24
const val MINDLE = 25
const val SEEROWL = 26
const val WISPET = 27
const val HAUNTHORN = 28
const val SCRAPPIT = 29
const val BRAWLBEAR = 30
const val FROSTKIT = 31
const val GLACIFOX = 32
const val FLOPFIN = 33
const val TEMPESTAIL = 34
const val CINDERFOAL = 35
const val PYRESTRIDER = 36
const val FLUFFNAP = 37

val DEX = listOf(
    Species("Emberpup", T.FIRE, null, intArrayOf(44, 50, 42, 58, 48, 62), Color.rgb(232, 116, 59), 1.0f, "Flame Burst",
        R.drawable.emberpup_front, R.drawable.emberpup_back,
        listOf(1 to "Scratch", 1 to "Growl", 1 to "Flame Burst", 6 to "Quick Attack", 9 to "Will-O-Wisp", 13 to "Slash", 17 to "Fire Punch"), 3, 10, catchRate = 45),
    Species("Aquafin", T.WATER, null, intArrayOf(50, 46, 52, 56, 54, 44), Color.rgb(79, 163, 224), 1.0f, "Bubble Beam",
        R.drawable.aquafin_front, R.drawable.aquafin_back,
        listOf(1 to "Tackle", 1 to "Tail Whip", 1 to "Bubble Beam", 5 to "Withdraw", 8 to "Aqua Jet", 13 to "Headbutt", 17 to "Waterfall"), 4, 10, catchRate = 45),
    Species("Sproutle", T.LEAF, null, intArrayOf(52, 48, 50, 56, 54, 46), Color.rgb(107, 191, 89), 1.0f, "Vine Whip",
        R.drawable.sproutle_front, R.drawable.sproutle_back,
        listOf(1 to "Tackle", 1 to "Growl", 1 to "Vine Whip", 5 to "Poison Powder", 8 to "Razor Leaf", 13 to "Sleep Powder", 17 to "Mega Drain"), 5, 10, catchRate = 45),
    Species("Blazehorn", T.FIRE, null, intArrayOf(66, 78, 66, 90, 70, 84), Color.rgb(196, 65, 43), 1.15f, "Inferno",
        R.drawable.blazehorn_front, R.drawable.blazehorn_back,
        listOf(1 to "Scratch", 1 to "Growl", 1 to "Flame Burst", 6 to "Quick Attack", 9 to "Will-O-Wisp", 10 to "Inferno", 13 to "Slash", 17 to "Fire Punch", 21 to "Flamethrower", 25 to "Headbutt", 28 to "Swords Dance"), catchRate = 45),
    Species("Tidalon", T.WATER, null, intArrayOf(76, 70, 82, 82, 80, 56), Color.rgb(46, 111, 191), 1.15f, "Tidal Crash",
        R.drawable.tidalon_front, R.drawable.tidalon_back,
        listOf(1 to "Tackle", 1 to "Tail Whip", 1 to "Bubble Beam", 5 to "Withdraw", 8 to "Aqua Jet", 10 to "Tidal Crash", 13 to "Headbutt", 17 to "Waterfall", 22 to "Surf", 27 to "Take Down"), catchRate = 45),
    Species("Thornpaw", T.LEAF, null, intArrayOf(74, 72, 76, 82, 80, 60), Color.rgb(62, 142, 65), 1.15f, "Thorn Storm",
        R.drawable.thornpaw_front, R.drawable.thornpaw_back,
        listOf(1 to "Tackle", 1 to "Growl", 1 to "Vine Whip", 5 to "Poison Powder", 8 to "Razor Leaf", 10 to "Thorn Storm", 13 to "Sleep Powder", 17 to "Mega Drain", 21 to "Giga Drain", 25 to "Headbutt", 28 to "Growth"), catchRate = 45),
    Species("Pipwing", T.NORMAL, T.FLYING, intArrayOf(40, 45, 40, 35, 35, 56), Color.rgb(205, 170, 120), 1.0f, "",
        R.drawable.pipwing_front, R.drawable.pipwing_back,
        listOf(1 to "Tackle", 1 to "Gust", 5 to "Sand Toss", 9 to "Quick Attack", 13 to "Wing Attack"), 7, 16, catchRate = 255),
    Species("Swoopwing", T.NORMAL, T.FLYING, intArrayOf(63, 72, 60, 50, 52, 78), Color.rgb(190, 140, 90), 1.15f, "",
        R.drawable.swoopwing_front, R.drawable.swoopwing_back,
        listOf(1 to "Tackle", 1 to "Gust", 5 to "Sand Toss", 9 to "Quick Attack", 13 to "Wing Attack", 16 to "Aerial Ace", 21 to "Double Team", 25 to "Drill Peck", 29 to "Sky Dive"), catchRate = 120),
    Species("Nibblet", T.NORMAL, null, intArrayOf(30, 56, 35, 25, 35, 72), Color.rgb(180, 150, 200), 1.0f, "",
        R.drawable.nibblet_front, R.drawable.nibblet_back,
        listOf(1 to "Tackle", 1 to "Tail Whip", 4 to "Quick Attack", 8 to "Gnaw", 12 to "Headbutt"), 9, 14, catchRate = 255),
    Species("Gnawfang", T.NORMAL, null, intArrayOf(56, 76, 58, 40, 52, 88), Color.rgb(150, 120, 170), 1.15f, "",
        R.drawable.gnawfang_front, R.drawable.gnawfang_back,
        listOf(1 to "Tackle", 1 to "Tail Whip", 4 to "Quick Attack", 8 to "Gnaw", 12 to "Headbutt", 14 to "Slash", 20 to "Take Down", 26 to "Double-Edge"), catchRate = 127),
    Species("Wrigglet", T.BUG, null, intArrayOf(45, 30, 35, 20, 20, 45), Color.rgb(150, 200, 70), 1.0f, "",
        R.drawable.wrigglet_front, R.drawable.wrigglet_back,
        listOf(1 to "Tackle", 1 to "String Shot"), 11, 6, catchRate = 255),
    Species("Cocovex", T.BUG, null, intArrayOf(50, 20, 55, 25, 25, 30), Color.rgb(190, 190, 90), 1.0f, "",
        R.drawable.cocovex_front, R.drawable.cocovex_back,
        listOf(1 to "Tackle", 1 to "String Shot", 6 to "Harden"), 12, 10, catchRate = 120),
    Species("Glimmerwing", T.BUG, T.FLYING, intArrayOf(60, 45, 50, 88, 78, 72), Color.rgb(200, 120, 220), 1.15f, "",
        R.drawable.glimmerwing_front, R.drawable.glimmerwing_back,
        listOf(1 to "Tackle", 1 to "String Shot", 6 to "Harden", 10 to "Confusion", 13 to "Gust", 16 to "Stun Spore", 20 to "Psybeam", 24 to "Sleep Powder", 28 to "Aerial Ace"), catchRate = 45),
    Species("Hivelet", T.BUG, T.POISON, intArrayOf(40, 50, 35, 25, 35, 50), Color.rgb(235, 200, 60), 1.0f, "",
        R.drawable.hivelet_front, R.drawable.hivelet_back,
        listOf(1 to "Poison Sting", 1 to "String Shot", 6 to "Bug Bite", 11 to "Twin Sting", 15 to "Acid"), 14, 16, catchRate = 255),
    Species("Stingmaw", T.BUG, T.POISON, intArrayOf(65, 82, 55, 45, 60, 78), Color.rgb(220, 170, 40), 1.15f, "",
        R.drawable.stingmaw_front, R.drawable.stingmaw_back,
        listOf(1 to "Poison Sting", 1 to "String Shot", 6 to "Bug Bite", 11 to "Twin Sting", 15 to "Acid", 16 to "Quick Attack", 21 to "Sludge", 26 to "Megahorn"), catchRate = 90),
    Species("Zapling", T.ELECTRIC, null, intArrayOf(35, 40, 30, 50, 40, 70), Color.rgb(250, 220, 70), 1.0f, "",
        R.drawable.zapling_front, R.drawable.zapling_back,
        listOf(1 to "Thunder Shock", 1 to "Growl", 5 to "Quick Attack", 9 to "Thunder Wave", 14 to "Spark", 18 to "Double Team"), 16, 20, catchRate = 190),
    Species("Voltmunk", T.ELECTRIC, null, intArrayOf(60, 65, 52, 82, 66, 96), Color.rgb(240, 190, 40), 1.15f, "",
        R.drawable.voltmunk_front, R.drawable.voltmunk_back,
        listOf(1 to "Thunder Shock", 1 to "Growl", 5 to "Quick Attack", 9 to "Thunder Wave", 14 to "Spark", 18 to "Double Team", 20 to "Thunderbolt", 25 to "Agility", 29 to "Thunder"), catchRate = 75),
    Species("Pebblit", T.ROCK, T.GROUND, intArrayOf(40, 80, 100, 30, 30, 20), Color.rgb(150, 140, 130), 1.0f, "",
        R.drawable.pebblit_front, R.drawable.pebblit_back,
        listOf(1 to "Tackle", 1 to "Harden", 6 to "Rock Throw", 10 to "Mud Shot", 15 to "Rock Tomb", 20 to "Rock Slide"), 18, 25, catchRate = 255),
    Species("Boulderback", T.ROCK, T.GROUND, intArrayOf(80, 110, 128, 55, 65, 45), Color.rgb(120, 110, 100), 1.25f, "",
        R.drawable.boulderback_front, R.drawable.boulderback_back,
        listOf(1 to "Tackle", 1 to "Harden", 6 to "Rock Throw", 10 to "Mud Shot", 15 to "Rock Tomb", 20 to "Rock Slide", 25 to "Earthquake", 29 to "Stone Edge"), catchRate = 45),
    Species("Dustpup", T.GROUND, null, intArrayOf(50, 65, 45, 30, 35, 55), Color.rgb(210, 170, 100), 1.0f, "",
        R.drawable.dustpup_front, R.drawable.dustpup_back,
        listOf(1 to "Scratch", 1 to "Sand Toss", 5 to "Mud Shot", 9 to "Gnaw", 13 to "Bone Smash", 17 to "Burrow Strike"), 20, 20, catchRate = 190),
    Species("Sandjaw", T.GROUND, null, intArrayOf(75, 95, 72, 45, 55, 76), Color.rgb(180, 130, 70), 1.15f, "",
        R.drawable.sandjaw_front, R.drawable.sandjaw_back,
        listOf(1 to "Scratch", 1 to "Sand Toss", 5 to "Mud Shot", 9 to "Gnaw", 13 to "Bone Smash", 17 to "Burrow Strike", 20 to "Slash", 24 to "Earthquake", 28 to "Swords Dance"), catchRate = 90),
    Species("Hissle", T.POISON, null, intArrayOf(35, 60, 44, 40, 54, 55), Color.rgb(150, 100, 190), 1.0f, "",
        R.drawable.hissle_front, R.drawable.hissle_back,
        listOf(1 to "Tackle", 1 to "Leer", 5 to "Poison Sting", 9 to "Gnaw", 13 to "Acid", 17 to "Toxic"), 22, 22, catchRate = 255),
    Species("Coilfang", T.POISON, null, intArrayOf(60, 85, 69, 65, 79, 80), Color.rgb(120, 70, 160), 1.15f, "",
        R.drawable.coilfang_front, R.drawable.coilfang_back,
        listOf(1 to "Tackle", 1 to "Leer", 5 to "Poison Sting", 9 to "Gnaw", 13 to "Acid", 17 to "Toxic", 22 to "Sludge", 27 to "Sludge Bomb"), catchRate = 90),
    Species("Budling", T.LEAF, T.POISON, intArrayOf(45, 49, 49, 65, 65, 45), Color.rgb(100, 190, 150), 1.0f, "",
        R.drawable.budling_front, R.drawable.budling_back,
        listOf(1 to "Tackle", 1 to "Growl", 1 to "Absorb", 5 to "Poison Powder", 9 to "Razor Leaf", 13 to "Sleep Powder"), 24, 15, catchRate = 45),
    Species("Bloomfang", T.LEAF, T.POISON, intArrayOf(78, 82, 84, 100, 100, 62), Color.rgb(70, 150, 120), 1.15f, "",
        R.drawable.bloomfang_front, R.drawable.bloomfang_back,
        listOf(1 to "Tackle", 1 to "Growl", 1 to "Absorb", 5 to "Poison Powder", 9 to "Razor Leaf", 13 to "Sleep Powder", 15 to "Sludge", 20 to "Giga Drain", 25 to "Sludge Bomb", 29 to "Growth"), catchRate = 45),
    Species("Mindle", T.PSYCHIC, null, intArrayOf(38, 30, 36, 70, 50, 60), Color.rgb(240, 200, 120), 1.0f, "",
        R.drawable.mindle_front, R.drawable.mindle_back,
        listOf(1 to "Confusion", 1 to "Barrier", 7 to "Hypnosis", 11 to "Psybeam", 16 to "Amnesia"), 26, 22, catchRate = 100),
    Species("Seerowl", T.PSYCHIC, null, intArrayOf(65, 50, 62, 110, 86, 95), Color.rgb(200, 150, 230), 1.15f, "",
        R.drawable.seerowl_front, R.drawable.seerowl_back,
        listOf(1 to "Confusion", 1 to "Barrier", 7 to "Hypnosis", 11 to "Psybeam", 16 to "Amnesia", 22 to "Psychic", 26 to "Recover", 29 to "Agility"), catchRate = 50),
    Species("Wispet", T.GHOST, T.POISON, intArrayOf(30, 35, 30, 100, 35, 80), Color.rgb(130, 90, 180), 1.0f, "",
        R.drawable.wispet_front, R.drawable.wispet_back,
        listOf(1 to "Lick", 1 to "Smokescreen", 6 to "Night Shade", 11 to "Hypnosis", 16 to "Shadow Claw", 20 to "Sludge"), 28, 24, catchRate = 90),
    Species("Haunthorn", T.GHOST, T.POISON, intArrayOf(45, 50, 45, 115, 55, 95), Color.rgb(100, 60, 150), 1.15f, "",
        R.drawable.haunthorn_front, R.drawable.haunthorn_back,
        listOf(1 to "Lick", 1 to "Smokescreen", 6 to "Night Shade", 11 to "Hypnosis", 16 to "Shadow Claw", 20 to "Sludge", 24 to "Shadow Ball", 28 to "Sludge Bomb"), catchRate = 45),
    Species("Scrappit", T.FIGHTING, null, intArrayOf(55, 80, 50, 35, 35, 35), Color.rgb(200, 120, 80), 1.0f, "",
        R.drawable.scrappit_front, R.drawable.scrappit_back,
        listOf(1 to "Karate Chop", 1 to "Leer", 5 to "Mach Punch", 9 to "Headbutt", 14 to "Brick Break", 19 to "Submission"), 30, 24, catchRate = 180),
    Species("Brawlbear", T.FIGHTING, null, intArrayOf(85, 112, 80, 45, 60, 50), Color.rgb(170, 90, 60), 1.25f, "",
        R.drawable.brawlbear_front, R.drawable.brawlbear_back,
        listOf(1 to "Karate Chop", 1 to "Leer", 5 to "Mach Punch", 9 to "Headbutt", 14 to "Brick Break", 19 to "Submission", 24 to "Cross Chop", 28 to "Swords Dance"), catchRate = 45),
    Species("Frostkit", T.ICE, null, intArrayOf(45, 45, 40, 60, 55, 65), Color.rgb(170, 220, 240), 1.0f, "",
        R.drawable.frostkit_front, R.drawable.frostkit_back,
        listOf(1 to "Powder Snow", 1 to "Tail Whip", 5 to "Quick Attack", 9 to "Icy Wind", 14 to "Ice Shard", 18 to "Aurora Beam"), 32, 22, catchRate = 120),
    Species("Glacifox", T.ICE, null, intArrayOf(72, 70, 66, 95, 90, 86), Color.rgb(130, 190, 230), 1.15f, "",
        R.drawable.glacifox_front, R.drawable.glacifox_back,
        listOf(1 to "Powder Snow", 1 to "Tail Whip", 5 to "Quick Attack", 9 to "Icy Wind", 14 to "Ice Shard", 18 to "Aurora Beam", 22 to "Ice Beam", 28 to "Blizzard"), catchRate = 60),
    Species("Flopfin", T.WATER, null, intArrayOf(20, 10, 55, 15, 20, 80), Color.rgb(230, 120, 100), 1.0f, "",
        R.drawable.flopfin_front, R.drawable.flopfin_back,
        listOf(1 to "Tackle", 1 to "Bubble", 8 to "Water Gun"), 34, 15, catchRate = 255),
    Species("Tempestail", T.WATER, T.FLYING, intArrayOf(80, 105, 72, 70, 86, 80), Color.rgb(60, 120, 200), 1.25f, "",
        R.drawable.tempestail_front, R.drawable.tempestail_back,
        listOf(1 to "Tackle", 1 to "Bubble", 8 to "Water Gun", 15 to "Waterfall", 18 to "Wing Attack", 22 to "Surf", 26 to "Sky Dive"), catchRate = 45),
    Species("Cinderfoal", T.FIRE, null, intArrayOf(50, 80, 55, 62, 62, 88), Color.rgb(240, 150, 60), 1.0f, "",
        R.drawable.cinderfoal_front, R.drawable.cinderfoal_back,
        listOf(1 to "Ember", 1 to "Tail Whip", 5 to "Quick Attack", 9 to "Will-O-Wisp", 14 to "Headbutt", 19 to "Fire Punch"), 36, 24, catchRate = 90),
    Species("Pyrestrider", T.FIRE, null, intArrayOf(68, 100, 70, 82, 82, 106), Color.rgb(210, 90, 50), 1.15f, "",
        R.drawable.pyrestrider_front, R.drawable.pyrestrider_back,
        listOf(1 to "Ember", 1 to "Tail Whip", 5 to "Quick Attack", 9 to "Will-O-Wisp", 14 to "Headbutt", 19 to "Fire Punch", 24 to "Flamethrower", 28 to "Take Down"), catchRate = 45),
    Species("Fluffnap", T.NORMAL, null, intArrayOf(105, 80, 58, 40, 72, 24), Color.rgb(110, 150, 160), 1.25f, "",
        R.drawable.fluffnap_front, R.drawable.fluffnap_back,
        listOf(1 to "Tackle", 1 to "Harden", 6 to "Headbutt", 11 to "Amnesia", 15 to "Body Slam", 20 to "Strength", 25 to "Recover", 28 to "Double-Edge"), catchRate = 25)
)

const val MAX_LVL = 30
const val MAX_PARTY = 6

/** One move a critter knows, with its remaining PP. */
class MoveSlot(val move: Move, var pp: Int = move.pp)

/** One critter in play (yours, a wild one or a trainer's). Stats come from the species' base stats and the level. */
class Mon(var s: Species, var lvl: Int) {
    var xp = 0
    val moves = ArrayList<MoveSlot>()
    // battle-only state, cleared when the fight ends
    var status: St? = null
    var sleep = 0
    var flinch = false
    val stage = IntArray(7)

    val maxHp get() = Rules.hpStat(s.hp, lvl)
    val atk get() = Rules.stat(s.atk, lvl)
    val def get() = Rules.stat(s.def, lvl)
    val spa get() = Rules.stat(s.spa, lvl)
    val spd get() = Rules.stat(s.spd, lvl)
    val spe get() = Rules.stat(s.spe, lvl)
    var hp = maxHp
    var shown = hp.toFloat()

    init { resetMoves() }

    /** The default moveset: the last four moves the species learns up to this level. */
    fun resetMoves() {
        moves.clear()
        val known = ArrayList<Move>()
        for ((l, n) in s.learn) if (l <= lvl) { val m = mv(n); known.remove(m); known.add(m) }
        known.takeLast(4).forEach { moves.add(MoveSlot(it)) }
        if (moves.isEmpty()) moves.add(MoveSlot(mv("Tackle")))
    }

    fun knows(m: Move) = moves.any { it.move === m }
    fun heal() { hp = maxHp; clearBattleState(); moves.forEach { it.pp = it.move.pp } }
    fun clearBattleState() { status = null; sleep = 0; flinch = false; stage.fill(0) }
}

object Rules {
    /** Multiplier of one attacking type against a (possibly dual-typed) defender: 0, 0.25, 0.5, 1, 2 or 4. */
    fun eff(a: T, d: Species): Float = typeMult(a, d.type) * (d.type2?.let { typeMult(a, it) } ?: 1f)
    /** Best multiplier any of an attacker's own types has against a defender (used by the AI and the checker bot). */
    fun eff(a: Species, d: Species): Float = a.types.maxOf { eff(it, d) }

    // Stats follow the classic formula with a fixed "individual value" of 15 for every critter.
    fun stat(base: Int, lvl: Int) = (2 * base + 15) * lvl / 100 + 5
    fun hpStat(base: Int, lvl: Int) = (2 * base + 15) * lvl / 100 + lvl + 10

    fun stageMult(n: Int) = if (n >= 0) (2 + n) / 2f else 2f / (2 - n)
    fun accMult(n: Int) = if (n >= 0) (3 + n) / 3f else 3f / (3 - n)
    fun speed(m: Mon): Float = m.spe * stageMult(m.stage[SPE]) * (if (m.status == St.PAR) 0.5f else 1f)

    fun hits(u: Mon, t: Mon, m: Move, rnd: Random): Boolean {
        if (m.acc == 0) return true
        val st = (u.stage[ACC] - t.stage[EVA]).coerceIn(-6, 6)
        return rnd.nextInt(100) < (m.acc * accMult(st)).toInt()
    }

    fun critRoll(m: Move, rnd: Random) = rnd.nextInt(if (m.crit) 8 else 16) == 0

    fun stab(u: Mon, m: Move) = if (m.type == u.s.type || m.type == u.s.type2) 1.5f else 1f

    fun damage(a: Mon, d: Mon, m: Move, crit: Boolean, rnd: Random = Random): Int {
        if (m.levelDmg) return if (eff(m.type, d.s) == 0f) 0 else a.lvl
        if (m.power <= 0) return 0
        val sp = m.type.special
        var asg = a.stage[if (sp) SPA else ATK]; var dsg = d.stage[if (sp) SPD else DEF]
        if (crit) { asg = max(0, asg); dsg = min(0, dsg) }
        var atk = (if (sp) a.spa else a.atk) * stageMult(asg)
        if (!sp && a.status == St.BRN) atk *= 0.5f
        val def = max(1f, (if (sp) d.spd else d.def) * stageMult(dsg))
        var dmg = ((2f * a.lvl / 5f + 2f) * m.power * atk / def) / 50f + 2f
        if (crit) dmg *= 2f
        dmg *= 0.85f + rnd.nextFloat() * 0.15f
        dmg *= stab(a, m)
        val e = eff(m.type, d.s)
        dmg *= e
        return if (e == 0f) 0 else max(1, dmg.toInt())
    }

    fun xpFor(foe: Mon, trainer: Boolean) = foe.lvl * (if (trainer) 14 else 9)
    fun xpNeed(lvl: Int) = lvl * 20

    /** Critter Orb throw: how many times it wobbles (4 = caught), using the classic capture formula. */
    fun catchShakes(foe: Mon, rnd: Random): Int {
        val bonus = when (foe.status) { St.SLP, St.FRZ -> 2f; null -> 1f; else -> 1.5f }
        val a = (3f * foe.maxHp - 2f * foe.hp) * foe.s.catchRate / (3f * foe.maxHp) * bonus
        if (a >= 255f) return 4
        val b = 1048560.0 / sqrt(sqrt(16711680.0 / a))
        var n = 0
        while (n < 4 && rnd.nextInt(65536) < b) n++
        return n
    }
}
