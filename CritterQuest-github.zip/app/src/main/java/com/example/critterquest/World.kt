package com.example.critterquest

// ---------------------------------------------------------------------------------------------
// World model: tiles, maps, warps, people and the little "script" language used for dialogue.
// Pure Kotlin (no drawing) so the whole story can be unit-tested without a device.
// ---------------------------------------------------------------------------------------------

const val DOWN = 0
const val LEFT = 1
const val RIGHT = 2
const val UP = 3
val DX = intArrayOf(0, -1, 1, 0)
val DY = intArrayOf(1, 0, 0, -1)
fun opposite(d: Int) = 3 - d

enum class Theme { MEADOW, FOREST, SHORE, ASH, KEEP, INDOOR }

/** One character per tile in the ASCII maps (see Maps.kt and MAPS.md). */
enum class Tl(val ch: Char, val solid: Boolean) {
    GROUND('.', false), PATH(',', false), TALL(';', false), TREE('#', true), WATER('~', true), BRIDGE('=', false),
    ROOF('^', true), WALL('h', true), DOOR('D', false), FLOWER('*', false), FENCE('f', true), SIGN('s', true),
    ROCK('R', true), LAVA('L', true), SAND('b', false), FLOOR('_', false), IWALL('W', true), TABLE('T', true),
    BED('B', true), STONE('P', true), GATE('G', true), CRYSTAL('c', true), RUG('r', false), SHELF('K', true),
    ORB1('1', true), ORB2('2', true), ORB3('3', true), BELL('Q', true);

    companion object {
        private val by = values().associateBy { it.ch }
        fun of(c: Char) = by[c]
    }
}

/** Stepping on any tile of the rectangle (x0..x1, y0..y1) moves you to [to]. Relative offsets are kept. */
class Warp(
    val x0: Int, val y0: Int, val x1: Int, val y1: Int, val to: String, val tx: Int, val ty: Int,
    val face: Int = -1, val need: (Game.() -> Boolean)? = null, val deny: String = ""
) {
    fun at(x: Int, y: Int) = x in x0..x1 && y in y0..y1
}

class Wild(val sp: Int, val lo: Int, val hi: Int, val weight: Int = 1)

class GameMap(
    val id: String, val name: String, val theme: Theme, val accent: Int, art: String,
    val warps: List<Warp> = emptyList(), val wild: List<Wild> = emptyList(),
    val notes: Map<Pair<Int, Int>, String> = emptyMap()
) {
    val rows: List<String> = art.trim().lines().map { it.trimEnd() }
    val h = rows.size
    val w = rows.maxOf { it.length }
    fun tile(x: Int, y: Int): Tl =
        if (x < 0 || y < 0 || y >= h || x >= rows[y].length) Tl.TREE else Tl.of(rows[y][x]) ?: Tl.GROUND
    fun warpAt(x: Int, y: Int): Warp? = warps.firstOrNull { it.at(x, y) }
}

// ---- people ----------------------------------------------------------------------------------

const val K_PLAIN = 0
const val K_CAP = 1
const val K_COAT = 2
const val K_HOOD = 3
const val K_ROBE = 4

class Look(val skin: Int, val hair: Int, val top: Int, val legs: Int, val kind: Int = K_PLAIN)

class Trainer(
    val id: String, val name: String, val smart: Boolean = false,
    val team: Game.() -> List<Pair<Int, Int>> // species index (see DEX) to level
)

class Npc(
    val id: String, val map: String, val x: Int, val y: Int, val name: String, val look: Look,
    val face: Int = DOWN, val sight: Int = 0, val trainer: Trainer? = null,
    val show: Game.() -> Boolean = { true },
    val talk: Game.() -> List<Step>
)

/** A cut-scene that fires when the player steps inside a rectangle. */
class Trig(
    val map: String, val x0: Int, val y0: Int, val x1: Int, val y1: Int, val once: String?,
    val cond: Game.() -> Boolean = { true }, val script: Game.() -> List<Step>
) {
    fun at(m: String, x: Int, y: Int) = m == map && x in x0..x1 && y in y0..y1
}

// ---- script steps ----------------------------------------------------------------------------

sealed class Step {
    class Say(val who: String, val text: String, val portrait: Int = -1) : Step()
    class Ask(val who: String, val text: String, val opts: List<String>, val portrait: Int = -1, val then: Game.(Int) -> List<Step>) : Step()
    class Act(val f: Game.() -> Unit) : Step()
    class Fight(val t: Trainer, val after: List<Step> = emptyList(), val lose: List<Step>? = null) : Step()
    class Cond(val test: Game.() -> Boolean, val yes: List<Step>, val no: List<Step> = emptyList()) : Step()
    class Alert(val npcId: String) : Step()
    class Wait(val ms: Long) : Step()
}

class BattleReq(val trainer: Trainer?, val wild: Mon?)

fun say(who: String, text: String, portrait: Int = -1) = Step.Say(who, text, portrait)
fun narr(text: String, portrait: Int = -1) = Step.Say("", text, portrait)
fun act(f: Game.() -> Unit) = Step.Act(f)
fun ask(who: String, text: String, opts: List<String>, portrait: Int = -1, then: Game.(Int) -> List<Step>) = Step.Ask(who, text, opts, portrait, then)
fun fight(t: Trainer, after: List<Step> = emptyList(), lose: List<Step>? = null) = Step.Fight(t, after, lose)
fun cond(test: Game.() -> Boolean, yes: List<Step>, no: List<Step> = emptyList()) = Step.Cond(test, yes, no)
fun team(vararg p: Pair<Int, Int>): Game.() -> List<Pair<Int, Int>> = { p.toList() }
