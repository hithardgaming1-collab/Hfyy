package com.example.critterquest

import android.graphics.Color

// ---------------------------------------------------------------------------------------------
// The world of Critter Quest. Every map is plain ASCII art - edit it right here.
// Legend:  .ground  ,path  ;tall grass (wild critters)  #tree/cliff  ~water  =bridge  ^roof  h wall
//          D door   *flowers  f fence  s sign  R boulder  L lava  b sand  _ floor  W indoor wall
//          T table  B bed  P Rest Stone  G shrine gate  c crystal  r rug  K shelf  1 2 3 starter orbs  Q the Heart Bell
// Row/column 0 is the top-left tile. Warps, wild critters and sign texts are listed under each map.
// ---------------------------------------------------------------------------------------------

val MAPS: Map<String, GameMap> = listOf(
    GameMap("mossbrook", "Mossbrook", Theme.MEADOW, Color.rgb(200, 170, 110), """
########################
#......................#
#..^^^^^......^^^^^^^..#
#..hhhhh......hhhhhhh..#
#..hhDhh......hhhDhhh..#
#*...,.......s...,..*..#
#....,..s........,..*..#
#,,,,,,,,,,,,,,,,,,,,,,,
#,,,,,,,,,,,,,,,,,,,,,,,
#..^^^^^.....ffffffffff#
#..hhhhh..***f~~~~~~~~.#
#..hhhhh...P.f~~~~~~~~.#
#........****f~~~~~~~~.#
#.*.....*....f~~~~~~~~.#
#......................#
########################
""",
        warps = listOf(
        Warp(5, 4, 5, 4, "home", 4, 6, UP),
        Warp(17, 4, 17, 4, "lab", 5, 7, UP),
        Warp(23, 7, 23, 8, "route1", 1, 6, need = { f("starter") },
            deny = "Professor Fern is waiting for you at the lab! You can't go out into the wilds without a partner."),
        ),
        notes = mapOf(
        (8 to 6) to "MOSSBROOK  -  Village of the Heart Bell's first keepers.",
        (13 to 5) to "FERN'S CRITTER LAB  -  Visitors welcome. Please knock first!",
        )),
    GameMap("home", "Your House", Theme.INDOOR, Color.rgb(200, 170, 110), """
WWWWWWWWWW
WKK___TTBW
W________W
W_TT_____W
W__rrrr__W
W__rrrr__W
W________W
WWWWDWWWWW
""",
        warps = listOf(
        Warp(4, 7, 4, 7, "mossbrook", 5, 5, DOWN),
        ),
        notes = mapOf(
        (1 to 1) to "A shelf of dusty almanacs. One is titled 'Critterlands Type Chart for the Curious': Fire beats Leaf, Leaf beats Water, Water beats Fire.",
        (2 to 1) to "Mom's cookbooks. Half the pages are stuck together with berry jam.",
        (6 to 1) to "A framed picture of you and Mom on your first day of school.",
        (7 to 1) to "A framed picture of you and Mom on your first day of school.",
        (2 to 3) to "Mom's famous berry pancakes. They smell amazing.",
        (3 to 3) to "Mom's famous berry pancakes. They smell amazing.",
        )),
    GameMap("lab", "Fern's Lab", Theme.INDOOR, Color.rgb(200, 170, 110), """
WWWWWWWWWWWW
WKKK____KKKW
W__________W
W___T123___W
W__________W
W___rrrr___W
W___rrrr___W
W__________W
WWWWWDWWWWWW
""",
        warps = listOf(
        Warp(5, 8, 5, 8, "mossbrook", 17, 5, DOWN),
        ),
        notes = mapOf(
        (1 to 1) to "Research notes: 'The Heart Bell chimes at dawn and dusk. Its sound calms every critter that hears it.'",
        (2 to 1) to "Research notes: 'Critters grow stronger by battling. Rest Stones restore them and record your journey.'",
        (3 to 1) to "Research notes: 'Elder forms appear when a partner reaches level 10. Their power is remarkable.'",
        (8 to 1) to "A shelf of critter field guides. Every page about the Hollow Keep has been torn out.",
        (9 to 1) to "A shelf of critter field guides. Every page about the Hollow Keep has been torn out.",
        (10 to 1) to "Old Warden records: 'Leaf, Tide and Ember Sigils together open the Shrine Gate on Gloam Pass.'",
        (4 to 3) to "A long table covered in notes and half-finished sketches of critters.",
        )),
    GameMap("route1", "Whisper Meadow", Theme.MEADOW, Color.rgb(200, 170, 110), """
##############################
#*.#...*......~~~...##.......#
#....;;;;;....~~~...;;;;;;*..#
#....;;;;;#...~~~...;;;;;;...#
#.#..;;;;;.....~...*;;;;;;...#
#.s...........P.*...;;;;;;...#
,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
##..#................*.s....##
#..;;;;.*...;;;;;;;...*...##.#
#..;;;;.#...;;;;;;;....*#...##
#*.;;;;.....;;;;;;;..........#
#...........;;;;;;;.......#..#
##############################
""",
        warps = listOf(
        Warp(0, 6, 0, 7, "mossbrook", 22, 7),
        Warp(29, 6, 29, 7, "briar", 1, 7),
        ),
        wild = listOf(
        Wild(NIBBLET, 3, 5, 4), Wild(PIPWING, 3, 5, 4), Wild(WRIGGLET, 3, 5, 3), Wild(BUDLING, 4, 5, 1)
        ),
        notes = mapOf(
        (2 to 5) to "WHISPER MEADOW  -  Wild critters hide in the tall grass. Briar Hollow lies to the east.",
        (23 to 8) to "BRIAR HOLLOW  -  Home of Warden Willow and the Leaf Shrine. Keep going east!",
        )),
    GameMap("briar", "Briar Hollow", Theme.FOREST, Color.rgb(70, 170, 90), """
##########################
##.......*..#..#......##.#
#..^^^^^#.^^^^^^^..^^^^^.#
#..hhhhh..hhhhhhh#.hhhhh.#
#..hhhhh#.hhhDhhh..hhhhh.#
#....,...*...,.......,...#
#....,...s...,.s.....,..##
,,,,,,,,,,,,,,,,,,,,,,,,,,
,,,,,,,,,,,,,,,,,,,,,,,,,,
#.....#....#,,...#.......#
#**^^^^^...*,,#..P.*****.#
#..hhhhh....,,.....******#
#..hhhhh....,,#.#..*****.#
#....#.##...,,..#.....#..#
#...........,,..#.#......#
############,,############
""",
        warps = listOf(
        Warp(0, 7, 0, 8, "route1", 28, 6),
        Warp(12, 15, 13, 15, "route2", 10, 1),
        Warp(13, 4, 13, 4, "leafshrine", 5, 10, UP),
        ),
        notes = mapOf(
        (9 to 6) to "BRIAR HOLLOW  -  A town grown between the roots of the Great Elm.",
        (15 to 6) to "LEAF SHRINE  -  Warden Willow tests all who seek the Leaf Sigil.",
        )),
    GameMap("leafshrine", "Leaf Shrine", Theme.INDOOR, Color.rgb(70, 170, 90), """
WWWWWWWWWWWW
W__________W
W_c__rr__c_W
W____rr____W
W____rr____W
W_c__rr__c_W
W____rr____W
W____rr____W
W_c__rr__c_W
W____rr____W
W__________W
WWWWWDWWWWWW
""",
        warps = listOf(
        Warp(5, 11, 5, 11, "briar", 13, 5, DOWN),
        )),
    GameMap("route2", "Saltwind Shore", Theme.SHORE, Color.rgb(70, 140, 230), """
##########,,##########
#bbbbbbbbb,,bR~~~~~~~#
#*R*bRbbbs,,bb~~~~~~~#
#bb;;;;;bb,,bb~~~~~~~#
#bb;;;;;bb,,bb~~~~~~~#
#bb;;;;;bb,,Rb~~~~~~~#
#bR;;;;;bb,,bb~~~~~~~#
#bb*bbbRbb,,Rb~~~~~~~#
#b;;;;bbbb,,*b~~~~~~~#
#b;;;;bbbb,,bf~~~~~~~#
#b;;;;bbbb,,bbbbbbbbb#
#bbb*bbRbb,,b;;;;;;bb#
#~~~~~~~~b,,b;;;;;;bb#
#~~~~~~~~b,,b;;;;;;bb#
#~~~~~~~~b,,P;;;;;;bb#
#~~~~~~~~b,,bbbbbbRbb#
#~~~~~~~~b,,bbbbbbbbb#
#~~~~~~~~~==~~~~~~~~~#
#~~~~~~~~~==~~~~~~~~~#
#~~~~~~~~~==~~~~~~~~~#
#~~~~~~~~~,,s~~~~~~~~#
##########,,##########
""",
        warps = listOf(
        Warp(10, 0, 11, 0, "briar", 12, 14),
        Warp(10, 21, 11, 21, "tidewatch", 12, 1),
        ),
        wild = listOf(
        Wild(FLOPFIN, 8, 10, 3), Wild(AQUAFIN, 8, 10, 2), Wild(PIPWING, 8, 10, 2), Wild(HIVELET, 8, 10, 2),
        Wild(COCOVEX, 8, 10, 2), Wild(ZAPLING, 9, 10, 1), Wild(DUSTPUP, 9, 10, 1)
        ),
        notes = mapOf(
        (9 to 2) to "SALTWIND SHORE  -  Follow the shell path south to Tidewatch Harbor.",
        (12 to 20) to "Mind the tide! The bridge is slippery at night.",
        )),
    GameMap("tidewatch", "Tidewatch Harbor", Theme.SHORE, Color.rgb(70, 140, 230), """
############,,############
#b*bbbbbbbbb,,bbbbbR*bbbb#
#bb^^^^^bbbb,,bbb^^^^^^^*#
#bbhhhhhRbbb,,bbbhhhhhhhb#
#bbhhhhhb*bb,,*bbhhhDhhhb#
#bbbb,bbbbbb,,bbbbRb,bbRb#
#bbbb,bbbbbb,,bbbbbb,bbbR#
#bbbb,bbbbsb,,bsbbb*,bbbb#
#,,,,,,,,,,,,,,,,,,,,,,,,,
#,,,,,,,,,,,,,,,,,,,,,,,,,
#bbbbbbbPbbbbRbbbbbbbbbbb#
#~~~===~~~===~~~~~===~~~~#
#~~~===~~~===~~~~~===~~~~#
#~~~===~~~===~~~~~===~~~~#
#~~~===~~~===~~~~~===~~~~#
##########################
""",
        warps = listOf(
        Warp(12, 0, 13, 0, "route2", 10, 20),
        Warp(25, 8, 25, 9, "route3", 1, 6),
        Warp(20, 4, 20, 4, "tideshrine", 5, 10, UP),
        ),
        notes = mapOf(
        (10 to 7) to "TIDEWATCH HARBOR  -  Fresh catch daily! The Ashen Trail leads east.",
        (15 to 7) to "TIDE SHRINE  -  Warden Marina welcomes all who respect the sea.",
        )),
    GameMap("tideshrine", "Tide Shrine", Theme.INDOOR, Color.rgb(70, 140, 230), """
WWWWWWWWWWWW
W~~~~__~~~~W
W_~__rr__~_W
W~~~_rr_~~~W
W____rr____W
W_~__rr__~_W
W~~~_rr_~~~W
W____rr____W
W_~__rr__~_W
W~~~_rr_~~~W
W__________W
WWWWWDWWWWWW
""",
        warps = listOf(
        Warp(5, 11, 5, 11, "tidewatch", 20, 5, DOWN),
        )),
    GameMap("route3", "Ashen Trail", Theme.ASH, Color.rgb(240, 100, 50), """
##############################
#.....LLLLLL....R....LLLL.R..#
#.R...LLLLLL.;;;;;;..LLLL...R#
#...R.LLLLLL.;;;;;;..LLLL..R.#
#.....LLLLLL.;;;;;;..........#
#..s...........P.............#
,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
#...R..........R..R......R...#
#RLLLLL.;;;;;;R.LLLLLLLL.;;;;#
#.LLLLL.;;;;;;..LLLLLLLL.;;;;#
#RLLLLL.;;;;;;.RLLLLLLLL.;;;;#
#...............LLLLLLLLR..R.#
##############################
""",
        warps = listOf(
        Warp(0, 6, 0, 7, "tidewatch", 24, 8),
        Warp(29, 6, 29, 7, "cinder", 1, 8),
        ),
        wild = listOf(
        Wild(CINDERFOAL, 12, 14, 3), Wild(PEBBLIT, 12, 14, 3), Wild(DUSTPUP, 12, 14, 2), Wild(HISSLE, 12, 14, 2),
        Wild(SCRAPPIT, 12, 14, 2), Wild(SWOOPWING, 13, 15, 1), Wild(BLAZEHORN, 13, 15, 1)
        ),
        notes = mapOf(
        (3 to 5) to "ASHEN TRAIL  -  Cinderpeak lies to the east. Keep clear of the lava!",
        )),
    GameMap("cinder", "Cinderpeak", Theme.ASH, Color.rgb(240, 100, 50), """
############,,############
#.......^^^R,,.........R.#
#.......hhh.,,.........R.#
#..^^^^^hDhR,,..R^^^^^^..#
#..hhhhh.,..,,...hhhhhh..#
#..hhhhh.,.R,,...hhhhhh..#
#....,...,..,,..R..,.....#
#....,...,s.,,.P...,.....#
,,,,,,,,,,,,,,,,,,,,,,,,,#
,,,,,,,,,,,,,,,,,,,,,,,,,#
#........^^^^^^^.........#
#........hhhhhhh..LLLLLLL#
#LLLLLLL.hhhhhhh..LLLLLLL#
#LLLLLLL...R......LLLLLLL#
#LLLLLLL..........LLLLLLL#
##########################
""",
        warps = listOf(
        Warp(0, 8, 0, 9, "route3", 28, 6),
        Warp(9, 3, 9, 3, "embershrine", 5, 10, UP),
        Warp(12, 0, 13, 0, "route4", 10, 20, need = { f("sigil_ember") },
            deny = "The road to Gloam Pass is sealed by an old Warden barrier. Only someone who has earned the Ember Sigil can pass."),
        ),
        notes = mapOf(
        (10 to 7) to "CINDERPEAK  -  Forged in fire, tempered by trust. Ember Shrine: north.",
        )),
    GameMap("embershrine", "Ember Shrine", Theme.INDOOR, Color.rgb(240, 100, 50), """
WWWWWWWWWWWW
W__________W
W_L__rr__L_W
W____rr____W
W____rr____W
W_L__rr__L_W
W____rr____W
W____rr____W
W_L__rr__L_W
W____rr____W
W__________W
WWWWWDWWWWWW
""",
        warps = listOf(
        Warp(5, 11, 5, 11, "cinder", 9, 4, DOWN),
        )),
    GameMap("route4", "Gloam Pass", Theme.KEEP, Color.rgb(170, 100, 240), """
######################
#........GGGGR.c.R..R#
#.........,,.....R...#
#.........,,.........#
#..R....R.,,...R.....#
#.;;;;;R.R,,.c.R....R#
#.;;;;;...,,R........#
#.;;;;;...,,R.......R#
#R;;;;;...,,.........#
#R.....R..,,...;;;;;.#
#.........,,c..;;;;;.#
#.........,,...;;;;;.#
#.R...c...,,...;;;;;.#
#.........,,.........#
#..;;;;;..,,.........#
#..;;;;;..,,.........#
#..;;;;;..,,..R......#
#..;;;;;..,,P........#
#.........,,.........#
#.........,,.R.......#
#..c.....s,,......c..#
##########,,##########
""",
        warps = listOf(
        Warp(10, 21, 11, 21, "cinder", 12, 1),
        Warp(9, 1, 12, 1, "keep", 8, 22, UP),
        ),
        wild = listOf(
        Wild(GNAWFANG, 16, 18, 3), Wild(SWOOPWING, 16, 18, 2), Wild(WISPET, 16, 18, 2), Wild(MINDLE, 16, 18, 2),
        Wild(FROSTKIT, 16, 18, 2), Wild(ZAPLING, 16, 18, 2), Wild(STINGMAW, 16, 18, 2), Wild(GLIMMERWING, 16, 18, 1),
        Wild(FLUFFNAP, 17, 18, 1)
        ),
        notes = mapOf(
        (9 to 20) to "GLOAM PASS  -  Beyond the Shrine Gate lies the Hollow Keep. Only bearers of all three Sigils may enter.",
        )),
    GameMap("keep", "Hollow Keep", Theme.KEEP, Color.rgb(170, 100, 240), """
WWWWWWWWWDWWWWWWWWWW
W________rr________W
W________rr________W
W________rr________W
W____c___rr___c____W
W________rr________W
W________rr________W
W________rr________W
WWWWWW___rr___WWWWWW
W________rr________W
W__P_____rr_____c__W
W________rr________W
W____c___rr___c____W
WWWWWWW__rr__WWWWWWW
W________rr________W
W________rr________W
W____c___rr___c____W
W________rr________W
W________rr________W
W________rr________W
W____c___rr___c____W
W_______rrrr_______W
W_______rrrr_______W
WWWWWWWWWDDWWWWWWWWW
""",
        warps = listOf(
        Warp(9, 23, 10, 23, "route4", 10, 3, DOWN),
        Warp(9, 0, 9, 0, "heart", 6, 10, UP),
        )),
    GameMap("heart", "Heart Chamber", Theme.KEEP, Color.rgb(255, 210, 90), """
WWWWWWWWWWWWWW
W_____QQ_____W
W_____rr_____W
W_c___rr___c_W
W_____rr_____W
W_____rr_____W
W_c___rr___c_W
W_____rr_____W
W_____rr_____W
W_c__rrrr__c_W
W____________W
WWWWWWDWWWWWWW
""",
        warps = listOf(
        Warp(6, 11, 6, 11, "keep", 9, 1, DOWN),
        ))

).associateBy { it.id }
