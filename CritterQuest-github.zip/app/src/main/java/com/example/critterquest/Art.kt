package com.example.critterquest

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import kotlin.math.abs
import kotlin.math.sin

/** [Art.tile] parts: everything, only the still base of a tile, or only its animated overlay (water ripples). */
const val PART_ALL = 0
const val PART_BASE = 1
const val PART_ANIM = 2
/** Tall grass sways in this many steps per cycle; GameView keeps one pre-drawn picture per step. */
const val GRASS_STEPS = 8

/**
 * Draws world tiles and people from simple shapes (no image files needed).
 * Everything is sized from the tile size [ts]; one "pixel unit" u is ts/16.
 */
class Art(private val p: Paint) {
    private val path = Path()

    private fun rgb(r: Int, g: Int, b: Int) = Color.rgb(r, g, b)
    private fun shade(c: Int, f: Float) = Color.rgb((Color.red(c) * f).toInt().coerceIn(0, 255), (Color.green(c) * f).toInt().coerceIn(0, 255), (Color.blue(c) * f).toInt().coerceIn(0, 255))
    private fun hash(x: Int, y: Int) = ((x * 73856093) xor (y * 19349663)) and 0x7fffffff

    private fun rect(c: Canvas, x: Float, y: Float, w: Float, h: Float, col: Int) { p.style = Paint.Style.FILL; p.color = col; c.drawRect(x, y, x + w, y + h, p) }
    private fun oval(c: Canvas, x: Float, y: Float, w: Float, h: Float, col: Int) { p.style = Paint.Style.FILL; p.color = col; c.drawOval(x, y, x + w, y + h, p) }
    private fun line(c: Canvas, x0: Float, y0: Float, x1: Float, y1: Float, w: Float, col: Int) {
        p.style = Paint.Style.STROKE; p.strokeWidth = w; p.strokeCap = Paint.Cap.ROUND; p.color = col; c.drawLine(x0, y0, x1, y1, p); p.style = Paint.Style.FILL
    }
    private fun poly(c: Canvas, col: Int, vararg v: Float) {
        path.reset(); path.moveTo(v[0], v[1]); var i = 2
        while (i < v.size) { path.lineTo(v[i], v[i + 1]); i += 2 }
        path.close(); p.style = Paint.Style.FILL; p.color = col; c.drawPath(path, p)
    }

    // ---------------- colour palettes per theme ----------------
    private fun ground(th: Theme, h: Int) = when (th) {
        Theme.MEADOW -> if (h % 7 == 0) rgb(116, 194, 88) else rgb(124, 202, 96)
        Theme.FOREST -> if (h % 7 == 0) rgb(78, 144, 76) else rgb(86, 154, 84)
        Theme.SHORE -> if (h % 7 == 0) rgb(220, 204, 156) else rgb(228, 212, 164)
        Theme.ASH -> if (h % 7 == 0) rgb(100, 92, 90) else rgb(110, 101, 99)
        Theme.KEEP -> if (h % 7 == 0) rgb(54, 48, 76) else rgb(62, 56, 84)
        Theme.INDOOR -> rgb(190, 142, 94)
    }
    private fun pathCol(th: Theme) = when (th) {
        Theme.ASH -> rgb(146, 134, 124); Theme.KEEP -> rgb(92, 84, 116); Theme.SHORE -> rgb(236, 224, 190)
        Theme.FOREST -> rgb(176, 148, 102); else -> rgb(206, 176, 124)
    }
    private fun roofCol(th: Theme) = when (th) {
        Theme.FOREST -> rgb(66, 128, 84); Theme.SHORE -> rgb(58, 108, 188); Theme.ASH -> rgb(92, 82, 104); else -> rgb(196, 78, 68)
    }

    // ---------------- still vs live tiles (lets GameView draw the map once and only redraw what moves) ----------------
    /**
     * True for tiles whose picture changes from frame to frame (animation, or a story flag).
     * Every other tile is drawn once into a cached map image. A NEW tile that uses [t] or the flags [g] in [tile]
     * MUST be added here, or it freezes on screen (`./run.sh cache` checks this).
     */
    fun isLive(tl: Tl) = when (tl) {
        Tl.TALL, Tl.WATER, Tl.BRIDGE, Tl.LAVA, Tl.STONE, Tl.CRYSTAL, Tl.ORB1, Tl.ORB2, Tl.ORB3, Tl.GATE, Tl.BELL -> true
        else -> false
    }

    /** What goes into the cached map image: every still tile, and just the plain base of open water. */
    fun drawStill(c: Canvas, g: Game, m: GameMap, x: Int, y: Int, ox: Float, oy: Float, ts: Float) {
        val tl = m.tile(x, y)
        if (!isLive(tl)) tile(c, g, m, x, y, ox, oy, ts, 0f)
        else if (tl == Tl.WATER) tile(c, g, m, x, y, ox, oy, ts, 0f, PART_BASE)
    }

    /** What is drawn on top of the cached image every frame (tall grass is handled by GameView from pre-drawn pictures). */
    fun drawLive(c: Canvas, g: Game, m: GameMap, x: Int, y: Int, ox: Float, oy: Float, ts: Float, t: Float) {
        val tl = m.tile(x, y)
        if (tl == Tl.WATER) tile(c, g, m, x, y, ox, oy, ts, t, PART_ANIM)
        else if (isLive(tl)) tile(c, g, m, x, y, ox, oy, ts, t)
    }

    /** Which of the 3 blade-height patterns the grass at (x, y) uses. */
    fun grassVariant(x: Int, y: Int) = hash(x, y) % 3
    /** Which sway step (0 until [GRASS_STEPS]) the grass in column [x] is in at time [t] seconds. */
    fun grassStep(x: Int, t: Float): Int {
        val tau = 6.2831855f
        return (((t * 2.2f + x) % tau) / tau * GRASS_STEPS).toInt().coerceIn(0, GRASS_STEPS - 1)
    }

    /** Tall grass. [ph] is the sway phase, [hv] (0..2) the blade heights. */
    fun tallGrass(c: Canvas, th: Theme, hv: Int, ph: Float, ox: Float, oy: Float, ts: Float) {
        val u = ts / 16f
        rect(c, ox, oy, ts, ts, shade(ground(th, 0), 0.9f))
        for (i in 0..4) {
            val bx = ox + (2 + 3 * i) * u; val sway = sin(ph + i) * u
            val col = if (i % 2 == 0) rgb(52, 146, 60) else rgb(74, 172, 80)
            line(c, bx, oy + 15 * u, bx + sway, oy + (5 + (hv + i) % 3) * u, 1.8f * u, col)
        }
    }

    /** Draw one tile at screen position (ox, oy). [m] gives the neighbours, [g] the story flags. Positions must be whole pixels. */
    fun tile(c: Canvas, g: Game, m: GameMap, x: Int, y: Int, ox: Float, oy: Float, ts: Float, t: Float, part: Int = PART_ALL) {
        val tl = m.tile(x, y); val th = m.theme; val h = hash(x, y); val u = ts / 16f
        val floorBase = { if (th == Theme.KEEP) floorKeep(c, ox, oy, ts, h) else floorWood(c, ox, oy, ts, h) }
        when (tl) {
            Tl.GROUND -> {
                rect(c, ox, oy, ts, ts, ground(th, h))
                if (h % 6 == 0) { val bx = ox + (h % 9 + 3) * u; val by = oy + (h / 7 % 9 + 5) * u
                    line(c, bx, by, bx - u, by - 3 * u, 1.3f * u, shade(ground(th, 0), 0.8f)); line(c, bx + 2 * u, by, bx + 3 * u, by - 3 * u, 1.3f * u, shade(ground(th, 0), 0.8f)) }
                if (th == Theme.KEEP && h % 9 == 0) line(c, ox + 3 * u, oy + 4 * u, ox + 9 * u, oy + 8 * u, u, rgb(40, 36, 60))
            }
            Tl.PATH -> {
                rect(c, ox, oy, ts, ts, pathCol(th))
                if (h % 3 == 0) rect(c, ox + (h % 11 + 2) * u, oy + (h / 5 % 11 + 2) * u, 2 * u, 1.5f * u, shade(pathCol(th), 0.88f))
                if (h % 5 == 0) rect(c, ox + (h % 7 + 5) * u, oy + (h / 3 % 9 + 3) * u, 1.5f * u, 1.5f * u, shade(pathCol(th), 1.1f))
            }
            Tl.SAND -> {
                rect(c, ox, oy, ts, ts, ground(Theme.SHORE, h))
                if (h % 4 == 0) rect(c, ox + (h % 12 + 2) * u, oy + (h / 5 % 12 + 2) * u, 1.5f * u, 1.5f * u, rgb(206, 188, 140))
            }
            Tl.TALL -> tallGrass(c, th, h % 3, t * 2.2f + x, ox, oy, ts)
            Tl.TREE -> {
                rect(c, ox, oy, ts, ts, ground(th, h))
                when (th) {
                    Theme.ASH -> { rect(c, ox + 6 * u, oy + 6 * u, 4 * u, 10 * u, rgb(58, 46, 44)); line(c, ox + 8 * u, oy + 8 * u, ox + 3 * u, oy + 3 * u, 1.6f * u, rgb(58, 46, 44)); line(c, ox + 8 * u, oy + 9 * u, ox + 13 * u, oy + 4 * u, 1.6f * u, rgb(58, 46, 44)) }
                    Theme.KEEP -> { poly(c, rgb(42, 38, 62), ox, oy + 16 * u, ox + 3 * u, oy + 2 * u, ox + 8 * u, oy + 7 * u, ox + 13 * u, oy + 1 * u, ox + 16 * u, oy + 16 * u); poly(c, rgb(60, 54, 86), ox + 3 * u, oy + 2 * u, ox + 8 * u, oy + 7 * u, ox + 6 * u, oy + 12 * u) }
                    else -> {
                        val dark = if (th == Theme.FOREST) rgb(28, 98, 54) else rgb(40, 130, 56)
                        rect(c, ox + 6.5f * u, oy + 9 * u, 3 * u, 7 * u, rgb(104, 70, 42))
                        oval(c, ox + 0.5f * u, oy + 0.5f * u, 15 * u, 12 * u, dark)
                        oval(c, ox + 2 * u, oy + 1 * u, 8 * u, 6 * u, shade(dark, 1.25f))
                    }
                }
            }
            Tl.WATER, Tl.BRIDGE -> {
                if (part != PART_ANIM) rect(c, ox, oy, ts, ts, rgb(54, 124, 212))
                if (part != PART_BASE) {
                    val wx = ((t * 6 + h % 16) % 16) * u
                    rect(c, ox + wx % (12 * u), oy + (h % 8 + 3) * u, 4 * u, 1.2f * u, rgb(140, 196, 248))
                    rect(c, ox + (wx + 7 * u) % (12 * u), oy + (h / 3 % 8 + 8) * u, 3 * u, 1.2f * u, rgb(110, 170, 236))
                }
                if (tl == Tl.BRIDGE) {
                    rect(c, ox + 1 * u, oy, 14 * u, ts, rgb(160, 112, 66))
                    for (i in 0..3) rect(c, ox + 1 * u, oy + (i * 4 + 3) * u, 14 * u, 0.8f * u, rgb(110, 74, 42))
                    rect(c, ox + 1 * u, oy, 1.2f * u, ts, rgb(118, 82, 48)); rect(c, ox + 13.8f * u, oy, 1.2f * u, ts, rgb(118, 82, 48))
                }
            }
            Tl.ROOF -> {
                val rc = roofCol(th)
                rect(c, ox, oy, ts, ts, rc)
                for (i in 0..3) rect(c, ox, oy + (i * 4 + 3) * u, ts, 0.9f * u, shade(rc, 0.78f))
                rect(c, ox, oy, ts, 2 * u, shade(rc, 1.2f))
                if (m.tile(x - 1, y) != Tl.ROOF) rect(c, ox, oy, 1.2f * u, ts, shade(rc, 0.7f))
                if (m.tile(x + 1, y) != Tl.ROOF) rect(c, ox + 14.8f * u, oy, 1.2f * u, ts, shade(rc, 0.7f))
            }
            Tl.WALL, Tl.DOOR -> {
                val wall = if (th == Theme.ASH) rgb(176, 160, 150) else rgb(238, 226, 198)
                rect(c, ox, oy, ts, ts, wall)
                if (m.tile(x, y - 1) == Tl.ROOF) rect(c, ox, oy, ts, 2 * u, rgb(90, 60, 40)) // eaves shadow
                if (tl == Tl.WALL && m.tile(x, y - 1) == Tl.ROOF && h % 2 == 0) {
                    rect(c, ox + 4 * u, oy + 4 * u, 8 * u, 8 * u, rgb(110, 76, 48))
                    rect(c, ox + 5 * u, oy + 5 * u, 6 * u, 6 * u, rgb(150, 210, 245))
                    rect(c, ox + 7.7f * u, oy + 5 * u, 0.7f * u, 6 * u, rgb(110, 76, 48))
                }
                if (m.tile(x, y + 1) != Tl.WALL && m.tile(x, y + 1) != Tl.DOOR) rect(c, ox, oy + 14 * u, ts, 2 * u, rgb(150, 136, 120))
                if (tl == Tl.DOOR) {
                    rect(c, ox + 3 * u, oy + 2 * u, 10 * u, 14 * u, rgb(86, 56, 36))
                    rect(c, ox + 4 * u, oy + 3 * u, 8 * u, 13 * u, rgb(138, 92, 56))
                    rect(c, ox + 7.6f * u, oy + 3 * u, 0.8f * u, 13 * u, rgb(96, 64, 40))
                    oval(c, ox + 9.8f * u, oy + 9 * u, 1.6f * u, 1.6f * u, rgb(250, 210, 80))
                }
            }
            Tl.FLOWER -> {
                rect(c, ox, oy, ts, ts, ground(th, h))
                val cols = intArrayOf(rgb(240, 90, 120), rgb(250, 210, 70), rgb(250, 250, 250), rgb(170, 120, 240))
                for (i in 0..2) {
                    val fx = ox + (3 + i * 5 + h % 3) * u; val fy = oy + (4 + (h / (i + 3)) % 8) * u
                    line(c, fx, fy, fx, fy + 4 * u, u, rgb(50, 130, 50))
                    oval(c, fx - 1.8f * u, fy - 1.8f * u, 3.6f * u, 3.6f * u, cols[(h + i) % 4]); oval(c, fx - 0.6f * u, fy - 0.6f * u, 1.2f * u, 1.2f * u, rgb(250, 240, 120))
                }
            }
            Tl.FENCE -> {
                rect(c, ox, oy, ts, ts, ground(th, h))
                val l = m.tile(x - 1, y) == Tl.FENCE; val r = m.tile(x + 1, y) == Tl.FENCE
                val wood = rgb(160, 112, 66)
                if (l || r || true) { if (l) rect(c, ox, oy + 6 * u, 8 * u, 1.8f * u, wood); if (r) rect(c, ox + 8 * u, oy + 6 * u, 8 * u, 1.8f * u, wood)
                    if (l) rect(c, ox, oy + 10 * u, 8 * u, 1.8f * u, wood); if (r) rect(c, ox + 8 * u, oy + 10 * u, 8 * u, 1.8f * u, wood) }
                rect(c, ox + 6.5f * u, oy + 3 * u, 3 * u, 11 * u, shade(wood, 0.85f))
                if (m.tile(x, y - 1) == Tl.FENCE) rect(c, ox + 7 * u, oy, 2 * u, 3 * u, shade(wood, 0.85f))
                if (m.tile(x, y + 1) == Tl.FENCE) rect(c, ox + 7 * u, oy + 14 * u, 2 * u, 2 * u, shade(wood, 0.85f))
            }
            Tl.SIGN -> {
                rect(c, ox, oy, ts, ts, if (th == Theme.KEEP || th == Theme.ASH) ground(th, h) else ground(th, h))
                rect(c, ox + 7 * u, oy + 8 * u, 2 * u, 7 * u, rgb(110, 74, 42))
                rect(c, ox + 2 * u, oy + 2.5f * u, 12 * u, 7 * u, rgb(176, 128, 76)); rect(c, ox + 3 * u, oy + 3.5f * u, 10 * u, 5 * u, rgb(224, 190, 130))
                rect(c, ox + 4 * u, oy + 4.7f * u, 8 * u, 0.9f * u, rgb(110, 74, 42)); rect(c, ox + 4 * u, oy + 6.4f * u, 6 * u, 0.9f * u, rgb(110, 74, 42))
            }
            Tl.ROCK -> {
                rect(c, ox, oy, ts, ts, ground(th, h))
                oval(c, ox + 1.5f * u, oy + 5 * u, 13 * u, 10 * u, rgb(120, 120, 128)); oval(c, ox + 3 * u, oy + 5.5f * u, 6 * u, 4 * u, rgb(170, 170, 178))
                oval(c, ox + 6 * u, oy + 11 * u, 8 * u, 3 * u, rgb(90, 90, 98))
            }
            Tl.LAVA -> {
                rect(c, ox, oy, ts, ts, rgb(214, 66, 20))
                val k = sin(t * 2f + h) * 0.5f + 0.5f
                oval(c, ox + (2 + h % 6) * u, oy + (3 + h / 3 % 6) * u, (4 + 2 * k) * u, (3 + k) * u, rgb(255, 168, 40))
                oval(c, ox + (8 + h % 4) * u, oy + (9 + h / 5 % 4) * u, 3 * u, 2.2f * u, rgb(255, 214, 90))
                for (d in 0..3) {
                    val nb = m.tile(x + DX[d], y + DY[d])
                    if (nb != Tl.LAVA) when (d) { UP -> rect(c, ox, oy, ts, 2 * u, rgb(70, 30, 20)); DOWN -> rect(c, ox, oy + 14 * u, ts, 2 * u, rgb(70, 30, 20))
                        LEFT -> rect(c, ox, oy, 2 * u, ts, rgb(70, 30, 20)); else -> rect(c, ox + 14 * u, oy, 2 * u, ts, rgb(70, 30, 20)) }
                }
            }
            Tl.FLOOR -> floorBase()
            Tl.IWALL -> {
                if (th == Theme.KEEP) {
                    rect(c, ox, oy, ts, ts, rgb(40, 36, 62))
                    for (i in 0..3) rect(c, ox, oy + (i * 4 + 3) * u, ts, 0.8f * u, rgb(26, 22, 44))
                    for (i in 0..3) rect(c, ox + ((i % 2) * 8 + 5) * u, oy + i * 4 * u, 0.8f * u, 4 * u, rgb(26, 22, 44))
                } else {
                    rect(c, ox, oy, ts, ts, rgb(150, 106, 74))
                    rect(c, ox, oy, ts, 3 * u, rgb(176, 130, 92)); rect(c, ox, oy + 13 * u, ts, 3 * u, rgb(110, 76, 52))
                    rect(c, ox + 7.6f * u, oy + 3 * u, 0.8f * u, 10 * u, rgb(128, 90, 62))
                }
            }
            Tl.TABLE -> {
                floorBase()
                rect(c, ox + 1 * u, oy + 5 * u, 14 * u, 6 * u, rgb(170, 116, 66)); rect(c, ox + 1 * u, oy + 5 * u, 14 * u, 1.6f * u, rgb(206, 150, 94))
                rect(c, ox + 2 * u, oy + 11 * u, 2 * u, 4 * u, rgb(120, 80, 46)); rect(c, ox + 12 * u, oy + 11 * u, 2 * u, 4 * u, rgb(120, 80, 46))
            }
            Tl.BED -> {
                floorBase()
                rect(c, ox + 1 * u, oy + 1 * u, 14 * u, 14 * u, rgb(120, 80, 46)); rect(c, ox + 2 * u, oy + 2 * u, 12 * u, 12 * u, rgb(226, 90, 90))
                rect(c, ox + 3 * u, oy + 3 * u, 10 * u, 3.5f * u, rgb(250, 250, 250)); rect(c, ox + 2 * u, oy + 8 * u, 12 * u, 1.2f * u, rgb(190, 60, 60))
            }
            Tl.SHELF -> {
                floorBase()
                rect(c, ox + 0.5f * u, oy + 1 * u, 15 * u, 14 * u, rgb(116, 78, 46))
                val cols = intArrayOf(rgb(200, 70, 70), rgb(70, 130, 200), rgb(230, 190, 70), rgb(80, 170, 100), rgb(160, 90, 190))
                for (row in 0..1) { rect(c, ox + 1.5f * u, oy + (2 + row * 6.5f) * u, 13 * u, 5.5f * u, rgb(70, 46, 28))
                    for (i in 0..5) rect(c, ox + (2 + i * 2.1f) * u, oy + (2.8f + row * 6.5f) * u, 1.7f * u, 4.2f * u, cols[(h + i + row) % 5]) }
            }
            Tl.STONE -> {
                if (th == Theme.INDOOR || th == Theme.KEEP) floorBase() else rect(c, ox, oy, ts, ts, if (m.tile(x, y + 1) == Tl.PATH) ground(th, h) else ground(th, h))
                val pulse = 0.55f + 0.45f * sin(t * 2.4f)
                p.style = Paint.Style.FILL; p.color = Color.argb((70 * pulse).toInt(), 120, 255, 230); c.drawCircle(ox + 8 * u, oy + 8 * u, 9 * u, p)
                poly(c, rgb(112, 124, 134), ox + 3 * u, oy + 15 * u, ox + 4 * u, oy + 4 * u, ox + 8 * u, oy + 1 * u, ox + 12 * u, oy + 4 * u, ox + 13 * u, oy + 15 * u)
                poly(c, rgb(146, 160, 170), ox + 4 * u, oy + 4 * u, ox + 8 * u, oy + 1 * u, ox + 8 * u, oy + 15 * u, ox + 3 * u, oy + 15 * u)
                line(c, ox + 8 * u, oy + 5 * u, ox + 8 * u, oy + 11 * u, 1.6f * u, Color.argb((150 + 105 * pulse).toInt(), 120, 255, 230))
                line(c, ox + 6 * u, oy + 8 * u, ox + 10 * u, oy + 8 * u, 1.6f * u, Color.argb((150 + 105 * pulse).toInt(), 120, 255, 230))
            }
            Tl.RUG -> {
                floorBase()
                val a = m.accent
                rect(c, ox, oy, ts, ts, shade(a, 0.55f))
                val edge = shade(a, 0.9f)
                if (m.tile(x - 1, y) != Tl.RUG) rect(c, ox, oy, 1.6f * u, ts, edge)
                if (m.tile(x + 1, y) != Tl.RUG) rect(c, ox + 14.4f * u, oy, 1.6f * u, ts, edge)
                if (m.tile(x, y - 1) != Tl.RUG) rect(c, ox, oy, ts, 1.6f * u, edge)
                if (m.tile(x, y + 1) != Tl.RUG) rect(c, ox, oy + 14.4f * u, ts, 1.6f * u, edge)
                if ((x + y) % 2 == 0) rect(c, ox + 6 * u, oy + 6 * u, 4 * u, 4 * u, shade(a, 0.7f))
            }
            Tl.CRYSTAL -> {
                if (th == Theme.INDOOR || th == Theme.KEEP) floorBase() else rect(c, ox, oy, ts, ts, ground(th, h))
                val a = m.accent; val pulse = 0.5f + 0.5f * sin(t * 2f + x)
                p.style = Paint.Style.FILL; p.color = Color.argb((60 * pulse).toInt() + 20, Color.red(a), Color.green(a), Color.blue(a)); c.drawCircle(ox + 8 * u, oy + 9 * u, 8 * u, p)
                poly(c, shade(a, 0.8f), ox + 4 * u, oy + 15 * u, ox + 5 * u, oy + 6 * u, ox + 8 * u, oy + 1 * u, ox + 11 * u, oy + 6 * u, ox + 12 * u, oy + 15 * u)
                poly(c, shade(a, 1.2f), ox + 5 * u, oy + 6 * u, ox + 8 * u, oy + 1 * u, ox + 8 * u, oy + 15 * u, ox + 4 * u, oy + 15 * u)
            }
            Tl.ORB1, Tl.ORB2, Tl.ORB3 -> {
                floorBase()
                rect(c, ox + 1 * u, oy + 6 * u, 14 * u, 9 * u, rgb(170, 116, 66)); rect(c, ox + 1 * u, oy + 6 * u, 14 * u, 1.6f * u, rgb(206, 150, 94))
                oval(c, ox + 4 * u, oy + 7.5f * u, 8 * u, 3 * u, rgb(90, 90, 110)) // cradle
                if (!g.f("starter")) {
                    val sp = DEX[tl.ordinal - Tl.ORB1.ordinal]; val pulse = 0.6f + 0.4f * sin(t * 3f + x)
                    p.style = Paint.Style.FILL; p.color = Color.argb((90 * pulse).toInt(), Color.red(sp.type.col), Color.green(sp.type.col), Color.blue(sp.type.col)); c.drawCircle(ox + 8 * u, oy + 5 * u, 7 * u, p)
                    p.color = sp.type.col; c.drawCircle(ox + 8 * u, oy + 5 * u, 4 * u, p)
                    p.color = Color.argb(180, 255, 255, 255); c.drawCircle(ox + 6.6f * u, oy + 3.6f * u, 1.2f * u, p)
                }
            }
            Tl.GATE -> {
                // A tall stone archway (it draws upward into the cliff row above). Sockets glow once their Sigil is owned.
                rect(c, ox, oy, ts, ts, ground(th, h))
                val first = (0..m.w).first { m.tile(it, y) == Tl.GATE }
                val count = (first until m.w).takeWhile { m.tile(it, y) == Tl.GATE }.size
                val idx = x - first; val edge = idx == 0 || idx == count - 1
                val stone = rgb(122, 114, 154); val dark = rgb(84, 78, 112); val top = oy - 14 * u
                val open = g.f("gate_open")
                rect(c, ox, top, ts, ts + 14 * u, stone)
                for (i in 0..4) rect(c, ox, top + (4 + i * 5.2f) * u, ts, 0.8f * u, dark)
                rect(c, ox, top, ts, 2.5f * u, rgb(170, 162, 200))
                if (idx == 0) rect(c, ox, top, 3 * u, ts + 14 * u, dark)
                if (idx == count - 1) rect(c, ox + 13 * u, top, 3 * u, ts + 14 * u, dark)
                if (open) {
                    rect(c, ox + (if (idx == 0) 3f else 0f) * u, oy - 8 * u, ts - (if (edge) 3f else 0f) * u, ts + 8 * u, rgb(14, 10, 26))
                    val pulse = 0.5f + 0.5f * sin(t * 2f + x)
                    p.style = Paint.Style.FILL; p.color = Color.argb((90 * pulse).toInt() + 30, 200, 160, 255); c.drawCircle(ox + 8 * u, oy + 6 * u, 8 * u, p)
                } else {
                    val flags = arrayOf("sigil_leaf", "sigil_tide", "sigil_ember")
                    val cols = intArrayOf(rgb(70, 210, 110), rgb(70, 160, 250), rgb(255, 120, 50))
                    p.style = Paint.Style.FILL; p.color = shade(dark, 0.7f); c.drawCircle(ox + 8 * u, oy + 2 * u, 6 * u, p)
                    if (idx in 0..2) {
                        val own = g.f(flags[idx]); val pulse = 0.6f + 0.4f * sin(t * 2.5f + idx)
                        if (own) { p.color = Color.argb((110 * pulse).toInt(), Color.red(cols[idx]), Color.green(cols[idx]), Color.blue(cols[idx])); c.drawCircle(ox + 8 * u, oy + 2 * u, 9 * u, p) }
                        p.color = if (own) cols[idx] else rgb(44, 40, 62); c.drawCircle(ox + 8 * u, oy + 2 * u, 4.5f * u, p)
                    } else { poly(c, rgb(60, 54, 84), ox + 8 * u, oy - 3 * u, ox + 11 * u, oy + 2 * u, ox + 8 * u, oy + 7 * u, ox + 5 * u, oy + 2 * u) }
                }
            }
            Tl.BELL -> {
                // The Bell is two tiles wide: each half draws its side around the shared edge, so camera cuts never hide it.
                floorKeep(c, ox, oy, ts, h)
                val left = m.tile(x + 1, y) == Tl.BELL
                val cx = if (left) ox + 16 * u else ox
                val done = g.f("ending"); val sw = if (done) sin(t * 2.2f) * 0.5f * u else 0f
                rect(c, if (left) ox - 1 * u else ox, oy - 13 * u, 17 * u, 2.5f * u, rgb(96, 64, 40))         // beam in the wall above
                rect(c, cx - 1 * u, oy - 11 * u, 2 * u, 13 * u, rgb(70, 70, 76))                                 // hanger
                poly(c, rgb(214, 160, 56), cx - 5 * u + sw, oy + 2 * u, cx + 5 * u + sw, oy + 2 * u, cx + 12 * u, oy + 15.5f * u, cx - 12 * u, oy + 15.5f * u)
                poly(c, rgb(246, 200, 90), cx - 4 * u + sw, oy + 2 * u, cx - 1 * u + sw, oy + 2 * u, cx - 3 * u, oy + 15.5f * u, cx - 10 * u, oy + 15.5f * u)
                rect(c, cx - 12.5f * u, oy + 14.5f * u, 25 * u, 1.6f * u, rgb(170, 122, 40))
                p.style = Paint.Style.FILL
                if (done) { val pl = 0.6f + 0.4f * sin(t * 3f); p.color = Color.argb((110 * pl).toInt(), 255, 230, 120); c.drawCircle(cx, oy + 14 * u, 6 * u, p)
                    p.color = rgb(255, 240, 150); c.drawCircle(cx, oy + 14 * u, 2.6f * u, p) }
                else { p.color = rgb(30, 22, 40); c.drawCircle(cx, oy + 14 * u, 2.6f * u, p) }
            }
        }
    }

    private fun floorWood(c: Canvas, ox: Float, oy: Float, ts: Float, h: Int) {
        val u = ts / 16f
        rect(c, ox, oy, ts, ts, if (h % 2 == 0) rgb(192, 144, 96) else rgb(186, 138, 90))
        rect(c, ox, oy + 7.6f * u, ts, 0.8f * u, rgb(150, 106, 68)); rect(c, ox + ((h % 3) * 4 + 3) * u, oy, 0.8f * u, 7.6f * u, rgb(150, 106, 68))
        rect(c, ox + ((h / 3 % 3) * 4 + 2) * u, oy + 8.4f * u, 0.8f * u, 7.6f * u, rgb(150, 106, 68))
    }

    private fun floorKeep(c: Canvas, ox: Float, oy: Float, ts: Float, h: Int) {
        val u = ts / 16f
        rect(c, ox, oy, ts, ts, if (h % 3 == 0) rgb(70, 64, 96) else rgb(76, 70, 104))
        rect(c, ox, oy, ts, 0.8f * u, rgb(50, 44, 72)); rect(c, ox, oy, 0.8f * u, ts, rgb(50, 44, 72))
        if (h % 8 == 0) rect(c, ox + 4 * u, oy + 5 * u, 3 * u, 0.8f * u, rgb(54, 48, 78))
    }

    // ---------------- people ----------------
    /** [by] is the y of the feet, [cx] the centre x. [moving] animates the legs. */
    fun person(c: Canvas, look: Look, cx: Float, by: Float, ts: Float, face: Int, moving: Boolean, phase: Float, t: Float) {
        val u = ts / 16f
        val bob = if (moving) -abs(sin(phase * Math.PI.toFloat() * 2f)) * u else 0f
        p.style = Paint.Style.FILL; p.color = Color.argb(70, 0, 0, 0); c.drawOval(cx - 5.5f * u, by - 2 * u, cx + 5.5f * u, by + 1.2f * u, p)
        val y0 = by + bob
        val legCol = look.legs
        val lShort = if (moving && phase < 0.5f) 1.6f * u else 0f
        val rShort = if (moving && phase >= 0.5f) 1.6f * u else 0f
        val robe = look.kind == K_ROBE; val coat = look.kind == K_COAT
        if (!robe) { rect(c, cx - 3.6f * u, y0 - 5 * u, 3.1f * u, 5 * u - lShort, legCol); rect(c, cx + 0.5f * u, y0 - 5 * u, 3.1f * u, 5 * u - rShort, legCol)
            rect(c, cx - 3.8f * u, y0 - 1.2f * u - lShort, 3.4f * u, 1.4f * u, rgb(50, 40, 40)); rect(c, cx + 0.4f * u, y0 - 1.2f * u - rShort, 3.4f * u, 1.4f * u, rgb(50, 40, 40)) }
        val topCol = look.top
        val bodyBottom = if (robe) y0 - 0.5f * u else if (coat) y0 - 2.5f * u else y0 - 5 * u
        poly(c, topCol, cx - 4.2f * u, y0 - 11 * u, cx + 4.2f * u, y0 - 11 * u, cx + (if (robe) 5.2f else 4.2f) * u, bodyBottom, cx - (if (robe) 5.2f else 4.2f) * u, bodyBottom)
        if (robe) rect(c, cx - 5.2f * u, bodyBottom - 1.2f * u, 10.4f * u, 1.2f * u, shade(topCol, 1.25f))
        if (coat) rect(c, cx - 0.5f * u, y0 - 11 * u, 1 * u, 8.5f * u, rgb(210, 210, 220))
        if (look.kind == K_HOOD) { p.color = rgb(150, 70, 190); c.drawCircle(cx, y0 - 8 * u, 1.3f * u, p) }
        // arms
        val swing = if (moving) (if (phase < 0.5f) 1f else -1f) * u else 0f
        rect(c, cx - 6 * u, y0 - 10.5f * u + swing, 1.9f * u, 5 * u, shade(topCol, 0.9f)); rect(c, cx + 4.1f * u, y0 - 10.5f * u - swing, 1.9f * u, 5 * u, shade(topCol, 0.9f))
        rect(c, cx - 6 * u, y0 - 6 * u + swing, 1.9f * u, 1.5f * u, look.skin); rect(c, cx + 4.1f * u, y0 - 6 * u - swing, 1.9f * u, 1.5f * u, look.skin)
        // head
        val hy = y0 - 14.5f * u
        p.color = look.skin; c.drawCircle(cx, hy, 4.3f * u, p)
        val d = when (face) { LEFT -> -1f; RIGHT -> 1f; else -> 0f }
        when (face) {
            UP -> { p.color = look.hair; c.drawCircle(cx, hy, 4.5f * u, p) }
            DOWN -> { p.color = look.hair; c.drawOval(cx - 4.7f * u, hy - 5 * u, cx + 4.7f * u, hy - 0.8f * u, p); rect(c, cx - 4.7f * u, hy - 3 * u, 1.3f * u, 3 * u, look.hair); rect(c, cx + 3.4f * u, hy - 3 * u, 1.3f * u, 3 * u, look.hair) }
            else -> { p.color = look.hair; c.drawOval(cx - 4.7f * u, hy - 5 * u, cx + 4.7f * u, hy - 0.5f * u, p); c.drawCircle(cx - d * 2.2f * u, hy - 0.5f * u, 3 * u, p) }
        }
        p.color = Color.rgb(30, 24, 30)
        when (face) { DOWN -> { c.drawCircle(cx - 1.8f * u, hy + 0.2f * u, 0.75f * u, p); c.drawCircle(cx + 1.8f * u, hy + 0.2f * u, 0.75f * u, p) }
            LEFT, RIGHT -> c.drawCircle(cx + d * 2.2f * u, hy + 0.2f * u, 0.75f * u, p) }
        when (look.kind) {
            K_CAP -> { p.color = rgb(210, 50, 50); c.drawArc(cx - 4.8f * u, hy - 5.6f * u, cx + 4.8f * u, hy + 2.6f * u, 180f, 180f, true, p)
                p.color = rgb(150, 30, 30); if (face == DOWN) c.drawRect(cx - 4.8f * u, hy - 1.2f * u, cx + 4.8f * u, hy - 0.2f * u, p) else if (face != UP) c.drawRect(cx + d * 3 * u - 1.5f * u, hy - 1.2f * u, cx + d * 6 * u + 1.5f * u, hy - 0.2f * u, p)
                p.color = Color.WHITE; if (face == DOWN) c.drawCircle(cx, hy - 3.2f * u, 0.9f * u, p) }
            K_HOOD -> { p.color = look.top; c.drawArc(cx - 5.2f * u, hy - 5.8f * u, cx + 5.2f * u, hy + 4.6f * u, 180f, 180f, true, p)
                if (face == UP) c.drawCircle(cx, hy, 5 * u, p)
                p.color = look.skin; if (face == DOWN) c.drawOval(cx - 3 * u, hy - 1.6f * u, cx + 3 * u, hy + 3.8f * u, p)
                p.color = Color.rgb(30, 24, 30); if (face == DOWN) { c.drawCircle(cx - 1.4f * u, hy + 0.9f * u, 0.7f * u, p); c.drawCircle(cx + 1.4f * u, hy + 0.9f * u, 0.7f * u, p) } }
        }
    }

    /** "!" bubble over a trainer who just spotted you. */
    fun alert(c: Canvas, cx: Float, by: Float, ts: Float) {
        val u = ts / 16f
        p.style = Paint.Style.FILL; p.color = Color.WHITE; c.drawRoundRect(cx - 3.5f * u, by - 29 * u, cx + 3.5f * u, by - 19 * u, 2f * u, 2f * u, p)
        p.color = Color.rgb(230, 60, 50); c.drawRect(cx - 0.8f * u, by - 27.5f * u, cx + 0.8f * u, by - 23 * u, p); c.drawRect(cx - 0.8f * u, by - 21.8f * u, cx + 0.8f * u, by - 20.4f * u, p)
    }
}
