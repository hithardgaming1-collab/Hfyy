package com.example.critterquest

import android.app.Activity
import android.os.Bundle
import android.view.WindowManager

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.setBackgroundDrawable(null) // GameView paints every pixel; the default window background would be a wasted full-screen fill
        val v = GameView(this)
        setContentView(v)
        v.requestFocus()
    }
}
