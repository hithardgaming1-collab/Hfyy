package com.example.critterquest

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

const val M_FIGHT = 0; const val M_REST = 1; const val M_SWAP = 2; const val M_CATCH = 3; const val M_RUN = 4

/** How good a move looks for [u] to use on [t] (damage-ish number; status moves score low unless they would help). */
fun moveScore(u: Mon, t: Mon, m: Move): Float {
    if (m.damaging) {
        val e = Rules.eff(m.type, t.s)
        if (e == 0f) return 0f
        var s = (if (m.levelDmg) 40f else m.power.toFloat()) * e * Rules.stab(u, m) * (if (m.acc == 0) 1f else m.acc / 100f)
        if (m.recoil) s *= 0.85f
        val atk = if (m.type.special) u.spa else u.atk
        val def = if (m.type.special) t.spd else t.def
        return s * atk.toFloat() / max(1, def)
    }
    if (m.heal) return if (u.hp < u.maxHp * 0.45f) 120f else 0f
    if (m.status != null) return if (canInflict(t, m.status) && Rules.eff(m.type, t.s) > 0f) 45f else 0f
    if (m.stat >= 0) {
        val x = if (m.self) u else t
        val now = x.stage[m.stat]
        return if ((m.stages > 0 && now < 2 && u.hp > u.maxHp / 2) || (m.stages < 0 && now > -2)) 20f else 0f
    }
    return 0f
}

fun canInflict(t: Mon, st: St): Boolean {
    if (t.status != null) return false
    return when (st) {
        St.BRN -> T.FIRE !in t.s.types
        St.PSN -> T.POISON !in t.s.types
        St.FRZ -> T.ICE !in t.s.types
        else -> true
    }
}

/**
 * One fight: your party (one critter out at a time) against a wild critter or a trainer's whole team.
 * Messages are queued and shown one by one; GameView calls [pump] on a timer. Game effects (damage, status...)
 * run when their message is shown, so the HP bars and the text stay in step.
 * [clock] only drives the little lunge / hurt animations.
 */
class Battle(
    val party: List<Mon>, val team: List<Mon>, val trainer: Trainer?, var heals: Int, var orbs: Int = 0,
    val clock: () -> Long = { 0L }, private val rnd: Random = Random.Default
) {
    var cur = max(0, party.indexOfFirst { it.hp > 0 })   // which party member is out
    val me get() = party[cur]
    var idx = 0
    val foe get() = team[idx]
    var text = ""
    var menuOn = false
    var menu = 0
    var over = 0 // 0 running, 1 won, 2 lost, 3 got away, 4 caught the wild critter
    var caught: Mon? = null
    var swapping = false   // the party list is open
    var swapSel = 0
    var fighting = false   // the move list is open
    var moveSel = 0
    var learnFor: Mon? = null   // a critter wants to learn [learnMove] but already knows four moves
    var learnMove: Move? = null
    var learnSel = 0
    private var forced = false // your critter fainted: you must pick another
    var lungeMe = 0L; var lungeFoe = 0L; var hitMe = 0L; var hitFoe = 0L
    /** Menu rows: 0 Fight, 1 Rest, 2 Swap, 3 Catch (wild only), 4 Run (wild only) */
    val items get() = if (trainer == null) 5 else 3
    private val q = ArrayDeque<Pair<() -> String, () -> Unit>>()

    init {
        if (trainer == null) text = "A wild ${foe.s.name} appears!"
        else { text = "${trainer.name} wants to battle!"; say("${trainer.name} sent out ${foe.s.name}!") }
    }

    fun menuLabel(i: Int) = when (i) {
        M_FIGHT -> "Fight"; M_REST -> "Rest ($heals)"; M_SWAP -> "Swap"
        M_CATCH -> "Catch ($orbs)"; else -> "Run"
    }
    fun menuEnabled(i: Int) = when (i) { M_REST -> heals > 0; M_SWAP -> canSwap(); M_CATCH -> orbs > 0; else -> true }

    private fun say(t: String, a: () -> Unit = {}) { q.addLast({ t } to a) }
    private fun sayFront(t: String) { q.addFirst({ t } to {}) }

    /** Name as shown in messages: your critters plain, the other side "Wild X" / "Foe X". */
    private fun nm(m: Mon) = if (m in team) (if (trainer == null) "Wild " else "Foe ") + m.s.name else m.s.name

    fun canSwap() = party.count { it.hp > 0 } > 1

    /** Show the next message, or open the menu when the queue is empty. */
    fun pump() {
        if (menuOn || over != 0 || learnFor != null) return
        val m = q.removeFirstOrNull()
        if (m != null) { text = m.first(); m.second(); return }
        menuOn = true; fighting = false
        if (forced) { swapping = true; swapSel = party.indexOfFirst { it.hp > 0 }; text = "Choose your next critter!" }
        else text = "What will ${me.s.name} do?"
    }

    private fun end(code: Int) {
        over = code
        party.forEach { it.clearBattleState() }
        team.forEach { it.clearBattleState() }
    }

    // ---------------- player input ----------------

    /** A main-menu choice (see the M_ constants). Fight opens the move list; the rest happen right away. */
    fun use(i: Int) {
        if (!menuOn || swapping || fighting || learnFor != null) return
        when (i) {
            M_FIGHT -> {
                if (me.moves.none { it.pp > 0 }) fightWith(-1)
                else { fighting = true; moveSel = me.moves.indexOfFirst { it.pp > 0 } }
            }
            M_REST -> {
                if (heals == 0) return
                menuOn = false; heals--
                val who = me
                say("${who.s.name} rested and recovered!") {
                    who.hp = min(who.maxHp, who.hp + who.maxHp * 4 / 10); who.status = null; who.sleep = 0
                    foePhase()
                }
            }
            M_SWAP -> if (canSwap()) { swapping = true; swapSel = party.indexOfFirst { it.hp > 0 && party.indexOf(it) != cur } }
            M_CATCH -> {
                if (trainer != null || orbs == 0) return
                menuOn = false; orbs--
                throwOrb()
            }
            M_RUN -> {
                if (trainer != null) return
                menuOn = false
                say("Got away safely!") { end(3) }
            }
        }
    }

    fun closeFight() { fighting = false }

    /** Use move slot [slot] of the critter that is out (-1 = Struggle, when every move is out of PP). */
    fun fightWith(slot: Int) {
        if (!menuOn || swapping || learnFor != null) return
        val ms = if (slot < 0) null else me.moves.getOrNull(slot)
        if (slot >= 0 && (ms == null || ms.pp <= 0)) return
        fighting = false; menuOn = false
        val u = me; val t = foe
        val pm = ms?.move ?: STRUGGLE
        val fs = pickFoeMove()
        val fm = fs?.move ?: STRUGGLE
        val meFirst = when {
            pm.prio != fm.prio -> pm.prio > fm.prio
            else -> { val a = Rules.speed(u); val b = Rules.speed(t); if (a == b) rnd.nextBoolean() else a > b }
        }
        val mine: (() -> Unit) -> Unit = { nx -> action(u, t, true, pm, ms, nx) }
        val theirs: (() -> Unit) -> Unit = { nx -> action(t, u, false, fm, fs, nx) }
        chain(if (meFirst) listOf(mine, theirs) else listOf(theirs, mine)) { endOfTurn() }
    }

    /** Pick party member [i] from the open party list (costs a turn, unless your critter just fainted). */
    fun swap(i: Int) {
        if (!swapping || i !in party.indices || party[i].hp <= 0 || (i == cur && !forced)) return
        val wasForced = forced
        val old = me
        swapping = false; menuOn = false; forced = false
        say(if (wasForced) "Go, ${party[i].s.name}!" else "Come back, ${old.s.name}! Go, ${party[i].s.name}!") {
            old.stage.fill(0); old.flinch = false
            cur = i
            if (!wasForced) foePhase()
        }
    }

    fun closeSwap() { if (swapping && !forced) swapping = false }

    /** Answer the "forget a move?" prompt: 0..3 replaces that move, anything else keeps the old moves. */
    fun answerLearn(sel: Int) {
        val m = learnFor ?: return; val nw = learnMove ?: return
        learnFor = null; learnMove = null
        if (sel in 0 until m.moves.size) {
            val old = m.moves[sel].move
            m.moves[sel] = MoveSlot(nw)
            sayFront("${m.s.name} forgot ${old.name} and learned ${nw.name}!")
        } else sayFront("${m.s.name} did not learn ${nw.name}.")
    }

    // ---------------- turn flow ----------------

    private fun chain(steps: List<(() -> Unit) -> Unit>, done: () -> Unit) {
        if (steps.isEmpty()) { done(); return }
        steps[0] { chain(steps.drop(1), done) }
    }

    /** Only the other side acts (after Rest, Swap or a failed Critter Orb). */
    private fun foePhase() {
        val u = foe; val t = me
        val fs = pickFoeMove()
        val step: (() -> Unit) -> Unit = { nx -> action(u, t, false, fs?.move ?: STRUGGLE, fs, nx) }
        chain(listOf(step)) { endOfTurn() }
    }

    private fun pickFoeMove(): MoveSlot? {
        val f = foe; val t = me
        val usable = f.moves.filter { it.pp > 0 }
        if (usable.isEmpty()) return null
        val sc = usable.map { moveScore(f, t, it.move) }
        if (trainer?.smart == true && rnd.nextInt(100) < 80) return usable[sc.indexOf(sc.maxOrNull()!!)]
        val total = sc.sum()
        if (total <= 0f) return usable[rnd.nextInt(usable.size)]
        var r = rnd.nextFloat() * total
        for (i in usable.indices) { r -= sc[i]; if (r < 0f) return usable[i] }
        return usable.last()
    }

    /** One critter tries to use a move. [next] is only called if the turn carries on (nobody fainted). */
    private fun action(u: Mon, t: Mon, mine: Boolean, m: Move, slot: MoveSlot?, next: () -> Unit) {
        if (u.status == St.SLP) {
            if (u.sleep > 0) { u.sleep--; say("${nm(u)} is fast asleep."); next(); return }
            u.status = null; say("${nm(u)} woke up!")
        }
        if (u.status == St.FRZ) {
            if (rnd.nextInt(100) < 20) { u.status = null; say("${nm(u)} thawed out!") }
            else { say("${nm(u)} is frozen solid!"); next(); return }
        }
        if (u.flinch) { u.flinch = false; say("${nm(u)} flinched and couldn't move!"); next(); return }
        if (u.status == St.PAR && rnd.nextInt(4) == 0) { say("${nm(u)} is fully paralyzed!"); next(); return }
        say("${nm(u)} used ${m.name}!") {
            if (slot != null) slot.pp = max(0, slot.pp - 1)
            val c = clock()
            if (mine) lungeMe = c else lungeFoe = c
            if (m.damaging) hitMove(u, t, mine, m, next) else statusMove(u, t, m, next)
        }
    }

    private fun hitMove(u: Mon, t: Mon, mine: Boolean, m: Move, next: () -> Unit) {
        val e = Rules.eff(m.type, t.s)
        if (e == 0f) { say("It doesn't affect ${nm(t)}..."); next(); return }
        if (!Rules.hits(u, t, m, rnd)) { say("${nm(u)}'s attack missed!"); next(); return }
        val crit = !m.levelDmg && Rules.critRoll(m, rnd)
        val dmg = Rules.damage(u, t, m, crit, rnd)
        val c = clock()
        if (mine) hitFoe = c else hitMe = c
        t.hp = max(0, t.hp - dmg)
        if (crit) say("A critical hit!")
        if (e > 1f) say("It's super effective!") else if (e < 1f) say("It's not very effective...")
        if (m.drain && dmg > 0) { u.hp = min(u.maxHp, u.hp + max(1, dmg / 2)); say("${nm(t)} had its energy drained!") }
        if (m.recoil && dmg > 0) {
            u.hp = max(if (t.hp <= 0) 1 else 0, u.hp - max(1, dmg / 4))
            say("${nm(u)} was hurt by recoil!")
        }
        if (t.hp > 0) {
            if (m.status != null && rnd.nextInt(100) < m.chance) inflict(t, m.status, true)
            if (m.stat >= 0 && rnd.nextInt(100) < m.chance) changeStat(if (m.self) u else t, m.stat, m.stages, true)
            if (m.flinch > 0 && rnd.nextInt(100) < m.flinch) t.flinch = true
        }
        val tDead = t.hp <= 0; val uDead = u.hp <= 0
        if (tDead) faint(t)
        if (uDead) faint(u)
        if (!tDead && !uDead) next()
    }

    private fun statusMove(u: Mon, t: Mon, m: Move, next: () -> Unit) {
        if (m.heal) {
            if (u.hp >= u.maxHp) say("${nm(u)}'s HP is full!")
            else { u.hp = min(u.maxHp, u.hp + u.maxHp / 2); say("${nm(u)} regained health!") }
            next(); return
        }
        if (!m.self && !Rules.hits(u, t, m, rnd)) { say("${nm(u)}'s move missed!"); next(); return }
        if (m.status != null) {
            if (Rules.eff(m.type, t.s) == 0f) say("It doesn't affect ${nm(t)}...") else inflict(t, m.status, false)
        } else if (m.stat >= 0) changeStat(if (m.self) u else t, m.stat, m.stages, false)
        next()
    }

    /** Try to give [t] a status condition. [quiet] = a bonus effect of an attack: stay silent when it does not apply. */
    private fun inflict(t: Mon, st: St, quiet: Boolean) {
        if (t.status != null) { if (!quiet) say("But it failed!"); return }
        if (!canInflict(t, st)) { if (!quiet) say("It doesn't affect ${nm(t)}..."); return }
        t.status = st
        if (st == St.SLP) t.sleep = 1 + rnd.nextInt(3)
        say(when (st) {
            St.BRN -> "${nm(t)} was burned!"
            St.PSN -> "${nm(t)} was poisoned!"
            St.PAR -> "${nm(t)} is paralyzed! It may be unable to move!"
            St.SLP -> "${nm(t)} fell asleep!"
            St.FRZ -> "${nm(t)} was frozen solid!"
        })
    }

    private fun changeStat(x: Mon, stat: Int, n: Int, quiet: Boolean) {
        val now = x.stage[stat]
        if (n > 0 && now >= 6) { if (!quiet) say("${nm(x)}'s ${STAT_NAMES[stat]} won't go any higher!"); return }
        if (n < 0 && now <= -6) { if (!quiet) say("${nm(x)}'s ${STAT_NAMES[stat]} won't go any lower!"); return }
        x.stage[stat] = (now + n).coerceIn(-6, 6)
        say("${nm(x)}'s ${STAT_NAMES[stat]} ${if (abs(n) >= 2) "sharply " else ""}${if (n > 0) "rose" else "fell"}!")
    }

    /** Burn and poison hurt at the end of every turn. */
    private fun endOfTurn() {
        val a = me; val b = foe
        a.flinch = false; b.flinch = false
        residual(a) { residual(b) { } }
    }

    private fun residual(m: Mon, next: () -> Unit) {
        val st = m.status
        if (m.hp > 0 && (st == St.BRN || st == St.PSN)) {
            say("${nm(m)} is hurt by its ${if (st == St.BRN) "burn" else "poison"}!") {
                m.hp = max(0, m.hp - max(1, m.maxHp / 8))
                if (m.hp <= 0) faint(m) else next()
            }
        } else next()
    }

    private fun faint(x: Mon) {
        if (x in team) foeFainted()
        else say("${x.s.name} fainted!") { if (party.any { it.hp > 0 }) forced = true else end(2) }
    }

    private fun foeFainted() {
        val f = foe
        say("${nm(f)} fainted!") {
            val gain = Rules.xpFor(f, trainer != null)
            val lead = if (me.hp > 0) me else party.firstOrNull { it.hp > 0 }
            if (lead != null) say("${lead.s.name} gained $gain XP!") {
                grow(lead, gain)
                val others = party.filter { it !== lead && it.hp > 0 }
                if (others.isNotEmpty()) {
                    say("The rest of the party shared ${gain / 2} XP.")
                    others.forEach { grow(it, gain / 2) }
                }
                nextFoe()
            } else nextFoe()
        }
    }

    /** Give XP, then queue level-up, new-move and evolution messages. */
    private fun grow(m: Mon, xp: Int) {
        m.xp += xp
        while (m.lvl < MAX_LVL && m.xp >= Rules.xpNeed(m.lvl)) {
            m.xp -= Rules.xpNeed(m.lvl)
            val before = m.maxHp
            m.lvl++
            m.hp = min(m.maxHp, m.hp + (m.maxHp - before))
            say("${m.s.name} grew to Lv${m.lvl}!")
            for ((l, n) in m.s.learn) if (l == m.lvl) learn(m, mv(n))
        }
        if (m.lvl >= MAX_LVL) m.xp = 0
        var sp = m.s
        while (sp.evo >= 0 && m.lvl >= sp.evoLvl) {
            val from = sp; val to = DEX[from.evo]
            say("What? ${from.name} is changing!")
            say("${from.name} evolved into ${to.name}!") {
                val before = m.maxHp
                m.s = to
                m.hp = min(m.maxHp, m.hp + (m.maxHp - before))
                for ((l, n) in to.learn) if (l >= from.evoLvl && l <= m.lvl) learn(m, mv(n))
            }
            sp = to
        }
    }

    private fun learn(m: Mon, mv: Move) {
        if (m.knows(mv)) return
        if (m.moves.size < 4) { m.moves.add(MoveSlot(mv)); say("${m.s.name} learned ${mv.name}!") }
        else say("${m.s.name} wants to learn ${mv.name}.") { learnFor = m; learnMove = mv; learnSel = 0 }
    }

    private fun nextFoe() {
        if (idx + 1 < team.size) say("${trainer!!.name} sent out ${team[idx + 1].s.name}!") { idx++ }
        else say(if (trainer != null) "You defeated ${trainer.name}!" else "${me.s.name} won the battle!") { end(1) }
    }

    // ---------------- catching ----------------

    private fun throwOrb() {
        val f = foe
        val n = Rules.catchShakes(f, rnd)
        say("You threw a Critter Orb!")
        for (i in 0 until min(n, 3)) say("The orb wobbles...")
        if (n >= 4) say("Gotcha! ${f.s.name} was caught!") { caught = f; end(4) }
        else say(when (n) {
            0 -> "Oh no! ${f.s.name} broke free!"
            1 -> "Aww! It appeared to be caught!"
            2 -> "Aargh! Almost had it!"
            else -> "Shoot! It was so close too!"
        }) { foePhase() }
    }
}
