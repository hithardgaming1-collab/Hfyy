#!/usr/bin/env python3
"""Generates the original 64x64 pixel-art sprites for Critter Quest.

Usage:  python3 tools/make_sprites.py
Output: app/src/main/res/drawable-nodpi/<name>_front.png / <name>_back.png

Everything here is drawn from scratch with Pillow, so the art is original and
there is nothing third-party to license or scan. Requires: pip install pillow
"""
import math
import os
import sys
from PIL import Image, ImageDraw

W = 64
OUT = (34, 26, 50, 255)  # outline colour


def rgb(c, f=1.0):
    return tuple(max(0, min(255, int(v * f))) for v in c[:3]) + (255,)


def lighter(c, f=0.35):
    return tuple(max(0, min(255, int(v + (255 - v) * f))) for v in c[:3]) + (255,)


class Pen:
    def __init__(self):
        self.img = Image.new("RGBA", (W, W), (0, 0, 0, 0))
        self.d = ImageDraw.Draw(self.img)

    def poly(self, pts, col):
        self.d.polygon([(round(x), round(y)) for x, y in pts], fill=col)

    def oval(self, cx, cy, rx, ry, col, rot=0.0):
        pts = []
        a = math.radians(rot)
        for i in range(40):
            t = i / 40 * math.tau
            x, y = rx * math.cos(t), ry * math.sin(t)
            pts.append((cx + x * math.cos(a) - y * math.sin(a), cy + x * math.sin(a) + y * math.cos(a)))
        self.poly(pts, col)

    def blob(self, cx, cy, rx, ry, base, rot=0.0):
        """Shaded blob: dark rim, base fill (shifted up-left), small highlight."""
        self.oval(cx, cy, rx, ry, rgb(base, 0.72), rot)
        self.oval(cx - 1, cy - 1.2, rx - 1.6, ry - 1.8, base, rot)
        self.oval(cx - rx * 0.32, cy - ry * 0.42, max(1.2, rx * 0.28), max(1.0, ry * 0.2), lighter(base, 0.4), rot)

    def px(self, pts, col):
        for x, y in pts:
            self.img.putpixel((x, y), col)

    def finish(self):
        """Add a 1px dark outline around the whole silhouette."""
        a = self.img.split()[3]
        src = a.load()
        out = self.img.copy()
        dst = out.load()
        for y in range(W):
            for x in range(W):
                if src[x, y] == 0:
                    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        nx, ny = x + dx, y + dy
                        if 0 <= nx < W and 0 <= ny < W and src[nx, ny] > 0:
                            dst[x, y] = OUT
                            break
        return out


CREAM = (255, 236, 200, 255)
HORN = (250, 240, 210, 255)

SPECIES = {
    #  name        type     body              evolved
    "emberpup": ("fire", (232, 116, 59), False),
    "blazehorn": ("fire", (196, 65, 43), True),
    "aquafin": ("water", (79, 163, 224), False),
    "tidalon": ("water", (46, 111, 191), True),
    "sproutle": ("leaf", (107, 191, 89), False),
    "thornpaw": ("leaf", (62, 142, 65), True),
}


def flame(p, x, y, s, flip=1):
    """A small flame centred at (x, y); s scales it."""
    p.poly([(x - 5 * s, y + 4 * s), (x - 3 * s, y - 4 * s * 1.0), (x, y - 11 * s), (x + 2 * s, y - 4 * s),
            (x + 5 * s * flip, y - 7 * s), (x + 6 * s, y + 4 * s)], (240, 100, 30, 255))
    p.poly([(x - 3 * s, y + 4 * s), (x - 1 * s, y - 3 * s), (x, y - 7 * s), (x + 2 * s, y - 2 * s), (x + 4 * s, y + 4 * s)],
           (255, 170, 40, 255))
    p.poly([(x - 1.5 * s, y + 4 * s), (x, y - 1 * s), (x + 2 * s, y + 4 * s)], (255, 230, 110, 255))


def leaf(p, cx, cy, rx, ry, rot, col=(90, 190, 80, 255)):
    p.oval(cx, cy, rx, ry, rgb(col, 0.7), rot)
    p.oval(cx - 0.5, cy - 0.5, rx - 1, ry - 1, col, rot)
    a = math.radians(rot)
    p.d.line([(cx + math.sin(a) * ry * -0.8, cy + math.cos(a) * ry * 0.8),
              (cx + math.sin(a) * ry * 0.8, cy - math.cos(a) * ry * 0.8)], fill=rgb(col, 0.75), width=1)


def draw(name, back):
    kind, body, evo = SPECIES[name]
    p = Pen()
    dark = rgb(body, 0.72)
    cx = 32
    bw = 17 if evo else 15  # body half-width

    # ---- things behind the body -------------------------------------------------
    if not back:
        if kind == "fire":
            flame(p, 51, 46, 1.15 if evo else 1.0)
        elif kind == "water":
            p.oval(50, 50, 8, 4.5, lighter((150, 210, 245), 0.0), -35)
            p.oval(50, 50, 6, 3, lighter((150, 210, 245), 0.35), -35)
        else:
            leaf(p, 50, 46, 4.5, 10, 35)
    # ears / crest sit behind the head
    hy = 26
    if kind == "fire":
        for s in (-1, 1):
            p.poly([(cx + s * 11, hy - 4), (cx + s * 15, hy - 20), (cx + s * 4, hy - 12)], dark)
            p.poly([(cx + s * 10, hy - 6), (cx + s * 13.5, hy - 17), (cx + s * 6, hy - 11)], (255, 150, 90, 255))
        flame(p, cx, hy - 12 if evo else hy - 14, 1.1 if evo else 0.95)
    elif kind == "water":
        p.poly([(cx - 7, hy - 8), (cx, hy - 22 - (2 if evo else 0)), (cx + 7, hy - 8)], (150, 210, 245, 255))
        p.poly([(cx - 3, hy - 8), (cx, hy - 18 - (2 if evo else 0)), (cx + 3, hy - 8)], (205, 238, 252, 255))
        for s in (-1, 1):
            p.oval(cx + s * 15, hy + 3, 6, 3.2, (150, 210, 245, 255), s * -25)
    else:
        leaf(p, cx - 7, hy - 14, 3.5, 9, -28)
        leaf(p, cx + 7, hy - 14, 3.5, 9, 28)
    if evo:
        for s in (-1, 1):
            p.poly([(cx + s * 7, hy - 8), (cx + s * 12, hy - 22), (cx + s * 15, hy - 6)], rgb(HORN, 0.8))
            p.poly([(cx + s * 8.5, hy - 8), (cx + s * 12, hy - 19), (cx + s * 14, hy - 7)], HORN)

    # ---- feet, arms, body --------------------------------------------------------
    p.blob(22, 58, 7, 4, dark)
    p.blob(42, 58, 7, 4, dark)
    p.blob(cx, 45, bw, 13, body)
    for s in (-1, 1):
        p.blob(cx + s * (bw + 0.5), 46, 3.6, 5.5, dark)
    if not back:
        p.oval(cx, 48.5, 8, 8, CREAM)
        p.oval(cx - 1, 47.5, 6.5, 6.5, lighter(CREAM, 0.4))
    # type extras on the body
    if evo and kind == "leaf":
        for s in (-1, 1):
            p.poly([(cx + s * (bw - 3), 35), (cx + s * (bw + 6), 38), (cx + s * (bw - 3), 42)], rgb(HORN, 0.85))
            p.poly([(cx + s * (bw - 3), 36.5), (cx + s * (bw + 4), 38.3), (cx + s * (bw - 3), 40.5)], HORN)
    if back:
        # tail comes toward the viewer
        if kind == "fire":
            flame(p, cx, 52, 1.5 if evo else 1.3)
        elif kind == "water":
            p.oval(cx, 53, 9, 4.5, (150, 210, 245, 255))
            p.oval(cx, 53, 6, 2.6, (205, 238, 252, 255))
        else:
            leaf(p, cx, 52, 5, 9, 90 + 8)
        if evo and kind == "water":
            p.poly([(cx - 4, 34), (cx, 24), (cx + 4, 34)], (150, 210, 245, 255))
        if evo and kind == "leaf":
            for i in range(3):
                p.poly([(cx - 3, 37 + i * 5), (cx, 33 + i * 5), (cx + 3, 37 + i * 5)], HORN)

    # ---- head ---------------------------------------------------------------------
    p.blob(cx, hy, 14 if back else 13, 12 if back else 11.5, body)
    if back:
        p.oval(cx, hy + 9, 9, 2.4, dark)  # neck shadow
    else:
        # face
        for s in (-1, 1):
            ex = cx + s * 6.5
            p.oval(ex, hy + 1, 3.6, 4.0, (255, 255, 255, 255))
            p.oval(ex + s * -0.4, hy + 1.6, 2.1, 2.6, (20, 20, 30, 255))
            p.px([(round(ex - 1), round(hy))], (255, 255, 255, 255))
            p.oval(cx + s * 11.5, hy + 7, 2.4, 1.5, (255, 120, 140, 200))
            if evo:
                p.d.line([(round(ex - s * 4), round(hy - 6 + (1 if s else 0))), (round(ex + s * 3), round(hy - 4))],
                         fill=dark, width=1)
        p.px([(31, hy + 7), (32, hy + 7)], dark)
        p.px([(29, hy + 9), (30, hy + 10), (31, hy + 10), (32, hy + 10), (33, hy + 10), (34, hy + 9)], dark)
        if kind == "water" and evo:
            p.oval(cx, hy - 8, 1.8, 1.8, (255, 245, 255, 255))
    return p.finish()


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    out = os.path.join(here, "..", "app", "src", "main", "res", "drawable-nodpi")
    os.makedirs(out, exist_ok=True)
    sys.path.insert(0, here)
    import sprites_extra  # the species added after the starters (bird, bug, rock, snake... body plans)
    for n in SPECIES:
        draw(n, False).save(os.path.join(out, f"{n}_front.png"))
        draw(n, True).save(os.path.join(out, f"{n}_back.png"))
    for n in sprites_extra.EXTRA:
        sprites_extra.draw_extra(n, False).save(os.path.join(out, f"{n}_front.png"))
        sprites_extra.draw_extra(n, True).save(os.path.join(out, f"{n}_back.png"))
    # preview sheet (not shipped in the app): every species, front over back, in dex order
    names = list(SPECIES) + list(sprites_extra.EXTRA)
    cols = 10
    rows = (len(names) + cols - 1) // cols
    sheet = Image.new("RGBA", (W * 2 * cols, W * 2 * 2 * rows), (200, 235, 160, 255))
    for i, n in enumerate(names):
        for j, back in enumerate((False, True)):
            im = draw(n, back) if n in SPECIES else sprites_extra.draw_extra(n, back)
            s = im.resize((W * 2, W * 2), Image.NEAREST)
            sheet.alpha_composite(s, ((i % cols) * W * 2, (i // cols) * W * 4 + j * W * 2))
    sheet.save(os.path.join(here, "preview.png"))
    print("done:", len(names), "species")


if __name__ == "__main__":
    main()
