// Renders every map to PNG with the real Art.kt drawing code (via a Java2D stand-in for android.graphics).
package com.example.critterquest

import android.graphics.Canvas
import android.graphics.Paint
import java.awt.image.BufferedImage
import java.io.File
import javax.imageio.ImageIO

fun renderMap(art: Art, g: Game, m: GameMap, ts: Int, t: Float, withPeople: Boolean = true): BufferedImage {
    val img = BufferedImage(m.w * ts, m.h * ts, BufferedImage.TYPE_INT_ARGB)
    val c = Canvas(img)
    for (y in 0 until m.h) for (x in 0 until m.w) art.tile(c, g, m, x, y, (x * ts).toFloat(), (y * ts).toFloat(), ts.toFloat(), t)
    if (withPeople) for (n in (NPC_BY_MAP[m.id] ?: emptyList()).sortedBy { it.y })
        art.person(c, n.look, n.x * ts + ts / 2f, n.y * ts + ts * 0.94f, ts.toFloat(), n.face, false, 0f, t)
    return img
}

object Preview {
@JvmStatic fun main(args: Array<String>) {
    System.setProperty("java.awt.headless", "true")
    val out = File(args[0]); out.mkdirs()
    val ts = args.getOrNull(1)?.toInt() ?: 32
    val g = Game(); g.newGame(); g.chooseStarter(0)
    val art = Art(Paint())
    for ((id, m) in MAPS) {
        ImageIO.write(renderMap(art, g, m, ts, 0.3f), "png", File(out, "$id.png"))
    }
    // character sheet
    val looks = NPCS.map { it.look }.distinctBy { listOf(it.hair, it.top, it.kind) }
    val sheet = BufferedImage(ts * 2 * (looks.size + 1), ts * 6, BufferedImage.TYPE_INT_ARGB)
    val c = Canvas(sheet); c.drawColor(0xFF7CCA60.toInt())
    val all = listOf(PLAYER_LOOK) + looks
    for ((i, lk) in all.withIndex()) for (f in 0..3) art.person(c, lk, (i * 2 + 1) * ts.toFloat(), ts * (f + 1) * 1.3f, ts.toFloat() * 2f, f, false, 0f, 0f)
    ImageIO.write(sheet, "png", File(out, "_characters.png"))
    println("rendered ${MAPS.size} maps to $out")
}
}
