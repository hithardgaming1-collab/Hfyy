// Proves the map cache used by GameView draws the same picture as the plain per-frame drawing, using the real Art.kt.
//   1. layered (still tiles once + live tiles on top) == every tile drawn directly, on every map. The only allowed
//      difference is the soft glow that spills a few pixels out of a live tile (stone, crystal, bell, ripples): the old
//      row-by-row order let the next tile cut it off flat, the cache lets it fade out. It must stay next to a live tile.
//   2. a tile that Art.isLive() calls "still" really never changes with time or story flags
//   3. the grass sway steps cover the whole cycle
package com.example.critterquest

import android.graphics.Canvas
import android.graphics.Paint
import java.awt.image.BufferedImage

object CacheCheck {
    private const val TS = 40

    private fun newImg(m: GameMap) = BufferedImage(m.w * TS, m.h * TS, BufferedImage.TYPE_INT_ARGB)
    private fun same(a: BufferedImage, b: BufferedImage): Int {
        var bad = 0
        for (y in 0 until a.height) for (x in 0 until a.width) if (a.getRGB(x, y) != b.getRGB(x, y)) bad++
        return bad
    }

    /** Pixels that differ AND are not within the glow spill band (4.5 units) of a live tile. */
    private fun strayDiffs(a: BufferedImage, b: BufferedImage, m: GameMap, art: Art): Int {
        val band = Math.ceil(4.5 * TS / 16.0).toInt() + 1
        var bad = 0
        for (y in 0 until a.height) for (x in 0 until a.width) {
            if (a.getRGB(x, y) == b.getRGB(x, y)) continue
            val tx = x / TS; val ty = y / TS; var near = false
            for (dy in -1..1) for (dx in -1..1) {
                val nx = tx + dx; val ny = ty + dy
                if (nx < 0 || ny < 0 || nx >= m.w || ny >= m.h || !art.isLive(m.tile(nx, ny))) continue
                if (x >= nx * TS - band && x < (nx + 1) * TS + band && y >= ny * TS - band && y < (ny + 1) * TS + band) near = true
            }
            if (!near) bad++
        }
        return bad
    }

    private fun flagSets(): List<Game> {
        val fresh = Game().also { it.newGame() }
        val started = Game().also { it.newGame(); it.chooseStarter(1); it.flags.add("starter") }
        val late = Game().also { it.newGame(); it.chooseStarter(2); it.flags.addAll(listOf("starter", "sigil_leaf", "sigil_tide", "sigil_ember", "gate_open", "ending")) }
        return listOf(fresh, started, late)
    }

    /** A made-up map with every tile kind, so kinds that no real map uses are covered too. */
    private fun everyTile(th: Theme): GameMap {
        val row = Tl.values().joinToString("") { it.ch.toString() }
        val pad = ".".repeat(row.length)
        return GameMap("all_$th", "All", th, 0xFF7799CC.toInt(), listOf(pad, ".$row.", pad, ".$row.", pad).joinToString("\n"))
    }

    fun run(): Int {
        System.setProperty("java.awt.headless", "true")
        val art = Art(Paint())
        val maps = MAPS.values.toList() + Theme.values().map { everyTile(it) }
        val games = flagSets()
        val times = listOf(0.37f, 2.9f)
        var errors = 0; var tiles = 0

        // 1. layered == direct
        for (m in maps) for (g in games) for (t in times) {
            val direct = newImg(m); val dc = Canvas(direct)
            for (y in 0 until m.h) for (x in 0 until m.w) art.tile(dc, g, m, x, y, (x * TS).toFloat(), (y * TS).toFloat(), TS.toFloat(), t)
            val layer = newImg(m); val lc = Canvas(layer)
            for (y in 0 until m.h) for (x in 0 until m.w) art.drawStill(lc, g, m, x, y, (x * TS).toFloat(), (y * TS).toFloat(), TS.toFloat())
            // "blit the layer", then the live tiles in reading order
            val comp = newImg(m); val cc = Canvas(comp)
            cc.g.drawImage(layer, 0, 0, null)
            for (y in 0 until m.h) for (x in 0 until m.w) art.drawLive(cc, g, m, x, y, (x * TS).toFloat(), (y * TS).toFloat(), TS.toFloat(), t)
            val bad = strayDiffs(direct, comp, m, art); tiles += m.w * m.h
            if (bad != 0) { errors++; println("cache check FAILED: map ${m.id} t=$t flags=${g.flags.size}: $bad pixels differ away from any live tile") }
        }

        // 2. a tile marked "still" must not depend on time or flags (compare two times x two flag sets)
        for (m in maps) for (y in 0 until m.h) for (x in 0 until m.w) {
            val tl = m.tile(x, y)
            if (art.isLive(tl)) continue
            val shots = ArrayList<BufferedImage>()
            for ((g, t) in listOf(games[0] to 0.1f, games[0] to 3.7f, games[2] to 0.1f)) {
                val img = BufferedImage(TS * 3, TS * 3, BufferedImage.TYPE_INT_ARGB)
                art.tile(Canvas(img), g, m, x, y, TS.toFloat(), TS.toFloat(), TS.toFloat(), t); shots.add(img)
            }
            if (same(shots[0], shots[1]) != 0 || same(shots[0], shots[2]) != 0) {
                errors++; println("cache check FAILED: tile $tl (${m.id} $x,$y) changes over time/flags but Art.isLive() says it is still")
            }
        }

        // 3. grass steps cover 0 until GRASS_STEPS and never leave it
        val seen = HashSet<Int>()
        for (x in 0..40) for (k in 0..2000) { val s = art.grassStep(x, k * 0.01f); if (s !in 0 until GRASS_STEPS) { errors++; println("cache check FAILED: grass step $s") }; seen.add(s) }
        if (seen.size != GRASS_STEPS) { errors++; println("cache check FAILED: grass uses only ${seen.size} of $GRASS_STEPS steps") }

        println("cache check: ${maps.size} maps x ${games.size} flag sets x ${times.size} times (${tiles} tiles), errors=$errors")
        return errors
    }

    @JvmStatic fun main(args: Array<String>) { if (run() != 0) System.exit(1) }
}
