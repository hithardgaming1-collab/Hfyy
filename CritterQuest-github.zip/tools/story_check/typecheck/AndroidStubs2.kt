package android.content
class Prefs { fun contains(k: String) = false; fun getString(k: String, d: String?): String? = d; fun getInt(k: String, d: Int): Int = d
    fun edit(): Editor = Editor(); class Editor { fun putString(k: String, v: String): Editor = this; fun putInt(k: String, v: Int): Editor = this; fun remove(k: String): Editor = this; fun apply() {} } }
open class Context { val resources: android.content.res.Resources = android.content.res.Resources()
    fun getSharedPreferences(n: String, m: Int): Prefs = Prefs()
    companion object { const val MODE_PRIVATE = 0 } }
