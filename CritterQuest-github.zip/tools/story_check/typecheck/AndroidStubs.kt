// Type-check-only stand-ins for the Android classes GameView/Art/MainActivity use. Nothing here runs.
package android.graphics
object Color {
    const val WHITE = -1; const val BLACK = 0xFF000000.toInt(); const val GRAY = 0xFF888888.toInt(); const val YELLOW = 0xFFFFFF00.toInt()
    const val TRANSPARENT = 0
    fun rgb(r: Int, g: Int, b: Int): Int = 0
    fun argb(a: Int, r: Int, g: Int, b: Int): Int = 0
    fun red(c: Int) = 0; fun green(c: Int) = 0; fun blue(c: Int) = 0; fun alpha(c: Int) = 0
}
class Path { fun reset() {}; fun moveTo(x: Float, y: Float) {}; fun lineTo(x: Float, y: Float) {}; fun close() {} }
class Paint() {
    constructor(flags: Int) : this()
    enum class Style { FILL, STROKE, FILL_AND_STROKE }
    enum class Cap { BUTT, ROUND, SQUARE }
    enum class Align { LEFT, CENTER, RIGHT }
    companion object { const val ANTI_ALIAS_FLAG = 1; const val FILTER_BITMAP_FLAG = 2 }
    var color = 0; var style = Style.FILL; var strokeWidth = 1f; var strokeCap = Cap.BUTT
    var textSize = 12f; var textAlign = Align.LEFT; var isAntiAlias = false; var isFilterBitmap = false; var isDither = false
    var typeface: Typeface? = null; var shader: Shader? = null; var alpha = 255
    fun measureText(s: String): Float = 0f
}
class Typeface { companion object { val DEFAULT: Typeface = Typeface(); val DEFAULT_BOLD: Typeface = Typeface(); val MONOSPACE: Typeface = Typeface() } }
open class Shader { enum class TileMode { CLAMP, REPEAT, MIRROR } }
class LinearGradient(x0: Float, y0: Float, x1: Float, y1: Float, c0: Int, c1: Int, tile: Shader.TileMode) : Shader() { }
class Rect() { constructor(l: Int, t: Int, r: Int, b: Int) : this(); fun set(l: Int, t: Int, r: Int, b: Int) {} }
class RectF() { constructor(l: Float, t: Float, r: Float, b: Float) : this(); fun set(l: Float, t: Float, r: Float, b: Float) {}; fun contains(x: Float, y: Float): Boolean = false }
class Bitmap { val width = 0; val height = 0
    fun setHasAlpha(b: Boolean) {}; fun recycle() {}; val isRecycled = false
    enum class Config { ARGB_8888 }
    companion object { fun createBitmap(w: Int, h: Int, c: Config): Bitmap = Bitmap() } }
object BitmapFactory { class Options { var inScaled = true }
    fun decodeResource(r: android.content.res.Resources, id: Int): Bitmap? = null
    fun decodeResource(r: android.content.res.Resources, id: Int, o: Options): Bitmap? = null }
class Canvas() {
    constructor(b: Bitmap) : this()
    fun drawRect(l: Float, t: Float, r: Float, b: Float, p: Paint) {}
    fun drawOval(l: Float, t: Float, r: Float, b: Float, p: Paint) {}
    fun drawCircle(cx: Float, cy: Float, r: Float, p: Paint) {}
    fun drawRoundRect(l: Float, t: Float, r: Float, b: Float, rx: Float, ry: Float, p: Paint) {}
    fun drawLine(x0: Float, y0: Float, x1: Float, y1: Float, p: Paint) {}
    fun drawPath(path: Path, p: Paint) {}
    fun drawArc(l: Float, t: Float, r: Float, b: Float, s: Float, sw: Float, u: Boolean, p: Paint) {}
    fun drawText(s: String, x: Float, y: Float, p: Paint) {}
    fun drawColor(c: Int) {}
    fun drawBitmap(b: Bitmap, src: Rect?, dst: RectF, p: Paint?) {}
    fun drawBitmap(b: Bitmap, src: Rect?, dst: Rect, p: Paint?) {}
    fun drawBitmap(b: Bitmap, x: Float, y: Float, p: Paint?) {}
    fun save(): Int = 0; fun restore() {}
    fun rotate(deg: Float, px: Float, py: Float) {}
    fun rotate(deg: Float) {}
    fun translate(x: Float, y: Float) {}
    fun scale(x: Float, y: Float) {}
    fun clipRect(l: Float, t: Float, r: Float, b: Float): Boolean = true
    val width = 0; val height = 0
}
