package android.app
open class Activity : android.content.Context() { open fun onCreate(b: android.os.Bundle?) {}; val window = android.view.Window(); fun setContentView(v: android.view.View) {} }
