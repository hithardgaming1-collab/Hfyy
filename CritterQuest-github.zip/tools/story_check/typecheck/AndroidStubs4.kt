package android.os
object SystemClock { fun uptimeMillis(): Long = 0L; fun elapsedRealtime(): Long = 0L }
class Bundle
