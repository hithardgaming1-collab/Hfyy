package com.example.critterquest

import java.io.File

/** Writes MAPS.md straight from the real map/NPC data so the docs can never go out of date. */
object Docs {
    private val order = listOf("home", "mossbrook", "lab", "route1", "briar", "leafshrine", "route2", "tidewatch", "tideshrine",
        "route3", "cinder", "embershrine", "route4", "keep", "heart")

    @JvmStatic fun main(args: Array<String>) {
        val g = Game(); g.newGame(); g.chooseStarter(0)
        val sb = StringBuilder()
        sb.append("# Critter Quest - World Maps\n\n")
        sb.append("Every map is plain ASCII art in `app/src/main/java/com/example/critterquest/Maps.kt`. ")
        sb.append("Row 0 / column 0 is the top-left tile. Previews below are rendered by the game's own drawing code (`tools/story_check`).\n\n")
        sb.append("![World overview](docs/world_overview.png)\n\n")
        sb.append("## World layout\n\n```\n")
        sb.append("  Your House <-> Mossbrook <-> Fern's Lab\n          |  east (needs a partner)\n  Whisper Meadow (Route 1)\n          |  east\n")
        sb.append("  Briar Hollow <-> Leaf Shrine            Warden Willow  -> Leaf Sigil\n          |  south\n  Saltwind Shore (Route 2)\n          |  south\n")
        sb.append("  Tidewatch Harbor <-> Tide Shrine        Warden Marina  -> Tide Sigil\n          |  east\n  Ashen Trail (Route 3)\n          |  east\n")
        sb.append("  Cinderpeak <-> Ember Shrine             Warden Cinder  -> Ember Sigil\n          |  north (needs the Ember Sigil)\n  Gloam Pass (Route 4)\n          |  Shrine Gate (needs all 3 Sigils)\n")
        sb.append("  Hollow Keep\n          |  door guarded by Lieutenant Vex\n  Heart Chamber                           Baron Gloam, the Heart Bell\n```\n\n")
        sb.append("## Tile legend\n\n| Char | Tile | Walkable | Notes |\n|---|---|---|---|\n")
        val notes = mapOf('.' to "themed ground", ',' to "path", ';' to "tall grass - wild critters appear here", '#' to "tree / cliff / rock wall",
            '~' to "water", '=' to "bridge over water", '^' to "roof", 'h' to "house wall", 'D' to "door (needs a warp entry)", '*' to "flowers",
            'f' to "fence", 's' to "sign - press OK (text comes from the map's `notes`)", 'R' to "boulder", 'L' to "lava", 'b' to "sand",
            '_' to "indoor floor", 'W' to "indoor wall", 'T' to "table (can have a note)", 'B' to "bed - rest and save", 'P' to "Rest Stone - heal and save",
            'G' to "Shrine Gate - solid until all 3 Sigils are used", 'c' to "crystal / pillar", 'r' to "rug", 'K' to "shelf (can have a note)",
            '1' to "starter orb 1 (Emberpup)", '2' to "starter orb 2 (Aquafin)", '3' to "starter orb 3 (Sproutle)", 'Q' to "the Heart Bell (2 tiles wide)")
        for (t in Tl.values()) sb.append("| `${t.ch}` | ${t.name.lowercase()} | ${if (t.solid) "no" else "yes"} | ${notes[t.ch] ?: ""} |\n")
        sb.append("\n")
        val dirs = arrayOf("down", "left", "right", "up")
        for ((n, id) in order.withIndex()) {
            val m = MAPS.getValue(id)
            sb.append("## ${n + 1}. ${m.name}  (`$id`, ${m.w}x${m.h}, ${m.theme.name.lowercase()})\n\n![${m.name}](docs/maps/$id.png)\n\n")
            if (m.warps.isNotEmpty()) {
                sb.append("**Warps**\n\n| Step on (x,y) | Goes to | Arrives at | Condition |\n|---|---|---|---|\n")
                for (w in m.warps) {
                    val src = if (w.x0 == w.x1 && w.y0 == w.y1) "${w.x0},${w.y0}" else "${w.x0},${w.y0} to ${w.x1},${w.y1}"
                    val cond = if (w.need != null) w.deny.take(70) else if (m.tile(w.x0, w.y0) == Tl.GATE) "all 3 Sigils (cut-scene)" else ""
                    sb.append("| $src | ${MAPS.getValue(w.to).name} | ${w.tx},${w.ty} | $cond |\n")
                }
                sb.append("\n")
            }
            if (m.wild.isNotEmpty()) {
                sb.append("**Wild critters** (14% per step in tall grass)\n\n| Critter | Levels | Weight |\n|---|---|---|\n")
                for (w in m.wild) sb.append("| ${DEX[w.sp].name} | ${w.lo}-${w.hi} | ${w.weight} |\n")
                sb.append("\n")
            }
            val people = NPCS.filter { it.map == id }
            if (people.isNotEmpty()) {
                sb.append("**People**\n\n| Who | Tile | Facing | Role |\n|---|---|---|---|\n")
                for (p in people) {
                    val role = p.trainer?.let { t ->
                        val team = t.team(g).joinToString(", ") { "${DEX[it.first].name} Lv${it.second}" }
                        (if (t.smart) "boss/trainer (smart AI): " else "trainer: ") + team + if (p.sight > 0) " (sees ${p.sight} tiles)" else ""
                    } ?: "talks"
                    sb.append("| ${p.name} | ${p.x},${p.y} | ${dirs[p.face]} | $role |\n")
                }
                sb.append("\n")
            }
            if (m.notes.isNotEmpty()) {
                sb.append("**Signs / things to read**\n\n")
                for ((k, v) in m.notes.entries.distinctBy { it.value }) sb.append("- (${k.first},${k.second}) ${v}\n")
                sb.append("\n")
            }
            sb.append("```\n").append(m.rows.joinToString("\n")).append("\n```\n\n")
        }
        File(args[0]).writeText(sb.toString())
        println("wrote ${args[0]}")
    }
}
