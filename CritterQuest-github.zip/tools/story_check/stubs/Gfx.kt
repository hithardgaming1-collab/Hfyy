package android.graphics

import java.awt.BasicStroke
import java.awt.Graphics2D
import java.awt.RenderingHints
import java.awt.geom.Arc2D
import java.awt.geom.Ellipse2D
import java.awt.geom.Path2D
import java.awt.geom.RoundRectangle2D
import java.awt.image.BufferedImage

object Color {
    const val WHITE = -1; const val BLACK = 0xFF000000.toInt(); const val GRAY = 0xFF888888.toInt(); const val YELLOW = 0xFFFFFF00.toInt()
    fun rgb(r: Int, g: Int, b: Int): Int = (0xFF shl 24) or (r.coerceIn(0, 255) shl 16) or (g.coerceIn(0, 255) shl 8) or b.coerceIn(0, 255)
    fun argb(a: Int, r: Int, g: Int, b: Int): Int = (a.coerceIn(0, 255) shl 24) or (r.coerceIn(0, 255) shl 16) or (g.coerceIn(0, 255) shl 8) or b.coerceIn(0, 255)
    fun red(c: Int) = (c shr 16) and 255
    fun green(c: Int) = (c shr 8) and 255
    fun blue(c: Int) = c and 255
}

class Path {
    val p = Path2D.Float()
    fun reset() { p.reset() }
    fun moveTo(x: Float, y: Float) { p.moveTo(x.toDouble(), y.toDouble()) }
    fun lineTo(x: Float, y: Float) { p.lineTo(x.toDouble(), y.toDouble()) }
    fun close() { p.closePath() }
}

class Paint {
    enum class Style { FILL, STROKE }
    enum class Cap { BUTT, ROUND }
    enum class Align { LEFT, CENTER, RIGHT }
    var color = 0; var style = Style.FILL; var strokeWidth = 1f; var strokeCap = Cap.BUTT
    var textSize = 12f; var textAlign = Align.LEFT
}

class Canvas(val img: BufferedImage) {
    val g: Graphics2D = img.createGraphics().also { it.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON) }
    private fun use(p: Paint) { g.color = java.awt.Color(p.color, true); if (p.style == Paint.Style.STROKE) g.stroke = BasicStroke(p.strokeWidth, if (p.strokeCap == Paint.Cap.ROUND) BasicStroke.CAP_ROUND else BasicStroke.CAP_BUTT, BasicStroke.JOIN_ROUND) }
    private fun fillOrDraw(s: java.awt.Shape, p: Paint) { use(p); if (p.style == Paint.Style.FILL) g.fill(s) else g.draw(s) }
    fun drawRect(l: Float, t: Float, r: Float, b: Float, p: Paint) = fillOrDraw(java.awt.geom.Rectangle2D.Float(l, t, r - l, b - t), p)
    fun drawOval(l: Float, t: Float, r: Float, b: Float, p: Paint) = fillOrDraw(Ellipse2D.Float(l, t, r - l, b - t), p)
    fun drawCircle(cx: Float, cy: Float, r: Float, p: Paint) = fillOrDraw(Ellipse2D.Float(cx - r, cy - r, 2 * r, 2 * r), p)
    fun drawRoundRect(l: Float, t: Float, r: Float, b: Float, rx: Float, ry: Float, p: Paint) = fillOrDraw(RoundRectangle2D.Float(l, t, r - l, b - t, rx * 2, ry * 2), p)
    fun drawLine(x0: Float, y0: Float, x1: Float, y1: Float, p: Paint) { use(p); g.stroke = BasicStroke(p.strokeWidth, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND); g.draw(java.awt.geom.Line2D.Float(x0, y0, x1, y1)) }
    fun drawPath(path: Path, p: Paint) = fillOrDraw(path.p, p)
    fun drawArc(l: Float, t: Float, r: Float, b: Float, start: Float, sweep: Float, useCenter: Boolean, p: Paint) =
        fillOrDraw(Arc2D.Float(l, t, r - l, b - t, -start, -sweep, if (useCenter) Arc2D.PIE else Arc2D.OPEN), p)
    fun drawColor(c: Int) { g.color = java.awt.Color(c, true); g.fillRect(0, 0, img.width, img.height) }
    fun save() { }
    fun restore() { }
    fun rotate(deg: Float, px: Float, py: Float) { }
}
