#!/bin/sh
# Re-runs the automatic story checks after you edit maps, NPCs or dialogue.
# Needs: a JDK (17+) and the Kotlin compiler (kotlinc / kotlin on PATH, version 1.9+).
#   ./run.sh            validate every map + run every NPC script
#   ./run.sh play       also play the whole game with a bot for all 3 starters
#   ./run.sh balance    boss win-rate tables
#   ./run.sh maps       re-render docs/maps/*.png and rewrite MAPS.md
#   ./run.sh dex        rewrite CRITTERS.md (species, moves, type chart) from the real data
#   ./run.sh fuzz       thousands of random battles: moves, status, swaps, catching, learning (finds crashes)
#   ./run.sh demo       print two sample battles as text (to read the messages and turn order)
#   ./run.sh cache      only the map-cache check (also part of the plain ./run.sh)
#   ./run.sh typecheck  compile the WHOLE app (GameView, MainActivity...) against stand-in Android classes, no SDK needed
set -e
cd "$(dirname "$0")"
SRC=../../app/src/main/java/com/example/critterquest
OUT=${TMPDIR:-/tmp}/critterquest_check
rm -rf "$OUT"; mkdir -p "$OUT"
if [ "$1" = "typecheck" ]; then
    # compile-only: catches typos and API mistakes in the Android-facing files without the Android SDK
    RES=../../app/src/main/res/drawable-nodpi
    { echo "package com.example.critterquest"; echo "object R { object drawable {"; i=1
      for f in $RES/*.png; do echo " const val $(basename "$f" .png)=$i"; i=$((i+1)); done
      echo " const val banner=$i } }"; } > "$OUT/R.kt"
    kotlinc -nowarn -d "$OUT/classes" typecheck/AndroidStubs*.kt "$OUT/R.kt" $SRC/*.kt
    echo "typecheck: the whole app compiles"
    exit 0
fi
# the R stub is rebuilt from the real sprite folder so new species never need a manual edit
RES=../../app/src/main/res/drawable-nodpi
{ echo "package com.example.critterquest"; echo "object R { object drawable {"; i=1
  for f in $RES/*.png; do echo " const val $(basename "$f" .png)=$i"; i=$((i+1)); done
  echo " const val banner=$i } }"; } > stubs/R.kt
kotlinc -nowarn -d "$OUT" $SRC/Moves.kt $SRC/Critters.kt $SRC/World.kt $SRC/Maps.kt $SRC/Game.kt $SRC/Battle.kt $SRC/Cast.kt $SRC/Story.kt $SRC/Art.kt \
    stubs/R.kt stubs/Gfx.kt Check.kt CacheCheck.kt Preview.kt Docs.kt DexDocs.kt
if [ "$1" = "dex" ]; then
    kotlin -cp "$OUT" com.example.critterquest.DexDocs ../../CRITTERS.md
elif [ "$1" = "cache" ]; then
    kotlin -cp "$OUT" com.example.critterquest.CacheCheck
elif [ "$1" = "maps" ]; then
    kotlin -cp "$OUT" com.example.critterquest.Preview ../../docs/maps 32
    kotlin -cp "$OUT" com.example.critterquest.Docs ../../MAPS.md
else
    kotlin -cp "$OUT" com.example.critterquest.Check "$@"
fi
