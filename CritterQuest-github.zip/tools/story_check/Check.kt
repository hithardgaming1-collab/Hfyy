// Story check: validates every map, runs every NPC script, and plays the whole game with a bot.
//   args:  (none) = validate + smoke test     play = full playthroughs for all 3 starters     balance = boss win-rate tables
// See tools/story_check/run.sh. It never touches Android; it uses the same Game/Battle/Story code the app uses.
package com.example.critterquest

import kotlin.random.Random

// ======================= static validation =======================
fun validate(): Int {
    var bad = 0
    fun err(s: String) { println("  ERROR: $s"); bad++ }
    for ((id, m) in MAPS) {
        for ((y, r) in m.rows.withIndex()) {
            if (r.length != m.w) err("$id row $y has width ${r.length} != ${m.w}")
            for ((x, ch) in r.withIndex()) if (Tl.of(ch) == null) err("$id unknown tile '$ch' at $x,$y")
        }
        for (w in m.warps) {
            val dst = MAPS[w.to]
            if (dst == null) { err("$id warp -> missing map ${w.to}"); continue }
            for (y in w.y0..w.y1) for (x in w.x0..w.x1) {
                if (m.tile(x, y).solid && m.tile(x, y) != Tl.GATE) err("$id warp source $x,$y is solid (${m.tile(x, y)})")
                val tx = w.tx + (x - w.x0); val ty = w.ty + (y - w.y0)
                if (tx !in 0 until dst.w || ty !in 0 until dst.h) err("$id warp $x,$y arrives out of bounds in ${w.to}")
                else if (dst.tile(tx, ty).solid) err("$id warp $x,$y arrives on solid ${dst.tile(tx, ty)} at $tx,$ty in ${w.to}")
            }
        }
        for ((k, _) in m.notes) if (!m.tile(k.first, k.second).solid) err("$id note at ${k.first},${k.second} is on a walkable tile ${m.tile(k.first, k.second)}")
        for (t in TRIGS.filter { it.map == id }) if (t.x1 >= m.w || t.y1 >= m.h) err("$id trigger out of bounds")
    }
    val seen = HashSet<String>()
    for (n in NPCS) {
        val m = MAPS[n.map]
        if (m == null) { err("npc ${n.id} on missing map ${n.map}"); continue }
        if (n.id == "gloam_g") continue // intentionally appears in the opened gate during the cut-scene
        if (m.tile(n.x, n.y).solid) err("npc ${n.id} stands on solid ${m.tile(n.x, n.y)} at ${n.x},${n.y} in ${n.map}")
        if (m.warpAt(n.x, n.y) != null) err("npc ${n.id} stands on a warp")
        if (!seen.add(n.id)) err("duplicate npc id ${n.id}")
    }
    // static reachability per map: from every arrival point you can reach every warp / interactable
    for ((id, m) in MAPS) {
        val arrivals = ArrayList<Pair<Int, Int>>()
        for ((_, o) in MAPS) for (w in o.warps) if (w.to == id) for (y in w.y0..w.y1) for (x in w.x0..w.x1) arrivals.add((w.tx + x - w.x0) to (w.ty + y - w.y0))
        if (id == "home") arrivals.add(4 to 6)
        val seenT = HashSet<Pair<Int, Int>>(); val dq = ArrayDeque<Pair<Int, Int>>()
        arrivals.forEach { if (seenT.add(it)) dq.add(it) }
        while (dq.isNotEmpty()) {
            val (x, y) = dq.removeFirst()
            for (d in 0..3) { val p = (x + DX[d]) to (y + DY[d]); if (p.first in 0 until m.w && p.second in 0 until m.h && !m.tile(p.first, p.second).solid && seenT.add(p)) dq.add(p) }
        }
        for (w in m.warps) for (y in w.y0..w.y1) for (x in w.x0..w.x1) if ((x to y) !in seenT && m.tile(x, y) != Tl.GATE) {
            // gate tiles are only reachable by stepping from below once open; treat them via neighbours
            err("$id warp tile $x,$y not reachable from arrivals")
        }
        for (y in 0 until m.h) for (x in 0 until m.w) {
            val t = m.tile(x, y)
            if (t in listOf(Tl.STONE, Tl.BED, Tl.ORB1, Tl.ORB2, Tl.ORB3, Tl.GATE, Tl.BELL) || m.notes.containsKey(x to y)) {
                if ((0..3).none { d -> (x + DX[d]) to (y + DY[d]) in seenT }) err("$id interactable $t at $x,$y cannot be reached")
            }
        }
        for (n in NPCS.filter { it.map == id }) if ((0..3).none { d -> (n.x + DX[d]) to (n.y + DY[d]) in seenT }) err("npc ${n.id} cannot be reached")
        for (y in 0 until m.h) for (x in 0 until m.w) if (m.tile(x, y) == Tl.TALL && (x to y) !in seenT) err("$id tall grass at $x,$y is unreachable")
    }
    // species and moves
    val names = HashSet<String>()
    for ((i, sp) in DEX.withIndex()) {
        if (!names.add(sp.name)) err("duplicate species name ${sp.name}")
        if (sp.base.size != 6 || sp.base.any { it <= 0 }) err("${sp.name} has bad base stats")
        var prev = 0
        for ((l, n) in sp.learn) {
            if (mvOrNull(n) == null) err("${sp.name} learns unknown move '$n'")
            if (l < prev) err("${sp.name}'s learnset is not sorted at $n"); prev = l
            if (l !in 1..MAX_LVL) err("${sp.name} learns $n at level $l")
        }
        if (sp.learn.none { it.first == 1 }) err("${sp.name} knows no move at level 1")
        if (sp.learn.none { mvOrNull(it.second)?.damaging == true }) err("${sp.name} has no attacking move")
        if (sp.evo >= 0 && (sp.evo !in DEX.indices || sp.evo == i || sp.evoLvl !in 2..MAX_LVL)) err("${sp.name} has a bad evolution")
        if (sp.catchRate !in 3..255) err("${sp.name} has a bad catch rate")
    }
    val movesSeen = HashSet<String>()
    for (m in MOVES) if (!movesSeen.add(m.name)) err("duplicate move ${m.name}")
    // every species can be obtained: wild tables + story gifts, then evolutions
    val got = HashSet<Int>(listOf(EMBERPUP, AQUAFIN, SPROUTLE))
    for ((_, m) in MAPS) for (w in m.wild) got.add(w.sp)
    var grew = true
    while (grew) { grew = false; for (i in got.toList()) { val e = DEX[i].evo; if (e >= 0 && got.add(e)) grew = true } }
    for (i in DEX.indices) if (i !in got) err("${DEX[i].name} cannot be obtained anywhere")
    for ((id, m) in MAPS) for (w in m.wild) if (w.sp !in DEX.indices || w.lo > w.hi || w.lo < 1) err("$id has a bad wild entry")
    println("validate: ${MAPS.size} maps, ${NPCS.size} npcs, ${TRIGS.size} triggers, ${DEX.size} species, ${MOVES.size} moves, errors=$bad")
    return bad
}

// ======================= bot that plays the game =======================
class Bot(val starter: Int, seed: Int) {
    val rnd = Random(seed)
    val g = Game(rnd)
    var now = 1000L
    var losses = 0
    var grindBattles = 0
    val log = ArrayList<String>()
    val pending = HashSet<String>()

    private fun offense(a: Mon, d: Mon) = (a.moves.filter { it.pp > 0 }.maxOfOrNull { moveScore(a, d, it.move) } ?: 0f).toDouble()
    private fun score(m: Mon, foe: Mon): Double = (offense(m, foe) - offense(foe, m)) / 60.0 + m.hp.toDouble() / m.maxHp

    /** A sensible player: lead with the best matchup, rest when low, pick the strongest move. */
    fun act(b: Battle) {
        var best = -1; var bs = -99.0
        for (i in b.party.indices) if (b.party[i].hp > 0) {
            val sc = score(b.party[i], b.foe); if (sc > bs) { bs = sc; best = i }
        }
        if (b.swapping) { b.swap(if (best >= 0) best else b.party.indexOfFirst { it.hp > 0 }); return }
        val curScore = score(b.me, b.foe)
        if (best != b.cur && b.canSwap() && bs - curScore >= 1.5) { b.use(M_SWAP); b.swap(best); return }
        if (b.me.hp < b.me.maxHp * 0.38 && b.heals > 0) { b.use(M_REST); return }
        autoFight(b)
    }

    fun avgLvl() = g.party.map { it.lvl }.average()

    fun runBattle() {
        val req = g.battleReq!!
        val team = if (req.trainer != null) req.trainer.team(g).map { Mon(DEX[it.first], it.second) } else listOf(req.wild!!)
        val b = Battle(g.party, team, req.trainer, g.heals, g.orbs, { now }, rnd)
        var guard = 0
        while (b.over == 0 && guard++ < 5000) { b.pump(); autoLearn(b); if (b.menuOn && b.learnFor == null) act(b) }
        check(b.over != 0) { "battle did not end" }
        g.heals = b.heals; g.orbs = b.orbs
        if (b.over == 2) { losses++; log.add("  LOSS vs ${req.trainer?.name ?: "wild"} (party ${g.party.joinToString { it.s.name + it.lvl }}) at ${g.map.id}") }
        g.battleDone(b.over, b.caught)
    }

    fun settle() {
        var guard = 0
        while (guard++ < 20000) {
            g.tick(now)
            val c = g.cur
            when {
                g.battleReq != null -> runBattle()
                c is Step.Say -> g.advance()
                c is Step.Ask -> g.advance(0)
                !g.idle(now) -> now += 60
                else -> return
            }
        }
        error("settle stuck at ${g.map.id} ${g.px},${g.py} cur=${g.cur} q")
    }

    private fun solidAt(m: String, x: Int, y: Int): Boolean {
        val mm = MAPS.getValue(m); val t = mm.tile(x, y)
        if (t == Tl.GATE) return !g.f("gate_open")
        if (t.solid) return true
        return NPC_BY_MAP[m]?.any { it.x == x && it.y == y && it.show(g) } == true
    }

    data class Node(val m: String, val x: Int, val y: Int)

    /** BFS from the player's position; returns directions to reach a node satisfying [goal]. */
    fun path(goal: (Node) -> Boolean): List<Int>? {
        val start = Node(g.map.id, g.px, g.py)
        val prev = HashMap<Node, Pair<Node, Int>>(); val dq = ArrayDeque<Node>(); dq.add(start); prev[start] = start to -1
        while (dq.isNotEmpty()) {
            val n = dq.removeFirst()
            if (goal(n) && n != start) {
                val out = ArrayList<Int>(); var c = n
                while (c != start) { val (p, d) = prev.getValue(c); out.add(d); c = p }
                return out.reversed()
            }
            val m = MAPS.getValue(n.m)
            for (d in 0..3) {
                val nx = n.x + DX[d]; val ny = n.y + DY[d]
                if (nx < 0 || ny < 0 || nx >= m.w || ny >= m.h) continue
                val w = m.warpAt(nx, ny)
                if (w?.need != null && !w.need.invoke(g)) continue
                if (solidAt(n.m, nx, ny)) continue
                val nn = if (w != null) Node(w.to, w.tx + (nx - w.x0), w.ty + (ny - w.y0)) else Node(n.m, nx, ny)
                if (nn !in prev) { prev[nn] = n to d; dq.add(nn) }
            }
        }
        return null
    }

    /** Walk a path; stops early (returns false) if something interrupts and moves us off-route. */
    fun walk(p: List<Int>): Boolean {
        for (d in p) {
            val before = Node(g.map.id, g.px, g.py)
            now += 200
            g.step(d, now); now += 200; settle()
            val expected = Node(before.m, before.x + DX[d], before.y + DY[d])
            val after = Node(g.map.id, g.px, g.py)
            // anything other than a clean step (warp aside) means a cut-scene / fight happened: replan
            if (after != expected && !(after.m != before.m)) return false
            if (g.battleReq != null || g.cur != null) { settle() }
        }
        return true
    }

    fun go(goal: (Node) -> Boolean, what: String) {
        var tries = 0
        while (tries++ < 60) {
            val p = path(goal) ?: error("no path to $what from ${g.map.id} ${g.px},${g.py}")
            if (walk(p)) return
        }
        error("could not reach $what")
    }

    fun goMap(id: String) { if (g.map.id != id) go({ it.m == id }, "map $id") }

    fun faceAndUse(dx: Int, dy: Int) {
        val d = (0..3).first { DX[it] == dx && DY[it] == dy }
        now += 200; g.step(d, now); now += 200; g.tick(now)
        g.interact(now); settle()
    }

    fun talkNpc(id: String) {
        val n = NPCS.first { it.id == id }
        goMap(n.map)
        go({ it.m == n.map && abs(it.x - n.x) + abs(it.y - n.y) == 1 }, "npc $id")
        if (g.map.id != n.map) return
        faceAndUse(n.x - g.px, n.y - g.py)
    }

    private fun abs(i: Int) = if (i < 0) -i else i

    fun useTile(map: String, tile: Tl, nth: Int = 0) {
        val m = MAPS.getValue(map)
        val spots = ArrayList<Pair<Int, Int>>()
        for (y in 0 until m.h) for (x in 0 until m.w) if (m.tile(x, y) == tile) spots.add(x to y)
        val (tx, ty) = spots[nth]
        goMap(map)
        go({ it.m == map && abs(it.x - tx) + abs(it.y - ty) == 1 }, "$tile in $map")
        faceAndUse(tx - g.px, ty - g.py)
    }

    fun restAt(map: String) { useTile(map, if (map == "home") Tl.BED else Tl.STONE) }

    fun nearestGrassMap(): String = when (g.map.id) {
        "keep", "route4" -> "route4"; "cinder", "route3", "embershrine" -> "route3"; "tidewatch", "tideshrine", "route2" -> "route2"
        else -> if (g.sigils >= 2) "route3" else if (g.sigils >= 1) "route2" else "route1"
    }

    /** Grind wild fights in tall grass until the partner reaches [lvl]. */
    fun grind(lvl: Int) {
        val gm = nearestGrassMap(); val m = MAPS.getValue(gm)
        var guard = 0
        while (avgLvl() < lvl && guard++ < 400) {
            goMap(gm)
            var target: Pair<Int, Int>? = null
            for (y in 0 until m.h) for (x in 0 until m.w) if (m.tile(x, y) == Tl.TALL && target == null) target = x to y
            val t = target!!
            go({ it.m == gm && it.x == t.first && it.y == t.second }, "grass")
            var steps = 0
            while (avgLvl() < lvl && steps++ < 300) {
                val d = if (steps % 2 == 0) RIGHT else LEFT
                now += 200
                val moved = g.step(d, now); now += 200; settle()
                if (g.map.id != gm) break
                if (!moved) { val d2 = if (d == RIGHT) LEFT else RIGHT; g.step(d2, now); now += 200; settle() }
                if (g.battleReq == null && g.party.all { it.hp < it.maxHp * 0.4 } && steps % 3 == 0) {
                    // too hurt: stone / bed
                    val rm = if (gm == "route1") null else gm
                    if (rm != null) { useTile(rm, Tl.STONE); goMap(gm); go({ it.m == gm && it.x == t.first && it.y == t.second }, "grass") }
                    else { restAt("mossbrook"); break }
                }
            }
            grindBattles++
            break
        }
    }

    /** Win a story fight; after a blackout, grind two levels and retry. */
    fun until(what: String, cond: () -> Boolean, act: () -> Unit) {
        var attempts = 0
        while (!cond()) {
            check(attempts++ < 12) { "stuck: $what" }
            if (attempts > 1) {
                val lvlBefore = avgLvl()
                grind((avgLvl() + 2).toInt())
                log.add("  retry '$what' attempt $attempts after grinding avg Lv${lvlBefore.toInt()} -> Lv${avgLvl().toInt()}")
                // heal at stone/bed
                val rm = g.map.id
                if (rm !in listOf("keep", "route4")) { }
            }
            act()
        }
    }
}

/** Pick the best usable move (by [moveScore]) and fight; Struggle if nothing has PP left. */
fun autoFight(b: Battle) {
    val me = b.me
    val slot = me.moves.indices.filter { me.moves[it].pp > 0 }.maxByOrNull { moveScore(me, b.foe, me.moves[it].move) } ?: -1
    b.use(M_FIGHT); b.fightWith(slot)
}

/** Answer a "forget a move?" prompt like a sensible player: swap out the weakest move if the new one is stronger. */
fun autoLearn(b: Battle) {
    val m = b.learnFor ?: return; val nw = b.learnMove ?: return
    val weakest = m.moves.indices.minByOrNull { m.moves[it].move.power }!!
    b.answerLearn(if (nw.power > m.moves[weakest].move.power) weakest else -1)
}

var lastBot: Bot? = null
var totalLosses = 0
fun playthrough(starter: Int, seed: Int): Boolean {
    val b = Bot(starter, seed); lastBot = b; val g = b.g
    println("=== playthrough: starter ${DEX[starter].name} (seed $seed)")
    fun mark(s: String) = println("  [${s.padEnd(18)}] ${g.party.joinToString(" ") { it.s.name.take(5) + it.lvl }}  losses=${b.losses}")
    g.newGame(); b.settle()
    // Prologue
    b.goMap("lab"); b.settle()
    check(g.f("lab_intro")) { "lab intro did not fire" }
    b.useTile("lab", Tl.values().first { it.ordinal == Tl.ORB1.ordinal + starter }, 0); b.settle()
    check(g.f("starter") && g.starter == starter) { "starter not chosen" }
    check(g.f("t_kit1")) { "kit1 spar not finished" }
    mark("lab done")
    // Leaf: Briar Hollow
    b.until("briar grunt", { g.f("t_g_briar") }) { b.talkNpc("g_briar") }
    b.until("willow", { g.f("sigil_leaf") }) { b.talkNpc("willow") }
    mark("leaf sigil")
    b.until("tide grunt", { g.f("t_g_tide") }) { b.talkNpc("g_tide") }
    b.until("marina", { g.f("sigil_tide") }) { b.talkNpc("marina") }
    mark("tide sigil")
    b.until("kit2", { g.f("t_kit2") }) { b.goMap("tidewatch"); b.settle(); if (!g.f("t_kit2")) b.talkNpc("kit_t") }
    mark("kit2")
    b.until("cinder grunt", { g.f("t_g_cinder") }) { b.talkNpc("g_cinder") }
    b.until("cinder", { g.f("sigil_ember") }) { b.talkNpc("cinder") }
    mark("ember sigil")
    b.goMap("route4"); b.settle()
    b.until("kit3", { g.f("t_kit3") }) { b.goMap("route4"); b.settle(); if (!g.f("t_kit3")) b.talkNpc("kit_p") }
    mark("kit3")
    check(g.sigils == 3)
    b.useTile("route4", Tl.GATE, 0); b.settle()
    check(g.f("gate_open")) { "gate did not open" }
    mark("gate open")
    b.goMap("keep"); b.settle()
    b.until("vex", { g.f("t_vex") }) { b.goMap("keep"); b.settle(); if (!g.f("t_vex")) b.talkNpc("vex") }
    mark("vex")
    b.goMap("heart"); b.settle()
    b.until("gloam", { g.f("ending") }) { b.goMap("heart"); b.settle(); if (!g.f("ending")) b.talkNpc("gloam") }
    mark("ending")
    check(g.endingPending) { "ending not pending" }
    // save/load round trip + finish
    g.finishGame()
    val s = g.serialize()
    check(g.f("champion") && g.map.id == "home")
    val g2 = Game(); check(g2.load(s)) { "load failed" }
    check(g2.flags == g.flags && g2.party.map { it.lvl } == g.party.map { it.lvl } && g2.starter == starter) { "save/load mismatch" }
    // post game: Kit rematch works
    b.talkNpc("kit_post"); mark("post-game rematch")
    println("  total losses=${b.losses}")
    totalLosses += b.losses
    return true
}

// ======================= every NPC script, many flag combos =======================
fun smoke() {
    val universe = listOf("starter", "kit_in_lab", "lab_intro", "kit_intro", "sigil_leaf", "sigil_tide", "sigil_ember", "gate_open", "gloam_here",
        "gloam_left", "t_vex", "t_gloam", "ending", "champion", "heart_crowd", "t_kit1", "t_kit2", "t_kit3", "t_g_briar", "t_willow")
    val rnd = Random(7); var runs = 0
    repeat(60) {
        val g = Game(rnd); g.newGame(); g.chooseStarter(it % 3)
        universe.forEach { f -> if (rnd.nextInt(2) == 0) g.set(f) }
        for (n in NPCS) {
            g.play(n.talk(g)); var guard = 0
            while (guard++ < 400) {
                g.tick(100_000L * guard)
                val c = g.cur
                when {
                    g.battleReq != null -> { val t = g.battleReq!!.trainer; if (t != null) t.team(g).forEach { check(it.first in DEX.indices) }; g.battleDone(if (rnd.nextInt(4) == 0) 2 else 1) }
                    c is Step.Say -> g.advance()
                    c is Step.Ask -> g.advance(rnd.nextInt(c.opts.size))
                    else -> break
                }
            }
            check(guard < 400) { "script for ${n.id} never ended" }
            runs++
        }
        for (t in TRIGS) { g.play(t.script(g)); var guard = 0
            while (guard++ < 400) { g.tick(100_000L * guard); val c = g.cur
                when { g.battleReq != null -> g.battleDone(1); c is Step.Say -> g.advance(); c is Step.Ask -> g.advance(0); else -> break } } }
    }
    println("smoke: $runs NPC scripts ran cleanly across random flag sets")
}

// ======================= catching, storage and save compatibility =======================
fun catchTest() {
    val rnd = Random(5)
    val g = Game(rnd); g.newGame(); g.chooseStarter(0)
    repeat(40) {
        val foe = Mon(DEX[NIBBLET], 4); foe.hp = 1
        g.battleReq = BattleReq(null, foe)
        val b = Battle(g.party, listOf(foe), null, g.heals, g.orbs, { 0L }, rnd)
        var guard = 0
        while (b.over == 0 && guard++ < 500) { b.pump(); if (b.menuOn) { if (b.orbs > 0) b.use(M_CATCH) else b.use(M_RUN) } }
        check(b.over == 4 || b.over == 3 || b.over == 2) { "catch battle ended oddly: ${b.over}" }
        if (b.over == 4) check(b.caught === foe) { "caught critter missing" }
        g.heals = b.heals; g.orbs = b.orbs
        g.battleDone(b.over, b.caught)
        var d = 0; while (g.cur != null && d++ < 20) g.advance()
        g.healAll()
    }
    check(g.party.size == MAX_PARTY) { "party should be full after many catches (${g.party.size})" }
    check(g.box.isNotEmpty()) { "overflow critters should go to the box" }
    check(NIBBLET in g.dexCaught) { "dex not updated" }
    // box deposit / withdraw
    val before = g.box.size
    g.deposit(5); check(g.box.size == before + 1 && g.party.size == MAX_PARTY - 1)
    g.withdraw(0); check(g.party.size == MAX_PARTY && g.box.size == before)
    // save round trip keeps moves, PP, box, orbs and dex
    g.party[0].moves[0].pp = 3
    val text = g.serialize(); val g2 = Game(); check(g2.load(text)) { "load failed" }
    check(g2.box.size == g.box.size && g2.orbs == g.orbs && g2.dexCaught == g.dexCaught) { "box/orbs/dex lost in save" }
    check(g2.party.map { m -> m.moves.map { it.move.name to it.pp } } == g.party.map { m -> m.moves.map { it.move.name to it.pp } }) { "moves lost in save" }
    // a save from before moves existed must still load, with sensible default moves
    val old = text.lines().filter { !it.startsWith("orbs=") && !it.startsWith("box=") && !it.startsWith("dex=") }.joinToString("\n") { l ->
        if (l.startsWith("party=")) "party=" + l.removePrefix("party=").split(';').joinToString(";") { it.split(':').take(4).joinToString(":") } else l }
    val g3 = Game(); check(g3.load(old)) { "old-format save failed to load" }
    check(g3.party.all { it.moves.isNotEmpty() } && g3.orbs == MAX_ORBS) { "old save defaults wrong" }
    println("catch test: ok (party ${g.party.size}, box ${g.box.size}, dex ${g.dexCaught.size}/${DEX.size})")
}

// ======================= random battles: finds crashes and rule bugs =======================
fun fuzz(rounds: Int) {
    val rnd = Random(11); var wins = 0; var losses = 0; var caught = 0; var ran = 0
    val seenStatus = HashSet<St>(); var learned = 0
    repeat(rounds) { r ->
        val party = List(1 + rnd.nextInt(3)) { Mon(DEX[rnd.nextInt(DEX.size)], 3 + rnd.nextInt(28)) }
        val wild = rnd.nextInt(2) == 0
        val team = List(if (wild) 1 else 1 + rnd.nextInt(3)) { Mon(DEX[rnd.nextInt(DEX.size)], 3 + rnd.nextInt(28)) }
        val tr = if (wild) null else Trainer("f", "Fuzz", rnd.nextBoolean()) { emptyList() }
        val b = Battle(party, team, tr, 2, 3, { 0L }, rnd)
        var guard = 0
        while (b.over == 0 && guard++ < 30000) {
            b.pump()
            if (b.learnFor != null) { learned++; b.answerLearn(rnd.nextInt(6)) }
            if (b.menuOn && b.learnFor == null) {
                if (b.swapping) b.swap(rnd.nextInt(party.size))
                else when (rnd.nextInt(12)) {
                    0 -> b.use(M_SWAP); 1 -> b.use(M_REST); 2 -> b.use(M_CATCH); 3 -> b.use(M_RUN)
                    else -> { if (b.fighting || rnd.nextBoolean()) { b.use(M_FIGHT); b.fightWith(rnd.nextInt(4)) } else autoFight(b) }
                }
            }
            (party + team).forEach { m -> m.status?.let { seenStatus.add(it) }
                check(m.hp in 0..m.maxHp) { "hp out of range: ${m.s.name} ${m.hp}/${m.maxHp}" }
                check(m.moves.all { it.pp in 0..it.move.pp } && m.moves.size in 1..4) { "bad moves on ${m.s.name}" } }
        }
        check(guard < 30000) { "fuzz battle $r never ended (over=${b.over}, menuOn=${b.menuOn}, fighting=${b.fighting}, swapping=${b.swapping})" }
        when (b.over) { 1 -> wins++; 2 -> losses++; 3 -> ran++; 4 -> { caught++; check(b.caught != null) } }
        check((party + team).all { m -> m.status == null && m.stage.all { it == 0 } }) { "battle state leaked after the fight" }
    }
    println("fuzz: $rounds random battles ok (won $wins, lost $losses, ran $ran, caught $caught, learn prompts $learned, statuses seen $seenStatus)")
}

// ======================= balance =======================
fun winRate(me: Mon, team: List<Pair<Int, Int>>, smart: Boolean, trials: Int = 300): Double {
    var w = 0; val rnd = Random(3)
    repeat(trials) {
        val m = Mon(me.s, me.lvl); m.xp = 0
        val b = Battle(listOf(m), team.map { Mon(DEX[it.first], it.second) }, Trainer("x", "X", smart) { team }, MAX_HEALS, 0, { 0L }, rnd)
        var guard = 0
        while (b.over == 0 && guard++ < 5000) {
            b.pump(); autoLearn(b)
            if (b.menuOn && b.learnFor == null) {
                if (b.me.hp < b.me.maxHp * 0.38 && b.heals > 0) b.use(M_REST) else autoFight(b)
            }
        }
        if (b.over == 1) w++
    }
    return w.toDouble() / trials
}

fun demo() {
    val rnd = Random(4)
    fun fightLog(title: String, party: List<Mon>, team: List<Mon>, trainer: Trainer?) {
        println("--- $title")
        val b = Battle(party, team, trainer, 3, 3, { 0L }, rnd)
        println(b.text)
        var guard = 0
        while (b.over == 0 && guard++ < 400) {
            b.pump(); autoLearn(b)
            if (b.menuOn && b.learnFor == null) {
                if (b.swapping) { b.swap(b.party.indexOfFirst { it.hp > 0 }); continue }
                val m = b.me
                println("   [${m.s.name} Lv${m.lvl} HP ${m.hp}/${m.maxHp} ${m.status?.tag ?: ""} | ${b.foe.s.name} HP ${b.foe.hp}/${b.foe.maxHp} ${b.foe.status?.tag ?: ""}]  moves: ${m.moves.joinToString { it.move.name + " " + it.pp }}")
                if (m.hp < m.maxHp * 0.38 && b.heals > 0) b.use(M_REST) else autoFight(b)
            } else if (b.text.isNotEmpty()) println(b.text.also { })
        }
    }
    fightLog("Emberpup 5 vs wild Nibblet 4", listOf(Mon(DEX[EMBERPUP], 5)), listOf(Mon(DEX[NIBBLET], 4)), null)
    fightLog("Boss-ish: Sproutle 12 vs Marina", listOf(Mon(DEX[SPROUTLE], 12), Mon(DEX[BLAZEHORN], 12)), listOf(Mon(DEX[AQUAFIN], 14), Mon(DEX[TIDALON], 15)), Trainer("m", "Warden Marina", true) { emptyList() })
}

object Check {
@JvmStatic fun main(args: Array<String>) {
    if (args.contains("demo")) { demo(); return }
    var bad = validate()
    smoke()
    catchTest()
    if (CacheCheck.run() != 0) bad++
    fuzz(if (args.contains("fuzz")) 6000 else 400)
    if (args.contains("balance")) {
        println("--- win rate for a FRESH level-L partner (no xp carry) vs each boss, per starter")
        val g = Game(); g.newGame()
        val bosses = listOf(T_WILLOW, T_MARINA, T_CINDER, T_VEX, T_GLOAM)
        for (st in 0..2) {
            g.chooseStarter(st)
            val sp = if (st == 0) DEX[0] else DEX[st]
            for (t in bosses) {
                val team = t.team(g)
                val line = StringBuilder("${DEX[st].name.padEnd(9)} vs ${t.name.padEnd(16)} ${team.map { "${DEX[it.first].name}${it.second}" }}: ")
                for (L in (team.minOf { it.second } - 4)..(team.maxOf { it.second } + 4)) {
                    val me = Mon(if (L >= 10) DEX[evoOf(st)] else DEX[st], L)
                    line.append("L$L=${(winRate(me, team, t.smart) * 100).toInt()} ")
                }
                println(line)
            }
        }
    }
    if (args.contains("play")) {
        var ok = 0
        for (st in 0..2) for (seed in 1..2) { try { if (playthrough(st, seed)) ok++ } catch (e: Throwable) { println("  PLAYTHROUGH FAILED (starter $st seed $seed): $e") }
            lastBot?.log?.forEach(::println) }
        println("playthroughs completed: $ok/6, average losses per run = ${totalLosses / 6.0}")
    }
    if (bad > 0) System.exit(1)
}
}
