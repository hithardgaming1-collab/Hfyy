plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.critterquest"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.critterquest"
        minSdk = 21; targetSdk = 34; versionCode = 1; versionName = "1.0"
    }
    // One fixed "debug" key (the normal public Android debug password, kept in this folder), so every APK you build,
    // on your PC or online on GitHub, is signed the same way and installs OVER the old one without losing the save.
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions {
        jvmTarget = "17"
        // skip the generated null-check calls on every function call: the drawing code runs hundreds of them per frame
        freeCompilerArgs += listOf("-Xno-param-assertions", "-Xno-call-assertions", "-Xno-receiver-assertions")
    }
}
