package com.example.critterquest

import kotlin.math.min

// ---------------------------------------------------------------------------------------------
// The Market on every Critter Station: things to buy with coins (coins come from winning fights).
// To sell something new, add a Ware to MARKET below: its name, its price, a line about it, how many you carry
// now, how many more you can carry, and what buying n of it does. Nothing else needs to change.
// ---------------------------------------------------------------------------------------------

class Ware(val name: String, val price: Int, val desc: String, val have: Game.() -> Int, val room: Game.() -> Int, val give: Game.(Int) -> Unit)

val MARKET: List<Ware> = listOf(
    Ware("Critter Orb", ORB_PRICE, "Throw one at a weakened wild critter to catch it.", { orbs }, { ORB_CAP - orbs }, { orbs += it })
)

private val QUANTITIES = listOf(1, 5, 10)

/** The shop window: pick a ware, or go back to the station's menu. */
fun Game.marketHome(): List<Step> {
    val opts = MARKET.map { "${it.name}   ${it.price} coins" } + "Back"
    return listOf(ask("Market", "You have $coins coins. What would you like?", opts) { c ->
        if (c >= MARKET.size) boxHome(STATION_KEEPER) else marketWare(MARKET[c])
    })
}

private fun Game.marketWare(w: Ware): List<Step> {
    val opts = QUANTITIES.map { "Buy $it   ${it * w.price} coins" } + "Back"
    return listOf(ask("Market", "${w.name}: ${w.desc} You carry ${w.have(this)}. You have $coins coins.", opts) { c ->
        if (c >= QUANTITIES.size) marketHome()
        else {
            val want = QUANTITIES[c]; val room = w.room(this); val afford = coins / w.price
            val n = min(want, min(room, afford))
            val plural = { k: Int -> if (k == 1) w.name else w.name + "s" }
            when {
                room <= 0 -> listOf(say("Market", "You can't carry any more ${w.name}s.")) + marketWare(w)
                n <= 0 -> listOf(say("Market", "A ${w.name} costs ${w.price} coins. You have $coins.")) + marketWare(w)
                else -> {
                    coins -= n * w.price; w.give(this, n)
                    val why = if (n < want) (if (n == room) " That is all you can carry." else " That is all you can afford.") else ""
                    listOf(narr("Bought $n ${plural(n)} for ${n * w.price} coins.$why")) + marketWare(w)
                }
            }
        }
    })
}
