package com.example.critterquest

// ---------------------------------------------------------------------------------------------
// The legendary critters. Each waits at a fixed place (a Spot) in a hidden sanctum; the entrances are
// flowered nooks on Briar Hollow, Saltwind Shore and the Ashen Trail (open once you hold all three Sigils)
// and the pond shore in Mossbrook (open once the Heart Bell rings again). Walk up and press OK to challenge.
// A legendary cannot be knocked out (see Battle.holds): weaken it, then use your orbs. Each sanctum has a
// Rest Stone, so you can refill your orbs and try again. Once caught it is gone from its spot for good.
// To add one: a species in Critters.kt (rarity = Rarity.LEGENDARY), a sprite row in tools/sprites_extra.py, a sanctum
// map and a warp into it in Maps.kt, and a Spot here. ./run.sh checks that every legendary has exactly one Spot.
// ---------------------------------------------------------------------------------------------

val SPOTS: List<Spot> = listOf(
    Spot("verdarch", "grove", 6, 2, VERDARCH, 20,
        intro = listOf(
            "Elderwood Grove is utterly still. An enormous stag lifts its head, and leaves drift around its antlers like falling stars.",
            "Verdarch, Archon of the Leaf. It has weighed every Sigil-bearer for a thousand years."),
        caught = listOf("The grove breathes out. Verdarch bows its crown and walks beside you.")),
    Spot("maelarch", "grotto", 6, 2, MAELARCH, 24,
        intro = listOf(
            "Moonlight pours through the cave mouth onto a glassy pool. Something vast rises beneath it, crowned in ice.",
            "Maelarch, Archon of the Tide. The sea itself seems to hold its breath."),
        caught = listOf("The tide settles. Maelarch lowers its crown to you, and the grotto sighs.")),
    Spot("pyrarch", "crater", 6, 2, PYRARCH, 27,
        intro = listOf(
            "Heat shimmers over the crater. Wings of living flame unfurl from the glowing rock.",
            "Pyrarch, Archon of the Flame. Its stare is a sunrise that never blinks."),
        caught = listOf("The embers dim. Pyrarch folds its wings and burns beside you now.")),
    Spot("tollwraith", "hollow", 6, 2, TOLLWRAITH, 30,
        intro = listOf(
            "A single deep note rings through the hollow, and a bell of violet light drifts down to meet you.",
            "Tollwraith, the echo of the Heart Bell itself. It remembers every dawn it rang."),
        caught = listOf("The hollow rings once, softly. Tollwraith's echo is yours to carry now."))
)

/** What happens when you press OK in front of a legendary: its introduction, then a choice to challenge it. */
fun spotScript(s: Spot): List<Step> {
    val sp = DEX[s.species]
    return s.intro.map { narr(it, s.species) } + ask("", "Challenge ${sp.name}?  Lv${s.lvl}, ${sp.typeLabel}. It cannot be knocked out: weaken it, then use your orbs. A Rest Stone refills them.",
        listOf("Challenge", "Back away"), s.species) {
        if (it == 0) listOf(act { battleReq = BattleReq(null, Mon(DEX[s.species], s.lvl)) })
        else listOf(narr("You step back. ${sp.name} watches you go."))
    }
}
