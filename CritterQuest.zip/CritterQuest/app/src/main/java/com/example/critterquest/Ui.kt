package com.example.critterquest

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import kotlin.math.max
import kotlin.math.min

/**
 * GBA-style interface pieces, all drawn from plain rectangles in logical (small-screen) pixels, no smoothing:
 * framed text boxes, the menu cursor, the "more text" arrow and the HP bar.
 */
object Ui {
    // ---- battle layout rules (GameView draws with them, tools/story_check/InfoFit.kt and TextFit.kt check them) ----

    /** Width of one chip (type / status plate): its letters plus the frame. */
    fun chipWidth(label: String): Float = PixelFont.width(label.take(3).uppercase()) + 5f

    /** Width of the battle name / level / HP plates: 116px, but never so narrow that a long name runs into "Lv30"
     *  (a 4:3 screen is only about 213 logical pixels wide, and 42% of that is too little). */
    fun infoWidth(screenW: Float): Float = min(116f, max(screenW * 0.42f, 104f))

    /** True when the status chip fits between the name and the level on the plate's top row; if not it goes in front of the HP bar. */
    fun statusBesideName(name: String, tag: String, level: Int, boxW: Float): Boolean =
        12f + PixelFont.width(name) + chipWidth(tag) + 3f <= boxW - 8f - PixelFont.width("Lv$level")

    /** Text lines for a battle text box: [top] is the first line's offset and [pitch] the spacing. Up to 2 lines use the roomy
     *  spacing, 3 lines squeeze together so they still fit the 44px box, and anything longer ends in "..." (nothing vanishes silently). */
    class Fit(val lines: List<String>, val top: Float, val pitch: Float)
    fun fitText(s: String, maxW: Int): Fit {
        val all = PixelFont.wrap(s, maxW)
        if (all.size <= 2) return Fit(all, 9f, 14f)
        val lines = all.take(3).toMutableList()
        if (all.size > 3) {
            var l = lines[2]
            while (l.isNotEmpty() && PixelFont.width("$l...") > maxW) l = l.dropLast(1)
            lines[2] = l.trimEnd() + "..."
        }
        return Fit(lines, 6f, 11f)
    }

    // The palette of the interface: white boxes with a light-blue ring and a darker blue outline, blue text with a soft shadow.
    val INK = Color.rgb(56, 88, 208)
    val INK_SHADOW = Color.rgb(216, 208, 208)           // a plain light grey, not a tint of the blue
    val WHITE_INK = Color.rgb(248, 248, 248)
    val WHITE_SHADOW = Color.rgb(96, 96, 112)
    val BOX_FILL = Color.rgb(248, 248, 248)
    val BOX_EDGE = Color.rgb(164, 210, 230)     // the light-blue ring
    val BOX_OUTLINE = Color.rgb(80, 120, 169)   // the darker blue line round it
    val BOX_GRIP = Color.rgb(230, 243, 255)     // the pale strips inside both ends of a big text box
    val BOX_LINE = 0                            // (old thin red inner line: not used any more)
    val DARK_FILL = Color.rgb(40, 48, 88)
    val DARK_OUTLINE = Color.rgb(24, 24, 40)
    val SEL = Color.rgb(200, 48, 48)
    val GOLD = Color.rgb(248, 200, 64)

    private val p = Paint().apply { isAntiAlias = false; isDither = false; style = Paint.Style.FILL }

    fun rect(c: Canvas, x: Float, y: Float, w: Float, h: Float, col: Int) {
        p.style = Paint.Style.FILL; p.color = col
        c.drawRect(Math.round(x).toFloat(), Math.round(y).toFloat(), Math.round(x + w).toFloat(), Math.round(y + h).toFloat(), p)
    }

    /** How many pixels each corner row is cut away, for a box [h] pixels tall: tall boxes (the dialogue box) get big, pill-like
     *  ends, small plates and chips keep tight corners. */
    private fun cornerFor(h: Int): IntArray = when {
        h >= 42 -> intArrayOf(10, 8, 6, 5, 4, 3, 2, 2, 1, 1)
        h >= 26 -> intArrayOf(7, 5, 3, 2, 1, 1)
        h >= 14 -> intArrayOf(5, 3, 2, 1, 1)
        else -> intArrayOf(3, 1, 1)
    }

    /** A rounded rectangle shrunk by [inset] pixels on every side; [prof] is the corner profile of the OUTER box, so rings nest. */
    private fun rrect(c: Canvas, x: Int, y: Int, w: Int, h: Int, inset: Int, col: Int, prof: IntArray) {
        val iw = w - 2 * inset; val ih = h - 2 * inset
        if (iw <= 0 || ih <= 0) return
        for (row in 0 until ih) {   // rows are counted inside the shrunk box, so every ring keeps the dark outline visible just outside it
            val d = if (row < prof.size) prof[row] else if (ih - 1 - row < prof.size) prof[ih - 1 - row] else 0
            val k = max(0, d - inset)
            if (iw - 2 * k > 0) rect(c, (x + inset + k).toFloat(), (y + inset + row).toFloat(), (iw - 2 * k).toFloat(), 1f, col)
        }
    }

    /**
     * A framed box with rounded corners: outline, a ring ([edge], [ring] pixels wide) and the [fill]. [line] (if not 0) adds a thin inner line.
     * Light boxes get the blue outline, dark boxes (banners, name tags) a near-black one.
     */
    fun box(c: Canvas, x: Float, y: Float, w: Float, h: Float, fill: Int = BOX_FILL, edge: Int = BOX_EDGE, line: Int = 0,
            outline: Int = if (fill == BOX_FILL) BOX_OUTLINE else DARK_OUTLINE, ring: Int = 1, grip: Boolean = false) {
        val ix = Math.round(x); val iy = Math.round(y); val iw = Math.round(w); val ih = Math.round(h)
        val prof = cornerFor(ih)
        rrect(c, ix, iy, iw, ih, 0, outline, prof)
        rrect(c, ix, iy, iw, ih, 1, edge, prof)
        rrect(c, ix, iy, iw, ih, 1 + ring, fill, prof)
        if (grip && iw >= 90 && ih >= 30) {                              // the pale strip inside each end of a big text box
            val gy = iy + ih / 2f - 7f
            rect(c, ix + 5f, gy, 3f, 14f, BOX_GRIP); rect(c, ix + iw - 8f, gy, 3f, 14f, BOX_GRIP)
        }
        if (line != 0) {
            rect(c, ix + 4f, iy + 3f, iw - 8f, 1f, line); rect(c, ix + 4f, iy + ih - 4f, iw - 8f, 1f, line)
            rect(c, ix + 3f, iy + 4f, 1f, ih - 8f, line); rect(c, ix + iw - 4f, iy + 4f, 1f, ih - 8f, line)
        }
    }

    /** The standard light text box with the thin red line. */
    fun textBox(c: Canvas, x: Float, y: Float, w: Float, h: Float, ring: Int = 2, grip: Boolean = false) = box(c, x, y, w, h, BOX_FILL, BOX_EDGE, BOX_LINE, BOX_OUTLINE, ring, grip)

    /** A dark box (banners, the world pause menu backdrop). */
    fun darkBox(c: Canvas, x: Float, y: Float, w: Float, h: Float) = box(c, x, y, w, h, DARK_FILL, Color.rgb(120, 128, 176), 0)

    /** The small right-pointing triangle that marks the selected menu line. */
    fun cursor(c: Canvas, x: Float, y: Float, col: Int = SEL) {
        val ix = Math.round(x); val iy = Math.round(y)
        rect(c, ix.toFloat(), iy.toFloat(), 1f, 7f, col); rect(c, ix + 1f, iy + 1f, 1f, 5f, col)
        rect(c, ix + 2f, iy + 2f, 1f, 3f, col); rect(c, ix + 3f, iy + 3f, 1f, 1f, col)
    }

    /** The "more text" arrow at the end of a page; [bob] 0 or 1 moves it down a pixel. */
    fun moreArrow(c: Canvas, x: Float, y: Float, bob: Int, col: Int = SEL) {
        val ix = Math.round(x); val iy = Math.round(y) + bob
        rect(c, ix.toFloat(), iy.toFloat(), 7f, 1f, col); rect(c, ix + 1f, iy + 1f, 5f, 1f, col)
        rect(c, ix + 2f, iy + 2f, 3f, 1f, col); rect(c, ix + 3f, iy + 3f, 1f, 1f, col)
    }

    /** HP bar of [w] pixels: dark frame, coloured fill (green, yellow, red), [frac] 0..1. */
    fun hpBar(c: Canvas, x: Float, y: Float, w: Float, frac: Float) {
        val f = frac.coerceIn(0f, 1f)
        rect(c, x, y, w, 5f, Color.rgb(56, 56, 72)); rect(c, x + 1f, y + 1f, w - 2f, 3f, Color.rgb(216, 216, 208))
        val fill = Math.round((w - 2f) * f).toFloat()
        val col = if (f > 0.5f) Color.rgb(56, 200, 80) else if (f > 0.2f) Color.rgb(248, 200, 40) else Color.rgb(232, 64, 56)
        if (fill > 0f) { rect(c, x + 1f, y + 1f, fill, 3f, col); rect(c, x + 1f, y + 1f, fill, 1f, Color.argb(90, 255, 255, 255)) }
    }

    /** Thin experience bar. */
    fun xpBar(c: Canvas, x: Float, y: Float, w: Float, frac: Float) {
        rect(c, x, y, w, 3f, Color.rgb(56, 56, 72)); rect(c, x + 1f, y + 1f, w - 2f, 1f, Color.rgb(216, 216, 208))
        val fill = Math.round((w - 2f) * frac.coerceIn(0f, 1f)).toFloat()
        if (fill > 0f) rect(c, x + 1f, y + 1f, fill, 1f, Color.rgb(64, 168, 248))
    }
}
