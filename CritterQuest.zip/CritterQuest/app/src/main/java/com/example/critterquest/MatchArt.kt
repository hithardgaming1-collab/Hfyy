package com.example.critterquest

import android.graphics.Bitmap
import android.graphics.Color

// ---------------------------------------------------------------------------------------------
// KJPW: the wrestler pictures. wrestlers.png (made by tools/make_wrestlers.py) holds ONE template in marker
// colours: 29 poses side by side (32x32 cells) and three body types (rows: normal, big, giant). [WrestlerSprites]
// recolours it for any WLook, so a new wrestler never needs new art. Same trick as people.png / Sprites.person.
// ---------------------------------------------------------------------------------------------

/** Cell numbers of the poses on the sheet: the same order as FRAMES in tools/make_wrestlers.py. */
object WF {
    const val FRONT0 = 0; const val BACK = 3; const val R0 = 4; const val L0 = 7; const val CHEER = 10
    const val PUNCH_R = 11; const val PUNCH_L = 12; const val KICK_R = 13; const val KICK_L = 14
    const val HURT_R = 15; const val HURT_L = 16; const val LIE_R = 17; const val LIE_L = 18; const val UPSIDE = 19
    const val KNEEL_R = 20; const val KNEEL_L = 21; const val RUN_R1 = 22; const val RUN_R2 = 23; const val RUN_L1 = 24; const val RUN_L2 = 25
    const val FLEX = 26; const val DIVE_R = 27; const val DIVE_L = 28
    const val COUNT = 29

    /** The cell for pose [ps] when the wrestler faces right ([right]) or left. */
    fun cell(ps: PS, right: Boolean): Int = when (ps) {
        PS.IDLE -> if (right) R0 else L0
        PS.PUNCH -> if (right) PUNCH_R else PUNCH_L
        PS.KICK -> if (right) KICK_R else KICK_L
        PS.HURT -> if (right) HURT_R else HURT_L
        PS.LIE -> if (right) LIE_R else LIE_L
        PS.SIT -> if (right) KNEEL_R else KNEEL_L
        PS.RUN1 -> if (right) RUN_R1 else RUN_L1
        PS.RUN2 -> if (right) RUN_R2 else RUN_L2
        PS.DIVE -> if (right) DIVE_R else DIVE_L
        PS.UPSIDE -> UPSIDE
        PS.CHEER -> CHEER
        PS.FLEX -> FLEX
    }
}

class WrestlerSprites(private val loader: () -> Bitmap?) {
    private val sheet: Bitmap? by lazy { loader() }
    private val sheetPx: IntArray? by lazy { sheet?.let { s -> IntArray(s.width * s.height).also { s.getPixels(it, 0, s.width, 0, 0, s.width, s.height) } } }
    private data class Key(val look: WLook, val pose: Int)
    private val cache = HashMap<Key, Bitmap>()

    private fun shade(c: Int, f: Float) = Color.rgb((Color.red(c) * f).toInt().coerceIn(0, 255), (Color.green(c) * f).toInt().coerceIn(0, 255), (Color.blue(c) * f).toInt().coerceIn(0, 255))
    private fun mk(r: Int, g: Int, b: Int) = Color.argb(255, r, g, b)

    /** The 32x32 picture of [look] in pose cell [pose] (0 until [WF.COUNT]), or null if the sheet is missing. */
    fun frame(look: WLook, pose: Int): Bitmap? {
        val s = sheet ?: return null; val src = sheetPx ?: return null
        val cell = pose.coerceIn(0, WF.COUNT - 1)
        return cache.getOrPut(Key(look, cell)) {
            val skin = look.skin
            val hair = if (look.bald) skin else look.hair
            val mask = if (look.mask != 0) look.mask else skin
            val beard = if (look.beard != 0) look.beard else skin
            val map = HashMap<Int, Int>()
            map[mk(255, 0, 0)] = hair; map[mk(190, 0, 0)] = shade(hair, .75f); map[mk(255, 90, 90)] = if (look.bald) skin else shade(hair, 1.35f)
            map[mk(255, 0, 255)] = skin; map[mk(190, 0, 190)] = shade(skin, .82f)
            map[mk(0, 0, 255)] = look.trunks; map[mk(0, 0, 190)] = shade(look.trunks, .72f)
            map[mk(255, 255, 0)] = mask; map[mk(190, 190, 0)] = shade(mask, .82f)
            map[mk(0, 255, 255)] = beard; map[mk(0, 190, 190)] = shade(beard, .82f)
            map[mk(58, 44, 52)] = look.boots; map[mk(110, 92, 92)] = shade(look.boots, 1.5f)
            val row = look.body.coerceIn(0, 2)
            val out = IntArray(32 * 32)
            for (y in 0 until 32) for (x in 0 until 32) {
                val v = src[(row * 32 + y) * s.width + cell * 32 + x]
                out[y * 32 + x] = map[v] ?: v
            }
            val bm = Bitmap.createBitmap(32, 32, Bitmap.Config.ARGB_8888)
            bm.setPixels(out, 0, 32, 0, 0, 32, 32)
            bm
        }
    }
}
