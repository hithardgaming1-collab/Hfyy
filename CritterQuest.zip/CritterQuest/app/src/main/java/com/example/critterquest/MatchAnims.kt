package com.example.critterquest

import kotlin.math.min

// ---------------------------------------------------------------------------------------------
// KJPW: the stage directions. [MatchAnims.build] turns one [Beat] of a bout (Bout.kt) into a short timeline of
// poses: where each wrestler stands, how high he is off the mat and which picture of the shared template he uses.
// No Android in here, so tools/story_check/ArenaCheck.kt can check every move.
//
// Positions are in stage pixels along the "attack axis": wrestler A (the one doing the move) is -26 from the middle and
// wrestler B +26, and a plus sign always points from A towards B. MatchView mirrors the axis when A is the right-hand wrestler.
// Poses switch at the key that names them, positions glide from key to key.
// ---------------------------------------------------------------------------------------------

enum class PS { IDLE, PUNCH, KICK, HURT, LIE, SIT, RUN1, RUN2, DIVE, UPSIDE, CHEER, FLEX }

/** Something extra that happens at a key: a hit flash, a heavy landing with dust and a shake, a roaring crowd, the referee's slap. */
enum class Fx { NONE, HIT, BIG, CROWD, SLAP, TAP }

/** One wrestler at one moment: [dx] along the axis, [dy] up off the mat (negative = up), the pose, and which way he faces (+1 = towards B's side). */
class Pz(val dx: Float, val dy: Float, val ps: PS, val face: Int = 1)

class Key(val t: Float, val a: Pz, val b: Pz, val fx: Fx = Fx.NONE)

/** [att] is the wrestler (0 or 1) who plays A. */
class Anim(val ms: Int, val keys: List<Key>, val att: Int)

object MatchAnims {
    const val HOME = 26f                       // half the gap between two wrestlers standing at their places

    private fun pa(dx: Float, dy: Float, ps: PS, f: Int = 1) = Pz(dx, dy, ps, f)
    private fun pb(dx: Float, dy: Float, ps: PS, f: Int = -1) = Pz(dx, dy, ps, f)
    private fun k(t: Float, a: Pz, b: Pz, fx: Fx = Fx.NONE) = Key(t, a, b, fx)

    private val I = PS.IDLE
    private val STAND_A = Pz(0f, 0f, I, 1)
    private val STAND_B = Pz(0f, 0f, I, -1)
    /** Lying on the mat, head towards the outside of the ring. */
    private fun lying(side: Int) = if (side == 0) Pz(-10f, 0f, PS.LIE, -1) else Pz(10f, 0f, PS.LIE, 1)
    fun rest(side: Int, p: WPos): Pz = if (p == WPos.DOWN) lying(side) else if (side == 0) STAND_A else STAND_B
    /** A sits on B to hold the pin down. */
    private val COVER_A = Pz(50f, -6f, PS.SIT, 1)
    private val CLINCH_A = Pz(12f, 0f, I, 1)
    private val CLINCH_B = Pz(-12f, 0f, I, -1)
    private val OFF_A = Pz(-190f, 0f, PS.RUN1, 1)
    private val OFF_B = Pz(190f, 0f, PS.RUN1, -1)

    /** Who plays A for this beat: the one who does the move, or the one who holds / pins when the beat is about the other. */
    fun attacker(beat: Beat): Int = when (beat.kind) {
        BeatKind.TAP, BeatKind.ESCAPE, BeatKind.KICKOUT -> 1 - beat.who
        else -> if (beat.who < 0) 0 else beat.who
    }

    fun duration(beat: Beat): Int = when (beat.kind) {
        BeatKind.INTRO -> 2300; BeatKind.BELL -> 1500; BeatKind.GETUP -> 1200; BeatKind.COVER -> 1100; BeatKind.COUNT -> 900
        BeatKind.KICKOUT -> 1200; BeatKind.WIN -> 2200; BeatKind.TAP -> 1700; BeatKind.ESCAPE -> 1400; BeatKind.MISS -> 1300
        else -> when (beat.move?.anim ?: WAnim.STRIKE) {
            WAnim.STRIKE, WAnim.KICK -> 1100; WAnim.STOMP -> 1200; WAnim.RUN, WAnim.DKICK, WAnim.DROP, WAnim.HOLD, WAnim.TAUNT -> 1500
            WAnim.SLAM -> 1600; WAnim.WHIP -> 1700; WAnim.SUPLEX, WAnim.SPIKE -> 1700; WAnim.BOMB -> 1900; WAnim.SPIN, WAnim.DIVE -> 2100
        }
    }

    /** The whole timeline of [beat]. [prev] is the beat before it (null at the start), [last] says this is the final beat of the match. */
    fun build(beat: Beat, prev: Beat?, last: Boolean): Anim {
        val att = attacker(beat); val def = 1 - att
        val before = prev?.pos ?: arrayOf(WPos.STAND, WPos.STAND)
        val after = beat.pos
        val covering = prev != null && (prev.kind == BeatKind.COVER || prev.kind == BeatKind.COUNT)
        var startA = rest(0, before[att]); var startB = rest(1, before[def])
        var endA = rest(0, after[att]); var endB = rest(1, after[def])
        val defDown = before[def] == WPos.DOWN
        val mid: List<Key>
        when (beat.kind) {
            BeatKind.INTRO -> {
                val me = beat.who
                startA = OFF_A; startB = if (me == 0) OFF_B else Pz(0f, 0f, PS.FLEX, -1)
                endA = Pz(0f, 0f, PS.FLEX, 1); endB = if (me == 0) OFF_B else Pz(0f, 0f, PS.FLEX, -1)
                val z = ArrayList<Key>()
                for (i in 0..6) z.add(k(0.04f + i * 0.085f, pa(-190f + 190f * (i + 1) / 7f, 0f, if (i % 2 == 0) PS.RUN2 else PS.RUN1), endB))
                z.add(k(0.66f, pa(0f, 0f, PS.FLEX), endB, Fx.CROWD))
                mid = z
            }
            BeatKind.BELL -> {
                startA = Pz(0f, 0f, PS.FLEX, 1); startB = Pz(0f, 0f, PS.FLEX, -1)
                mid = listOf(k(0.15f, STAND_A, STAND_B, Fx.CROWD), k(0.50f, pa(8f, 0f, I), pb(-8f, 0f, I)), k(0.72f, pa(8f, 0f, I), pb(-8f, 0f, I)))
            }
            BeatKind.GETUP -> mid = listOf(
                k(0.25f, pa(-10f, 0f, PS.SIT, -1), startB), k(0.45f, pa(-8f, 0f, PS.SIT, 1), startB),
                k(0.65f, pa(-4f, 0f, PS.HURT, 1), startB), k(0.80f, pa(0f, 0f, I), startB))
            BeatKind.COVER -> {
                startA = if (covering) COVER_A else startA
                endA = COVER_A
                mid = listOf(k(0.15f, STAND_A, startB), k(0.35f, pa(30f, 0f, I), startB), k(0.55f, pa(50f, -6f, PS.SIT), startB, Fx.SLAP))
            }
            BeatKind.COUNT -> {
                startA = COVER_A; endA = COVER_A
                mid = listOf(k(0.20f, COVER_A, pb(10f, -3f, PS.LIE, 1)), k(0.40f, COVER_A, startB, Fx.SLAP), k(0.60f, COVER_A, pb(10f, -3f, PS.LIE, 1)), k(0.80f, COVER_A, startB))
            }
            BeatKind.KICKOUT -> {
                startA = if (covering) COVER_A else startA
                mid = listOf(
                    k(0.20f, startA, pb(10f, -4f, PS.LIE, 1)), k(0.35f, pa(56f, -16f, PS.HURT), pb(10f, -16f, PS.SIT, 1), Fx.BIG),
                    k(0.55f, pa(66f, 0f, PS.HURT), pb(10f, -4f, PS.LIE, 1)), k(0.72f, pa(30f, 0f, I), startB))
            }
            BeatKind.WIN -> {
                startA = if (covering) COVER_A else startA
                endA = if (last) Pz(0f, 0f, PS.CHEER, 1) else endA
                mid = listOf(k(0.25f, startA, startB), k(0.50f, pa(30f, 0f, I), endB), k(0.68f, pa(0f, -8f, PS.CHEER), endB, Fx.CROWD), k(0.82f, pa(0f, 0f, PS.CHEER), endB))
            }
            BeatKind.TAP -> {
                // the holder (A) is already on him; the tapper (B) slaps the mat
                val groundHold = defDown
                startA = if (groundHold) Pz(30f, 0f, PS.SIT, 1) else CLINCH_A
                startB = if (groundHold) pb(10f, 0f, PS.LIE, 1) else pb(-12f, 0f, PS.HURT)
                endA = if (last) Pz(0f, 0f, PS.CHEER, 1) else endA
                endB = lying(1)
                val z = ArrayList<Key>()
                for (i in 0..7) z.add(k(0.10f + i * 0.07f, startA, Pz(startB.dx + (if (i % 2 == 0) 2f else -2f), 0f, startB.ps, startB.face), if (i == 1) Fx.TAP else Fx.NONE))
                z.add(k(0.78f, Pz(14f, 0f, I, 1), endB))
                mid = z
            }
            BeatKind.ESCAPE -> {
                val ground = defDown
                startA = if (ground) Pz(30f, 0f, PS.SIT, 1) else CLINCH_A
                startB = if (ground) pb(10f, 0f, PS.LIE, 1) else pb(-12f, 0f, PS.HURT)
                mid = listOf(
                    k(0.20f, startA, pb(startB.dx + 2f, 0f, startB.ps, startB.face)), k(0.35f, startA, pb(startB.dx - 2f, 0f, startB.ps, startB.face)),
                    k(0.50f, pa(startA.dx - 4f, 0f, PS.HURT), pb(startB.dx + 6f, 0f, PS.PUNCH), Fx.HIT),
                    k(0.70f, pa(startA.dx - 12f, 0f, PS.HURT), lying(1)))
            }
            BeatKind.MISS -> {
                val swing = when (beat.move?.kind) { WKind.KICK, WKind.AIR -> PS.KICK; else -> PS.PUNCH }
                mid = listOf(
                    k(0.15f, STAND_A, STAND_B), k(0.32f, pa(6f, 0f, I), STAND_B), k(0.44f, pa(12f, 0f, swing), pb(2f, 0f, I)),
                    k(0.56f, pa(16f, 0f, swing), pb(10f, -10f, I)), k(0.70f, pa(10f, 0f, PS.HURT), pb(14f, 0f, I)))
            }
            else -> mid = moveKeys(beat, defDown, prev)
        }
        val keys = ArrayList<Key>()
        keys.add(Key(0f, startA, startB))
        for (kk in mid) keys.add(kk)
        keys.add(Key(0.90f, endA, endB))
        keys.add(Key(1f, endA, endB))
        return Anim(duration(beat), keys, att)
    }

    /** The keys in the middle of a move, by its picture. B is assumed standing unless [defDown]. */
    private fun moveKeys(beat: Beat, defDown: Boolean, prev: Beat?): List<Key> {
        val an = beat.move?.anim ?: WAnim.STRIKE
        val bl = if (defDown) pb(10f, 0f, PS.LIE, 1) else STAND_B
        return when (an) {
            WAnim.STRIKE -> listOf(
                k(0.10f, STAND_A, STAND_B), k(0.28f, pa(6f, 0f, I), STAND_B), k(0.40f, pa(8f, 0f, PS.PUNCH), STAND_B),
                k(0.48f, pa(10f, 0f, PS.PUNCH), pb(4f, 0f, PS.HURT), Fx.HIT), k(0.64f, pa(8f, 0f, PS.PUNCH), pb(8f, 0f, PS.HURT)),
                k(0.78f, pa(2f, 0f, I), pb(6f, 0f, PS.HURT)))
            WAnim.KICK -> listOf(
                k(0.10f, STAND_A, STAND_B), k(0.30f, pa(4f, 0f, I), STAND_B), k(0.42f, pa(8f, 0f, PS.KICK), STAND_B),
                k(0.50f, pa(10f, 0f, PS.KICK), pb(4f, 0f, PS.HURT), Fx.HIT), k(0.66f, pa(8f, 0f, PS.KICK), pb(8f, 0f, PS.HURT)),
                k(0.78f, pa(2f, 0f, I), pb(5f, 0f, PS.HURT)))
            WAnim.RUN -> listOf(
                k(0.08f, STAND_A, STAND_B), k(0.18f, pa(-16f, 0f, PS.RUN1, -1), STAND_B), k(0.28f, pa(-34f, 0f, PS.RUN2, -1), STAND_B),
                k(0.36f, pa(-34f, 0f, I), STAND_B), k(0.44f, pa(-20f, 0f, PS.RUN1), STAND_B), k(0.52f, pa(-4f, 0f, PS.RUN2), STAND_B),
                k(0.60f, pa(10f, 0f, PS.PUNCH), pb(6f, 0f, PS.HURT), Fx.BIG), k(0.72f, pa(16f, 0f, I), pb(14f, 0f, PS.HURT)),
                k(0.82f, pa(8f, 0f, I), pb(12f, 0f, PS.HURT)))
            WAnim.DKICK -> listOf(
                k(0.08f, STAND_A, STAND_B), k(0.18f, pa(-16f, 0f, PS.RUN1, -1), STAND_B), k(0.28f, pa(-18f, 0f, I), STAND_B),
                k(0.38f, pa(-6f, 0f, PS.RUN2), STAND_B), k(0.48f, pa(8f, -14f, PS.DIVE), STAND_B),
                k(0.56f, pa(16f, -12f, PS.DIVE), pb(6f, 0f, PS.HURT), Fx.BIG), k(0.68f, pa(18f, 0f, PS.LIE, -1), pb(12f, 0f, PS.HURT)),
                k(0.82f, pa(14f, 0f, PS.SIT), pb(12f, 0f, PS.HURT)))
            WAnim.SLAM -> listOf(
                k(0.10f, STAND_A, STAND_B), k(0.26f, CLINCH_A, CLINCH_B), k(0.38f, CLINCH_A, pb(-12f, -14f, PS.HURT)),
                k(0.52f, CLINCH_A, pb(-12f, -30f, PS.UPSIDE)), k(0.62f, CLINCH_A, pb(-4f, -14f, PS.UPSIDE)),
                k(0.70f, pa(12f, 0f, PS.SIT), pb(8f, 0f, PS.LIE, 1), Fx.BIG), k(0.82f, pa(8f, 0f, I), pb(10f, 0f, PS.LIE, 1)))
            WAnim.SUPLEX -> listOf(
                k(0.10f, STAND_A, STAND_B), k(0.24f, CLINCH_A, CLINCH_B), k(0.36f, CLINCH_A, pb(-12f, -12f, PS.HURT)),
                k(0.50f, CLINCH_A, pb(-14f, -32f, PS.UPSIDE)), k(0.60f, pa(10f, 0f, I), pb(-14f, -34f, PS.UPSIDE)),
                k(0.68f, pa(10f, 0f, I), pb(-6f, -16f, PS.UPSIDE)), k(0.74f, pa(8f, 0f, PS.SIT), pb(6f, 0f, PS.LIE, 1), Fx.BIG),
                k(0.84f, pa(6f, 0f, I), pb(10f, 0f, PS.LIE, 1)))
            WAnim.SPIKE -> listOf(
                k(0.10f, STAND_A, STAND_B), k(0.24f, CLINCH_A, CLINCH_B), k(0.38f, CLINCH_A, pb(-12f, -6f, PS.HURT)),
                k(0.52f, pa(12f, 0f, PS.SIT), pb(-12f, -18f, PS.UPSIDE)), k(0.62f, pa(12f, 0f, PS.SIT), pb(-10f, -2f, PS.UPSIDE), Fx.BIG),
                k(0.76f, pa(10f, 0f, I), pb(8f, 0f, PS.LIE, 1)))
            WAnim.BOMB -> listOf(
                k(0.08f, STAND_A, STAND_B), k(0.22f, CLINCH_A, CLINCH_B), k(0.36f, CLINCH_A, pb(-12f, -10f, PS.HURT)),
                k(0.48f, CLINCH_A, pb(-10f, -34f, PS.LIE, 1)), k(0.60f, pa(11f, 0f, I), pb(-10f, -35f, PS.LIE, 1)),
                k(0.68f, pa(12f, 0f, I), pb(0f, -14f, PS.LIE, 1)), k(0.76f, pa(12f, 0f, PS.SIT), pb(10f, 0f, PS.LIE, 1), Fx.BIG),
                k(0.86f, pa(8f, 0f, I), pb(10f, 0f, PS.LIE, 1)))
            WAnim.SPIN -> listOf(
                k(0.08f, STAND_A, STAND_B), k(0.20f, CLINCH_A, CLINCH_B), k(0.32f, CLINCH_A, pb(-12f, -28f, PS.LIE, 1)),
                k(0.40f, CLINCH_A, pb(16f, -28f, PS.LIE, 1)), k(0.48f, CLINCH_A, pb(-18f, -28f, PS.LIE, -1)),
                k(0.56f, CLINCH_A, pb(16f, -28f, PS.LIE, 1)), k(0.64f, CLINCH_A, pb(-18f, -28f, PS.LIE, -1)),
                k(0.72f, CLINCH_A, pb(0f, -14f, PS.LIE, 1)), k(0.78f, pa(12f, 0f, PS.SIT), pb(10f, 0f, PS.LIE, 1), Fx.BIG),
                k(0.86f, pa(8f, 0f, I), pb(10f, 0f, PS.LIE, 1)))
            WAnim.HOLD -> {
                val again = (prev?.kind == BeatKind.HOLD) || beat.n > 1
                val ground = defDown
                val a0 = if (ground) Pz(30f, 0f, PS.SIT, 1) else CLINCH_A
                val b0 = if (ground) pb(10f, 0f, PS.LIE, 1) else pb(-12f, 0f, PS.HURT)
                val z = ArrayList<Key>()
                if (!again) { z.add(k(0.10f, STAND_A, bl)); z.add(k(0.30f, if (ground) pa(20f, 0f, I) else pa(6f, 0f, I), if (ground) bl else STAND_B)) }
                z.add(k(0.40f, a0, b0, Fx.HIT))
                for (i in 0..4) z.add(k(0.46f + i * 0.07f, a0, Pz(b0.dx + (if (i % 2 == 0) 2f else -2f), 0f, b0.ps, b0.face)))
                z
            }
            WAnim.DROP -> listOf(
                k(0.10f, STAND_A, bl), k(0.28f, pa(30f, 0f, I), bl), k(0.40f, pa(46f, -4f, PS.CHEER), bl), k(0.52f, pa(54f, -28f, PS.CHEER), bl),
                k(0.64f, pa(54f, -4f, PS.SIT), pb(10f, -2f, PS.LIE, 1), Fx.BIG), k(0.76f, pa(50f, 0f, PS.SIT), bl), k(0.84f, pa(30f, 0f, I), bl))
            WAnim.STOMP -> listOf(
                k(0.10f, STAND_A, bl), k(0.28f, pa(30f, 0f, I), bl), k(0.40f, pa(34f, 0f, PS.KICK), bl),
                k(0.48f, pa(34f, 0f, PS.KICK), pb(10f, -3f, PS.LIE, 1), Fx.HIT), k(0.58f, pa(34f, 0f, I), bl),
                k(0.66f, pa(34f, 0f, PS.KICK), pb(10f, -3f, PS.LIE, 1), Fx.HIT), k(0.76f, pa(30f, 0f, I), bl))
            WAnim.DIVE -> listOf(
                k(0.06f, STAND_A, bl), k(0.18f, pa(-16f, 0f, PS.RUN1, -1), bl), k(0.28f, pa(-40f, 0f, PS.RUN2, -1), bl),
                k(0.36f, pa(-40f, -30f, PS.FLEX), bl), k(0.46f, pa(-40f, -32f, PS.FLEX), bl, Fx.CROWD),
                k(0.56f, pa(-18f, -40f, PS.DIVE), bl), k(0.64f, pa(14f, -24f, PS.DIVE), bl), k(0.70f, pa(40f, -6f, PS.DIVE), bl),
                k(0.74f, pa(48f, 0f, PS.SIT), if (defDown) pb(10f, -2f, PS.LIE, 1) else pb(10f, 0f, PS.HURT), Fx.BIG),
                k(0.84f, pa(44f, 0f, PS.SIT), if (defDown) bl else pb(10f, 0f, PS.HURT)))
            WAnim.WHIP -> listOf(
                k(0.10f, STAND_A, STAND_B), k(0.24f, CLINCH_A, CLINCH_B), k(0.34f, pa(12f, 0f, PS.PUNCH), pb(-8f, 0f, PS.HURT)),
                k(0.46f, pa(10f, 0f, I), pb(30f, 0f, PS.RUN1, 1)), k(0.56f, pa(8f, 0f, I), pb(60f, 0f, PS.RUN2, 1)),
                k(0.62f, pa(8f, 0f, I), pb(66f, 0f, PS.HURT, 1), Fx.HIT), k(0.74f, pa(8f, 0f, I), pb(40f, 0f, PS.RUN1, -1)),
                k(0.82f, pa(10f, 0f, I), pb(10f, 0f, PS.HURT, -1)))
            WAnim.TAUNT -> listOf(
                k(0.10f, STAND_A, bl), k(0.22f, pa(0f, 0f, PS.FLEX), bl, Fx.CROWD), k(0.34f, pa(0f, -4f, PS.FLEX), bl), k(0.46f, pa(0f, 0f, PS.FLEX), bl),
                k(0.58f, pa(0f, -5f, PS.CHEER), bl), k(0.70f, pa(0f, 0f, PS.CHEER), bl), k(0.80f, pa(0f, 0f, I), bl))
        }
    }

    private fun lerp(a: Float, b: Float, u: Float) = a + (b - a) * u

    /** Where both wrestlers are at progress [t] (0..1) of [an]: the pose of the key just passed, the position gliding to the next key. */
    fun sample(an: Anim, t: Float): Array<Pz> {
        val ks = an.keys; val tt = t.coerceIn(0f, 1f)
        var i = 0
        while (i + 1 < ks.size && ks[i + 1].t <= tt) i++
        val k0 = ks[i]; val k1 = ks[min(i + 1, ks.size - 1)]
        val u = if (k1.t > k0.t) ((tt - k0.t) / (k1.t - k0.t)).coerceIn(0f, 1f) else 0f
        fun mix(p: Pz, q: Pz) = Pz(lerp(p.dx, q.dx, u), lerp(p.dy, q.dy, u), p.ps, p.face)
        return arrayOf(mix(k0.a, k1.a), mix(k0.b, k1.b))
    }
}
