package com.example.critterquest

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect

/**
 * The three pixel-art sheets and the little tricks to use them:
 *  - tiles.png      16x16 world tiles, one row per Theme (made by tools/make_tiles.py, cell numbers in TileAtlasData.kt)
 *  - people.png     16x24 characters in marker colours (tools/make_people.py); [person] recolours them for one [Look]
 *  - ow_critters.png 16x16 critters, one column per species in DEX order (tools/make_overworld.py)
 *  - ow_legends.png  32x32 pictures of the legendary critters standing in their sanctums (same script)
 * [loader] turns a resource id into a bitmap (GameView uses Android's decoder, the PC tools read the PNG files).
 */
class Sprites(loader: (Int) -> Bitmap?) {
    val tiles: Bitmap = loader(R.drawable.tiles) ?: error("tiles.png is missing")
    private val people: Bitmap = loader(R.drawable.people) ?: error("people.png is missing")
    val critters: Bitmap = loader(R.drawable.ow_critters) ?: error("ow_critters.png is missing")
    /** 32x32 world pictures of the legendary critters, one column each in DEX order (tools/make_overworld.py). */
    val legends: Bitmap = loader(R.drawable.ow_legends) ?: error("ow_legends.png is missing")
    private val legendDex = DEX.indices.filter { DEX[it].legendary }
    /** The Critter Station kiosk: two 16x24 frames (light on, light off), tools/make_station.py. */
    val stations: Bitmap = loader(R.drawable.ow_station) ?: error("ow_station.png is missing")
    fun stationRect(frame: Int, r: Rect) { r.set(frame * 16, 0, frame * 16 + 16, 24) }

    private val peoplePx = IntArray(people.width * people.height).also { people.getPixels(it, 0, people.width, 0, 0, people.width, people.height) }
    private data class Key(val skin: Int, val hair: Int, val top: Int, val legs: Int, val kind: Int, val face: Int, val frame: Int)
    private val cache = HashMap<Key, Bitmap>()

    private fun shade(c: Int, f: Float) = Color.rgb((Color.red(c) * f).toInt().coerceIn(0, 255), (Color.green(c) * f).toInt().coerceIn(0, 255), (Color.blue(c) * f).toInt().coerceIn(0, 255))

    /** The 16x24 sprite of [look] facing [face] (DOWN/LEFT/RIGHT/UP), walking [frame] 0 = standing, 1 = left foot, 2 = right foot. */
    fun person(look: Look, face: Int, frame: Int): Bitmap = cache.getOrPut(Key(look.skin, look.hair, look.top, look.legs, look.kind, face, frame)) {
        val map = HashMap<Int, Int>()
        map[0xFFFF0000.toInt()] = look.hair; map[0xFFBE0000.toInt()] = shade(look.hair, .75f); map[0xFFFF5A5A.toInt()] = shade(look.hair, 1.35f)
        map[0xFFFF00FF.toInt()] = look.skin; map[0xFFBE00BE.toInt()] = shade(look.skin, .82f)
        map[0xFF00FF00.toInt()] = look.top; map[0xFF00BE00.toInt()] = shade(look.top, .76f); map[0xFF78FF78.toInt()] = shade(look.top, 1.25f)
        map[0xFF0000FF.toInt()] = look.legs; map[0xFF0000BE.toInt()] = shade(look.legs, .72f)
        val dirRow = when (face) { DOWN -> 0; UP -> 1; else -> 2 }
        val row = look.kind.coerceIn(0, 4) * 3 + dirRow
        val out = IntArray(16 * 24)
        for (y in 0 until 24) for (x in 0 until 16) {
            val sx = frame * 16 + (if (face == RIGHT) 15 - x else x)
            val px = peoplePx[(row * 24 + y) * people.width + sx]
            out[y * 16 + x] = map[px] ?: px
        }
        val bm = Bitmap.createBitmap(16, 24, Bitmap.Config.ARGB_8888)
        bm.setPixels(out, 0, 16, 0, 0, 16, 24)
        bm
    }

    /** Sets [r] to the part of the critter sheet holding species [dex] (seen from the front, or [back]). */
    /** Sets [r] to the 32x32 picture of legendary species [dex] on the legends sheet. */
    fun legendRect(dex: Int, r: Rect) { val i = legendDex.indexOf(dex).coerceAtLeast(0); r.set(i * 32, 0, i * 32 + 32, 32) }

    fun critterRect(dex: Int, back: Boolean, r: Rect) { r.set(dex * 16, if (back) 16 else 0, dex * 16 + 16, if (back) 32 else 16) }
}
