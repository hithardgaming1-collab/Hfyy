package com.example.critterquest

// ---------------------------------------------------------------------------------------------
// The money rules, all in one place. Coins are meant to be SCARCE:
//   - A trainer pays once (you can only beat each one once), so the story holds a fixed amount of money.
//   - A wild critter pays almost nothing, so grinding the grass for coins is not worth it.
//   - Critter Orbs and KJPW tickets cost a lot (Rest Stones still refill your first MAX_ORBS orbs for free).
// EconomyCheck.kt guards this: it fails if prizes get so big or prices so small that coins stop being scarce.
// When you add jobs (a way to earn coins), pay for them with the same care: a few shifts should buy one ticket, not ten.
// ---------------------------------------------------------------------------------------------

const val ORB_PRICE = 60                  // Critter Orb at a Critter Station's Market
const val TICKET_PRICE = 150              // KJPW ticket at the machine in the plaza (good for one night)
const val TICKET_CAP = 20                 // the most tickets you can hold

const val TRAINER_PAY_PER_LEVEL = 5       // a trainer pays this per level of its toughest critter ...
const val LEADER_PAY_PER_LEVEL = 10       // ... and the leaders (Wardens, Vex, Gloam) pay double
const val WILD_LEVELS_PER_COIN = 3        // a wild critter drops 1 coin per this many levels (at least 1); x1.5 Uncommon, x2 Rare
