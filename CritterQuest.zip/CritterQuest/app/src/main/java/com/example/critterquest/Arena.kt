package com.example.critterquest

import android.graphics.Color
import kotlin.math.min

// ---------------------------------------------------------------------------------------------
// KJPW: the wrestling arena west of Mossbrook. Watch only: you never fight in it.
//
//   KJPW Plaza (map "plaza")  the ticket machine stands outside the hall, beside its door
//   the hallway (map "hall")      posters, wrestlers chatting backstage, the usher at the arena doors
//   the arena (map "arena")       the ring and the announcer, who puts on any bout you like
//
// A ticket costs coins (TICKET_PRICE), is bought at the ticket machine, and is good for one night: the usher takes it and
// you hold a pass until you walk out into the square again (Game.enter drops the pass). The bouts themselves are
// Bout.kt (the rules), MatchAnims.kt / MatchView.kt (the show). The wrestlers are in Wrestlers.kt, their moves in
// WrestleMoves.kt and WrestleFinishers.kt. To add a wrestler, add a line to ROSTER; to add a person standing about, add to ARENA_NPCS.
// ---------------------------------------------------------------------------------------------

const val PASS_FLAG = "arena_pass"
val ARENA_MAPS = setOf("hall", "arena")

/** A bout for GameView to show: two wrestler ids and the random seed that decides how it goes. */
class MatchReq(val a: String, val b: String, val seed: Int)

/** The ticket machine standing on a tile of a map (like a Critter Station, but it sells tickets). */
class TicketMachine(val map: String, val x: Int, val y: Int)
val TICKET_MACHINES: List<TicketMachine> = listOf(TicketMachine("plaza", 14, 6))

// ---- the ticket machine ----------------------------------------------------------------------

private val QUANTITIES = listOf(1, 5, 10)

fun Game.ticketScript(): List<Step> {
    val opts = QUANTITIES.map { "Buy $it   ${it * TICKET_PRICE} coins" } + "Leave"
    return listOf(ask("Ticket machine", "KJPW: one ticket is good for a whole night of wrestling. $TICKET_PRICE coins each. You hold $tickets ticket${if (tickets == 1) "" else "s"} and $coins coins.", opts) { c ->
        if (c >= QUANTITIES.size) listOf(narr("The machine hums. Come back for the show!"))
        else {
            val want = QUANTITIES[c]; val room = TICKET_CAP - tickets; val afford = coins / TICKET_PRICE
            val n = min(want, min(room, afford))
            when {
                room <= 0 -> listOf(say("Ticket machine", "You already hold $TICKET_CAP tickets, the most it will sell you.")) + ticketScript()
                n <= 0 -> listOf(say("Ticket machine", "A ticket costs $TICKET_PRICE coins. You have $coins.")) + ticketScript()
                else -> {
                    coins -= n * TICKET_PRICE; tickets += n
                    val why = if (n < want) (if (n == room) " That is as many as you can hold." else " That is all you can afford.") else ""
                    listOf(narr("Bought $n ticket${if (n == 1) "" else "s"} for ${n * TICKET_PRICE} coins.$why")) + ticketScript()
                }
            }
        }
    })
}

// ---- the usher at the arena doors -----------------------------------------------------------

fun Game.usherTalk(): List<Step> = when {
    f(PASS_FLAG) -> listOf(say("Usher", "Your ticket is good. Enjoy the show! The arena is through the doors."))
    tickets > 0 -> listOf(ask("Usher", "Tickets, please! Shall I take one of your $tickets tickets for tonight's show?", listOf("Show a ticket", "Not yet")) { c ->
        if (c == 0) listOf(act { tickets -= 1; set(PASS_FLAG) }, say("Usher", "Thank you! The doors are open. Your ticket is good until you leave the hall."))
        else listOf(say("Usher", "Take your time."))
    })
    else -> listOf(say("Usher", "Tickets, please! No ticket? The machine in the plaza sells them for $TICKET_PRICE coins."))
}

// ---- the announcer in the arena -----------------------------------------------------------------

private val ROSTER_SORTED: List<Wrestler> by lazy { ROSTER.sortedBy { it.name } }

/** A menu of the whole roster, 5 names a page; [pick] is called with the chosen wrestler. */
private fun Game.rosterMenu(prompt: String, page: Int, back: Game.() -> List<Step>, pick: Game.(Wrestler) -> List<Step>): List<Step> {
    val per = 5; val pages = (ROSTER_SORTED.size + per - 1) / per; val p = page.coerceIn(0, pages - 1)
    val slice = ROSTER_SORTED.subList(p * per, min(ROSTER_SORTED.size, p * per + per))
    val opts = slice.map { it.name } + "More..." + "Back"
    return listOf(ask("Announcer", "$prompt (page ${p + 1} of $pages)", opts) { c ->
        when {
            c < slice.size -> pick(slice[c])
            c == slice.size -> rosterMenu(prompt, (p + 1) % pages, back, pick)
            else -> back()
        }
    })
}

fun profile(w: Wrestler): List<Step> = listOf(
    say("Announcer", "${w.name}, ${w.style.label}, from ${w.from}. ${w.bio}"),
    say("Announcer", "Finisher: the ${w.finisher}. Also watch for: ${w.moves.take(3).joinToString(", ")}.")
)

private fun Game.bout(a: Wrestler, b: Wrestler): List<Step> = listOf(
    say("Announcer", "From ${a.from}, ${a.name}! And from ${b.from}, ${b.name}! Ring the bell!"),
    act { matchReq = MatchReq(a.id, b.id, rnd.nextInt(1 shl 30)) },
    act { play(afterBout()) }
)

fun Game.afterBout(): List<Step> =
    (if (lastWinner.isEmpty()) listOf(say("Announcer", "Leaving the ring already? The show goes on whenever you like."))
     else listOf(say("Announcer", "$lastWinner wins by $lastHow! What a bout! Give them a big hand!"))) + announcerTalk(false)

private fun Game.pickSecond(a: Wrestler): List<Step> =
    rosterMenu("And who faces ${a.name}?", 0, { announcerTalk(false) }) { b ->
        if (b === a) listOf(say("Announcer", "${a.name} cannot fight ${a.self}!")) + pickSecond(a) else bout(a, b)
    }

private fun Game.guide(): List<Step> =
    rosterMenu("Whose card shall I read?", 0, { announcerTalk(false) }) { w -> profile(w) + guide() }

fun Game.announcerTalk(first: Boolean = true): List<Step> {
    val opts = listOf("A surprise bout", "Pick the fighters", "Who's who?", "Not now")
    return listOf(ask("Announcer", if (first) "Welcome to KJPW! Tonight's bouts are all included with your ticket. What shall we see?" else "Another bout?", opts) { c ->
        when (c) {
            0 -> {
                val a = ROSTER[rnd.nextInt(ROSTER.size)]; var b = ROSTER[rnd.nextInt(ROSTER.size)]
                while (b === a) b = ROSTER[rnd.nextInt(ROSTER.size)]
                bout(a, b)
            }
            1 -> rosterMenu("Who is in the red corner?", 0, { announcerTalk(false) }) { a -> pickSecond(a) }
            2 -> guide()
            else -> listOf(say("Announcer", "Enjoy the night!"))
        }
    })
}

// ---- posters on the hallway wall -----------------------------------------------------------

/** The wrestler on the [i]th poster of a map (posters are the 'O' tiles, counted in reading order). */
fun posterWrestler(i: Int): Wrestler = ROSTER[(i * 7 + 2) % ROSTER.size]

/** How many 'O' tiles come before (x, y) in the map's rows. */
fun posterIndex(rows: List<String>, x: Int, y: Int): Int {
    var n = 0
    for (yy in 0 until y) n += rows[yy].count { it == 'O' }
    return n + rows[y].substring(0, x).count { it == 'O' }
}

/** What reading a poster says: a note for each 'O' tile of [art]. */
fun posterNotes(art: String): Map<Pair<Int, Int>, String> {
    val rows = art.trim().lines().map { it.trimEnd() }
    val out = HashMap<Pair<Int, Int>, String>()
    for ((y, r) in rows.withIndex()) for ((x, ch) in r.withIndex()) if (ch == 'O') {
        val w = posterWrestler(posterIndex(rows, x, y))
        out[x to y] = "POSTER: ${w.name}, ${w.style.label}, from ${w.from}. Finisher: the ${w.finisher}."
    }
    return out
}

// ---- the people -----------------------------------------------------------------------------------

private val BANTER = mapOf(
    WStyle.POWER to "I lift things. Then I throw them. That is the whole plan.",
    WStyle.FLYER to "The ropes are just a staircase to the sky.",
    WStyle.TECH to "Every hold has a counter. I know them all.",
    WStyle.BRAWL to "Why wrestle when you can brawl?",
    WStyle.GRAPPLE to "Get me on the mat and it is over.",
    WStyle.GIANT to "Careful. I sometimes forget how big I am.",
    WStyle.SHOWMAN to "A good match is a good show. Smile!",
    WStyle.ROOKIE to "It is my first season! Please cheer for me!"
)

private fun wrestlerNpc(id: String, map: String, x: Int, y: Int, face: Int): Npc {
    val w = ROSTER_BY_ID.getValue(id)
    val lk = Look(w.look.skin, w.look.hair, w.look.skin, w.look.trunks)         // bare chest, trunks
    return Npc("ar_w_$id", map, x, y, w.name, lk, face) {
        listOf(say(w.name, w.bio), say(w.name, BANTER.getValue(w.style)), say(w.name, "My finisher is the ${w.finisher}! Watch for it in the ring."))
    }
}

private fun person(id: String, map: String, x: Int, y: Int, name: String, look: Look, face: Int, vararg lines: String) =
    Npc(id, map, x, y, name, look, face) { lines.map { say(name, it) } }

private fun lk(skin: Int, hair: Int, top: Int, legs: Int, kind: Int = K_PLAIN) = Look(skin, hair, top, legs, kind)

val ARENA_NPCS: List<Npc> = listOf(
    // KJPW Plaza
    person("ar_pip", "plaza", 8, 7, "Little Lu", lk(Color.rgb(222, 170, 130), Color.rgb(40, 28, 24), Color.rgb(224, 64, 64), Color.rgb(60, 70, 110)), DOWN,
        "Wow, a real ticket machine! You put coins in and a ticket comes out!", "I want to see Anchor Abe's Harbor Hoist. It is the best."),
    person("ar_dot", "plaza", 19, 7, "Old Fan Dot", lk(Color.rgb(244, 208, 170), Color.rgb(200, 200, 210), Color.rgb(170, 90, 200), Color.rgb(90, 70, 110), K_COAT), LEFT,
        "I have seen every bout since KJPW opened.", "Bring a cushion. And when the lanterns glow bright, the whole hall shakes!"),
    person("ar_keeper", "plaza", 4, 7, "Lantern Keeper", lk(Color.rgb(176, 124, 90), Color.rgb(96, 60, 36), Color.rgb(240, 190, 60), Color.rgb(60, 60, 80), K_CAP), RIGHT,
        "Welcome to KJPW! Buy a ticket at the machine by the door. One ticket covers a whole night.",
        "Show it to the usher inside. Then the announcer will put on any bout you like. You only watch, nobody asks you to fight!"),
    // the hallway
    Npc("ar_usher", "hall", 20, 2, "Usher", lk(Color.rgb(236, 190, 150), Color.rgb(40, 30, 28), Color.rgb(150, 30, 44), Color.rgb(30, 28, 40), K_COAT), DOWN) { usherTalk() },
    wrestlerNpc("abe", "hall", 5, 2, DOWN), wrestlerNpc("fred", "hall", 10, 2, DOWN), wrestlerNpc("tess", "hall", 14, 2, DOWN), wrestlerNpc("pete", "hall", 17, 2, DOWN),
    wrestlerNpc("kelp", "hall", 5, 5, UP), wrestlerNpc("mama", "hall", 11, 5, UP), wrestlerNpc("duke", "hall", 18, 5, UP),
    // the arena
    Npc("ar_announcer", "arena", 12, 10, "Announcer", lk(Color.rgb(222, 170, 130), Color.rgb(30, 30, 40), Color.rgb(240, 240, 240), Color.rgb(30, 28, 40), K_COAT), DOWN) { announcerTalk() },
    person("ar_ref", "arena", 4, 7, "Ref Pat", lk(Color.rgb(236, 190, 150), Color.rgb(40, 30, 28), Color.rgb(246, 246, 250), Color.rgb(30, 28, 40)), RIGHT,
        "I have refereed ten thousand bouts. Mostly I get elbowed.", "Three taps on the mat or three counts, that is the rule."),
    wrestlerNpc("meteor", "arena", 19, 5, LEFT), wrestlerNpc("sal", "arena", 4, 11, RIGHT),
    person("ar_kid", "arena", 6, 12, "Fan Kai", lk(Color.rgb(176, 124, 90), Color.rgb(30, 30, 40), Color.rgb(70, 110, 210), Color.rgb(60, 60, 80)), UP,
        "My favourite is the one who wins! Which changes every night."),
    person("ar_snack", "arena", 17, 12, "Snack Seller", lk(Color.rgb(244, 208, 170), Color.rgb(160, 160, 170), Color.rgb(230, 130, 60), Color.rgb(60, 60, 80), K_CAP), LEFT,
        "Hot dumplings! ...Sorry, I am all out. Everyone is too busy cheering to eat.")
)

val ARENA_MOTION: Map<String, Walk> = mapOf(
    "ar_pip" to Walk(Motion.LOOK),
    "ar_kid" to Walk(Motion.LOOK),
    "ar_ref" to Walk(Motion.LOOK)
)
