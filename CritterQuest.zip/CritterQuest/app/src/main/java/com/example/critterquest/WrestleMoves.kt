package com.example.critterquest

// ---------------------------------------------------------------------------------------------
// KJPW: the move list. Every move is plain data: a name, how hard it hits, what it costs in spirit, which
// animation the match screen plays (MatchAnims.kt) and the line the announcer says. {A} is the wrestler doing it,
// {B} the one it is done to. Names are the ordinary wrestling-move names; the finishers (WrestleFinishers.kt) are
// invented for this game. To add a move: add one line here, then put its name in a wrestler's list in Wrestlers.kt.
// ---------------------------------------------------------------------------------------------

/** What a move is: the bout engine treats holds, big throws and light hits differently. */
enum class WKind { STRIKE, KICK, RUN, AIR, SLAM, SUPLEX, SPIKE, HOLD, GROUND, TAUNT }

/** Which picture the match screen plays for a move. */
enum class WAnim { STRIKE, KICK, RUN, DKICK, SLAM, SUPLEX, SPIKE, BOMB, SPIN, HOLD, DROP, STOMP, DIVE, WHIP, TAUNT }

/** Who a move is used on: a standing opponent, or one lying on the mat. */
enum class WNeed { STAND, DOWN }

class WMove(val name: String, val kind: WKind, val anim: WAnim, val power: Int, val cost: Int, val needs: WNeed,
            val line: String, val finisher: Boolean = false)

private fun m(n: String, k: WKind, a: WAnim, p: Int, c: Int, nd: WNeed, line: String) = WMove(n, k, a, p, c, nd, line)

/** Everything a wrestler can do besides his own finisher. About 80 moves in 13 families. */
val BASIC_MOVES: List<WMove> = listOf(
    // ---- strikes (standing opponent)
    m("Jab", WKind.STRIKE, WAnim.STRIKE, 2, 2, WNeed.STAND, "{A} snaps a quick jab into {B}!"),
    m("Forearm Smash", WKind.STRIKE, WAnim.STRIKE, 3, 3, WNeed.STAND, "{A} cracks {B} with a forearm smash!"),
    m("Chop", WKind.STRIKE, WAnim.STRIKE, 3, 3, WNeed.STAND, "{A} chops {B} across the chest! WHACK!"),
    m("Knife-Edge Chop", WKind.STRIKE, WAnim.STRIKE, 4, 4, WNeed.STAND, "A knife-edge chop from {A}! That one stings!"),
    m("Uppercut", WKind.STRIKE, WAnim.STRIKE, 4, 4, WNeed.STAND, "{A} throws a rising uppercut at {B}!"),
    m("Headbutt", WKind.STRIKE, WAnim.STRIKE, 4, 4, WNeed.STAND, "{A} lowers the head and headbutts {B}!"),
    m("Elbow Strike", WKind.STRIKE, WAnim.STRIKE, 3, 3, WNeed.STAND, "{A} drives an elbow into {B}'s jaw!"),
    m("Haymaker", WKind.STRIKE, WAnim.STRIKE, 5, 5, WNeed.STAND, "{A} winds up a huge haymaker!"),
    m("Palm Thrust", WKind.STRIKE, WAnim.STRIKE, 3, 3, WNeed.STAND, "{A} shoves {B} back with a palm thrust!"),
    m("Rapid Slaps", WKind.STRIKE, WAnim.STRIKE, 4, 4, WNeed.STAND, "{A} slaps {B} again and again and again!"),
    m("Sneak Attack", WKind.STRIKE, WAnim.STRIKE, 3, 3, WNeed.STAND, "{A} sneaks in a cheap shot while the ref looks away!"),
    // ---- kicks
    m("Low Kick", WKind.KICK, WAnim.KICK, 2, 2, WNeed.STAND, "{A} chops down {B}'s leg with a low kick!"),
    m("Roundhouse Kick", WKind.KICK, WAnim.KICK, 4, 4, WNeed.STAND, "{A} swings a roundhouse kick at {B}!"),
    m("Knee Strike", WKind.KICK, WAnim.KICK, 3, 3, WNeed.STAND, "{A} buries a knee in {B}'s stomach!"),
    m("Big Boot", WKind.KICK, WAnim.KICK, 5, 5, WNeed.STAND, "{A} plants a big boot right in {B}'s face!"),
    m("Enzuigiri", WKind.KICK, WAnim.KICK, 5, 5, WNeed.STAND, "{A} spins and catches {B} with an enzuigiri!"),
    m("Spin Kick", WKind.KICK, WAnim.KICK, 4, 4, WNeed.STAND, "{A} whirls around with a spin kick!"),
    // ---- running attacks
    m("Shoulder Tackle", WKind.RUN, WAnim.RUN, 4, 4, WNeed.STAND, "{A} charges in with a shoulder tackle!"),
    m("Clothesline", WKind.RUN, WAnim.RUN, 5, 5, WNeed.STAND, "{A} hits the ropes and... CLOTHESLINE!"),
    m("Lariat", WKind.RUN, WAnim.RUN, 6, 6, WNeed.STAND, "{A} swings a lariat that nearly takes {B}'s head off!"),
    m("Spear", WKind.RUN, WAnim.RUN, 6, 6, WNeed.STAND, "{A} lowers a shoulder and SPEARS {B} in half!"),
    m("Running Elbow", WKind.RUN, WAnim.RUN, 4, 4, WNeed.STAND, "{A} sprints in with a running elbow!"),
    m("Belly Bump", WKind.RUN, WAnim.RUN, 4, 4, WNeed.STAND, "{A} bounces off the ropes with a huge belly bump!"),
    m("Rope Whip", WKind.RUN, WAnim.WHIP, 4, 4, WNeed.STAND, "{A} whips {B} into the ropes and catches the rebound!"),
    // ---- dropkicks and flying hits on a standing opponent
    m("Dropkick", WKind.AIR, WAnim.DKICK, 5, 5, WNeed.STAND, "{A} leaps and drops both feet into {B}'s chest!"),
    m("Flying Forearm", WKind.AIR, WAnim.DKICK, 5, 5, WNeed.STAND, "{A} flies in with a flying forearm!"),
    m("Springboard Dropkick", WKind.AIR, WAnim.DKICK, 6, 6, WNeed.STAND, "{A} bounces off the ropes and soars with a dropkick!"),
    m("Missile Dropkick", WKind.AIR, WAnim.DKICK, 6, 6, WNeed.STAND, "{A} dives from the top with a missile dropkick!"),
    m("Crossbody", WKind.AIR, WAnim.DIVE, 5, 5, WNeed.STAND, "{A} flings {self} off the ropes with a crossbody!"),
    // ---- slams
    m("Hip Toss", WKind.SLAM, WAnim.SLAM, 3, 3, WNeed.STAND, "{A} flips {B} over with a hip toss!"),
    m("Bodyslam", WKind.SLAM, WAnim.SLAM, 5, 5, WNeed.STAND, "{A} hoists {B} up and bodyslams {him}!"),
    m("Scoop Slam", WKind.SLAM, WAnim.SLAM, 5, 5, WNeed.STAND, "{A} scoops {B} up and slams {him} down!"),
    m("Powerslam", WKind.SLAM, WAnim.SLAM, 6, 6, WNeed.STAND, "{A} lifts {B} high and POWERSLAMS {him}!"),
    m("Spinebuster", WKind.SLAM, WAnim.SLAM, 6, 6, WNeed.STAND, "{A} drives {B}'s back into the mat with a spinebuster!"),
    m("Fireman's Carry", WKind.SLAM, WAnim.SLAM, 5, 5, WNeed.STAND, "{A} swings {B} onto {his} shoulders and drops {him}!"),
    m("Atomic Drop", WKind.SLAM, WAnim.SLAM, 4, 4, WNeed.STAND, "{A} drops {B} with an atomic drop! Ouch!"),
    m("Neck Hoist Slam", WKind.SLAM, WAnim.SLAM, 7, 7, WNeed.STAND, "{A} grabs {B} by the neck and hoists {him} up... SLAM!"),
    m("Press Slam", WKind.SLAM, WAnim.SLAM, 7, 7, WNeed.STAND, "{A} presses {B} over {his} head and hurls {him} down!"),
    // ---- suplexes
    m("Snap Suplex", WKind.SUPLEX, WAnim.SUPLEX, 5, 5, WNeed.STAND, "{A} snaps {B} over with a quick suplex!"),
    m("Vertical Suplex", WKind.SUPLEX, WAnim.SUPLEX, 6, 6, WNeed.STAND, "{A} holds {B} upside down... vertical suplex!"),
    m("Belly-to-Belly", WKind.SUPLEX, WAnim.SUPLEX, 6, 6, WNeed.STAND, "{A} throws {B} overhead with a belly-to-belly suplex!"),
    m("German Suplex", WKind.SUPLEX, WAnim.SUPLEX, 7, 7, WNeed.STAND, "{A} wraps {his} arms round {B}... GERMAN SUPLEX!"),
    m("Tiger Suplex", WKind.SUPLEX, WAnim.SUPLEX, 7, 7, WNeed.STAND, "{A} locks {B}'s arms and arches back with a tiger suplex!"),
    // ---- head-first moves
    m("Neckbreaker", WKind.SPIKE, WAnim.SPIKE, 5, 5, WNeed.STAND, "{A} drops {B}'s neck over {his} knee!"),
    m("Facebuster", WKind.SPIKE, WAnim.SPIKE, 5, 5, WNeed.STAND, "{A} slams {B}'s face into the mat!"),
    m("DDT", WKind.SPIKE, WAnim.SPIKE, 6, 6, WNeed.STAND, "{A} grabs {B}'s head and drives it down with a DDT!"),
    m("Cutter", WKind.SPIKE, WAnim.SPIKE, 6, 6, WNeed.STAND, "{A} hooks {B}'s head and flips into a cutter!"),
    m("Piledriver", WKind.SPIKE, WAnim.SPIKE, 8, 8, WNeed.STAND, "{A} turns {B} upside down... PILEDRIVER!"),
    m("Brainbuster", WKind.SPIKE, WAnim.SPIKE, 8, 8, WNeed.STAND, "{A} hoists {B} up and spikes {him} head-first! Brainbuster!"),
    // ---- carries and spins
    m("Backbreaker", WKind.SLAM, WAnim.BOMB, 5, 5, WNeed.STAND, "{A} drops {B} across {his} knee with a backbreaker!"),
    m("Shoulder Drop", WKind.SLAM, WAnim.BOMB, 6, 6, WNeed.STAND, "{A} heaves {B} up and drops {him} with a huge shoulder slam!"),
    m("Spinning Slam", WKind.SLAM, WAnim.SPIN, 6, 6, WNeed.STAND, "{A} spins {B} round and round and SLAMS {him}!"),
    m("Airplane Spin", WKind.SLAM, WAnim.SPIN, 7, 7, WNeed.STAND, "{A} swings {B} like an airplane... and lets go!"),
    m("Powerbomb", WKind.SLAM, WAnim.BOMB, 8, 8, WNeed.STAND, "{A} sits {B} on {his} shoulders... POWERBOMB!"),
    m("Sit-Out Powerbomb", WKind.SLAM, WAnim.BOMB, 9, 9, WNeed.STAND, "{A} lifts {B} high and sits out! SIT-OUT POWERBOMB!"),
    // ---- holds (the first three on a standing opponent, the rest on the mat)
    m("Headlock", WKind.HOLD, WAnim.HOLD, 2, 2, WNeed.STAND, "{A} wraps {B} up in a headlock!"),
    m("Sleeper Hold", WKind.HOLD, WAnim.HOLD, 3, 3, WNeed.STAND, "{A} locks a sleeper hold on {B}!"),
    m("Bear Hug", WKind.HOLD, WAnim.HOLD, 4, 4, WNeed.STAND, "{A} grabs {B} in a crushing bear hug!"),
    m("Armbar", WKind.HOLD, WAnim.HOLD, 3, 3, WNeed.DOWN, "{A} twists {B}'s arm into an armbar!"),
    m("Ankle Lock", WKind.HOLD, WAnim.HOLD, 4, 4, WNeed.DOWN, "{A} traps {B}'s ankle in an ankle lock!"),
    m("Camel Clutch", WKind.HOLD, WAnim.HOLD, 5, 5, WNeed.DOWN, "{A} sits on {B}'s back and cranks the camel clutch!"),
    m("Cross-Face", WKind.HOLD, WAnim.HOLD, 5, 5, WNeed.DOWN, "{A} cranks {B}'s face back with the cross-face!"),
    m("Boston Crab", WKind.HOLD, WAnim.HOLD, 5, 5, WNeed.DOWN, "{A} flips {B} over and folds {him} into a Boston crab!"),
    m("Triangle Choke", WKind.HOLD, WAnim.HOLD, 6, 6, WNeed.DOWN, "{A} snaps a triangle choke onto {B}!"),
    m("Figure-Four", WKind.HOLD, WAnim.HOLD, 6, 6, WNeed.DOWN, "{A} ties {B}'s legs into a figure-four lock!"),
    // ---- attacks on a wrestler lying on the mat
    m("Stomp", WKind.GROUND, WAnim.STOMP, 2, 2, WNeed.DOWN, "{A} stomps on {B} while {he} is down!"),
    m("Fist Drop", WKind.GROUND, WAnim.STOMP, 3, 3, WNeed.DOWN, "{A} drops a fist onto {B}!"),
    m("Elbow Drop", WKind.GROUND, WAnim.DROP, 4, 4, WNeed.DOWN, "{A} drops an elbow onto {B}!"),
    m("Knee Drop", WKind.GROUND, WAnim.DROP, 4, 4, WNeed.DOWN, "{A} drops a knee across {B}'s chest!"),
    m("Leg Drop", WKind.GROUND, WAnim.DROP, 4, 4, WNeed.DOWN, "{A} leaps and drops a leg across {B}'s throat!"),
    m("Body Splash", WKind.GROUND, WAnim.DROP, 5, 5, WNeed.DOWN, "{A} jumps and splashes {his} whole body onto {B}!"),
    m("Senton", WKind.GROUND, WAnim.DROP, 5, 5, WNeed.DOWN, "{A} falls backward onto {B} with a senton!"),
    // ---- from the top rope, onto a wrestler lying on the mat
    m("Top-Rope Elbow", WKind.AIR, WAnim.DIVE, 7, 7, WNeed.DOWN, "{A} climbs to the top... and drops an elbow onto {B}!"),
    m("Diving Headbutt", WKind.AIR, WAnim.DIVE, 7, 7, WNeed.DOWN, "{A} dives from the top rope with a headbutt!"),
    m("Flying Body Press", WKind.AIR, WAnim.DIVE, 7, 7, WNeed.DOWN, "{A} flies off the top rope with a body press!"),
    m("Frog Splash", WKind.AIR, WAnim.DIVE, 8, 8, WNeed.DOWN, "{A} leaps from the top rope... FROG SPLASH!"),
    m("Moonsault", WKind.AIR, WAnim.DIVE, 8, 8, WNeed.DOWN, "{A} flips off the top rope with a MOONSAULT!"),
    // ---- showing off (no damage; the crowd loves it)
    m("Flex", WKind.TAUNT, WAnim.TAUNT, 0, 0, WNeed.STAND, "{A} flexes for the crowd!"),
    m("Taunt", WKind.TAUNT, WAnim.TAUNT, 0, 0, WNeed.STAND, "{A} beckons {B} to come and get it!"),
    m("Crowd Pump", WKind.TAUNT, WAnim.TAUNT, 0, 0, WNeed.STAND, "{A} throws {his} arms up and the crowd goes wild!")
)
