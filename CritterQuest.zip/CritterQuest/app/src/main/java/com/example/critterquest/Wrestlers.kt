package com.example.critterquest

// ---------------------------------------------------------------------------------------------
// KJPW: the roster. 24 wrestlers in the classic wrestling styles (like the type lists of old wrestling
// games), every one invented for this game: name, look, stats, moves and finisher are all plain data below.
//
// To add a wrestler: add one W(...) line at the end of ROSTER, no picture work is needed:
// every wrestler is drawn from one shared template that is recoloured from his WLook (wrestlers.png, see ASSETS.md).
// Stats go from 1 to 10: pow = how hard he hits, spd = who strikes first and who dodges, tech = counters and
// holds, tough = how much punishment he takes, sta = spirit (stamina) and kick-outs, charm = how loud the crowd gets.
// ---------------------------------------------------------------------------------------------

enum class WStyle(val label: String) {
    POWER("Powerhouse"), FLYER("High-flyer"), TECH("Technician"), BRAWL("Brawler"),
    GRAPPLE("Grappler"), GIANT("Giant"), SHOWMAN("Showman"), ROOKIE("Rookie")
}

/** How a wrestler is drawn. Colours are 0xAARRGGBB; [mask] and [beard] are 0 for "none". [body]: 0 normal, 1 big, 2 giant. */
class WLook(val skin: Int, val hair: Int, val trunks: Int, val boots: Int, val mask: Int = 0, val beard: Int = 0,
            val bald: Boolean = false, val body: Int = 0)

class Wrestler(
    val id: String, val name: String, val from: String, val style: WStyle, val she: Boolean, val look: WLook,
    val pow: Int, val spd: Int, val tech: Int, val tough: Int, val sta: Int, val charm: Int,
    val moves: List<String>, val finisher: String, val entrance: String, val bio: String
) {
    /** How much punishment he can take before the count: about 115 for a light flyer up to 200 for a giant. */
    val maxHp: Int get() = 70 + tough * 11 + look.body * 10
    val he: String get() = if (she) "she" else "he"
    val him: String get() = if (she) "her" else "him"
    val his: String get() = if (she) "her" else "his"
    val self: String get() = if (she) "herself" else "himself"
    val fin: WMove get() = wmove(finisher)
    val kit: List<WMove> get() = moves.map { wmove(it) }
}

private fun c(rgb: Int) = 0xFF000000.toInt() or rgb
private fun L(skin: Int, hair: Int, trunks: Int, boots: Int, mask: Int = 0, beard: Int = 0, bald: Boolean = false, body: Int = 0) =
    WLook(c(skin), c(hair), c(trunks), c(boots), if (mask == 0) 0 else c(mask), if (beard == 0) 0 else c(beard), bald, body)

private fun W(id: String, name: String, from: String, style: WStyle, she: Boolean, look: WLook, pow: Int, spd: Int, tech: Int, tough: Int,
              sta: Int, charm: Int, moves: String, finisher: String, entrance: String, bio: String) =
    Wrestler(id, name, from, style, she, look, pow, spd, tech, tough, sta, charm, moves.split(",").map { it.trim() }, finisher, entrance, bio)

val ROSTER: List<Wrestler> = listOf(
    W("abe", "Anchor Abe", "Tidewatch Harbor", WStyle.POWER, false, L(0xD6A076, 0x281C18, 0x284696, 0xF0F0F6, beard = 0x32221A, body = 1),
        8, 4, 5, 8, 7, 6, "Chop, Bodyslam, Powerslam, Bear Hug, Elbow Drop, Shoulder Tackle, Press Slam", "Harbor Hoist",
        "Anchor Abe stomps in with a rope over his shoulder!", "A Tidewatch dockhand who has hauled crates since he was twelve."),
    W("reef", "Reef Rascal", "Tidewatch Harbor", WStyle.FLYER, false, L(0xF0BE96, 0x187C82, 0xF06E5A, 0xFAFAFF, mask = 0x2CB2B2),
        4, 9, 6, 4, 6, 8, "Dropkick, Springboard Dropkick, Crossbody, Rope Whip, Flying Body Press, Frog Splash, Hip Toss", "Tide Turner",
        "Reef Rascal cartwheels down the aisle in a teal mask!", "Nobody knows who hides under the teal mask. Everybody knows how high he flies."),
    W("sal", "Ginger Sal", "Tidewatch Harbor", WStyle.BRAWL, false, L(0xE0AC82, 0xB43C28, 0xF08C46, 0x46322A, beard = 0xB43C28),
        7, 5, 4, 7, 7, 6, "Haymaker, Headbutt, Forearm Smash, Knee Strike, Clothesline, Stomp, Sneak Attack", "Hot Sauce Haymaker",
        "Ginger Sal swaggers in with a bottle of hot sauce on his belt!", "A fish-market brawler with a ginger beard and a fiery temper."),
    W("ollie", "Old Ollie", "Mossbrook", WStyle.TECH, false, L(0x784C34, 0x5A5A64, 0x1E1E26, 0xF0BE3C, beard = 0xC8C8D0, bald = true),
        4, 4, 10, 5, 5, 7, "Headlock, Armbar, Ankle Lock, Cross-Face, Snap Suplex, Figure-Four, Boston Crab", "Last Orders",
        "Old Ollie shuffles in, tips an imaginary hat and cracks his knuckles.", "The oldest wrestler in the hall. He has forgotten more holds than you will ever learn."),
    W("meteor", "Masked Meteor", "Cinderpeak", WStyle.FLYER, false, L(0xF0BE96, 0x7054C4, 0x7846BE, 0xFAD246, mask = 0xB09CF0),
        5, 9, 6, 4, 6, 9, "Dropkick, Missile Dropkick, Crossbody, Moonsault, Enzuigiri, Spin Kick, Flying Body Press", "Falling Star",
        "Masked Meteor streaks in under the lights, arms wide!", "A shooting star in a lavender mask. Fast, fearless and a little bit famous."),
    W("gus", "Granite Gus", "Briar Hollow", WStyle.GIANT, false, L(0xC68C62, 0xD2D2D8, 0x6E707C, 0x785032, body = 2),
        10, 2, 3, 10, 5, 5, "Big Boot, Neck Hoist Slam, Powerslam, Press Slam, Bear Hug, Elbow Drop, Stomp", "Mountain Drop",
        "The floor shakes. Granite Gus ducks under the doorframe!", "As big as the quarry he grew up in, and about as easy to move."),
    W("kid", "Cinder Kid", "Cinderpeak", WStyle.BRAWL, false, L(0xE0AC82, 0xE0452E, 0xD23C28, 0x3C2C34),
        6, 7, 4, 5, 8, 7, "Jab, Roundhouse Kick, Spin Kick, Low Kick, Dropkick, Knee Strike, Leg Drop", "Ember Kick",
        "Cinder Kid sprints in, trailing sparks and a big grin!", "Never stands still, never runs out of breath, and kicks like a mule."),
    W("doc", "Doc Hold", "Mossbrook", WStyle.TECH, false, L(0xFAD6B8, 0x5A5A64, 0x78C8AA, 0x6E8CC8),
        3, 5, 9, 5, 6, 5, "Armbar, Headlock, Sleeper Hold, Snap Suplex, Triangle Choke, Cross-Face, Knee Drop", "Doctor's Orders",
        "Doc Hold strolls in with a little black bag and a calm smile.", "Village doctor by day. At night he treats opponents to the Doctor's Orders."),
    W("moss", "Madam Moss", "Briar Hollow", WStyle.GRAPPLE, true, L(0xF0BE96, 0x3C783C, 0x3C9650, 0x50A064),
        5, 5, 8, 6, 7, 6, "Belly-to-Belly, Vertical Suplex, Camel Clutch, Boston Crab, Hip Toss, Headlock, Cutter", "Moss Wrap",
        "Madam Moss glides in, green hair swaying like willow branches.", "She grew up in the Briar woods and holds on tighter than any vine."),
    W("bao", "Big Bao", "Saltwind Shore", WStyle.GIANT, false, L(0xE6B488, 0x281C18, 0xFAFAFC, 0xE6B488, body = 2),
        8, 2, 4, 10, 6, 8, "Palm Thrust, Belly Bump, Rapid Slaps, Bodyslam, Body Splash, Senton, Press Slam", "Salt Splash",
        "Big Bao stamps twice, tosses a handful of salt and bows to the crowd.", "A gentle giant from the shore. Bows to everyone, then sits on them."),
    W("ike", "Ironclad Ike", "Cinderpeak", WStyle.POWER, false, L(0xA06848, 0x1C1C20, 0xA0A4B4, 0x5A5E6E, body = 1),
        9, 3, 4, 9, 6, 5, "Uppercut, Spinebuster, Powerslam, Fireman's Carry, Shoulder Drop, Atomic Drop, Elbow Drop", "Iron Gavel",
        "Ironclad Ike marches in, steel trunks gleaming!", "A blacksmith whose handshake bends spoons. Slow, steady, crushing."),
    W("crash", "Captain Crash", "Tidewatch Harbor", WStyle.BRAWL, false, L(0xF0BE96, 0x46321E, 0x3C96DC, 0xF0F0F6),
        7, 6, 4, 6, 6, 7, "Clothesline, Spear, Lariat, Running Elbow, Shoulder Tackle, Headbutt, Stomp", "Full Steam",
        "Captain Crash blows a whistle and charges down the aisle!", "Ferry captain, full speed ahead. Brakes are for other people."),
    W("lotus", "Lady Lotus", "Whisper Meadow", WStyle.FLYER, true, L(0xF0BE96, 0xFF78B4, 0xE65A9B, 0xFAFAFF, mask = 0xF59CC8),
        4, 8, 7, 4, 6, 9, "Springboard Dropkick, Enzuigiri, Crossbody, Cutter, Flying Body Press, Spin Kick, Hip Toss", "Lotus Drop",
        "Lady Lotus floats in, scattering petals over the crowd.", "Graceful, quick and sharper than she looks. The meadow's favourite."),
    W("stripe", "Stripe Sam", "Briar Hollow", WStyle.BRAWL, false, L(0xC68C62, 0xE67828, 0x96C832, 0x1E1E26),
        6, 7, 5, 5, 7, 6, "Crossbody, Roundhouse Kick, Forearm Smash, Rope Whip, Dropkick, Knee Drop, Sneak Attack", "Tiger Pounce",
        "Stripe Sam prowls in, low and slow, eyes on his prey.", "Moves like a big cat: patient, then suddenly everywhere."),
    W("owl", "Night Owl", "Gloam Pass", WStyle.TECH, false, L(0xF0BE96, 0x2C2C48, 0x2C2C48, 0xFAD246, mask = 0x2C2C48),
        5, 7, 9, 5, 6, 8, "Sleeper Hold, Enzuigiri, Neckbreaker, Armbar, Cutter, Spin Kick, Headlock", "Midnight Hush",
        "The lights dip. Night Owl glides in without a sound.", "Only ever seen after dark. Puts opponents to sleep, quite literally."),
    W("bruno", "Boulder Bruno", "Cinderpeak", WStyle.GIANT, false, L(0x785238, 0x3C281C, 0x8C6446, 0x3C281C, beard = 0x3C281C, body = 2),
        9, 2, 3, 9, 5, 4, "Haymaker, Powerslam, Powerbomb, Bear Hug, Elbow Drop, Knee Drop, Shoulder Tackle", "Rockslide",
        "Boulder Bruno rumbles in like a landslide!", "A miner from the Cinderpeak quarry. Hits like falling rock."),
    W("rick", "Slick Rick", "Tidewatch Harbor", WStyle.SHOWMAN, false, L(0xE0AC82, 0x1E1E26, 0xC88C28, 0x1E1E26),
        5, 6, 6, 5, 5, 10, "Taunt, Sneak Attack, Neckbreaker, DDT, Knee Drop, Cutter, Stomp", "The Encore",
        "Slick Rick struts in, combing his hair and winking at the crowd!", "Plays to the crowd, bends the rules, and always takes a bow."),
    W("fern", "Fern Fury", "Briar Hollow", WStyle.BRAWL, true, L(0xC68C62, 0x50B450, 0x1E786E, 0x143C38),
        6, 6, 4, 6, 7, 6, "Chop, Knife-Edge Chop, Forearm Smash, Dropkick, Neckbreaker, Low Kick, Stomp", "Leaf Cutter",
        "Fern Fury storms in with a leaf between her teeth!", "A forester with a mean chop. Her chops are heard in the next valley."),
    W("duke", "Dune Duke", "Saltwind Shore", WStyle.GRAPPLE, false, L(0xB07850, 0xD2B478, 0xDCBE82, 0x785A3C, beard = 0xD2B478),
        7, 4, 7, 7, 6, 5, "German Suplex, Vertical Suplex, Belly-to-Belly, Tiger Suplex, Boston Crab, Headlock, Knee Drop", "Sandstorm Suplex",
        "Dune Duke walks in kicking up a little sandstorm.", "A beach-wrestling champion. Everything ends in a suplex."),
    W("fred", "Frostbite Fred", "Gloam Pass", WStyle.TECH, false, L(0xFAD6B8, 0xDCEBF5, 0xB4E1F5, 0x6496C8),
        4, 6, 8, 5, 6, 5, "Ankle Lock, Armbar, Cross-Face, Low Kick, Snap Suplex, Triangle Choke, Elbow Strike", "Cold Snap",
        "A cold breeze sweeps the hall. Frostbite Fred has arrived.", "Cool, calm and very hard to warm up to. Loves a good ankle lock."),
    W("tess", "Thunder Tess", "Cinderpeak", WStyle.POWER, true, L(0xE0AC82, 0xFFE146, 0xFFE146, 0x28282E),
        8, 5, 4, 7, 6, 8, "Palm Thrust, Chop, Spinebuster, Hip Toss, Clothesline, Powerslam, Leg Drop", "Thunderclap",
        "Thunder Tess claps her hands and the lights flicker!", "Her clap rattles the rafters, and her hugs rattle ribs."),
    W("pete", "Pixel Pete", "Mossbrook", WStyle.ROOKIE, false, L(0xF0BE96, 0x785028, 0xC8C8CD, 0xD23C32),
        5, 5, 5, 5, 8, 7, "Jab, Dropkick, Hip Toss, Headlock, Forearm Smash, Knee Drop, Crowd Pump", "Lucky Punch",
        "Pixel Pete jogs in, waving at his mum in the stands!", "The new kid. Not the best at anything, and never, ever gives up."),
    W("mama", "Mama Bear", "Briar Hollow", WStyle.POWER, true, L(0x8C5A3C, 0x3C281C, 0x8C2846, 0x3C281C, body = 1),
        8, 3, 5, 9, 7, 8, "Bear Hug, Bodyslam, Atomic Drop, Fireman's Carry, Belly Bump, Knee Strike, Body Splash", "Bear Squeeze",
        "Mama Bear lumbers in and blows a kiss to the front row.", "Everybody's favourite gran. Hugs first, asks questions later."),
    W("kelp", "King Kelp", "Saltwind Shore", WStyle.SHOWMAN, false, L(0xD0966E, 0x1E8C5A, 0x1EAAAA, 0xFAD246),
        5, 7, 6, 5, 6, 10, "Crowd Pump, Flex, Taunt, Frog Splash, Dropkick, Neckbreaker, Sneak Attack", "Royal Splash",
        "King Kelp sweeps in wearing a seaweed crown and a huge smile!", "Crowned himself king of the shore. The crowd hasn't argued yet.")
)

val ROSTER_BY_ID: Map<String, Wrestler> = ROSTER.associateBy { it.id }
fun wrestler(id: String): Wrestler = ROSTER_BY_ID[id] ?: error("unknown wrestler: $id")
