package com.example.critterquest

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

// ---------------------------------------------------------------------------------------------
// KJPW: the match screen. It plays one Bout (Bout.kt) beat by beat: the stage directions come from
// MatchAnims.kt, the pictures from WrestlerSprites (MatchArt.kt), and the commentary is typed into the same kind of
// text box the rest of the game uses. Watch only: OK skips ahead, LEFT / RIGHT change the speed, BACK leaves.
// Everything is drawn in the small logical pixels (see GameView), wrestlers at double size.
// ---------------------------------------------------------------------------------------------
class MatchView(private val wa: Wrestler, private val wb: Wrestler, seed: Int, private val sprites: WrestlerSprites, nowMs: Long) {
    val bout = Bout(wa, wb, seed)
    private val ws = arrayOf(wa, wb)

    /** The player has finished with the screen (watched it to the end, or left). */
    var done = false; private set
    /** The bout ran to its end, so [winnerName] and [how] are known. */
    var finished = false; private set
    var winnerName = ""; private set
    var how = ""; private set
    var speed = 1; private set

    private var lastNow = nowMs
    private var vt = 0f                       // the show's own clock in ms: it runs 2 or 4 times faster at speed 2 or 4
    private var cur: Beat? = null
    private var prev: Beat? = null
    private var anim: Anim? = null
    private var beatT0 = 0f
    private var pages: List<List<String>> = emptyList()
    private var page = 0
    private var pageT0 = 0f
    private var typedAt = -1f
    private var ended = false
    private var leaveUntil = 0L
    private var fxIdx = 0
    private var textW = 0
    private val shownHp = FloatArray(2) { bout.hp[it].toFloat() }
    private val shownSp = FloatArray(2) { bout.sp[it].toFloat() }
    private var crowdShown = bout.crowd.toFloat()
    private var shakeUntil = 0f; private var shakeAmp = 0
    private var slapAt = -10000f
    private var refX = 0f
    private val t0Real = nowMs

    private class Effect(val kind: Int, val t0: Float, val x: Float, val y: Float, val text: String = "")   // 0 hit, 1 big hit, 2 dust, 3 number
    private val effects = ArrayList<Effect>()
    private var banner = ""; private var bannerAt = -10000f; private var bannerBig = false

    private val sp = Paint().apply { isAntiAlias = false; isFilterBitmap = false; isDither = false }
    private val path = Path()
    private val dst = Rect()

    companion object {
        /** The commentary of one beat cut into pages of two lines, for a text box [maxW] pixels wide. */
        fun pagesFor(text: String, maxW: Int): List<List<String>> = PixelFont.wrap(text, maxW).chunked(2)

        private val SKINS = intArrayOf(Color.rgb(244, 208, 170), Color.rgb(222, 170, 130), Color.rgb(176, 124, 90), Color.rgb(120, 82, 60), Color.rgb(250, 220, 190))
        private val HAIRS = intArrayOf(Color.rgb(40, 28, 24), Color.rgb(96, 60, 36), Color.rgb(210, 170, 90), Color.rgb(160, 160, 170), Color.rgb(200, 80, 50), Color.rgb(30, 30, 40))
        private val SHIRTS = intArrayOf(Color.rgb(214, 70, 70), Color.rgb(70, 110, 210), Color.rgb(240, 190, 60), Color.rgb(80, 180, 110), Color.rgb(170, 90, 200), Color.rgb(240, 240, 240), Color.rgb(60, 60, 80), Color.rgb(230, 130, 60))
        private val CONFETTI = intArrayOf(Color.rgb(248, 200, 64), Color.rgb(224, 64, 64), Color.rgb(80, 170, 240), Color.rgb(100, 210, 120), Color.rgb(250, 250, 250))
        private fun hash(a: Int, b: Int = 0) = (((a * 73856093) xor (b * 19349663) xor 0x5bd1e995) and 0x7fffffff)
    }

    // =============================================================================================
    //  the show: beats, timing, input
    // =============================================================================================
    private fun nextBeat() {
        val b = bout.next()
        if (b == null) { endShow(); return }
        prev = cur; cur = b
        anim = MatchAnims.build(b, prev, bout.drained)
        beatT0 = vt; fxIdx = 0; page = 0; pageT0 = vt; typedAt = -1f
        pages = pagesFor(b.text, max(60, textW))
        when (b.kind) {
            BeatKind.BELL -> say("DING DING!", true)
            BeatKind.COUNTER -> say("REVERSAL!", false)
            BeatKind.COVER -> say("ONE!", true)
            BeatKind.COUNT -> say("TWO!", true)
            BeatKind.KICKOUT -> say("KICK OUT!", true)
            BeatKind.WIN -> if (b.n == 3) say("THREE!", true)
            BeatKind.ESCAPE -> say("ROPE BREAK!", false)
            else -> {}
        }
    }

    private fun say(s: String, big: Boolean) { banner = s; bannerAt = vt; bannerBig = big }

    private fun endShow() {
        ended = true; finished = true
        val wi = bout.winner
        if (wi in 0..1) { winnerName = ws[wi].name; how = bout.how }
    }

    private fun pageLen() = pages.getOrNull(page)?.sumOf { it.length } ?: 0
    private fun typed() = ((vt - pageT0) / 22f).toInt() >= pageLen()
    private fun animDone() = anim?.let { vt - beatT0 >= it.ms } ?: true

    /** Fires the effect of a key (a hit, a heavy landing, the crowd, the referee's hand...). */
    private fun fire(key: Key, beat: Beat, p: Float) {
        val an = anim ?: return
        val s = MatchAnims.sample(an, p)
        val axis = if (an.att == 0) 1f else -1f
        val xa = axis * (-MatchAnims.HOME + s[0].dx); val xb = axis * (MatchAnims.HOME + s[1].dx)
        when (key.fx) {
            Fx.HIT, Fx.BIG -> {
                val big = key.fx == Fx.BIG
                effects.add(Effect(if (big) 1 else 0, vt, (xa + xb) / 2f, 30f))
                if (big) { effects.add(Effect(2, vt, xb, 0f)); shakeUntil = vt + 260f; shakeAmp = 2 }
                if (beat.dmg > 0 && beat.kind != BeatKind.KICKOUT) effects.add(Effect(3, vt, xb, 62f, "-" + beat.dmg))
            }
            Fx.CROWD -> crowdShown = min(100f, crowdShown + 8f)
            Fx.SLAP -> slapAt = vt
            Fx.TAP -> say("TAP! TAP!", true)
            Fx.NONE -> {}
        }
    }

    fun update(now: Long) {
        val real = (now - lastNow).coerceIn(0L, 100L); lastNow = now
        vt += real * speed
        if (cur == null && !ended) nextBeat()
        val b = cur; val an = anim
        if (b != null && an != null && !ended) {
            val p = (vt - beatT0) / an.ms
            while (fxIdx < an.keys.size && an.keys[fxIdx].t <= p) { fire(an.keys[fxIdx], b, an.keys[fxIdx].t); fxIdx++ }
            if (typed() && typedAt < 0f) typedAt = vt
            if (typedAt >= 0f && vt - typedAt >= 450f + pageLen() * 7f) {
                if (page < pages.size - 1) { page++; pageT0 = vt; typedAt = -1f }
                else if (animDone()) nextBeat()
            }
            for (i in 0..1) { shownHp[i] += (b.hp[i] - shownHp[i]) * (1f - Math.pow(0.92, real * speed / 16.667).toFloat()); shownSp[i] += (b.sp[i] - shownSp[i]) * 0.1f }
            crowdShown += (b.crowd - crowdShown) * 0.02f
        }
        // the referee strolls to the far side, or kneels over a pin
        if (an != null && b != null) {
            val axis = if (an.att == 0) 1f else -1f
            val target = if (b.kind == BeatKind.COVER || b.kind == BeatKind.COUNT || b.kind == BeatKind.KICKOUT) axis * (MatchAnims.HOME + 10f) - axis * 6f
                         else if (anim?.att == 0) 78f else -78f
            refX += (target - refX) * 0.04f
        }
        effects.removeAll { vt - it.t0 > 900f }
    }

    fun input(a: Int) {
        when (a) {
            4 -> ok()
            5 -> back()
            RIGHT -> speed = min(4, speed * 2)
            LEFT -> speed = max(1, speed / 2)
        }
    }

    /** Touch: tapping the lanterns steps the speed 1 -> 2 -> 4 -> 1. */
    fun cycleSpeed() { speed = if (speed >= 4) 1 else speed * 2 }

    private fun ok() {
        if (ended) { done = true; return }
        val an = anim ?: return
        if (!typed()) { pageT0 = vt - 100000f; return }
        if (page < pages.size - 1) { page++; pageT0 = vt; typedAt = -1f; return }
        if (!animDone()) beatT0 = vt - an.ms.toFloat()
        nextBeat()
    }

    private fun back() {
        if (ended) { done = true; return }
        if (lastNow < leaveUntil) { done = true; finished = false; return }
        leaveUntil = lastNow + 2500L
    }

    /** Leave right now (used when the screen is torn down from outside). */
    fun leave() { done = true }

    // =============================================================================================
    //  drawing helpers
    // =============================================================================================
    private fun rect(c: Canvas, x: Float, y: Float, w: Float, h: Float, col: Int) = Ui.rect(c, x, y, w, h, col)
    private fun tx(c: Canvas, s: String, x: Float, y: Float, col: Int = Ui.INK, align: Int = 0, scale: Int = 1, shadow: Int = Ui.INK_SHADOW) = PixelFont.draw(c, s, x, y, col, align, scale, shadow)
    private fun shade(c: Int, f: Float) = Color.rgb((Color.red(c) * f).toInt().coerceIn(0, 255), (Color.green(c) * f).toInt().coerceIn(0, 255), (Color.blue(c) * f).toInt().coerceIn(0, 255))
    private fun disc(c: Canvas, cx: Float, cy: Float, r: Float, col: Int) {
        val ir = r.toInt()
        for (dy in -ir..ir) { val hw = Math.round(Math.sqrt((r * r - dy * dy).coerceAtLeast(0f).toDouble())).toFloat(); rect(c, cx - hw, cy + dy, hw * 2, 1f, col) }
    }
    private fun ellipse(c: Canvas, cx: Float, cy: Float, rx: Float, ry: Float, col: Int) {
        val iy = ry.toInt()
        for (dy in -iy..iy) { val hw = Math.round(rx * Math.sqrt((1f - (dy.toFloat() * dy) / (ry * ry)).coerceAtLeast(0f).toDouble())).toFloat(); rect(c, cx - hw, cy + dy, hw * 2, 1f, col) }
    }
    private fun tri(c: Canvas, x0: Float, y0: Float, x1: Float, y1: Float, x2: Float, y2: Float, col: Int) {
        path.reset(); path.moveTo(x0, y0); path.lineTo(x1, y1); path.lineTo(x2, y2); path.close(); sp.style = Paint.Style.FILL; sp.color = col; c.drawPath(path, sp)
    }

    // =============================================================================================
    //  drawing
    // =============================================================================================
    fun draw(c: Canvas, w: Float, h: Float) {
        val tw = (w - 32f).toInt()
        if (tw != textW) { textW = tw; cur?.let { b -> val typedAll = typed(); pages = pagesFor(b.text, textW); page = min(page, max(0, pages.size - 1)); if (typedAll) pageT0 = vt - 100000f } }
        val boxH = 42f; val sceneH = h - boxH - 8f
        val base = sceneH - 17f                                  // the wrestlers' feet
        val cx = Math.round(w / 2f).toFloat()
        val shaking = vt < shakeUntil
        val sx = if (shaking) (if ((vt / 40f).toInt() % 2 == 0) shakeAmp else -shakeAmp).toFloat() else 0f
        val sy = if (shaking) (if ((vt / 55f).toInt() % 2 == 0) 1f else -1f) else 0f
        rect(c, 0f, 0f, w, h, Color.rgb(24, 18, 36))
        c.save(); c.translate(sx, sy)
        drawHall(c, w, sceneH, base)
        drawCrowd(c, w, base)
        drawRing(c, w, sceneH, base, cx)
        drawRef(c, base, cx)
        drawWrestlers(c, base, cx)
        drawEffects(c, base, cx)
        c.restore()
        if (ended) drawConfetti(c, w, sceneH)
        drawHud(c, w, h)
        drawBanner(c, w, cx)
        drawText(c, w, h, boxH)
        if (ended) drawResult(c, w, h, cx)
    }

    private fun drawHall(c: Canvas, w: Float, sceneH: Float, base: Float) {
        rect(c, 0f, 0f, w, sceneH, Color.rgb(38, 28, 62))
        rect(c, 0f, sceneH * 0.34f, w, sceneH * 0.33f, Color.rgb(50, 34, 70))
        rect(c, 0f, sceneH * 0.67f, w, sceneH * 0.33f, Color.rgb(62, 40, 74))
        val glow = 24 + (crowdShown * 0.7f).toInt()
        tri(c, w * 0.22f, 0f, w * 0.40f, base - 6f, w * 0.60f, base - 6f, Color.argb(22, 255, 244, 200))
        tri(c, w * 0.78f, 0f, w * 0.40f, base - 6f, w * 0.60f, base - 6f, Color.argb(22, 255, 244, 200))
        // a string of paper lanterns, brighter the louder the hall
        val ly = 31f
        rect(c, 0f, ly, w, 1f, Color.rgb(24, 18, 30))
        var x = 10f; var i = 0
        while (x < w) {
            val swing = if (sin(vt / 700f + i) > 0f) 0f else 1f
            disc(c, x + 4f, ly + 11f, 11f, Color.argb(glow, 255, 190, 80))
            rect(c, x + 3f + swing, ly, 1f, 4f, Color.rgb(24, 18, 30))
            rect(c, x + 1f, ly + 4f, 7f, 2f, Color.rgb(250, 200, 80))
            rect(c, x, ly + 6f, 9f, 8f, Color.rgb(214, 54, 52)); rect(c, x, ly + 6f, 3f, 8f, Color.rgb(240, 96, 80)); rect(c, x + 8f, ly + 6f, 1f, 8f, Color.rgb(150, 30, 40))
            rect(c, x + 1f, ly + 14f, 7f, 1f, Color.rgb(250, 200, 80)); rect(c, x + 4f, ly + 15f, 1f, 3f, Color.rgb(250, 200, 80))
            x += 30f; i++
        }
        // the floor in front of the ring
        rect(c, 0f, base + 15f, w, sceneH - base - 15f + 8f, Color.rgb(46, 30, 44))
    }

    private fun drawCrowd(c: Canvas, w: Float, base: Float) {
        for (r in 0..1) {
            val y0 = base - 76f + r * 13f
            val dim = if (r == 0) 0.62f else 0.85f
            var i = 0; var x = -2f + r * 5f
            while (x < w) {
                val hs = hash(i, r)
                var y = y0
                if ((hs % 100) < crowdShown * 0.9f && ((vt / 150f).toInt() + i + r) % 2 == 0) y -= 2f
                val skin = shade(SKINS[hs % SKINS.size], dim); val hair = shade(HAIRS[(hs / 7) % HAIRS.size], dim); val shirt = shade(SHIRTS[(hs / 13) % SHIRTS.size], dim)
                rect(c, x, y + 7f, 9f, 8f, shirt)
                rect(c, x + 2f, y, 5f, 7f, skin); rect(c, x + 2f, y, 5f, 2f, hair)
                if ((hs / 31) % 5 == 0 && (hs % 100) < crowdShown) { rect(c, x - 1f, y + 2f, 2f, 6f, skin); rect(c, x + 8f, y + 2f, 2f, 6f, skin) }   // arms up
                x += 10f; i++
            }
        }
    }

    private fun drawRing(c: Canvas, w: Float, sceneH: Float, base: Float, cx: Float) {
        val half = min(w / 2f - 12f, 118f)
        val l = cx - half; val r = cx + half
        val mat = Color.rgb(196, 206, 232); val matDark = Color.rgb(176, 188, 220)
        // back ropes
        val ropes = intArrayOf(Color.rgb(244, 244, 248), Color.rgb(224, 64, 64), Color.rgb(244, 244, 248))
        for ((i, hh) in intArrayOf(20, 34, 48).withIndex()) { rect(c, l, base - hh + 1f, r - l, 2f, Color.rgb(40, 30, 50)); rect(c, l, base - hh, r - l, 2f, ropes[i]) }
        // canvas
        rect(c, l, base - 10f, r - l, 13f, mat)
        var x = l; var k = 0
        while (x < r) { if (k % 2 == 0) rect(c, x, base - 10f, min(8f, r - x), 13f, matDark); x += 8f; k++ }
        rect(c, l, base - 10f, r - l, 1f, Color.rgb(226, 232, 248)); rect(c, l, base + 2f, r - l, 1f, Color.rgb(120, 130, 168))
        // the skirt with the hall's name
        rect(c, l - 6f, base + 3f, r - l + 12f, 12f, Color.rgb(132, 34, 50)); rect(c, l - 6f, base + 3f, r - l + 12f, 1f, Color.rgb(250, 200, 80)); rect(c, l - 6f, base + 14f, r - l + 12f, 1f, Color.rgb(250, 200, 80))
        tx(c, "KJPW", cx, base + 4f, Color.rgb(250, 200, 80), 1, 1, Color.rgb(70, 16, 28))
        // corner posts and pads
        for (px in floatArrayOf(l - 3f, r - 3f)) {
            rect(c, px, base - 60f, 6f, 66f, Color.rgb(24, 18, 30)); rect(c, px + 1f, base - 60f, 4f, 66f, Color.rgb(150, 150, 168)); rect(c, px + 1f, base - 60f, 1f, 66f, Color.rgb(200, 200, 214))
            for (hh in intArrayOf(20, 34, 48)) { rect(c, px - 1f, base - hh - 3f, 8f, 7f, Color.rgb(24, 18, 30)); rect(c, px, base - hh - 2f, 6f, 5f, Color.rgb(214, 54, 52)) }
        }
    }

    private fun drawRef(c: Canvas, base: Float, cx: Float) {
        val x = Math.round(cx + refX).toFloat(); val y = base - 6f
        val slap = vt - slapAt
        rect(c, x - 4f, y - 8f, 3f, 8f, Color.rgb(24, 20, 30)); rect(c, x + 1f, y - 8f, 3f, 8f, Color.rgb(24, 20, 30))      // legs
        for (i in 0..5) rect(c, x - 5f, y - 20f + i * 2f, 10f, 2f, if (i % 2 == 0) Color.rgb(246, 246, 250) else Color.rgb(30, 28, 40))   // striped shirt
        rect(c, x - 7f, y - 19f, 2f, 8f, Color.rgb(246, 246, 250)); rect(c, x - 7f, y - 11f, 2f, 2f, Color.rgb(236, 190, 150))
        if (slap in 0f..420f) { rect(c, x + 5f, y - 19f, 2f, 3f, Color.rgb(246, 246, 250)); rect(c, x + 5f, y - 16f, 3f, 12f, Color.rgb(236, 190, 150)) }
        else { rect(c, x + 5f, y - 19f, 2f, 8f, Color.rgb(246, 246, 250)); rect(c, x + 5f, y - 11f, 2f, 2f, Color.rgb(236, 190, 150)) }
        rect(c, x - 3f, y - 28f, 6f, 8f, Color.rgb(236, 190, 150)); rect(c, x - 3f, y - 28f, 6f, 2f, Color.rgb(40, 30, 28))
        rect(c, x - 1f, y - 20f, 2f, 1f, Color.rgb(214, 54, 52))
    }

    private fun drawWrestlers(c: Canvas, base: Float, cx: Float) {
        val an = anim ?: return
        val b = cur ?: return
        val p = if (ended) 1f else ((vt - beatT0) / an.ms).coerceIn(0f, 1f)
        val s = MatchAnims.sample(an, p)
        val axis = if (an.att == 0) 1 else -1
        val order = intArrayOf(1, 0)          // B first, so A (who is doing the move) is in front
        for (side in order) {
            val who = if (side == 0) an.att else 1 - an.att
            val pz = s[side]
            val xRel = axis * ((if (side == 0) -MatchAnims.HOME else MatchAnims.HOME) + pz.dx)
            val right = pz.face * axis > 0
            var bob = 0f
            if (pz.ps == PS.IDLE && ((vt / 380f).toInt() + who) % 2 == 0) bob = -1f
            val jit = if (pz.ps == PS.HURT) (if ((vt / 50f).toInt() % 2 == 0) 1f else -1f) else 0f
            val x = Math.round(cx + xRel + jit).toFloat(); val feet = Math.round(base + pz.dy + bob).toFloat()
            // shadow on the mat
            val air = abs(min(0f, pz.dy))
            val lie = pz.ps == PS.LIE || pz.ps == PS.SIT
            ellipse(c, x, base + 1f, max(7f, (if (lie) 27f else 15f) - air / 3f), 3f, Color.argb(70, 0, 0, 0))
            val bm = sprites.frame(ws[who].look, WF.cell(pz.ps, right))
            if (bm != null) { dst.set(Math.round(x - 32f), Math.round(feet - 64f), Math.round(x + 32f), Math.round(feet)); c.drawBitmap(bm, null, dst, sp) }
        }
    }

    private fun drawEffects(c: Canvas, base: Float, cx: Float) {
        for (e in effects) {
            val t = vt - e.t0
            val x = Math.round(cx + e.x).toFloat()
            when (e.kind) {
                0, 1 -> {
                    val life = if (e.kind == 1) 380f else 260f
                    if (t > life) continue
                    val k = if (e.kind == 1) 1.6f else 1f
                    val r = (3f + t / life * 9f) * k; val y = base - e.y
                    val col = if (t < life * 0.6f) Color.WHITE else Color.rgb(250, 190, 60)
                    rect(c, x - r, y - 1f, r * 2f, 2f, col); rect(c, x - 1f, y - r, 2f, r * 2f, col)
                    val d = r * 0.7f
                    for (sgn in intArrayOf(-1, 1)) for (sgn2 in intArrayOf(-1, 1)) rect(c, x + sgn * d - 1f, y + sgn2 * d - 1f, 2f, 2f, col)
                    disc(c, x, y, r * 0.45f, Color.rgb(250, 230, 120))
                }
                2 -> if (t < 480f) {
                    val u = t / 480f; val a = (150 * (1f - u)).toInt()
                    for (j in -1..1) disc(c, x + j * (8f + u * 10f), base - 2f - u * 6f, 3f + u * 5f, Color.argb(a, 232, 222, 200))
                }
                3 -> if (t < 800f) {
                    val u = t / 800f; val y = base - e.y - u * 14f
                    tx(c, e.text, x, y, Color.WHITE, 1, 1, Color.rgb(200, 40, 40))
                }
            }
        }
    }

    private fun drawConfetti(c: Canvas, w: Float, sceneH: Float) {
        for (i in 0 until 46) {
            val hs = hash(i, 9)
            val x = (hs % w.toInt()).toFloat() + 3f * sin(vt / 400f + i)
            val y = ((vt * (0.03f + (hs % 7) * 0.006f) + hs / 3) % (sceneH + 10f)) - 5f
            rect(c, x, y, 3f, 2f, CONFETTI[hs % CONFETTI.size])
        }
    }

    private fun drawHud(c: Canvas, w: Float, h: Float) {
        val b = cur
        val pw = min(124f, (w - 12f) / 2f)
        for (i in 0..1) {
            val x = if (i == 0) 4f else w - 4f - pw; val y = 3f
            Ui.darkBox(c, x, y, pw, 26f)
            val name = ws[i].name
            if (i == 0) tx(c, name, x + 7f, y + 4f, Ui.WHITE_INK, 0, 1, Ui.WHITE_SHADOW) else tx(c, name, x + pw - 7f, y + 4f, Ui.WHITE_INK, 2, 1, Ui.WHITE_SHADOW)
            Ui.hpBar(c, x + 7f, y + 14f, pw - 14f, shownHp[i] / ws[i].maxHp)
            Ui.xpBar(c, x + 7f, y + 21f, pw - 14f, shownSp[i] / 100f)
        }
        // the hall's noise as lit lanterns, and the speed
        val mid = w / 2f
        if (w - 2f * pw - 8f >= 30f) {
            val lit = Math.ceil(crowdShown / 20.0).toInt().coerceIn(0, 5)
            for (k in 0 until 5) {
                val lx = mid - 15f + k * 6f
                if (k < lit) { rect(c, lx, 6f, 5f, 6f, Color.rgb(224, 64, 56)); rect(c, lx, 5f, 5f, 1f, Color.rgb(250, 200, 80)); rect(c, lx + 1f, 12f, 3f, 1f, Color.rgb(250, 200, 80)) }
                else { rect(c, lx, 6f, 5f, 6f, Color.rgb(70, 62, 88)); rect(c, lx, 5f, 5f, 1f, Color.rgb(100, 92, 120)) }
            }
            tx(c, if (speed == 1) "x1" else "x$speed", mid, 15f, Ui.GOLD, 1, 1, Color.rgb(24, 24, 40))
        }
        val elapsed = lastNow - t0Real
        val msg = if (lastNow < leaveUntil) "Press BACK again to leave" else if (elapsed < 5000L) "OK skip   LEFT/RIGHT speed   BACK leave" else ""
        if (msg.isNotEmpty() && b != null) {
            val bw = PixelFont.width(msg) + 14f
            Ui.darkBox(c, mid - bw / 2f, 32f, bw, 15f)
            tx(c, msg, mid, 35f, Ui.WHITE_INK, 1, 1, Ui.WHITE_SHADOW)
        }
    }

    private fun drawBanner(c: Canvas, w: Float, cx: Float) {
        val t = vt - bannerAt
        if (t < 0f || t > 1000f || banner.isEmpty()) return
        val scale = if (bannerBig) 2 else 1
        val tw = PixelFont.width(banner, scale) + 22f; val th = if (bannerBig) 24f else 16f
        val a = if (t < 120f) t / 120f else if (t > 850f) (1000f - t) / 150f else 1f
        val y = 50f - (1f - a) * 6f
        if (a < 0.3f) return
        Ui.darkBox(c, cx - tw / 2f, y, tw, th)
        tx(c, banner, cx, y + (if (bannerBig) 6f else 4f), Ui.GOLD, 1, scale, Color.rgb(24, 24, 40))
    }

    private fun drawText(c: Canvas, w: Float, h: Float, boxH: Float) {
        val bx = 4f; val bw = w - 8f; val by = h - boxH - 4f
        Ui.textBox(c, bx, by, bw, boxH, ring = 2, grip = true)
        val b = cur ?: return
        val pg = pages.getOrNull(page) ?: return
        var shown = ((vt - pageT0) / 22f).toInt()
        for ((i, line) in pg.withIndex()) {
            val n = min(line.length, max(0, shown)); shown -= line.length
            tx(c, line.substring(0, n), bx + 12f, by + 9f + i * 15f)
        }
        if (typed() && !ended) Ui.moreArrow(c, bx + bw - 16f, by + boxH - 12f, if ((lastNow / 280L) % 2L == 0L) 0 else 1)
    }

    private fun drawResult(c: Canvas, w: Float, h: Float, cx: Float) {
        val pw = min(w - 24f, 190f); val x = cx - pw / 2f; val y = 40f
        val lines = PixelFont.wrap(if (how.isEmpty()) "What a match!" else "by $how", (pw - 24f).toInt())
        val ph = 36f + lines.size * 12f
        Ui.darkBox(c, x, y, pw, ph)
        tx(c, if (winnerName.isEmpty()) "THE END" else "WINNER", cx, y + 6f, Ui.GOLD, 1, 2, Color.rgb(24, 24, 40))
        tx(c, winnerName, cx, y + 24f, Ui.WHITE_INK, 1, 1, Ui.WHITE_SHADOW)
        for ((i, l) in lines.withIndex()) tx(c, l, cx, y + 36f + i * 12f, Color.rgb(200, 210, 240), 1, 1, Color.rgb(24, 24, 40))
        if ((lastNow / 500L) % 2L == 0L) tx(c, "OK", cx, y + ph - 11f, Ui.GOLD, 1, 1, Color.rgb(24, 24, 40))
    }
}
