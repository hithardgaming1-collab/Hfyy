package com.example.critterquest

// ---------------------------------------------------------------------------------------------
// KJPW: the finishers. One signature move per wrestler, all invented for this game. A finisher hits harder
// than anything else, costs a lot of spirit, and is only tried when the other wrestler is worn down (see Bout.kt).
// ---------------------------------------------------------------------------------------------

private fun f(n: String, k: WKind, a: WAnim, p: Int, nd: WNeed, line: String) = WMove(n, k, a, p, 10, nd, line, finisher = true)

val FINISHERS: List<WMove> = listOf(
    f("Harbor Hoist", WKind.SLAM, WAnim.BOMB, 10, WNeed.STAND, "{A} hauls {B} up like a crate off the dock... HARBOR HOIST!"),
    f("Tide Turner", WKind.AIR, WAnim.DIVE, 9, WNeed.DOWN, "{A} springs off the ropes and the tide turns... TIDE TURNER!"),
    f("Hot Sauce Haymaker", WKind.STRIKE, WAnim.STRIKE, 10, WNeed.STAND, "{A} turns up the heat... HOT SAUCE HAYMAKER!"),
    f("Last Orders", WKind.HOLD, WAnim.HOLD, 9, WNeed.DOWN, "{A} calls time and locks in LAST ORDERS!"),
    f("Falling Star", WKind.AIR, WAnim.DIVE, 10, WNeed.DOWN, "{A} soars off the top rope... FALLING STAR!"),
    f("Mountain Drop", WKind.SLAM, WAnim.SLAM, 10, WNeed.STAND, "{A} lifts {B} to the rafters... MOUNTAIN DROP!"),
    f("Ember Kick", WKind.KICK, WAnim.KICK, 9, WNeed.STAND, "{A}'s boot glows like an ember... EMBER KICK!"),
    f("Doctor's Orders", WKind.HOLD, WAnim.HOLD, 9, WNeed.DOWN, "{A} writes the prescription: DOCTOR'S ORDERS!"),
    f("Moss Wrap", WKind.HOLD, WAnim.HOLD, 9, WNeed.DOWN, "{A} wraps {B} up like creeping vines... MOSS WRAP!"),
    f("Salt Splash", WKind.GROUND, WAnim.DROP, 10, WNeed.DOWN, "{A} tosses the salt, leaps... SALT SPLASH!"),
    f("Iron Gavel", WKind.SLAM, WAnim.SLAM, 10, WNeed.STAND, "{A} raises {B} high and brings down the IRON GAVEL!"),
    f("Full Steam", WKind.RUN, WAnim.RUN, 10, WNeed.STAND, "{A} builds up a head of steam... FULL STEAM!"),
    f("Lotus Drop", WKind.AIR, WAnim.DIVE, 9, WNeed.DOWN, "{A} blooms off the top rope... LOTUS DROP!"),
    f("Tiger Pounce", WKind.AIR, WAnim.DIVE, 9, WNeed.STAND, "{A} crouches, springs and POUNCES on {B}!"),
    f("Midnight Hush", WKind.HOLD, WAnim.HOLD, 9, WNeed.STAND, "{A} whispers goodnight... MIDNIGHT HUSH!"),
    f("Rockslide", WKind.SLAM, WAnim.BOMB, 10, WNeed.STAND, "{A} lifts {B} and the whole hill comes down... ROCKSLIDE!"),
    f("The Encore", WKind.SPIKE, WAnim.SPIKE, 9, WNeed.STAND, "{A} takes a bow, then drives {B}'s head down... THE ENCORE!"),
    f("Leaf Cutter", WKind.STRIKE, WAnim.STRIKE, 9, WNeed.STAND, "{A} slices the air with a chop... LEAF CUTTER!"),
    f("Sandstorm Suplex", WKind.SUPLEX, WAnim.SUPLEX, 10, WNeed.STAND, "{A} whirls {B} up in a SANDSTORM SUPLEX!"),
    f("Cold Snap", WKind.HOLD, WAnim.HOLD, 9, WNeed.DOWN, "{A} freezes {B}'s ankle in place... COLD SNAP!"),
    f("Thunderclap", WKind.STRIKE, WAnim.STRIKE, 10, WNeed.STAND, "{A} claps both hands together... THUNDERCLAP!"),
    f("Lucky Punch", WKind.STRIKE, WAnim.STRIKE, 9, WNeed.STAND, "{A} shuts {his} eyes and swings... LUCKY PUNCH!"),
    f("Bear Squeeze", WKind.HOLD, WAnim.HOLD, 9, WNeed.STAND, "{A} wraps both arms round {B}... BEAR SQUEEZE!"),
    f("Royal Splash", WKind.AIR, WAnim.DIVE, 10, WNeed.DOWN, "{A} straightens the crown and leaps... ROYAL SPLASH!")
)

/** Every move in the hall, basics and finishers. */
val WMOVES: List<WMove> = BASIC_MOVES + FINISHERS

private val WMOVE_BY_NAME: Map<String, WMove> = WMOVES.associateBy { it.name }

fun wmoveOrNull(name: String): WMove? = WMOVE_BY_NAME[name]
fun wmove(name: String): WMove = WMOVE_BY_NAME[name] ?: error("unknown wrestling move: $name")
