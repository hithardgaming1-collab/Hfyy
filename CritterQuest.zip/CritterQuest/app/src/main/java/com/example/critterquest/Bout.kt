package com.example.critterquest

import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

// ---------------------------------------------------------------------------------------------
// KJPW: the bout engine. No pictures and no Android in here: [Bout] plays one match between two wrestlers and
// hands out the story one [Beat] at a time (a move, a reversal, a cover, a kick-out, a tap...). The match screen
// (MatchView.kt) draws each beat; tools/story_check/ArenaCheck.kt plays thousands of bouts to prove they all finish.
// The same seed always plays the same match.
// ---------------------------------------------------------------------------------------------

enum class WPos { STAND, DOWN }

enum class BeatKind { INTRO, BELL, MOVE, COUNTER, MISS, TAUNT, GETUP, COVER, COUNT, KICKOUT, HOLD, ESCAPE, TAP, WIN }

/** One step of the show. [who] is the wrestler doing it (0 or 1; -1 = the whole hall). hp / sp / pos are the numbers AFTER it. */
class Beat(
    val kind: BeatKind, val who: Int, val move: WMove?, val text: String,
    val hp: IntArray, val sp: IntArray, val pos: Array<WPos>,
    val hit: Boolean = true, val dmg: Int = 0, val n: Int = 0, val crowd: Int = 0, val knock: Boolean = false
)

const val MAX_BEATS = 140

class Bout(val a: Wrestler, val b: Wrestler, seed: Int = Random.nextInt()) {
    private val rnd = Random(seed)
    val w: Array<Wrestler> = arrayOf(a, b)
    val hp = intArrayOf(a.maxHp, b.maxHp)
    val sp = intArrayOf(70, 70)                       // spirit: spent by moves, needed for finishers and kick-outs
    val pos = arrayOf(WPos.STAND, WPos.STAND)
    var crowd = 20                                    // 0..100: how loud the hall is
    private var momentum = 0                          // -3..3, above 0 = wrestler 0 has the upper hand
    var over = false; private set
    var winner = -1; private set
    var how = ""; private set
    var beats = 0; private set
    private val queue = ArrayDeque<Beat>()
    private var started = false
    private val warned = Array(2) { BooleanArray(2) }  // "is hurting" / "can barely stand" said already

    fun frac(i: Int) = hp[i].toDouble() / w[i].maxHp

    /** True once the match is over and every beat has been handed out, so the beat [next] just returned was the last one. */
    val drained: Boolean get() = over && queue.isEmpty()

    /** The next beat of the match, or null when the match is over and everything has been told. */
    fun next(): Beat? {
        var guard = 0
        while (queue.isEmpty() && !over && guard++ < 50) step()
        return queue.removeFirstOrNull()
    }

    // ---- helpers
    private fun say(s: String, att: Int): String {
        val x = w[att]; val y = w[1 - att]
        return s.replace("{A}", x.name).replace("{B}", y.name).replace("{his}", x.his).replace("{him}", y.him).replace("{he}", y.he).replace("{self}", x.self)
    }
    private fun add(kind: BeatKind, who: Int, mv: WMove?, text: String, hit: Boolean = true, dmg: Int = 0, n: Int = 0, knock: Boolean = false) {
        crowd = crowd.coerceIn(0, 100)
        queue.add(Beat(kind, who, mv, text, hp.copyOf(), sp.copyOf(), pos.copyOf(), hit, dmg, n, crowd, knock))
    }
    private fun pick(vararg s: String) = s[rnd.nextInt(s.size)]
    private fun shift(toward: Int, by: Int = 1) { momentum = (momentum + if (toward == 0) by else -by).coerceIn(-3, 3) }

    // ---- the show
    private fun step() {
        beats++
        if (!started) { started = true; intro(); return }
        if (beats > MAX_BEATS) { forceEnd(); return }
        for (i in 0..1) sp[i] = min(100, sp[i] + 2 + w[i].sta / 4)
        val d0 = pos[0] == WPos.DOWN; val d1 = pos[1] == WPos.DOWN
        when {
            d0 && d1 -> getUp(if (w[0].spd + rnd.nextInt(4) >= w[1].spd + rnd.nextInt(4)) 0 else 1)
            d0 -> if (rnd.nextDouble() < riseChance(0)) getUp(0) else attack(1, 0)
            d1 -> if (rnd.nextDouble() < riseChance(1)) getUp(1) else attack(0, 1)
            else -> {   // who moves first: the quicker wrestler more often, never always, and whoever has the upper hand
                val p0 = (0.5 + (w[0].spd - w[1].spd) * 0.025 + momentum * 0.04).coerceIn(0.25, 0.75)
                val i = if (rnd.nextDouble() < p0) 0 else 1
                attack(i, 1 - i)
            }
        }
    }

    private fun intro() {
        add(BeatKind.INTRO, 0, null, a.entrance)
        add(BeatKind.INTRO, 1, null, b.entrance)
        add(BeatKind.BELL, -1, null, "DING DING DING! ${a.name} against ${b.name}! Let the bout begin!")
    }

    private fun riseChance(i: Int) = (0.30 + w[i].sta * 0.03 + sp[i] / 400.0 - (1 - frac(i)) * 0.15).coerceIn(0.15, 0.7)

    private fun getUp(i: Int) {
        pos[i] = WPos.STAND; sp[i] = max(0, sp[i] - 3)
        add(BeatKind.GETUP, i, null, pick("${w[i].name} staggers back to ${w[i].his} feet!", "${w[i].name} drags ${w[i].self} up off the mat!", "${w[i].name} is up! The crowd roars!"))
    }

    // ---- choosing a move
    private fun weight(att: Int, def: Int, m: WMove): Double {
        val x = w[att]
        var v = 1.0
        v *= when (x.style) {
            WStyle.POWER, WStyle.GIANT -> when (m.kind) { WKind.SLAM -> 2.0; WKind.SUPLEX -> 1.3; WKind.STRIKE -> 1.2; else -> 1.0 }
            WStyle.FLYER -> when (m.kind) { WKind.AIR -> 2.2; WKind.KICK -> 1.4; WKind.RUN -> 1.2; else -> 1.0 }
            WStyle.TECH -> when (m.kind) { WKind.HOLD -> 2.2; WKind.SUPLEX -> 1.2; else -> 1.0 }
            WStyle.BRAWL -> when (m.kind) { WKind.STRIKE -> 1.8; WKind.RUN -> 1.4; WKind.KICK -> 1.2; else -> 1.0 }
            WStyle.GRAPPLE -> when (m.kind) { WKind.SUPLEX -> 2.0; WKind.HOLD -> 1.5; WKind.SLAM -> 1.3; else -> 1.0 }
            WStyle.SHOWMAN -> when (m.kind) { WKind.TAUNT -> 2.0; WKind.SPIKE -> 1.3; else -> 1.0 }
            WStyle.ROOKIE -> 1.0
        }
        if (m.kind == WKind.TAUNT) v *= 0.35 + x.charm / 20.0
        else v *= if (frac(def) > 0.6) 1.4 - m.power * 0.08 else 0.6 + m.power * 0.1       // light moves early, heavy ones late
        if (m.cost > sp[att]) v *= 0.1
        return max(v, 0.02)
    }

    private fun choose(att: Int, def: Int): WMove {
        val x = w[att]
        val downed = pos[def] == WPos.DOWN
        val need = if (downed) WNeed.DOWN else WNeed.STAND
        val f = x.fin
        if (f.needs == need && sp[att] >= 30) {
            val fr = frac(def)
            if ((fr < 0.6 && rnd.nextDouble() < 0.30) || (fr < 0.35 && rnd.nextDouble() < 0.80)) return f
        }
        var pool = x.kit.filter { it.needs == need }
        if (pool.isEmpty()) pool = (if (downed) listOf("Stomp", "Elbow Drop", "Knee Drop") else listOf("Jab", "Low Kick", "Hip Toss", "Headlock")).map { wmove(it) }
        val ws = pool.map { weight(att, def, it) }
        var r = rnd.nextDouble() * ws.sum()
        for ((i, m) in pool.withIndex()) { r -= ws[i]; if (r <= 0) return m }
        return pool.last()
    }

    // ---- attacks
    private fun attack(att: Int, def: Int) {
        val mv = choose(att, def)
        if (mv.kind == WKind.TAUNT) {
            crowd += 4 + w[att].charm; sp[att] = min(100, sp[att] + 6); shift(att)
            add(BeatKind.TAUNT, att, mv, say(mv.line, att) + " " + pick("The crowd eats it up!", "Nice showmanship!", "The fans love it!"))
            return
        }
        sp[att] = max(0, sp[att] - mv.cost)
        if (mv.needs == WNeed.STAND) {
            if (rnd.nextDouble() < counterChance(att, def, mv)) { counter(att, def, mv); return }
            if (rnd.nextDouble() < missChance(att, def, mv)) {
                shift(def)
                add(BeatKind.MISS, att, mv, say(mv.line, att) + " " + say(pick("{B} ducks under it!", "{B} sidesteps it!", "{B} slips away at the last second!"), att), hit = false)
                return
            }
        }
        land(att, def, mv, null)
    }

    private fun counterChance(att: Int, def: Int, m: WMove): Double {
        val base = when (m.kind) { WKind.SLAM, WKind.SUPLEX, WKind.SPIKE -> 0.10; WKind.HOLD -> 0.08; WKind.STRIKE, WKind.KICK -> 0.05; else -> 0.07 }
        return (base + (w[def].tech - w[att].tech) * 0.015 + (w[def].spd - w[att].spd) * 0.008 - if (m.finisher) 0.03 else 0.0).coerceIn(0.02, 0.30)
    }
    private fun missChance(att: Int, def: Int, m: WMove): Double {
        val base = when (m.kind) { WKind.STRIKE, WKind.KICK -> 0.10; WKind.RUN, WKind.AIR -> 0.15; else -> 0.05 }
        return (base + (w[def].spd - w[att].spd) * 0.02 - if (m.finisher) 0.04 else 0.0).coerceIn(0.02, 0.40)
    }

    private fun counter(att: Int, def: Int, mv: WMove) {
        val kit = w[def].kit.filter { it.needs == WNeed.STAND && it.kind != WKind.TAUNT && it.kind != WKind.HOLD && !it.finisher && it.power <= 6 }
        val cm = if (kit.isEmpty()) wmove("Hip Toss") else kit[rnd.nextInt(kit.size)]
        crowd += 6
        land(def, att, cm, say("{B} sees it coming and REVERSES it!", att))
    }

    private fun damage(att: Int, def: Int, m: WMove): Int {
        val base = m.power * 1.9 + 2
        val pf = 0.75 + w[att].pow * 0.05
        val tf = 1.15 - w[def].tough * 0.035
        return (base * pf * tf * (1 + crowd / 400.0) * (0.85 + rnd.nextDouble() * 0.3)).toInt().coerceAtLeast(1)
    }

    private fun knocks(def: Int, m: WMove, dmg: Int): Boolean {
        if (m.needs == WNeed.DOWN) return false
        if (m.finisher || m.kind == WKind.SLAM || m.kind == WKind.SUPLEX || m.kind == WKind.SPIKE || m.kind == WKind.AIR) return true
        val ch = (if (m.kind == WKind.RUN) 0.25 else 0.12) + m.power * 0.05 + (if (frac(def) < 0.3) 0.25 else 0.0) - w[def].tough * 0.015
        return rnd.nextDouble() < ch
    }

    /** [att] connects with [m] on [def]. [lead] is a line to say first (a reversal). */
    private fun land(att: Int, def: Int, m: WMove, lead: String?) {
        if (m.kind == WKind.HOLD) { hold(att, def, m, lead); return }
        val dmg = damage(att, def, m)
        hp[def] = max(0, hp[def] - dmg)
        crowd += m.power; shift(att)
        val down = pos[def] == WPos.DOWN || knocks(def, m, dmg)
        if (down) pos[def] = WPos.DOWN
        val knockedNow = down && m.needs == WNeed.STAND
        val react = if (knockedNow) pick("{B} crashes to the mat!", "{B} is down!", "The whole ring shakes!", "{B} lies there, dazed!")
                    else pick("{B} staggers!", "{B} reels from the blow!", "That hurt {B}!", "{B} winces!")
        var text = (if (lead != null) "$lead " else "") + say(m.line, att) + " " + say(react, att)
        text += warning(def, att)
        add(if (lead != null) BeatKind.COUNTER else BeatKind.MOVE, att, m, text, dmg = dmg, knock = knockedNow)
        if (hp[def] <= 0) { pos[def] = WPos.DOWN; cover(att, def, m, true); return }
        if (pos[def] == WPos.DOWN) {
            val p = (0.04 + 0.85 * (1 - frac(def)) + m.power * 0.02).coerceIn(0.0, 0.95)   // covers get likelier as the other one wears down
            if (rnd.nextDouble() < p) cover(att, def, m, false)
        }
    }

    private fun warning(def: Int, att: Int): String {
        val f = frac(def)
        if (f < 0.25 && !warned[def][1]) { warned[def][1] = true; return " " + say("{B} can barely stand... the end may be near!", att) }
        if (f < 0.5 && !warned[def][0]) { warned[def][0] = true; return " " + say("{B} is starting to hurt!", att) }
        return ""
    }

    // ---- pins
    private fun cover(att: Int, def: Int, m: WMove, ko: Boolean) {
        val d = w[def]
        // chance that the three count is reached: tiny while he is fresh, big when he is beaten up
        val win = Math.pow(1 - frac(def), 1.6) * 1.05 + m.power * 0.012 - d.sta * 0.008 - sp[def] / 100.0 * 0.06 + (if (m.finisher) 0.12 else 0.0)
        val p = if (ko) 0.04 else (1 - win).coerceIn(0.03, 0.97)
        val kickAt = if (rnd.nextDouble() < p) pick1(1, 2, 2, 2, 3) else 0
        add(BeatKind.COVER, att, null, say("{A} hooks the leg and covers {B}! ONE!", att), n = 1)
        if (kickAt == 1) { kickOut(att, def, 1); return }
        add(BeatKind.COUNT, att, null, "TWO!", n = 2)
        if (kickAt > 0) { kickOut(att, def, kickAt); return }
        over = true; winner = att; how = "pinfall with the ${m.name}"
        crowd += 20
        add(BeatKind.WIN, att, m, say("THREE! {A} wins by pinfall with the ${m.name}!", att), n = 3)
    }
    private fun pick1(vararg v: Int) = v[rnd.nextInt(v.size)]

    private fun kickOut(att: Int, def: Int, at: Int) {
        sp[def] = max(0, sp[def] - 8); crowd += 8; shift(def, 1)
        val t = if (at == 3) "{B} kicks out at the very last second!!" else "{B} kicks out at ${if (at == 1) "ONE" else "TWO"}!"
        add(BeatKind.KICKOUT, def, null, say(t, att), n = at)
    }

    // ---- holds
    private fun hold(att: Int, def: Int, m: WMove, lead: String?) {
        val x = w[att]; val y = w[def]
        val first = max(1, damage(att, def, m) / 2)
        hp[def] = max(0, hp[def] - first)
        crowd += m.power; shift(att)
        if (m.needs == WNeed.STAND) pos[def] = WPos.STAND
        add(BeatKind.HOLD, att, m, (if (lead != null) "$lead " else "") + say(m.line, att) + " " + say("{B} is trapped!", att) + warning(def, att), dmg = first, n = 1)
        for (round in 1..3) {
            var tap = 0.02 + 0.65 * Math.pow(1 - frac(def), 1.2) + m.power * 0.015 + (x.tech - y.tech) * 0.02 - y.tough * 0.01
            if (hp[def] <= 0) tap += 0.4
            val esc = (0.18 + y.spd * 0.03 + y.sta * 0.01).coerceIn(0.1, 0.6)
            if (round == 3) { if (frac(def) < 0.45) tap = 1.0 else { breakHold(att, def, m, round); return } }
            if (rnd.nextDouble() < tap.coerceIn(0.03, 1.0)) {
                over = true; winner = att; how = "submission to the ${m.name}"; crowd += 20
                add(BeatKind.TAP, def, m, say("{B} TAPS OUT! {A} wins by submission with the ${m.name}!", att), n = round)
                return
            }
            if (rnd.nextDouble() < esc) { breakHold(att, def, m, round); return }
            val more = max(1, damage(att, def, m) / 3)
            hp[def] = max(0, hp[def] - more)
            add(BeatKind.HOLD, att, m, say(pick("{A} cranks it tighter! {B} is in agony!", "{B} cries out! Will {he} tap?", "The ref asks {B} if {he} wants to give up!"), att), dmg = more, n = round + 1)
        }
    }

    private fun breakHold(att: Int, def: Int, m: WMove, round: Int) {
        pos[def] = WPos.DOWN; sp[def] = max(0, sp[def] - 4); crowd += 6; shift(def)
        add(BeatKind.ESCAPE, def, m, say(pick("{A} drags {self} to the ropes! The hold is broken!", "{A} wriggles free!", "{A} reaches the ropes just in time!"), def), n = round)
    }

    private fun forceEnd() {
        val loser = if (hp[0] <= hp[1]) 0 else 1
        val win = 1 - loser
        over = true; winner = win; how = "the referee stopping the contest"
        pos[loser] = WPos.DOWN
        add(BeatKind.WIN, win, null, say("The referee stops the contest! ${w[win].name} wins, with {B} unable to continue!", win))
    }
}
