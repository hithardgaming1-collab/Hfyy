package com.example.critterquest

import android.graphics.Color

// ---------------------------------------------------------------------------------------------
// KJPW's three maps (same ASCII-art format as Maps.kt; Maps.kt adds them to MAPS):
//   plaza  KJPW Plaza: the hall's front door, the ticket machine, the road back to Mossbrook (west edge of Mossbrook)
//   hall   the hallway: wrestler posters on the wall, wrestlers chatting backstage, the usher at the arena doors
//   arena  the arena: bleachers, the ring, the announcer who puts on the bouts (watch only)
// New tiles:  M ring   S bleacher seats   N lantern post   O wrestler poster (its note is made by posterNotes)
// ---------------------------------------------------------------------------------------------

private val LANTERN = Color.rgb(250, 190, 80)

private const val PLAZA_ART = """
########################
#.....^^^^^^^^^^^......#
#.*...^^^^^^^^^^^....*.#
#.....hhhhhhhhhhh......#
#.....hhhhhhhhhhh......#
#....NhhhhhDhhhhhN.....#
#*.....,,s,,,,,,.......#
#......,,N,,,N,,..*....#
#,,,,,,,,,,,,,,,,,,,,,,,
#,,,,,,,,,,,,,,,,,,,,,,,
#......................#
#.*.......*.......*..*.#
########################
"""

private const val HALL_ART = """
WWWWWWWWWWWWWWWWWWWWWW
WWOWWWWOWWWWOWWWOWWOWW
WN___________________W
W_rrrrrrrrrrrrrrrrrr_D
W_rrrrrrrrrrrrrrrrrr_W
WN__________________NW
WWWDWWWWWWWWWWWWWWWWWW
"""

private const val ARENA_ART = """
WWWWWWWWWWWWWWWWWWWWWWWWW
WSSSSSSSSSSSSSSSSSSSSSSSW
WSSSSSSSSSSSSSSSSSSSSSSSW
WSSN_________________NSSW
WSS_____MMMMMMMMM_____SSW
WSS_____MMMMMMMMM_____SSW
WSS_____MMMMMMMMM_____SSW
WSS_____MMMMMMMMM_____SSW
WSS_____MMMMMMMMM_____SSW
WSS___________________SSW
W_______________________W
W__________rrr__________W
W__________rrr__T_______W
W_________NrrrN_________W
WWWWWWWWWWWWDWWWWWWWWWWWW
"""

val ARENA_MAP_LIST: List<GameMap> = listOf(
    GameMap("plaza", "KJPW Plaza", Theme.MEADOW, LANTERN, PLAZA_ART,
        warps = listOf(
            Warp(23, 8, 23, 9, "mossbrook", 1, 7),
            Warp(11, 5, 11, 5, "hall", 3, 5, UP),
        ),
        notes = mapOf(
            (9 to 6) to "KJPW  -  Pro wrestling, every night! Buy a ticket at the machine, then go on in.",
        )),
    GameMap("hall", "KJPW Hall", Theme.INDOOR, LANTERN, HALL_ART,
        warps = listOf(
            Warp(3, 6, 3, 6, "plaza", 11, 6, DOWN),
            Warp(21, 3, 21, 3, "arena", 12, 13, UP, need = { f(PASS_FLAG) },
                deny = "The arena doors are closed. Show a ticket to the usher first."),
        ),
        notes = posterNotes(HALL_ART)),
    GameMap("arena", "KJPW Arena", Theme.INDOOR, LANTERN, ARENA_ART,
        warps = listOf(
            Warp(12, 14, 12, 14, "hall", 20, 3, LEFT),
        )),
)
