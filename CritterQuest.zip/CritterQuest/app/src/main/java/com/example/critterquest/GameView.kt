package com.example.critterquest

import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import kotlin.math.*

// ---- the picture is small, like the old handhelds ----
/** The game is drawn about this many pixels tall (a classic handheld screen is 160) and zoomed up by a whole number. */
private const val TARGET_H = 160
/** The size of one map tile in game pixels. */
private const val TS = 16
/** Redraw at most every FRAME_MS (about 30 fps). Movement and animation use the clock, so this only saves work. */
private const val FRAME_MS = 33L
/** Turning on the spot before walking takes this long (ms). */
private const val TURN_MS = 110L

/**
 * Draws the game and turns remote / gamepad / touch input into actions.
 * Game rules live in Game.kt and Battle.kt, the world in Maps.kt, the story in Story.kt and Cast.kt.
 */
class GameView(ctx: Context) : View(ctx) {
    private val p = Paint().apply { isAntiAlias = false; isDither = false }
    private val path = Path()
    private val bmps = HashMap<Int, Bitmap?>()
    private val spritePaint = Paint().apply { isAntiAlias = false; isFilterBitmap = false; isDither = false }
    private val srcR = Rect()
    private val dstR = RectF()
    private val art = Art(p, Sprites { id -> bmp(id) })
    private val life = Life()
    private val show = DEX.map { Mon(it, 5) }
    private val prefs = ctx.getSharedPreferences("critterquest", Context.MODE_PRIVATE)

    // Everything is drawn into a small bitmap (lw x lh, "logical" pixels) and that is zoomed to the screen by a whole number.
    // All draw code and all touch boxes work in logical pixels. Two bitmaps take turns so one is never drawn while it is shown.
    private var viewW = 0; private var viewH = 0
    private var lw = 0; private var lh = 0
    private var zoom = 1; private var offX = 0; private var offY = 0
    private val frames = arrayOfNulls<Bitmap>(2)
    private val frameCanvases = arrayOfNulls<Canvas>(2)
    private var flip = 0
    private val blitPaint = Paint().apply { isAntiAlias = false; isDither = false }
    private val blitDst = Rect()

    // The map is drawn once into `layer`; only animated ("live") tiles are redrawn each frame (see Art.isLive).
    private var layer: Bitmap? = null
    private var layerMap: GameMap? = null
    private var layerTs = 0
    private var liveX = IntArray(0); private var liveY = IntArray(0); private var liveGrass = BooleanArray(0); private var liveN = 0
    private val grassPics = arrayOfNulls<Bitmap>(Theme.values().size * 3 * GRASS_STEPS)
    private var grassTs = 0
    private val seen = ArrayList<Npc>()
    private var lastBattleTick = 0L

    private val TITLE = 0; private val WORLD = 1; private val BATTLE = 2; private val CREDITS = 3
    private var scene = TITLE
    private var game = Game().also { it.npcMotion = true }
    private var battle: Battle? = null
    private var hasSave = prefs.contains("save")
    private var titleSel = 0
    private var held = -1
    private var turnUntil = 0L
    private var lastMapId = ""
    private var fadeAt = 0L
    private var flashAt = 0L
    private var battleLast = 0L
    private var pauseSel = -1
    private var journal = false
    private var toast = ""; private var toastAt = 0L
    private var touchMode = false
    private var runToggle = false // run is a lock: one press of a run button turns it on, the next press turns it off
    private var msgText = ""; private var msgT0 = 0L
    private var padPointer = -1; private var padDir = -1
    private var creditsT0 = 0L
    private val boxes = ArrayList<Pair<RectF, () -> Unit>>()

    // dialogue box state
    private var dlgFor: Step? = null
    private var dlgPages: List<List<String>> = emptyList()
    private var dlgPage = 0
    private var dlgT0 = 0L
    private var askSel = 0

    init { isFocusable = true; isFocusableInTouchMode = true; requestFocus() }

    private fun now() = SystemClock.uptimeMillis()

    private fun fresh(): Game = Game().also { g -> g.npcMotion = true; g.saveHook = { s -> prefs.edit().putString("save", s).apply(); hasSave = true } }

    // =============================================================================================
    //  update
    // =============================================================================================
    private fun update() {
        val t = now()
        when (scene) {
            WORLD -> updateWorld(t)
            BATTLE -> updateBattle(t)
        }
    }

    private fun updateWorld(t: Long) {
        game.tick(t)
        game.wantRun = runToggle
        life.update(game, t)
        if (game.cur != null) held = -1
        if (game.cur !== dlgFor) buildDialogue(game.cur, t)
        if (game.battleReq != null) { startBattle(t); return }
        if (game.map.id != lastMapId) { lastMapId = game.map.id; fadeAt = t }
        if (game.endingPending && game.scriptDone) { startCredits(t); return }
        if (held >= 0 && pauseSel < 0 && !journal && t >= turnUntil) {
            // Standing still and pressing a new direction only turns you (a short beat); keep holding to walk.
            // While already walking, a direction change takes effect at the next tile with no pause.
            val standing = t - game.moveT0 > game.stepMs + 70
            if (held != game.face && standing && game.idle(t)) { game.face = held; turnUntil = t + TURN_MS }
            else game.step(held, t)
        }
    }

    private fun startBattle(t: Long) {
        val req = game.battleReq ?: return
        val team = if (req.trainer != null) req.trainer.team(game).map { Mon(DEX[it.first], it.second) } else listOf(req.wild!!)
        (game.party + team).forEach { it.shown = it.hp.toFloat(); bmp(it.s.front); bmp(it.s.back) } // load sprites now, not mid-fight
        lastBattleTick = t
        battle = Battle(game.party, team, req.trainer, game.heals, game.orbs, { now() })
        scene = BATTLE; battleLast = t; flashAt = t; held = -1
    }

    private fun updateBattle(t: Long) {
        val b = battle ?: return
        val dt = (t - lastBattleTick).coerceIn(1L, 100L); lastBattleTick = t
        val k = 1f - 0.92f.pow(dt / 16.667f) // 0.08 per frame at 60 fps, the same speed at any frame rate
        for (m in b.party) m.shown += (m.hp - m.shown) * k
        for (m in b.team) m.shown += (m.hp - m.shown) * k
        if (b.over != 0) { if (t - battleLast >= 1000) endBattle(t, b); return }
        if (b.menuOn || t - battleLast < 1000) return
        b.pump(); battleLast = t
    }

    private fun endBattle(t: Long, b: Battle) {
        game.heals = b.heals; game.orbs = b.orbs
        battle = null; scene = WORLD; held = -1; fadeAt = t
        game.battleDone(b.over, b.caught)
    }

    private fun startCredits(t: Long) { scene = CREDITS; creditsT0 = t; held = -1 }

    // =============================================================================================
    //  input
    // =============================================================================================
    private fun mapKey(k: Int): Int = when (k) {
        KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_S -> DOWN
        KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_A -> LEFT
        KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_D -> RIGHT
        KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_W -> UP
        KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER, KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_SPACE -> 4
        KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_BUTTON_B, KeyEvent.KEYCODE_ESCAPE, KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_BUTTON_START -> 5
        // run on / off (one press each): TV remote number keys 0-9; gamepad X / Y; keyboard X / Z / J / K
        KeyEvent.KEYCODE_0, KeyEvent.KEYCODE_1, KeyEvent.KEYCODE_2, KeyEvent.KEYCODE_3, KeyEvent.KEYCODE_4,
        KeyEvent.KEYCODE_5, KeyEvent.KEYCODE_6, KeyEvent.KEYCODE_7, KeyEvent.KEYCODE_8, KeyEvent.KEYCODE_9,
        KeyEvent.KEYCODE_BUTTON_X, KeyEvent.KEYCODE_BUTTON_Y, KeyEvent.KEYCODE_X, KeyEvent.KEYCODE_Z, KeyEvent.KEYCODE_J, KeyEvent.KEYCODE_K -> 6
        else -> -1
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        val a = mapKey(keyCode)
        if (a < 0 || (a == 5 && scene == TITLE)) return super.onKeyDown(keyCode, event)
        if ((event?.repeatCount ?: 0) != 0) return true // holding a button does nothing extra: every button is one press
        if (a == 6) toggleRun() else onAction(a)
        return true
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        val a = mapKey(keyCode)
        if (a < 0 || (a == 5 && scene == TITLE)) return super.onKeyUp(keyCode, event)
        if (a == 6) return true // run is a lock, letting go changes nothing
        if (a == held) held = -1
        return true
    }

    /** One press of a run button: run on; the next press: run off. Only while walking about (not in menus, talks or fights). */
    private fun toggleRun() {
        if (scene != WORLD || game.cur != null || pauseSel >= 0 || journal) return
        runToggle = !runToggle
        toast = if (runToggle) "Run ON" else "Run OFF"; toastAt = now()
    }

    /** A TV pop-up (volume bar, notification) can take the focus before a button is let go; that key-up never reaches us, so stop walking. */
    override fun onWindowFocusChanged(hasWindowFocus: Boolean) {
        super.onWindowFocusChanged(hasWindowFocus)
        if (!hasWindowFocus) held = -1
    }

    /** 0 down, 1 left, 2 right, 3 up, 4 OK, 5 back / menu */
    private fun onAction(a: Int) {
        when (scene) {
            TITLE -> titleInput(a)
            WORLD -> worldInput(a)
            BATTLE -> battleInput(a)
            CREDITS -> if (a == 4 && now() - creditsT0 > creditsLength()) finishCredits()
        }
    }

    private fun titleInput(a: Int) {
        val n = if (hasSave) 2 else 1
        when (a) { UP -> titleSel = (titleSel + n - 1) % n; DOWN -> titleSel = (titleSel + 1) % n; 4 -> titleOk() }
    }

    private fun titleOk() {
        val item = if (hasSave && titleSel == 0) "Continue" else "New Game"
        val g = fresh(); g.clock = now()
        if (item == "Continue") {
            if (!g.load(prefs.getString("save", "") ?: "")) { hasSave = false; titleSel = 0; return }
        } else g.newGame()
        game = g; enterWorld()
    }

    private fun enterWorld() {
        scene = WORLD; held = -1; battle = null; pauseSel = -1; journal = false; dlgFor = null
        lastMapId = ""; fadeAt = now()
    }

    private fun worldInput(a: Int) {
        if (journal) { if (a == 4 || a == 5) journal = false; return }
        if (pauseSel >= 0) {
            when (a) { UP -> pauseSel = (pauseSel + 3) % 4; DOWN -> pauseSel = (pauseSel + 1) % 4; 4 -> pauseOk(); 5 -> pauseSel = -1 }
            return
        }
        val cur = game.cur
        if (cur != null) { dialogueInput(a, cur); return }
        when (a) {
            in 0..3 -> held = a
            4 -> game.interact(now())
            5 -> if (game.idle(now())) pauseSel = 0
        }
    }

    private fun pauseOk() {
        when (pauseSel) {
            0 -> pauseSel = -1
            1 -> { pauseSel = -1; journal = true }
            2 -> { game.save(); toast = "Journey saved!"; toastAt = now(); pauseSel = -1 }
            3 -> { game.save(); scene = TITLE; titleSel = 0; pauseSel = -1; hasSave = prefs.contains("save") }
        }
    }

    private fun dialogueInput(a: Int, cur: Step) {
        if (dlgPages.isEmpty()) return
        val page = dlgPages[dlgPage]
        val full = ((now() - dlgT0) / 22).toInt() >= page.sumOf { it.length }
        val last = dlgPage >= dlgPages.size - 1
        when (a) {
            4 -> if (!full) dlgT0 = now() - 100000
            else if (!last) { dlgPage++; dlgT0 = now() }
            else if (cur is Step.Ask) game.advance(askSel) else game.advance()
            UP, DOWN -> if (cur is Step.Ask && last && full) askSel = (askSel + (if (a == DOWN) 1 else cur.opts.size - 1)) % cur.opts.size
        }
    }

    private fun buildDialogue(cur: Step?, t: Long) {
        dlgFor = cur; dlgPage = 0; dlgT0 = t; askSel = 0; dlgPages = emptyList()
        val text = when (cur) { is Step.Say -> cur.text; is Step.Ask -> cur.text; else -> return }
        if (lw == 0) return
        dlgPages = PixelFont.wrap(text, lw - 8 - 24).chunked(2)
    }

    private fun battleInput(a: Int) {
        val b = battle ?: return
        if (b.learnFor != null) { // "forget a move?" prompt: 0..3 = the old moves, 4 = keep them all
            when (a) {
                UP -> b.learnSel = (b.learnSel + 4) % 5
                DOWN -> b.learnSel = (b.learnSel + 1) % 5
                4 -> { b.answerLearn(b.learnSel); battleLast = 0 }
                5 -> { b.answerLearn(-1); battleLast = 0 }
            }
            return
        }
        if (b.fighting && !b.swapping) { // the move list (2 x 2)
            val n = b.me.moves.size
            when (a) {
                UP -> if (b.moveSel >= 2) b.moveSel -= 2
                DOWN -> if (b.moveSel + 2 < n) b.moveSel += 2
                LEFT -> if (b.moveSel % 2 == 1) b.moveSel--
                RIGHT -> if (b.moveSel % 2 == 0 && b.moveSel + 1 < n) b.moveSel++
                4 -> if (b.me.moves[b.moveSel].pp > 0) b.fightWith(b.moveSel)
                5 -> b.closeFight()
            }
            return
        }
        if (b.swapping) {
            when (a) {
                UP -> moveSwap(b, -1); DOWN -> moveSwap(b, 1)
                4 -> b.swap(b.swapSel); 5 -> b.closeSwap()
            }
            return
        }
        if (!b.menuOn) { if (a == 4) battleLast = 0; return }
        val n = b.items
        when (a) {
            UP -> b.menu = if (b.menu >= 2) b.menu - 2 else b.menu + 2 * ((n - 1 - b.menu) / 2)
            DOWN -> b.menu = if (b.menu + 2 < n) b.menu + 2 else b.menu % 2
            LEFT, RIGHT -> if ((b.menu xor 1) < n) b.menu = b.menu xor 1
            4 -> chooseMenu(b, b.menu)
        }
    }

    private fun chooseMenu(b: Battle, i: Int) {
        if (!b.menuEnabled(i)) return
        b.menu = i; b.use(i)
    }

    private fun moveSwap(b: Battle, dir: Int) {
        var s = b.swapSel; var n = 0
        do { s = (s + dir + b.party.size) % b.party.size; n++ } while ((b.party[s].hp <= 0 || s == b.cur) && n < 12)
        if (b.party[s].hp > 0 && s != b.cur) b.swapSel = s
    }

    private fun finishCredits() { game.finishGame(); enterWorld() }

    // ---- touch: menus register tap boxes while drawing; an on-screen pad appears while walking ----
    private fun hit(x: Float, y: Float, w: Float, h: Float, a: () -> Unit) { boxes.add(RectF(x, y, x + w, y + h) to a) }

    private fun padCenterX() = 38f
    private fun padCenterY() = lh - 40f
    private fun padRadius() = 27f
    private fun inCircle(x: Float, y: Float, cx: Float, cy: Float, r: Float) = (x - cx) * (x - cx) + (y - cy) * (y - cy) <= r * r
    private fun padDirAt(x: Float, y: Float): Int {
        val dx = x - padCenterX(); val dy = y - padCenterY(); val r = padRadius()
        if (dx * dx + dy * dy > r * r * 1.5f || dx * dx + dy * dy < r * r * 0.05f) return -1
        return if (abs(dx) > abs(dy)) (if (dx < 0) LEFT else RIGHT) else (if (dy < 0) UP else DOWN)
    }
    private fun touchPadVisible() = touchMode && scene == WORLD && game.cur == null && pauseSel < 0 && !journal

    private fun lx(v: Float) = (v - offX) / zoom
    private fun ly(v: Float) = (v - offY) / zoom

    override fun onTouchEvent(e: MotionEvent): Boolean {
        touchMode = true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex; val x = lx(e.getX(i)); val y = ly(e.getY(i))
                for (k in boxes.indices.reversed()) if (boxes[k].first.contains(x, y)) { boxes[k].second(); return true }
                if (touchPadVisible()) {
                    val d = padDirAt(x, y)
                    if (d >= 0) { padPointer = e.getPointerId(i); padDir = d; onAction(d); return true }
                    if (inCircle(x, y, lw - 30f, lh - 42f, 17f)) { onAction(4); return true }
                    if (inCircle(x, y, lw - 64f, lh - 20f, 11f)) { onAction(5); return true }
                    if (inCircle(x, y, lw - 64f, lh - 52f, 12f)) { runToggle = !runToggle; return true }
                    return true
                }
                if (scene == TITLE) { return true }
                onAction(4)
            }
            MotionEvent.ACTION_MOVE -> if (padPointer >= 0) {
                val i = e.findPointerIndex(padPointer)
                if (i >= 0) { val d = padDirAt(lx(e.getX(i)), ly(e.getY(i))); if (d != padDir) { padDir = d; held = d } }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                if (padPointer >= 0 && (e.actionMasked == MotionEvent.ACTION_CANCEL || e.getPointerId(e.actionIndex) == padPointer)) { padPointer = -1; padDir = -1; held = -1 }
            }
        }
        return true
    }

    // =============================================================================================
    //  frame setup and small drawing helpers
    // =============================================================================================
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { viewW = w; viewH = h; setupFrame() }

    private fun setupFrame() {
        if (viewW <= 0 || viewH <= 0) return
        zoom = max(1, viewH / TARGET_H)
        lh = max(1, viewH / zoom); lw = max(1, viewW / zoom)
        offX = (viewW - lw * zoom) / 2; offY = (viewH - lh * zoom) / 2
        for (i in 0..1) { frames[i] = Bitmap.createBitmap(lw, lh, Bitmap.Config.ARGB_8888); frames[i]!!.setHasAlpha(false); frameCanvases[i] = Canvas(frames[i]!!) }
        blitDst.set(offX, offY, offX + lw * zoom, offY + lh * zoom)
        layer?.recycle(); layer = null; layerMap = null; flip = 0
        if (dlgFor != null) buildDialogue(dlgFor, now())
    }

    /** The still part of map [m] drawn once; null if memory ran out (the caller then draws every tile each frame). */
    private fun mapLayer(m: GameMap): Bitmap? {
        if (layerMap === m && layerTs == TS) return layer
        layer?.recycle(); layer = null; layerMap = m; layerTs = TS; liveN = 0
        try {
            val bm = Bitmap.createBitmap(m.w * TS, m.h * TS, Bitmap.Config.ARGB_8888); bm.setHasAlpha(false)
            val lc = Canvas(bm); val tsf = TS.toFloat()
            val xs = IntArray(m.w * m.h); val ys = IntArray(m.w * m.h); val gs = BooleanArray(m.w * m.h)
            var n = 0
            for (y in 0 until m.h) for (x in 0 until m.w) {
                art.drawStill(lc, game, m, x, y, x * tsf, y * tsf, tsf)
                val tl = m.tile(x, y)
                if (art.isLive(tl)) { xs[n] = x; ys[n] = y; gs[n] = tl == Tl.TALL; n++ }
            }
            for (hv in 0..2) for (st in 0 until GRASS_STEPS) grassPic(m.theme, hv, st)
            liveX = xs; liveY = ys; liveGrass = gs; liveN = n; layer = bm
        } catch (e: OutOfMemoryError) { layer = null; liveN = 0 }
        return layer
    }

    /** One pre-drawn picture of swaying tall grass (theme x blade pattern x sway step). */
    private fun grassPic(th: Theme, hv: Int, step: Int): Bitmap {
        val i = (th.ordinal * 3 + hv) * GRASS_STEPS + step
        var b = grassPics[i]
        if (b == null) {
            b = Bitmap.createBitmap(TS, TS, Bitmap.Config.ARGB_8888); b.setHasAlpha(false)
            art.tallGrass(Canvas(b), th, hv, step, 0f, 0f, TS.toFloat())
            grassPics[i] = b
        }
        return b
    }

    private fun bmp(id: Int): Bitmap? {
        if (!bmps.containsKey(id)) {
            bmps[id] = try {
                BitmapFactory.decodeResource(resources, id, BitmapFactory.Options().apply { inScaled = false })
            } catch (e: Exception) { null }
        }
        return bmps[id]
    }

    /** Text in the pixel font: align 0 left / 1 centre / 2 right of x, scale 1 or 2, shadow colour or 0. */
    private fun tx(c: Canvas, s: String, x: Float, y: Float, col: Int = Ui.INK, align: Int = 0, scale: Int = 1, shadow: Int = Ui.INK_SHADOW) =
        PixelFont.draw(c, s, x, y, col, align, scale, shadow)

    private fun rect(c: Canvas, x: Float, y: Float, w: Float, h: Float, col: Int) = Ui.rect(c, x, y, w, h, col)

    private fun disc(c: Canvas, cx: Float, cy: Float, r: Float, col: Int) {
        val ir = r.toInt()
        for (dy in -ir..ir) { val hw = Math.round(sqrt((r * r - dy * dy).coerceAtLeast(0f))).toFloat(); rect(c, cx - hw, cy + dy, hw * 2, 1f, col) }
    }

    private fun ellipse(c: Canvas, cx: Float, cy: Float, rx: Float, ry: Float, col: Int) {
        val iy = ry.toInt()
        for (dy in -iy..iy) { val hw = Math.round(rx * sqrt((1f - (dy.toFloat() * dy) / (ry * ry)).coerceAtLeast(0f))).toFloat(); rect(c, cx - hw, cy + dy, hw * 2, 1f, col) }
    }

    private fun tri(c: Canvas, a: Float, b: Float, d: Float, e: Float, f: Float, g: Float) {
        path.reset(); path.moveTo(a, b); path.lineTo(d, e); path.lineTo(f, g); path.close(); p.style = Paint.Style.FILL; c.drawPath(path, p)
    }

    /** A critter's 64x64 battle sprite with its feet at (cx, by); [dir] = which way a lunge goes, [lunge]/[hurt] = start times. */
    private fun battleSprite(c: Canvas, m: Mon, cx: Float, by: Float, dir: Int, lunge: Long, hurt: Long, t: Float, back: Boolean) {
        val nowMs = now()
        val bm = bmp(if (back) m.s.back else m.s.front) ?: return
        if (nowMs - hurt < 480 && ((nowMs - hurt) / 60) % 2 == 0L) return          // blinks when hit
        val la = (nowMs - lunge) / 260f
        val dx = if (la in 0f..1f) dir * sin(la * PI.toFloat()) * 12f else 0f
        val bob = if ((t * 1.8f).toInt() % 2 == 0) 0f else -1f
        c.drawBitmap(bm, Math.round(cx - bm.width / 2f + dx).toFloat(), Math.round(by - bm.height + bob).toFloat(), spritePaint)
    }

    /** A type or status label: small coloured plate with three letters. Returns its width. */
    private fun chip(c: Canvas, label: String, col: Int, x: Float, y: Float): Float {
        val s = label.take(3).uppercase(); val w = Ui.chipWidth(label)
        rect(c, x + 1, y, w - 2, 9f, Color.rgb(24, 24, 40)); rect(c, x, y + 1, w, 7f, Color.rgb(24, 24, 40))
        rect(c, x + 1, y + 1, w - 2, 7f, col)
        PixelFont.draw(c, s, x + 3, y + 1, Color.WHITE, 0, 1, 0)
        return w
    }

    // =============================================================================================
    //  onDraw
    // =============================================================================================
    override fun onDraw(canvas: Canvas) {
        val t0 = now()
        if (lw == 0 && viewW > 0) setupFrame()
        val fb = frames[flip]; val c = frameCanvases[flip]
        if (fb == null || c == null) { postInvalidateDelayed(FRAME_MS); return }
        flip = flip xor 1
        update()
        boxes.clear()
        val w = lw.toFloat(); val h = lh.toFloat(); val t = t0 / 1000f
        p.style = Paint.Style.FILL
        when (scene) {
            TITLE -> drawTitle(c, w, h, t)
            WORLD -> drawWorld(c, w, h, t)
            BATTLE -> drawBattle(c, w, h, t)
            CREDITS -> drawCredits(c, w, h, t)
        }
        if (offX > 0 || offY > 0) canvas.drawColor(Color.BLACK)
        canvas.drawBitmap(fb, null, blitDst, blitPaint)
        postInvalidateDelayed(max(1L, FRAME_MS - (now() - t0)))
    }

    private fun drawTitle(c: Canvas, w: Float, h: Float, t: Float) {
        // sky, drifting clouds and a grassy hill
        rect(c, 0f, 0f, w, h, Color.rgb(120, 192, 248)); rect(c, 0f, h * 0.35f, w, h * 0.30f, Color.rgb(152, 214, 250)); rect(c, 0f, h * 0.55f, w, h * 0.25f, Color.rgb(184, 230, 252))
        for (i in 0..3) {
            val cx = ((i * 97 + t * (4f + i)) % (w + 60f)) - 30f; val cy = 24f + i * 17f
            ellipse(c, cx, cy, 20f, 5f, Color.WHITE); ellipse(c, cx - 9f, cy + 1f, 12f, 4f, Color.WHITE); ellipse(c, cx + 11f, cy + 1f, 11f, 4f, Color.rgb(228, 244, 255))
        }
        rect(c, 0f, h * 0.80f, w, h * 0.20f, Color.rgb(96, 176, 72))
        ellipse(c, w * 0.30f, h * 0.84f, w * 0.62f, h * 0.17f, Color.rgb(112, 192, 80)); ellipse(c, w * 0.82f, h * 0.86f, w * 0.5f, h * 0.14f, Color.rgb(104, 184, 76))
        rect(c, 0f, h * 0.84f, w, h * 0.16f, Color.rgb(96, 176, 72))
        // the title on a framed plate
        val tw = PixelFont.width("CRITTER QUEST", 2) + 24f
        Ui.box(c, w / 2 - tw / 2, 12f, tw, 30f, Color.rgb(40, 48, 96), Color.rgb(248, 200, 64), 0)
        tx(c, "CRITTER QUEST", w / 2, 18f, Ui.GOLD, 1, 2, Color.rgb(120, 70, 20))
        tx(c, "The Silence of the Heart Bell", w / 2, 46f, Color.rgb(40, 48, 96), 1, 1, Color.rgb(230, 244, 255))
        for (i in 0..2) {
            val bm = bmp(show[i].s.front) ?: continue
            val cx = w * (0.22f + 0.28f * i); val bob = if ((t * 2f + i).toInt() % 2 == 0) 0 else -1
            ellipse(c, cx, h * 0.69f + 1, 20f, 3f, Color.argb(70, 30, 70, 30))
            c.drawBitmap(bm, Math.round(cx - 32f).toFloat(), (Math.round(h * 0.69f) - 62 + bob).toFloat(), spritePaint)
        }
        val items = if (hasSave) listOf("Continue", "New Game") else listOf("New Game")
        val bw = 92f; val bh = items.size * 14f + 12f; val bx = w / 2 - bw / 2; val by = h * 0.74f
        Ui.textBox(c, bx, by, bw, bh)
        for ((i, s) in items.withIndex()) {
            val y = by + 7f + i * 14f
            if (i == titleSel) Ui.cursor(c, bx + 9f, y + 1f)
            tx(c, s, bx + 20f, y)
            hit(bx, y - 3f, bw, 14f) { titleSel = i; titleOk() }
        }
        tx(c, "D-pad: move   OK: talk   BACK: menu   0-9: run", w / 2, h - 11f, Color.rgb(40, 48, 96), 1, 1, Color.rgb(230, 244, 255))
    }

    // ---------------------------------------------------------------------------------------------
    private fun drawWorld(c: Canvas, w: Float, h: Float, t: Float) {
        val g = game; val m = g.map; val nowMs = now()
        val ts = TS.toFloat()
        val prog = ((nowMs - g.moveT0) / g.stepMs.toFloat()).coerceIn(0f, 1f)
        val fx = g.fromX + (g.px - g.fromX) * prog; val fy = g.fromY + (g.py - g.fromY) * prog
        val mw = m.w * ts; val mh = m.h * ts
        var camX = fx * ts + ts / 2 - w / 2; var camY = fy * ts + ts / 2 - h / 2
        camX = if (mw <= w) -(w - mw) / 2 else camX.coerceIn(0f, mw - w)
        camY = if (mh <= h) -(h - mh) / 2 else camY.coerceIn(0f, mh - h)
        camX = camX.roundToInt().toFloat(); camY = camY.roundToInt().toFloat()
        c.drawColor(Color.rgb(10, 10, 18))
        val x0 = max(0, floor(camX / ts).toInt()); val x1 = min(m.w - 1, ceil((camX + w) / ts).toInt())
        val y0 = max(0, floor(camY / ts).toInt()); val y1 = min(m.h - 1, ceil((camY + h) / ts).toInt())
        val lyr = mapLayer(m)
        if (lyr != null) { // fast path: copy the cached map, then redraw only the animated tiles that are on screen
            c.drawBitmap(lyr, -camX, -camY, spritePaint)
            for (k in 0 until liveN) {
                val lx = liveX[k]; val ly = liveY[k]
                if (lx < x0 || lx > x1 || ly < y0 - 1 || ly > y1) continue
                val ox = lx * ts - camX; val oy = ly * ts - camY
                if (liveGrass[k]) c.drawBitmap(grassPic(m.theme, art.grassVariant(lx, ly), art.grassStep(lx, t)), ox, oy, spritePaint)
                else art.drawLive(c, g, m, lx, ly, ox, oy, ts, t)
            }
        } else {
            for (y in y0..y1) for (x in x0..x1) art.tile(c, g, m, x, y, x * ts - camX, y * ts - camY, ts, t)
        }

        // everything that stands or walks about, drawn back to front
        val items = ArrayList<Pair<Float, () -> Unit>>()
        fun sx(tx: Float) = Math.round(tx * ts - camX + ts / 2).toFloat()
        fun sy(ty: Float) = Math.round(ty * ts - camY + ts - 1).toFloat()
        for (n in g.npcs()) {
            val mv = g.movers[n.id]; val moving = g.npcMoving(n, nowMs); val pr = g.npcProgress(n, nowMs)
            val tx = if (mv != null && moving) mv.fx + (mv.x - mv.fx) * pr else g.npcX(n).toFloat()
            val ty = if (mv != null && moving) mv.fy + (mv.y - mv.fy) * pr else g.npcY(n).toFloat()
            if (tx < x0 - 1 || tx > x1 + 1 || ty < y0 - 1 || ty > y1 + 2) continue
            items.add(ty to {
                val cx = sx(tx); val by = sy(ty)
                art.person(c, n.look, cx, by, ts, g.npcFacing(n), moving, pr, t, g.npcFoot(n), 0)
                if (g.alert === n) art.alert(c, cx, by, ts)
            })
        }
        for (s in SPOTS) {   // legendary critters waiting in their sanctums
            if (s.map != m.id || g.f(s.flag) || s.x < x0 - 2 || s.x > x1 + 2 || s.y < y0 - 1 || s.y > y1 + 2) continue
            items.add(s.y.toFloat() to { art.legend(c, s.species, sx(s.x.toFloat()), sy(s.y.toFloat()), ts, t, DEX[s.species].type.col) })
        }
        items.add(fy to { art.person(c, PLAYER_LOOK, sx(fx), sy(fy), ts, g.face, prog < 1f, prog, t, g.stepCount) })
        val lead = g.party.firstOrNull { it.hp > 0 }
        if (lead != null) {   // your lead critter trails one tile behind you
            val ffx = g.fFromX + (g.fX - g.fFromX) * prog; val ffy = g.fFromY + (g.fY - g.fFromY) * prog
            if (abs(ffx - fx) + abs(ffy - fy) > 0.6f) items.add(ffy to {
                val walking = prog < 1f && (g.fFromX != g.fX || g.fFromY != g.fY)
                val bob = if (walking && (prog * 4f).toInt() % 2 == 0) -1f else 0f
                art.critter(c, DEX.indexOf(lead.s), sx(ffx), sy(ffy) + bob, ts, g.fFace == UP, g.fFace == LEFT)
            })
        }
        for (cr in life.critters) {   // wild critters going about their day
            val moving = cr.moving(nowMs); val pr = cr.progress(nowMs)
            val tx = if (moving) cr.fx + (cr.x - cr.fx) * pr else cr.x.toFloat()
            val ty = if (moving) cr.fy + (cr.y - cr.fy) * pr else cr.y.toFloat()
            if (tx < x0 - 1 || tx > x1 + 1 || ty < y0 - 1 || ty > y1 + 2) continue
            items.add(ty to {
                val cx = sx(tx)
                val by = sy(ty) + (if (moving) -sin(pr * PI.toFloat()) * 3f else if (((nowMs / 650) + cr.dex) % 2 == 0L) 0f else -1f)
                if (!moving && m.tile(cr.x, cr.y) == Tl.TALL) {          // hiding: only the top peeks out of the grass
                    c.save(); c.clipRect(0f, 0f, w, by - 5f); art.critter(c, cr.dex, cx, by, ts, cr.face == UP, cr.face == LEFT); c.restore()
                } else art.critter(c, cr.dex, cx, by, ts, cr.face == UP, cr.face == LEFT)
                if (life.startled(cr, nowMs)) art.emote(c, cx, by + 8f, ts, '!')
            })
        }
        items.sortBy { it.first }
        for (it in items) it.second()
        // light dusk tint inside the Keep for mood
        if (m.theme == Theme.KEEP && m.id != "route4") rect(c, 0f, 0f, w, h, Color.argb(40, 40, 20, 80))

        drawBanner(c, w, h, nowMs)
        if (nowMs - toastAt < 1800 && toast.isNotEmpty()) { val tw = PixelFont.width(toast) + 18f; Ui.textBox(c, 4f, h - 24f, tw, 20f); tx(c, toast, 13f, h - 18f) }
        game.cur?.let { drawDialogue(c, w, h, it, nowMs) }
        if (pauseSel >= 0) drawPause(c, w, h)
        if (journal) drawJournal(c, w, h)
        if (touchPadVisible()) drawTouch(c, w, h)
        val fa = 1f - (nowMs - fadeAt) / 450f
        if (fa > 0f) rect(c, 0f, 0f, w, h, Color.argb((fa * 255).toInt(), 0, 0, 0))
    }

    private fun drawBanner(c: Canvas, w: Float, h: Float, nowMs: Long) {
        val age = nowMs - game.bannerAt
        if (age > 2600 || game.bannerName.isEmpty() || game.cur != null) return
        val a = if (age < 300) age / 300f else if (age > 2300) (2600 - age) / 300f else 1f
        val tw = PixelFont.width(game.bannerName) + 22f
        val y = -17f + 21f * a
        Ui.box(c, 4f, y, tw, 17f, Ui.DARK_FILL, Color.rgb(248, 200, 64), 0)
        tx(c, game.bannerName, 15f, y + 5f, Ui.GOLD, 0, 1, Color.rgb(24, 24, 40))
    }

    private fun drawDialogue(c: Canvas, w: Float, h: Float, cur: Step, nowMs: Long) {
        val who: String; val portrait: Int
        when (cur) { is Step.Say -> { who = cur.who; portrait = cur.portrait }; is Step.Ask -> { who = cur.who; portrait = cur.portrait }; else -> return }
        if (dlgPages.isEmpty()) { buildDialogue(cur, nowMs); if (dlgPages.isEmpty()) return }
        hit(0f, 0f, w, h) { dialogueInput(4, cur) } // any tap advances the text (registered first = lowest priority)
        val bx = 4f; val bw = w - 8f; val bh = 42f; val by = h - bh - 4f
        if (portrait in DEX.indices) {
            val bm = bmp(show[portrait].s.front)
            Ui.textBox(c, bx + 4f, by - 82f, 74f, 74f)
            if (bm != null) c.drawBitmap(bm, bx + 9f, by - 77f, spritePaint)
        }
        val tabW = PixelFont.width(who) + 14f
        if (who.isNotEmpty()) Ui.textBox(c, bx + 8f, by - 12f, tabW, 20f, ring = 1)   // the speaker's name sits on a little tab behind the box
        Ui.textBox(c, bx, by, bw, bh, ring = 2, grip = true)   // the big dialogue box: thick light-blue ring, rounded ends, pale grips
        if (who.isNotEmpty()) tx(c, who, bx + 15f, by - 8f)
        val page = dlgPages[min(dlgPage, dlgPages.size - 1)]
        var shown = ((nowMs - dlgT0) / 26).toInt()
        val total = page.sumOf { it.length }
        for ((i, line) in page.withIndex()) {
            val n = min(line.length, max(0, shown)); shown -= line.length
            tx(c, line.substring(0, n), bx + 12f, by + 9f + i * 15f)
        }
        val full = ((nowMs - dlgT0) / 26).toInt() >= total
        val last = dlgPage >= dlgPages.size - 1
        if (full && !(last && cur is Step.Ask)) Ui.moreArrow(c, bx + bw - 16f, by + bh - 12f, if ((nowMs / 280) % 2 == 0L) 0 else 1)
        if (cur is Step.Ask && last && full) {
            val rowH = 13f; val ow = max(80f, cur.opts.maxOf { PixelFont.width(it) } + 34f); val oh = rowH * cur.opts.size + 12f
            val ox = bx + bw - ow; val oy = by - oh - 3f
            Ui.textBox(c, ox, oy, ow, oh)
            for ((i, o) in cur.opts.withIndex()) {
                val ry = oy + 7f + i * rowH
                if (i == askSel) Ui.cursor(c, ox + 9f, ry + 1f)
                tx(c, o, ox + 20f, ry)
                hit(ox, ry - 3f, ow, rowH) { askSel = i; game.advance(i) }
            }
        }
    }

    private fun drawPause(c: Canvas, w: Float, h: Float) {
        val items = listOf("Resume", "Journal", "Save", "Quit to Title")
        hit(0f, 0f, w, h) { pauseSel = -1 }
        val bw = 92f; val bh = items.size * 14f + 12f; val x = w - bw - 6f; val y = 6f
        Ui.textBox(c, x, y, bw, bh)
        for ((i, s) in items.withIndex()) {
            val ry = y + 7f + i * 14f
            if (i == pauseSel) Ui.cursor(c, x + 9f, ry + 1f)
            tx(c, s, x + 20f, ry)
            hit(x, ry - 3f, bw, 14f) { pauseSel = i; pauseOk() }
        }
    }

    private fun drawJournal(c: Canvas, w: Float, h: Float) {
        Ui.textBox(c, 5f, 5f, w - 10f, h - 10f)
        val red = Color.rgb(176, 56, 40)
        tx(c, "JOURNAL", w / 2, 12f, Ui.INK, 1, 2)
        tx(c, game.chapter(), 16f, 30f, red)
        val lines = PixelFont.wrap("Goal: " + game.objective(), (w - 40f).toInt())
        for ((i, l) in lines.withIndex()) tx(c, l, 16f, 42f + i * 11f)
        val sy = 42f + max(lines.size, 2) * 11f + 4f
        tx(c, "Sigils", 16f, sy)
        val flags = listOf("sigil_leaf" to Color.rgb(70, 190, 100), "sigil_tide" to Color.rgb(70, 150, 240), "sigil_ember" to Color.rgb(250, 110, 50))
        for ((i, f) in flags.withIndex()) {
            val cx = 70f + i * 16f
            disc(c, cx, sy + 4f, 6f, Color.rgb(40, 36, 52)); disc(c, cx, sy + 4f, 5f, if (game.f(f.first)) f.second else Color.rgb(196, 190, 176))
        }
        // the legendary critters you have caught: a gold LEG tag and one disc per legend in the colour of its type
        val lx0 = w - 16f - SPOTS.size * 12f
        chip(c, Rarity.LEGENDARY.tag, Rarity.LEGENDARY.col, lx0 - Ui.chipWidth("LEG") - 3f, sy - 1f)
        for ((i, sp) in SPOTS.withIndex()) {
            val cx = lx0 + i * 12f + 6f
            disc(c, cx, sy + 4f, 6f, Color.rgb(40, 36, 52)); disc(c, cx, sy + 4f, 5f, if (game.f(sp.flag)) DEX[sp.species].type.col else Color.rgb(196, 190, 176))
        }
        val py = sy + 16f
        tx(c, "Party", 16f, py)
        for ((i, m) in game.party.withIndex()) {
            val col = i % 2; val row = i / 2
            val x = 16f + col * ((w - 32f) / 2f); val y = py + 12f + row * 18f
            art.critter(c, DEX.indexOf(m.s), x + 8f, y + 15f, 16f, false)
            tx(c, "${m.s.name} Lv${m.lvl}", x + 20f, y)
            tx(c, "HP ${m.hp}/${m.maxHp}", x + 20f, y + 9f, m.s.type.col, 0, 1, 0)
        }
        tx(c, "Critterdex ${game.dexCaught.size}/${DEX.size}   Orbs ${game.orbs}   At Mom's ${game.box.size}", w / 2, h - 28f, Ui.INK, 1)
        tx(c, "OK / BACK to close", w / 2, h - 17f, Color.rgb(120, 100, 80), 1, 1, 0)
        hit(0f, 0f, w, h) { journal = false }
    }

    private fun drawTouch(c: Canvas, w: Float, h: Float) {
        p.style = Paint.Style.FILL
        val cx = padCenterX(); val cy = padCenterY(); val r = padRadius()
        p.color = Color.argb(55, 255, 255, 255); c.drawCircle(cx, cy, r, p)
        p.color = Color.argb(130, 255, 255, 255)
        tri(c, cx, cy - r * 0.9f, cx - r * 0.3f, cy - r * 0.5f, cx + r * 0.3f, cy - r * 0.5f)
        tri(c, cx, cy + r * 0.9f, cx - r * 0.3f, cy + r * 0.5f, cx + r * 0.3f, cy + r * 0.5f)
        tri(c, cx - r * 0.9f, cy, cx - r * 0.5f, cy - r * 0.3f, cx - r * 0.5f, cy + r * 0.3f)
        tri(c, cx + r * 0.9f, cy, cx + r * 0.5f, cy - r * 0.3f, cx + r * 0.5f, cy + r * 0.3f)
        p.color = Color.argb(70, 255, 255, 255)
        c.drawCircle(w - 30f, h - 42f, 17f, p); c.drawCircle(w - 64f, h - 20f, 11f, p)
        p.color = if (runToggle) Color.argb(150, 250, 214, 100) else Color.argb(70, 255, 255, 255); c.drawCircle(w - 64f, h - 52f, 12f, p)
        PixelFont.draw(c, "OK", w - 30f, h - 46f, Color.argb(230, 255, 255, 255), 1, 1, 0)
        PixelFont.draw(c, "MENU", w - 64f, h - 24f, Color.argb(230, 255, 255, 255), 1, 1, 0)
        PixelFont.draw(c, "RUN", w - 64f, h - 56f, Color.argb(230, 255, 255, 255), 1, 1, 0)
    }

    // ---------------------------------------------------------------------------------------------
    /** The battlefield: sky, ground and two platforms, coloured after the area where the fight happens. */
    private fun battleBg(c: Canvas, th: Theme, w: Float, sceneH: Float, foeX: Float, foeBase: Float, meX: Float, meBase: Float) {
        val sky = when (th) {
            Theme.MEADOW -> intArrayOf(Color.rgb(136, 200, 248), Color.rgb(168, 220, 252), Color.rgb(198, 238, 254))
            Theme.FOREST -> intArrayOf(Color.rgb(112, 170, 180), Color.rgb(148, 196, 198), Color.rgb(180, 216, 212))
            Theme.SHORE -> intArrayOf(Color.rgb(152, 212, 248), Color.rgb(184, 230, 252), Color.rgb(214, 244, 255))
            Theme.ASH -> intArrayOf(Color.rgb(142, 108, 106), Color.rgb(172, 134, 122), Color.rgb(202, 160, 138))
            Theme.KEEP -> intArrayOf(Color.rgb(34, 28, 62), Color.rgb(50, 42, 86), Color.rgb(68, 58, 110))
            Theme.INDOOR -> intArrayOf(Color.rgb(132, 92, 64), Color.rgb(150, 106, 74), Color.rgb(170, 124, 90))
        }
        val gr = when (th) {
            Theme.MEADOW -> intArrayOf(Color.rgb(112, 192, 80), Color.rgb(96, 176, 72))
            Theme.FOREST -> intArrayOf(Color.rgb(72, 148, 76), Color.rgb(58, 128, 66))
            Theme.SHORE -> intArrayOf(Color.rgb(236, 220, 168), Color.rgb(218, 200, 146))
            Theme.ASH -> intArrayOf(Color.rgb(118, 106, 102), Color.rgb(98, 88, 86))
            Theme.KEEP -> intArrayOf(Color.rgb(62, 54, 94), Color.rgb(48, 42, 76))
            Theme.INDOOR -> intArrayOf(Color.rgb(198, 150, 100), Color.rgb(184, 136, 88))
        }
        val hor = sceneH * 0.46f
        rect(c, 0f, 0f, w, hor * 0.5f, sky[0]); rect(c, 0f, hor * 0.5f, w, hor * 0.3f, sky[1]); rect(c, 0f, hor * 0.8f, w, hor * 0.2f + 1, sky[2])
        if (th == Theme.SHORE) rect(c, 0f, hor - 7f, w, 8f, Color.rgb(64, 144, 224))
        rect(c, 0f, hor, w, sceneH - hor, gr[0])
        for (i in 0 until 7) rect(c, 0f, hor + 4f + i * (sceneH - hor) / 7f, w, (sceneH - hor) / 14f, gr[1])      // soft stripes of ground
        rect(c, 0f, hor, w, 1f, Color.argb(90, 0, 0, 0))
        val dark = Color.argb(110, 20, 30, 20)
        ellipse(c, foeX, foeBase + 3f, 47f, 7f, dark); ellipse(c, foeX, foeBase + 2f, 44f, 6f, gr[1]); ellipse(c, foeX, foeBase + 1f, 40f, 5f, gr[0])
        ellipse(c, meX, meBase + 3f, 56f, 8f, dark); ellipse(c, meX, meBase + 2f, 53f, 7f, gr[1]); ellipse(c, meX, meBase + 1f, 48f, 6f, gr[0])
    }

    /** The name / level / HP plate: [own] adds HP numbers and the experience bar. */
    private fun infoBox(c: Canvas, m: Mon, x: Float, y: Float, w: Float, own: Boolean, badge: Rarity? = null) {
        val bh = if (own) 50f else 38f
        Ui.box(c, x, y, w, bh, Ui.BOX_FILL, Ui.BOX_EDGE, 0)
        tx(c, m.s.name, x + 8f, y + 6f)
        // the status chip sits beside the name when there is room before "LvNN"; a long name pushes it in front of the HP bar instead
        val st = m.status
        val beside = st != null && Ui.statusBesideName(m.s.name, st.tag, m.lvl, w)
        if (st != null && beside) chip(c, st.tag, st.col, x + 12f + PixelFont.width(m.s.name), y + 5f)
        tx(c, "Lv${m.lvl}", x + w - 8f, y + 6f, Ui.INK, 2)
        tx(c, "HP", x + 8f, y + 18f, Color.rgb(224, 112, 56), 0, 1, 0)
        var barX = x + 23f
        if (st != null && !beside) barX += chip(c, st.tag, st.col, barX, y + 16f) + 2f
        Ui.hpBar(c, barX, y + 19f, x + w - 10f - barX, m.shown / m.maxHp)
        var cx = x + 8f
        for (ty in m.s.types) cx += chip(c, ty.label, ty.col, cx, y + 27f) + 2f
        if (badge != null) chip(c, badge.tag, badge.col, cx + 1f, y + 27f)   // wild Uncommon / Rare / Legendary critters wear their rarity
        if (own) {
            tx(c, "${m.hp}/${m.maxHp}", x + w - 8f, y + 28f, Ui.INK, 2, 1, 0)
            tx(c, "EXP", x + 8f, y + 40f, Color.rgb(64, 120, 216), 0, 1, 0)
            Ui.xpBar(c, x + 29f, y + 41f, w - 39f, m.xp.toFloat() / Rules.xpNeed(m.lvl))
        }
    }

    private fun pips(c: Canvas, mons: List<Mon>, x: Float, y: Float) {
        for ((i, m) in mons.withIndex()) {
            val px = x + i * 8f
            rect(c, px, y, 6f, 6f, Color.rgb(24, 24, 40)); rect(c, px + 1f, y + 1f, 4f, 4f, if (m.hp > 0) Color.rgb(232, 64, 56) else Color.rgb(160, 160, 168))
            if (m.hp > 0) rect(c, px + 1f, y + 3f, 4f, 1f, Color.WHITE)
        }
    }

    private fun drawBattle(c: Canvas, w: Float, h: Float, t: Float) {
        val b = battle ?: return; val nowMs = now()
        val bottomH = 44f; val sceneH = h - bottomH - 4f
        val foeX = w * 0.70f; val foeBase = sceneH * 0.50f + 6f
        val meX = w * 0.27f; val meBase = sceneH - 13f
        battleBg(c, game.map.theme, w, sceneH, foeX, foeBase, meX, meBase)
        rect(c, 0f, sceneH, w, h - sceneH, Color.rgb(24, 24, 40))
        battleSprite(c, b.foe, foeX, foeBase, -1, b.lungeFoe, b.hitFoe, t, false)
        battleSprite(c, b.me, meX, meBase, 1, b.lungeMe, b.hitMe, t, true)
        val iw = Ui.infoWidth(w)
        infoBox(c, b.foe, 4f, 4f, iw, false, if (b.trainer == null && b.foe.s.rarity != Rarity.COMMON) b.foe.s.rarity else null)
        if (b.trainer != null) pips(c, b.team, 10f, 45f)
        infoBox(c, b.me, w - iw - 4f, sceneH - 52f, iw, true)
        pips(c, b.party, w - iw + 6f, sceneH - 59f)

        // the text / menu area
        val by = h - bottomH - 2f
        if (b.text != msgText) { msgText = b.text; msgT0 = nowMs }
        val menu = b.menuOn && !b.swapping && !b.fighting
        when {
            b.menuOn && b.fighting && !b.swapping -> drawMoves(c, w, h, b, by)
            menu -> {
                val mw = 122f
                Ui.textBox(c, 2f, by, w - mw - 6f, bottomH, grip = true)
                val fit = Ui.fitText(b.text, (w - mw - 30f).toInt())
                for ((i, l) in fit.lines.withIndex()) tx(c, l, 12f, by + fit.top + i * fit.pitch)
                Ui.box(c, w - mw - 2f, by, mw, bottomH, Ui.BOX_FILL, Ui.BOX_EDGE, Ui.BOX_LINE)
                for (i in 0 until b.items) {
                    val x = w - mw + 12f + (i % 2) * 52f; val y = by + 7f + (i / 2) * 12f
                    val ok = b.menuEnabled(i)
                    if (i == b.menu) Ui.cursor(c, x - 9f, y)
                    tx(c, b.menuLabel(i), x, y, if (ok) Ui.INK else Color.rgb(176, 176, 184), 0, 1, if (ok) Ui.INK_SHADOW else 0)
                    hit(x - 11f, y - 2f, 52f, 11f) { chooseMenu(b, i) }
                }
            }
            else -> {
                Ui.textBox(c, 2f, by, w - 4f, bottomH, grip = true)
                val fit = Ui.fitText(b.text, (w - 34f).toInt()); val lines = fit.lines
                var shown = ((nowMs - msgT0) / 22).toInt()
                for ((i, l) in lines.withIndex()) { val n = min(l.length, max(0, shown)); shown -= l.length; tx(c, l.substring(0, n), 12f, by + fit.top + i * fit.pitch) }
                if (!b.menuOn) hit(0f, 0f, w, h) { battleLast = 0 }
            }
        }
        if (b.swapping) drawSwap(c, w, h, b, t)
        if (b.learnFor != null) drawLearn(c, w, h, b)
        if (nowMs - flashAt < 350) rect(c, 0f, 0f, w, h, Color.argb(((1f - (nowMs - flashAt) / 350f) * 255).toInt(), 255, 255, 255))
    }

    /** The move list: four moves in a 2 x 2 grid, with PP, type, power and accuracy of the highlighted one on the right. */
    private fun drawMoves(c: Canvas, w: Float, h: Float, b: Battle, by: Float) {
        val iw = 98f
        Ui.textBox(c, 2f, by, w - iw - 6f, 44f, grip = true)
        Ui.box(c, w - iw - 2f, by, iw, 44f, Ui.BOX_FILL, Ui.BOX_EDGE, Ui.BOX_LINE)
        val half = (w - iw - 14f) / 2f
        for ((i, ms) in b.me.moves.withIndex()) {
            val x = 18f + (i % 2) * half; val y = by + 10f + (i / 2) * 17f
            if (i == b.moveSel) Ui.cursor(c, x - 10f, y)
            tx(c, ms.move.name, x, y, if (ms.pp > 0) Ui.INK else Color.rgb(176, 176, 184), 0, 1, if (ms.pp > 0) Ui.INK_SHADOW else 0)
            hit(x - 12f, y - 4f, half, 16f) { b.moveSel = i; if (ms.pp > 0) b.fightWith(i) }
        }
        val sel = b.me.moves.getOrNull(b.moveSel)
        if (sel != null) {
            val ix = w - iw + 4f
            tx(c, "PP ${sel.pp}/${sel.move.pp}", ix, by + 7f, if (sel.pp == 0) Color.rgb(216, 56, 48) else Ui.INK)
            chip(c, sel.move.type.label, sel.move.type.col, ix, by + 19f)
            tx(c, sel.move.type.label, ix + 24f, by + 20f, Ui.INK, 0, 1, 0)
            tx(c, sel.move.info.replace("  ", " "), ix, by + 32f, Ui.INK, 0, 1, 0)
        }
        hit(w - 46f, by - 14f, 44f, 14f) { b.closeFight() }
    }

    /** "Forget a move to learn a new one?" - shown when a critter that knows four moves levels into a fifth. */
    private fun drawLearn(c: Canvas, w: Float, h: Float, b: Battle) {
        val m = b.learnFor ?: return; val nw = b.learnMove ?: return
        val pw = min(w - 16f, 236f); val x = (w - pw) / 2f; val y = 4f; val rowH = 14f
        Ui.textBox(c, x, y, pw, 50f + rowH * 5 + 10f)
        tx(c, "${m.s.name} wants to learn ${nw.name}!", x + pw / 2, y + 8f, Color.rgb(176, 56, 40), 1)
        chip(c, nw.type.label, nw.type.col, x + 12f, y + 20f)
        tx(c, nw.info, x + 40f, y + 21f, Ui.INK, 0, 1, 0)
        tx(c, "Forget which move?", x + pw / 2, y + 36f, Ui.INK, 1)
        for (i in 0..4) {
            val ry = y + 50f + i * rowH
            if (i == b.learnSel) { Ui.cursor(c, x + 10f, ry + 1f) }
            if (i < m.moves.size) {
                val mo = m.moves[i].move
                tx(c, mo.name, x + 22f, ry)
                chip(c, mo.type.label, mo.type.col, x + pw - 52f, ry - 1f)
                tx(c, "${if (mo.power > 0) mo.power else "--"}", x + pw - 12f, ry, Ui.INK, 2, 1, 0)
            } else tx(c, "Keep my old moves", x + 22f, ry)
            hit(x, ry - 3f, pw, rowH) { b.learnSel = i; b.answerLearn(i); battleLast = 0 }
        }
    }

    private fun drawSwap(c: Canvas, w: Float, h: Float, b: Battle, t: Float) {
        val forced = b.text.startsWith("Choose")
        if (!forced) hit(0f, 0f, w, h) { b.closeSwap() }
        val pw = w - 14f; val x = 7f; val y = 3f; val rowH = 22f
        Ui.textBox(c, x, y, pw, 16f + rowH * b.party.size + 6f)
        tx(c, if (forced) "Choose your next critter!" else "Swap to which critter?", x + pw / 2, y + 7f, Color.rgb(176, 56, 40), 1)
        for ((i, m) in b.party.withIndex()) {
            val ry = y + 16f + i * rowH; val dead = m.hp <= 0; val out = i == b.cur && !dead; val sel = i == b.swapSel
            if (sel && !dead && !out) rect(c, x + 5f, ry, pw - 10f, rowH - 2f, Color.argb(90, 248, 200, 64))
            if (sel && !dead && !out) Ui.cursor(c, x + 8f, ry + 6f)
            art.critter(c, DEX.indexOf(m.s), x + 28f, ry + 18f, 16f, false)
            val col = if (dead || out) Color.rgb(160, 160, 168) else Ui.INK
            tx(c, "${m.s.name} Lv${m.lvl}" + if (out) " (out)" else if (dead) " (fainted)" else "", x + 42f, ry + 3f, col, 0, 1, if (dead || out) 0 else Ui.INK_SHADOW)
            Ui.hpBar(c, x + 42f, ry + 13f, pw - 130f, m.hp.toFloat() / m.maxHp)
            tx(c, "${m.hp}/${m.maxHp}", x + 42f + pw - 126f, ry + 11f, col, 0, 1, 0)
            var cx = x + pw - 66f
            for (ty in m.s.types) cx += chip(c, ty.label, ty.col, cx, ry + 3f) + 2f
            if (!dead && !out) hit(x, ry, pw, rowH) { b.swapSel = i; b.swap(i) }
        }
    }

    // ---------------------------------------------------------------------------------------------
    private val creditLines = listOf(
        "CRITTER QUEST", "", "The Silence of the Heart Bell", "", "~", "",
        "The Heart Bell rings again.", "The Wardens keep their Sigils.", "Baron Gloam tends the Bell at dawn and dusk.", "",
        "Somewhere on the Ashen Trail,", "a lonely critter is running home.", "", "~", "",
        "STARRING", "You", "Professor Fern", "Kit, the Rival", "Mom", "",
        "WARDENS", "Willow of Leaf", "Marina of Tide", "Cinder of Ember", "",
        "THE HOLLOW GUILD", "Baron Gloam", "Lieutenant Vex", "and a lot of grunts", "",
        "CRITTERS", "Emberpup  Blazehorn", "Aquafin  Tidalon", "Sproutle  Thornpaw", "and ${DEX.size - 6} more to find", "", "~", "",
        "Thank you for playing!"
    )
    private fun creditsLength() = (((lh + 8f) / 14f + creditLines.size) * 1000f).toLong() + 1500L

    private fun drawCredits(c: Canvas, w: Float, h: Float, t: Float) {
        rect(c, 0f, 0f, w, h, Color.rgb(16, 18, 44)); rect(c, 0f, h * 0.5f, w, h * 0.5f, Color.rgb(22, 24, 58)); rect(c, 0f, h * 0.8f, w, h * 0.2f, Color.rgb(30, 32, 70))
        for (i in 0 until 50) {
            val sx = ((i * 7919) % 1000) / 1000f * w; val sy = ((i * 104729) % 760) / 1000f * h
            if ((t * 1.5f + i).toInt() % 3 != 0) rect(c, sx, sy, if (i % 4 == 0) 2f else 1f, if (i % 4 == 0) 2f else 1f, Color.rgb(255, 255, 224))
        }
        rect(c, 0f, h - 12f, w, 12f, Color.rgb(24, 70, 40)); rect(c, 0f, h - 12f, w, 1f, Color.rgb(60, 130, 70))
        val el = (now() - creditsT0) / 1000f
        val speed = 14f; val lineH = 14f
        for ((i, s) in creditLines.withIndex()) {
            val y = h + 8f + i * lineH - el * speed
            if (y < -20f || y > h + 4f) continue
            val head = s == "CRITTER QUEST"; val sub = s.isNotEmpty() && s == s.uppercase() && !head && s != "~"
            val col = if (head) Ui.GOLD else if (sub) Color.rgb(150, 184, 255) else Color.WHITE
            tx(c, if (s == "~") "* * *" else s, w / 2, y, col, 1, if (head) 2 else 1, Color.rgb(8, 8, 24))
        }
        for (i in 0..7) art.critter(c, i * 5 % DEX.size, ((w * (0.05f + 0.13f * i) + el * 26f) % (w * 1.1f)), h - 2f + (if ((t * 4 + i).toInt() % 2 == 0) 0f else -1f), 16f, false)
        if (now() - creditsT0 > creditsLength() && (t * 2).toInt() % 2 == 0) tx(c, "Press OK", w / 2, h - 40f, Ui.GOLD, 1, 1, Color.rgb(8, 8, 24))
        hit(0f, 0f, w, h) { onAction(4) }
    }
}
