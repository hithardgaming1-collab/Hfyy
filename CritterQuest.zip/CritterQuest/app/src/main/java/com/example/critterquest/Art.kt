package com.example.critterquest

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import kotlin.math.sin
import kotlin.math.sqrt

const val PART_ALL = 0
const val PART_BASE = 1
const val PART_ANIM = 2
/** Tall grass sways in this many frames per cycle; GameView keeps one pre-drawn picture per step. */
const val GRASS_STEPS = TA.TALL_FRAMES   // sway frames per tall-grass pattern (set in tools/make_tiles.py)

/**
 * Draws world tiles and people. Ground, trees, water, houses... come from the pixel-art sheet (Sprites.kt), the few tiles
 * that depend on a map's colour or on the story (rugs, crystals, the gate, the bell, the starter orbs) are built from
 * whole-pixel rectangles. Nothing is smoothed, so it stays crisp when the small picture is scaled up.
 * The tile size [ts] is 16 in the game (the sheet's native size); other sizes just scale it.
 */
class Art(private val p: Paint, private val spr: Sprites) {
    private val src = Rect(); private val dst = Rect()
    init { p.isAntiAlias = false; p.isFilterBitmap = false; p.isDither = false }

    private fun rgb(r: Int, g: Int, b: Int) = Color.rgb(r, g, b)
    private fun shade(c: Int, f: Float) = Color.rgb((Color.red(c) * f).toInt().coerceIn(0, 255), (Color.green(c) * f).toInt().coerceIn(0, 255), (Color.blue(c) * f).toInt().coerceIn(0, 255))
    private fun hash(x: Int, y: Int) = ((x * 73856093) xor (y * 19349663)) and 0x7fffffff

    private fun rect(c: Canvas, x: Float, y: Float, w: Float, h: Float, col: Int) {
        p.style = Paint.Style.FILL; p.color = col
        c.drawRect(Math.round(x).toFloat(), Math.round(y).toFloat(), Math.round(x + w).toFloat(), Math.round(y + h).toFloat(), p)
    }
    /** A filled circle made of whole-pixel rows. */
    private fun disc(c: Canvas, cx: Float, cy: Float, r: Float, col: Int) {
        val ir = r.toInt()
        for (dy in -ir..ir) { val hw = Math.round(sqrt((r * r - dy * dy).coerceAtLeast(0f))).toFloat(); rect(c, cx - hw, cy + dy, hw * 2, 1f, col) }
    }

    /** Draws cell [idx] of theme row [th] from the tile sheet into the tile at (ox, oy). */
    private fun cell(c: Canvas, th: Theme, idx: Int, ox: Float, oy: Float, ts: Float) {
        val sx = idx * 16; val sy = th.ordinal * 16
        src.set(sx, sy, sx + 16, sy + 16)
        dst.set(Math.round(ox), Math.round(oy), Math.round(ox + ts), Math.round(oy + ts))
        c.drawBitmap(spr.tiles, src, dst, p)
    }

    // ---------------- still vs live tiles (lets GameView draw the map once and only redraw what moves) ----------------
    /**
     * True for tiles whose picture changes from frame to frame (animation, or a story flag).
     * Every other tile is drawn once into a cached map image. A NEW tile that uses [t] or the flags [g] in [tile]
     * MUST be added here, or it freezes on screen (`./run.sh cache` checks this).
     */
    fun isLive(tl: Tl) = when (tl) {
        Tl.TALL, Tl.WATER, Tl.BRIDGE, Tl.LAVA, Tl.STONE, Tl.CRYSTAL, Tl.ORB1, Tl.ORB2, Tl.ORB3, Tl.GATE, Tl.BELL -> true
        else -> false
    }

    /** What goes into the cached map image: every still tile, and just the first frame of open water. */
    fun drawStill(c: Canvas, g: Game, m: GameMap, x: Int, y: Int, ox: Float, oy: Float, ts: Float) {
        val tl = m.tile(x, y)
        if (!isLive(tl)) tile(c, g, m, x, y, ox, oy, ts, 0f)
        else if (tl == Tl.WATER) tile(c, g, m, x, y, ox, oy, ts, 0f, PART_BASE)
    }

    /** What is drawn on top of the cached image every frame (tall grass is handled by GameView from pre-drawn pictures). */
    fun drawLive(c: Canvas, g: Game, m: GameMap, x: Int, y: Int, ox: Float, oy: Float, ts: Float, t: Float) {
        val tl = m.tile(x, y)
        if (tl == Tl.WATER) tile(c, g, m, x, y, ox, oy, ts, t, PART_ANIM)
        else if (isLive(tl)) tile(c, g, m, x, y, ox, oy, ts, t)
    }

    /** Which of the 3 blade-height patterns the grass at (x, y) uses. */
    fun grassVariant(x: Int, y: Int) = hash(x, y) % 3
    /** Which sway step (0 until [GRASS_STEPS]) the grass in column [x] is in at time [t] seconds. */
    fun grassStep(x: Int, t: Float): Int = (((t * 2.2f + x * 0.9f) % 6.2831855f) / 6.2831855f * GRASS_STEPS).toInt().coerceIn(0, GRASS_STEPS - 1)

    /** Tall grass: blade heights [hv] (0..2), sway frame [step] (0 until [GRASS_STEPS]). */
    fun tallGrass(c: Canvas, th: Theme, hv: Int, step: Int, ox: Float, oy: Float, ts: Float) = cell(c, th, TA.TALL + hv * GRASS_STEPS + step, ox, oy, ts)

    private fun floorCell(c: Canvas, th: Theme, h: Int, ox: Float, oy: Float, ts: Float) = cell(c, th, TA.FLOOR + (if (th == Theme.KEEP) 0 else h % 3), ox, oy, ts)

    /** True when the tile at (x, y) is part of a 2x2 block of trees on the even grid (drawn as one big tree). */
    private fun isBigTree(m: GameMap, x: Int, y: Int): Boolean {
        val bx = x and -2; val by = y and -2
        return bx + 1 < m.w && by + 1 < m.h && m.tile(bx, by) == Tl.TREE && m.tile(bx + 1, by) == Tl.TREE &&
            m.tile(bx, by + 1) == Tl.TREE && m.tile(bx + 1, by + 1) == Tl.TREE
    }

    /** The darker "patch" tiles: tall grass, flower beds and the forest floor under big trees. */
    private fun isPatch(m: GameMap, x: Int, y: Int): Boolean {
        val t = m.tile(x, y)
        return t == Tl.TALL || t == Tl.FLOWER || (t == Tl.TREE && isBigTree(m, x, y))
    }

    /** A soft pale rim on a ground tile wherever it touches a patch (cells TA.FEATHER + 0..3 = patch above / below / left / right,
     *  4..7 = a patch only on the diagonal), so the edge of a grass patch or a forest fades into the meadow instead of ending in a hard line. */
    private fun feather(c: Canvas, th: Theme, m: GameMap, x: Int, y: Int, ox: Float, oy: Float, ts: Float) {
        if (th == Theme.INDOOR) return
        val up = isPatch(m, x, y - 1); val down = isPatch(m, x, y + 1); val left = isPatch(m, x - 1, y); val right = isPatch(m, x + 1, y)
        if (up) cell(c, th, TA.FEATHER + 0, ox, oy, ts)
        if (down) cell(c, th, TA.FEATHER + 1, ox, oy, ts)
        if (left) cell(c, th, TA.FEATHER + 2, ox, oy, ts)
        if (right) cell(c, th, TA.FEATHER + 3, ox, oy, ts)
        if (!up && !left && isPatch(m, x - 1, y - 1)) cell(c, th, TA.FEATHER + 4, ox, oy, ts)
        if (!up && !right && isPatch(m, x + 1, y - 1)) cell(c, th, TA.FEATHER + 5, ox, oy, ts)
        if (!down && !left && isPatch(m, x - 1, y + 1)) cell(c, th, TA.FEATHER + 6, ox, oy, ts)
        if (!down && !right && isPatch(m, x + 1, y + 1)) cell(c, th, TA.FEATHER + 7, ox, oy, ts)
    }

    /** Draw one tile at screen position (ox, oy). [m] gives the neighbours, [g] the story flags. Positions must be whole pixels. */
    fun tile(c: Canvas, g: Game, m: GameMap, x: Int, y: Int, ox: Float, oy: Float, ts: Float, t: Float, part: Int = PART_ALL) {
        val tl = m.tile(x, y); val th = m.theme; val h = hash(x, y); val u = ts / 16f
        val indoors = th == Theme.INDOOR || th == Theme.KEEP
        val water = ((t * 3f).toInt() + h) % 4
        fun nb(dx: Int, dy: Int) = m.tile(x + dx, y + dy)
        val groundCell = { cell(c, th, TA.GROUND + (if (h % 8 < 4) 0 else if (h % 8 < 6) 3 else if (h % 8 == 6) 1 else 2), ox, oy, ts) }
        when (tl) {
            Tl.GROUND -> { groundCell(); feather(c, th, m, x, y, ox, oy, ts) }
            Tl.PATH -> {
                cell(c, th, TA.PATH + h % 3, ox, oy, ts)
                val grassy = { n: Tl -> n == Tl.GROUND || n == Tl.TALL || n == Tl.FLOWER || n == Tl.TREE || n == Tl.FENCE || n == Tl.ROCK || n == Tl.SAND }
                if (grassy(nb(0, -1))) cell(c, th, TA.PATH_EDGE + 0, ox, oy, ts)
                if (grassy(nb(0, 1))) cell(c, th, TA.PATH_EDGE + 1, ox, oy, ts)
                if (grassy(nb(-1, 0))) cell(c, th, TA.PATH_EDGE + 2, ox, oy, ts)
                if (grassy(nb(1, 0))) cell(c, th, TA.PATH_EDGE + 3, ox, oy, ts)
            }
            Tl.SAND -> cell(c, th, TA.SAND + h % 2, ox, oy, ts)
            Tl.TALL -> tallGrass(c, th, h % 3, grassStep(x, t), ox, oy, ts)
            Tl.TREE -> {
                // A 2x2 block of trees on the even grid is drawn as one big tree; every other tree is a small single-tile tree.
                // Every tile of a block makes the same decision, so a tree is never drawn half-way.
                val bx = x and -2; val by = y and -2
                val big = isBigTree(m, x, y)
                if (big) cell(c, th, TA.BIGTREE + (y - by) * 2 + (x - bx), ox, oy, ts)
                else cell(c, th, TA.TREE + h % 2, ox, oy, ts)
            }
            Tl.WATER, Tl.BRIDGE -> {
                cell(c, th, TA.WATER + (if (part == PART_BASE) 0 else water), ox, oy, ts)
                val wet = { n: Tl -> n == Tl.WATER || n == Tl.BRIDGE }
                if (!wet(nb(0, -1))) cell(c, th, TA.WATER_EDGE + 0, ox, oy, ts)
                if (!wet(nb(0, 1))) cell(c, th, TA.WATER_EDGE + 1, ox, oy, ts)
                if (!wet(nb(-1, 0))) cell(c, th, TA.WATER_EDGE + 2, ox, oy, ts)
                if (!wet(nb(1, 0))) cell(c, th, TA.WATER_EDGE + 3, ox, oy, ts)
                if (tl == Tl.WATER) {   // an outer corner of a pond is rounded (the cell is empty for themes with a foam shore)
                    if (!wet(nb(0, -1)) && !wet(nb(-1, 0))) cell(c, th, TA.WATER_CORNER + 0, ox, oy, ts)
                    if (!wet(nb(0, -1)) && !wet(nb(1, 0))) cell(c, th, TA.WATER_CORNER + 1, ox, oy, ts)
                    if (!wet(nb(0, 1)) && !wet(nb(-1, 0))) cell(c, th, TA.WATER_CORNER + 2, ox, oy, ts)
                    if (!wet(nb(0, 1)) && !wet(nb(1, 0))) cell(c, th, TA.WATER_CORNER + 3, ox, oy, ts)
                }
                if (tl == Tl.BRIDGE) cell(c, th, TA.BRIDGE, ox, oy, ts)
            }
            Tl.ROOF -> cell(c, th, TA.ROOF + (if (nb(0, -1) != Tl.ROOF) 4 else 0) + (if (nb(-1, 0) != Tl.ROOF) 2 else 0) + (if (nb(1, 0) != Tl.ROOF) 1 else 0), ox, oy, ts)
            Tl.WALL, Tl.DOOR -> {
                val eave = nb(0, -1) == Tl.ROOF
                if (tl == Tl.DOOR) cell(c, th, TA.DOOR + (if (eave) 1 else 0), ox, oy, ts)
                else {
                    val found = nb(0, 1) != Tl.WALL && nb(0, 1) != Tl.DOOR
                    val window = eave && h % 2 == 0
                    cell(c, th, TA.WALL + (if (window) 4 else 0) + (if (found) 2 else 0) + (if (eave) 1 else 0), ox, oy, ts)
                }
            }
            Tl.FLOWER -> cell(c, th, TA.FLOWER + h % 4, ox, oy, ts)
            Tl.FENCE -> cell(c, th, TA.FENCE + (if (nb(-1, 0) == Tl.FENCE) 1 else 0) + (if (nb(1, 0) == Tl.FENCE) 2 else 0) + (if (nb(0, -1) == Tl.FENCE) 4 else 0) + (if (nb(0, 1) == Tl.FENCE) 8 else 0), ox, oy, ts)
            Tl.SIGN -> cell(c, th, TA.SIGN, ox, oy, ts)
            Tl.ROCK -> cell(c, th, TA.ROCK, ox, oy, ts)
            Tl.LAVA -> {
                cell(c, th, TA.LAVA + ((t * 2.5f).toInt() + h) % 4, ox, oy, ts)
                if (nb(0, -1) != Tl.LAVA) cell(c, th, TA.LAVA_EDGE + 0, ox, oy, ts)
                if (nb(0, 1) != Tl.LAVA) cell(c, th, TA.LAVA_EDGE + 1, ox, oy, ts)
                if (nb(-1, 0) != Tl.LAVA) cell(c, th, TA.LAVA_EDGE + 2, ox, oy, ts)
                if (nb(1, 0) != Tl.LAVA) cell(c, th, TA.LAVA_EDGE + 3, ox, oy, ts)
            }
            Tl.FLOOR -> floorCell(c, th, h, ox, oy, ts)
            Tl.IWALL -> cell(c, th, TA.IWALL, ox, oy, ts)
            Tl.TABLE -> cell(c, th, TA.TABLE, ox, oy, ts)
            Tl.BED -> cell(c, th, TA.BED, ox, oy, ts)
            Tl.SHELF -> cell(c, th, TA.SHELF + h % 3, ox, oy, ts)
            Tl.STONE -> {
                if (indoors) floorCell(c, th, h, ox, oy, ts) else groundCell()
                cell(c, th, TA.STONE + ((t * 3f).toInt() + x) % 4, ox, oy, ts)
            }
            Tl.RUG -> {
                floorCell(c, th, h, ox, oy, ts)
                val a = m.accent; val edge = shade(a, 0.9f)
                rect(c, ox, oy, ts, ts, shade(a, 0.55f))
                if (nb(-1, 0) != Tl.RUG) rect(c, ox, oy, 2 * u, ts, edge)
                if (nb(1, 0) != Tl.RUG) rect(c, ox + 14 * u, oy, 2 * u, ts, edge)
                if (nb(0, -1) != Tl.RUG) rect(c, ox, oy, ts, 2 * u, edge)
                if (nb(0, 1) != Tl.RUG) rect(c, ox, oy + 14 * u, ts, 2 * u, edge)
                if ((x + y) % 2 == 0) rect(c, ox + 6 * u, oy + 6 * u, 4 * u, 4 * u, shade(a, 0.7f))
            }
            Tl.CRYSTAL -> {
                if (indoors) floorCell(c, th, h, ox, oy, ts) else groundCell()
                val a = m.accent; val pulse = 0.5f + 0.5f * sin(t * 2f + x)
                p.style = Paint.Style.FILL; p.color = Color.argb((60 * pulse).toInt() + 20, Color.red(a), Color.green(a), Color.blue(a))
                disc(c, ox + 8 * u, oy + 9 * u, 8 * u, p.color)
                val dark = shade(a, 0.62f)
                for (row in 1..14) {
                    val hw = if (row < 7) 1 + (row - 1) / 2 else if (row < 12) 4 else 3
                    val x0 = ox + (8 - hw) * u; val w = hw * 2 * u
                    rect(c, x0 - u, oy + row * u, w + 2 * u, u, rgb(26, 20, 44))
                    rect(c, x0, oy + row * u, w, u, shade(a, 0.9f)); rect(c, x0, oy + row * u, hw * u, u, shade(a, 1.25f)); rect(c, x0 + (hw * 2 - 1) * u, oy + row * u, u, u, dark)
                }
                rect(c, ox + 5 * u, oy + 15 * u, 6 * u, u, rgb(26, 20, 44)); rect(c, ox + 7 * u, oy + 2 * u, u, u, rgb(255, 255, 255))
            }
            Tl.ORB1, Tl.ORB2, Tl.ORB3 -> {
                floorCell(c, th, h, ox, oy, ts)
                rect(c, ox + 1 * u, oy + 6 * u, 14 * u, 10 * u, rgb(30, 22, 36)); rect(c, ox + 2 * u, oy + 7 * u, 12 * u, 8 * u, rgb(170, 116, 66))
                rect(c, ox + 2 * u, oy + 7 * u, 12 * u, 2 * u, rgb(212, 156, 98)); rect(c, ox + 2 * u, oy + 14 * u, 12 * u, u, rgb(120, 78, 44))
                rect(c, ox + 4 * u, oy + 9 * u, 8 * u, 3 * u, rgb(92, 92, 112)); rect(c, ox + 5 * u, oy + 9 * u, 6 * u, u, rgb(130, 130, 150))
                if (!g.f("starter")) {
                    val sp = DEX[tl.ordinal - Tl.ORB1.ordinal]; val pulse = 0.6f + 0.4f * sin(t * 3f + x)
                    disc(c, ox + 8 * u, oy + 5 * u, 7 * u, Color.argb((90 * pulse).toInt(), Color.red(sp.type.col), Color.green(sp.type.col), Color.blue(sp.type.col)))
                    disc(c, ox + 8 * u, oy + 5 * u, 5 * u, rgb(30, 22, 36)); disc(c, ox + 8 * u, oy + 5 * u, 4 * u, sp.type.col)
                    rect(c, ox + 6 * u, oy + 3 * u, 2 * u, u, rgb(255, 255, 255)); rect(c, ox + 6 * u, oy + 4 * u, u, u, rgb(255, 255, 255))
                }
            }
            Tl.GATE -> {
                // A tall stone archway (it draws upward into the cliff row above). Sockets glow once their Sigil is owned.
                groundCell()
                val first = (0..m.w).first { m.tile(it, y) == Tl.GATE }
                val count = (first until m.w).takeWhile { m.tile(it, y) == Tl.GATE }.size
                val idx = x - first; val edge = idx == 0 || idx == count - 1
                val stone = rgb(122, 114, 154); val dark = rgb(84, 78, 112); val top = oy - 14 * u
                val open = g.f("gate_open")
                rect(c, ox, top, ts, ts + 14 * u, stone)
                for (i in 0..4) rect(c, ox, top + (4 + i * 5) * u, ts, u, dark)
                rect(c, ox, top, ts, 2 * u, rgb(170, 162, 200))
                if (idx == 0) rect(c, ox, top, 3 * u, ts + 14 * u, dark)
                if (idx == count - 1) rect(c, ox + 13 * u, top, 3 * u, ts + 14 * u, dark)
                if (open) {
                    rect(c, ox + (if (idx == 0) 3f else 0f) * u, oy - 8 * u, ts - (if (edge) 3f else 0f) * u, ts + 8 * u, rgb(14, 10, 26))
                    val pulse = 0.5f + 0.5f * sin(t * 2f + x)
                    disc(c, ox + 8 * u, oy + 6 * u, 8 * u, Color.argb((90 * pulse).toInt() + 30, 200, 160, 255))
                } else {
                    val flags = arrayOf("sigil_leaf", "sigil_tide", "sigil_ember")
                    val cols = intArrayOf(rgb(70, 210, 110), rgb(70, 160, 250), rgb(255, 120, 50))
                    disc(c, ox + 8 * u, oy + 2 * u, 6 * u, shade(dark, 0.7f))
                    if (idx in 0..2) {
                        val own = g.f(flags[idx]); val pulse = 0.6f + 0.4f * sin(t * 2.5f + idx)
                        if (own) disc(c, ox + 8 * u, oy + 2 * u, 9 * u, Color.argb((110 * pulse).toInt(), Color.red(cols[idx]), Color.green(cols[idx]), Color.blue(cols[idx])))
                        disc(c, ox + 8 * u, oy + 2 * u, 5 * u, rgb(26, 22, 40)); disc(c, ox + 8 * u, oy + 2 * u, 4 * u, if (own) cols[idx] else rgb(44, 40, 62))
                    } else for (r in 0..4) rect(c, ox + (8 - r) * u, oy + (2 - 5 + r) * u, 2 * r * u + u, u, rgb(60, 54, 84)).also { rect(c, ox + (8 - r) * u, oy + (2 + 5 - r) * u, 2 * r * u + u, u, rgb(60, 54, 84)) }
                }
            }
            Tl.BELL -> {
                // The Bell is two tiles wide: each half draws its side around the shared edge, so camera cuts never hide it.
                cell(c, th, TA.FLOOR, ox, oy, ts)
                val left = m.tile(x + 1, y) == Tl.BELL
                val cx = if (left) ox + 16 * u else ox
                val done = g.f("ending"); val sw = if (done) Math.round(sin(t * 2.2f)).toFloat() * u else 0f
                rect(c, if (left) ox - 1 * u else ox, oy - 13 * u, 17 * u, 3 * u, rgb(96, 64, 40))
                rect(c, cx - 1 * u, oy - 10 * u, 2 * u, 12 * u, rgb(70, 70, 76))
                for (row in 0..13) {                       // the bell body widens towards the lip
                    val hw = 4 + row * 8 / 13; val yy = oy + (2 + row) * u
                    rect(c, cx - (hw + 1) * u + sw, yy, (hw * 2 + 2) * u, u, rgb(60, 38, 22))
                    rect(c, cx - hw * u + sw, yy, hw * 2 * u, u, rgb(214, 160, 56)); rect(c, cx - hw * u + sw, yy, 3 * u, u, rgb(250, 208, 100))
                }
                rect(c, cx - 13 * u, oy + 15 * u, 26 * u, u, rgb(60, 38, 22))
                if (done) { val pl = 0.6f + 0.4f * sin(t * 3f); disc(c, cx, oy + 14 * u, 6 * u, Color.argb((110 * pl).toInt(), 255, 230, 120)); disc(c, cx, oy + 14 * u, 3 * u, rgb(255, 240, 150)) }
                else disc(c, cx, oy + 14 * u, 3 * u, rgb(30, 22, 40))
            }
        }
    }

    // ---------------- people ----------------
    /**
     * A person standing with the middle of their feet at (cx, by). [moving] + [phase] (0..1 through the step) + [foot] (which foot
     * is forward, alternates every tile) pick the walking frame: stand, step, stand, step... [t] and [seed] are unused now.
     */
    fun person(c: Canvas, look: Look, cx: Float, by: Float, ts: Float, face: Int, moving: Boolean, phase: Float, t: Float, foot: Int = 0, seed: Int = 0) {
        val frame = if (!moving) 0 else if (phase in 0.18f..0.82f) 1 + (foot and 1) else 0
        val bm = spr.person(look, face, frame)
        val s = ts / 16f
        val lift = if (moving && frame != 0) 0f else 0f
        dst.set(Math.round(cx - 8 * s), Math.round(by - 23 * s - lift), Math.round(cx + 8 * s), Math.round(by + s - lift))
        c.drawBitmap(bm, null, dst, p)
    }

    /** A small overworld critter standing with its feet at (cx, by); [back] = seen from behind. */
    fun critter(c: Canvas, dex: Int, cx: Float, by: Float, ts: Float, back: Boolean, flip: Boolean = false) {
        spr.critterRect(dex, back, src)
        val s = ts / 16f
        if (flip) { c.save(); c.scale(-1f, 1f); dst.set(Math.round(-(cx + 8 * s)), Math.round(by - 15 * s), Math.round(-(cx - 8 * s)), Math.round(by + s)); c.drawBitmap(spr.critters, src, dst, p); c.restore() }
        else { dst.set(Math.round(cx - 8 * s), Math.round(by - 15 * s), Math.round(cx + 8 * s), Math.round(by + s)); c.drawBitmap(spr.critters, src, dst, p) }
    }

    /** A Critter Station kiosk: 16x24, its little light blinking. [by] is the bottom of its tile. */
    fun station(c: Canvas, cx: Float, by: Float, ts: Float, t: Float) {
        val s = ts / 16f
        spr.stationRect(if ((t * 1.4f).toInt() % 2 == 0) 0 else 1, src)
        dst.set(Math.round(cx - 8 * s), Math.round(by - 23 * s), Math.round(cx + 8 * s), Math.round(by + s))
        c.drawBitmap(spr.stations, src, dst, p)
    }

    /** A legendary critter standing in its sanctum: the 32x32 picture on a slowly pulsing halo, hovering a pixel, with drifting sparkles. */
    fun legend(c: Canvas, dex: Int, cx: Float, by: Float, ts: Float, t: Float, glow: Int) {
        val s = ts / 16f
        val pulse = sin(t * 2.2f) * 0.5f + 0.5f
        val r = Color.red(glow); val g = Color.green(glow); val b = Color.blue(glow)
        disc(c, cx, by - 14 * s, (19f + 1.5f * pulse) * s, Color.argb(30, r, g, b))
        disc(c, cx, by - 14 * s, (14f + 1.5f * pulse) * s, Color.argb(46, r, g, b))
        val bob = if (sin(t * 2.6f) > 0f) 0f else -s
        spr.legendRect(dex, src)
        dst.set(Math.round(cx - 16 * s), Math.round(by - 31 * s + bob), Math.round(cx + 16 * s), Math.round(by + s + bob))
        c.drawBitmap(spr.legends, src, dst, p)
        for (k in 0 until 4) {   // four sparkles rise and fade around it
            val ph = (t * 0.55f + k * 0.25f) % 1f
            val sx = cx + (if (k % 2 == 0) -1 else 1) * (12f + 4f * k) * s * 0.9f
            val sy = by - (6f + 26f * ph) * s
            val a = (255 * (1f - ph)).toInt().coerceIn(0, 255)
            val col = Color.argb(a, 255, 240, 170)
            rect(c, sx - s, sy, 3 * s, s, col); rect(c, sx, sy - s, s, 3 * s, col)
        }
    }

    /** "!" bubble over a trainer who just spotted you (above the head of a 24-pixel person). */
    fun alert(c: Canvas, cx: Float, by: Float, ts: Float) = emote(c, cx, by, ts, '!')

    /** A small speech bubble with one symbol: '!' (spotted you), '?' (curious) or the heart. */
    fun emote(c: Canvas, cx: Float, by: Float, ts: Float, glyph: Char) {
        val s = ts / 16f; val x = cx - 5 * s; val y = by - 38 * s
        rect(c, x + s, y, 8 * s, 11 * s, rgb(30, 26, 44)); rect(c, x, y + s, 10 * s, 9 * s, rgb(30, 26, 44))
        rect(c, x + s, y + s, 8 * s, 9 * s, Color.WHITE)
        rect(c, cx - 1 * s, y + 11 * s, 2 * s, 2 * s, rgb(30, 26, 44)); rect(c, cx - 1 * s, y + 10 * s, 2 * s, s, Color.WHITE)
        val col = when (glyph) { '!' -> rgb(224, 56, 48); '?' -> rgb(56, 96, 216); else -> rgb(232, 64, 112) }
        when (glyph) {
            '!' -> { rect(c, cx - 1 * s, y + 2 * s, 2 * s, 5 * s, col); rect(c, cx - 1 * s, y + 8 * s, 2 * s, 1.5f * s, col) }
            '?' -> { rect(c, cx - 2 * s, y + 2 * s, 4 * s, s, col); rect(c, cx + 1 * s, y + 3 * s, 1 * s, 2 * s, col); rect(c, cx - 0 * s, y + 5 * s, 1 * s, 1 * s, col); rect(c, cx - 1 * s, y + 6 * s, 1 * s, 1 * s, col); rect(c, cx - 1 * s, y + 8 * s, 1 * s, 1 * s, col) }
            else -> { rect(c, cx - 3 * s, y + 3 * s, 2 * s, 2 * s, col); rect(c, cx + 1 * s, y + 3 * s, 2 * s, 2 * s, col); rect(c, cx - 3 * s, y + 4 * s, 6 * s, 2 * s, col); rect(c, cx - 2 * s, y + 6 * s, 4 * s, 1 * s, col); rect(c, cx - 1 * s, y + 7 * s, 2 * s, 1 * s, col) }
        }
    }
}
