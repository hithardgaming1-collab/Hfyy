package com.example.critterquest

import kotlin.math.abs
import kotlin.random.Random

const val HOP_MS = 230L   // time for an ambient critter to hop one tile

/**
 * Small wild critters that just live in the scenery: they potter about their patch, hide in the tall grass, notice you
 * with a "!" and hop away. They are only for show: they never block you, start a fight or touch the story.
 * Species come from the map's wild table (so the critters you see are the ones you can meet there).
 * GameView owns one Life and calls [update] every frame.
 */
class Life {
    class Critter(val dex: Int, var x: Int, var y: Int, val homeX: Int, val homeY: Int) {
        var fx = x; var fy = y; var t0 = -10_000L; var face = DOWN; var nextAt = 0L; var noticedAt = -10_000L; var foot = 0
        fun moving(now: Long) = now - t0 < HOP_MS
        fun progress(now: Long) = ((now - t0) / HOP_MS.toFloat()).coerceIn(0f, 1f)
    }

    val critters = ArrayList<Critter>()
    private var mapId = ""
    private var owner: Game? = null

    private fun walkable(t: Tl) = t == Tl.GROUND || t == Tl.PATH || t == Tl.TALL || t == Tl.FLOWER || t == Tl.SAND

    private fun townSpecies(th: Theme): List<Int> = when (th) {
        Theme.MEADOW -> listOf(NIBBLET, PIPWING, WRIGGLET)
        Theme.FOREST -> listOf(BUDLING, WRIGGLET, HIVELET)
        Theme.SHORE -> listOf(PIPWING, FLOPFIN)
        Theme.ASH -> listOf(HISSLE, CINDERFOAL)
        Theme.KEEP -> listOf(WISPET)
        Theme.INDOOR -> emptyList()
    }

    private fun spawn(g: Game) {
        critters.clear()
        val m = g.map
        val rnd = Random(m.id.hashCode())
        val species = if (m.wild.isNotEmpty()) m.wild.flatMap { w -> List(w.weight) { w.sp } } else townSpecies(m.theme)
        if (species.isEmpty()) return
        val want = if (m.wild.isNotEmpty()) 6 else 3
        var tries = 0
        while (critters.size < want && tries++ < 400) {
            val x = rnd.nextInt(m.w); val y = rnd.nextInt(m.h)
            if (!walkable(m.tile(x, y))) continue
            if (m.wild.isNotEmpty() && m.tile(x, y) != Tl.TALL && rnd.nextInt(3) != 0) continue   // most hide in the tall grass
            if (abs(x - g.px) + abs(y - g.py) < 5 || !free(g, x, y, null)) continue
            critters.add(Critter(species[rnd.nextInt(species.size)], x, y, x, y).also { it.face = rnd.nextInt(4); it.nextAt = rnd.nextLong(2500) })
        }
    }

    private fun free(g: Game, x: Int, y: Int, self: Critter?): Boolean {
        val m = g.map
        if (x < 0 || y < 0 || x >= m.w || y >= m.h || !walkable(m.tile(x, y))) return false
        if (m.warpAt(x, y) != null || TRIGS.any { it.at(m.id, x, y) }) return false
        if (g.npcAt(x, y) != null) return false
        if ((x == g.px && y == g.py) || (x == g.fromX && y == g.fromY) || (x == g.fX && y == g.fY)) return false
        return critters.none { it !== self && ((it.x == x && it.y == y) || (it.fx == x && it.fy == y && it.t0 > 0)) }
    }

    /** True while [c] has just spotted the player (shows the "!" bubble). */
    fun startled(c: Critter, now: Long) = now - c.noticedAt < 900

    fun update(g: Game, now: Long) {
        if (owner !== g || mapId != g.map.id) { owner = g; mapId = g.map.id; spawn(g) }
        if (g.cur != null) return
        for (c in critters) {
            if (c.moving(now)) continue
            val near = maxOf(abs(c.x - g.px), abs(c.y - g.py)) <= 2
            val onPlayer = (c.x == g.px && c.y == g.py) || (c.x == g.fX && c.y == g.fY && !(g.fX == g.px && g.fY == g.py))
            if (!onPlayer && now < c.nextAt) continue
            var d = -1
            if (near || onPlayer) {
                if (now - c.noticedAt > 3500) c.noticedAt = now
                // hop to the free neighbour that is furthest from the player
                var best = -1
                for (k in 0..3) {
                    val nx = c.x + DX[k]; val ny = c.y + DY[k]
                    if (!free(g, nx, ny, c)) continue
                    val dist = abs(nx - g.px) + abs(ny - g.py)
                    if (dist > best) { best = dist; d = k }
                }
                c.nextAt = now + 380
            } else {
                val k = rnd(c, now)
                val nx = c.x + DX[k]; val ny = c.y + DY[k]
                c.face = k
                if (abs(nx - c.homeX) <= 4 && abs(ny - c.homeY) <= 3 && free(g, nx, ny, c)) d = k
                c.nextAt = now + 900 + (now * 31 + c.x * 17 + c.y * 7) % 2600
            }
            if (d >= 0) { c.fx = c.x; c.fy = c.y; c.x += DX[d]; c.y += DY[d]; c.face = d; c.t0 = now; c.foot = c.foot xor 1 }
        }
    }

    private fun rnd(c: Critter, now: Long) = (((now / 7) + c.x * 5 + c.y * 3 + c.dex).toInt() and 0x7fffffff) % 4
}
