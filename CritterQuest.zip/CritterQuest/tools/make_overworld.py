#!/usr/bin/env python3
"""Shrinks every critter's battle sprite into a 16x16 overworld sprite (for the follower and the wild critters walking about).

Writes app/.../res/drawable-nodpi/ow_critters.png: one column per species in DEX order (read from Critters.kt),
row 0 = seen from the front, row 1 = seen from behind. Each is cut to its shape, reduced to a handful of colours
and given a dark outline, so it reads like a tiny handheld sprite. Run after adding a species.
"""
import os, re
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, "..", "app", "src", "main", "res", "drawable-nodpi")
SRC = os.path.join(HERE, "..", "app", "src", "main", "java", "com", "example", "critterquest", "Critters.kt")

def dex_order():
    text = open(SRC).read()
    return re.findall(r'^\s*Species\("([A-Za-z]+)"', text, re.M)

def legend_order():
    """Names of the legendary species (rarity = Rarity.LEGENDARY), in DEX order."""
    text = open(SRC).read()
    return [m.group(1) for m in re.finditer(r'Species\("([A-Za-z]+)"(?:(?!\n    Species\().)*?Rarity\.LEGENDARY', text, re.S)]

def largest_blob(im):
    """Keeps only the biggest connected shape: the legendaries' loose sparkles would otherwise shrink the critter."""
    w, h = im.size; px = im.load(); seen = set(); best = []
    for y in range(h):
        for x in range(w):
            if px[x, y][3] and (x, y) not in seen:
                comp = [(x, y)]; seen.add((x, y)); i = 0
                while i < len(comp):
                    cx, cy = comp[i]; i += 1
                    for dx in (-1, 0, 1):
                        for dy in (-1, 0, 1):
                            n = (cx + dx, cy + dy)
                            if 0 <= n[0] < w and 0 <= n[1] < h and px[n][3] and n not in seen: seen.add(n); comp.append(n)
                if len(comp) > len(best): best = comp
    out = Image.new("RGBA", im.size, (0, 0, 0, 0)); op = out.load()
    for p in best: op[p] = px[p]
    return out

def tiny(path, size=14, canvas=16, colors=7, clean=False):
    im = Image.open(path).convert("RGBA")
    if clean: im = largest_blob(im)
    im = im.crop(im.getbbox())
    k = size / max(im.size)
    w, h = max(1, round(im.width * k)), max(1, round(im.height * k))
    small = im.resize((w, h), Image.BOX)
    px = small.load()
    # cut a clean silhouette, then reduce colours so it looks hand-placed
    for y in range(h):
        for x in range(w):
            r, g, b, a = px[x, y]
            px[x, y] = (r, g, b, 255) if a >= 110 else (0, 0, 0, 0)
    rgb = Image.new("RGB", small.size, (0, 255, 0)); rgb.paste(small, mask=small.getchannel("A"))
    q = rgb.quantize(colors=colors, method=Image.MEDIANCUT).convert("RGB")
    out = Image.new("RGBA", (canvas, canvas), (0, 0, 0, 0)); op = out.load(); qp = q.load()
    ox, oy = (canvas - w) // 2, canvas - h - 1
    for y in range(h):
        for x in range(w):
            if px[x, y][3]:
                op[ox + x, oy + y] = qp[x, y] + (255,)
    # dark outline: transparent pixels touching the shape become dark; and the shape's own rim is darkened a little
    base = out.copy(); bp = base.load()
    for y in range(canvas):
        for x in range(canvas):
            if bp[x, y][3] == 0:
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < canvas and 0 <= ny < canvas and bp[nx, ny][3]:
                        r, g, b, _ = bp[nx, ny]; op[x, y] = (int(r * .28) + 8, int(g * .28) + 6, int(b * .28) + 14, 255); break
    return out

def main():
    names = dex_order()
    legends = set(legend_order())
    atlas = Image.new("RGBA", (16 * len(names), 32), (0, 0, 0, 0))
    for i, n in enumerate(names):
        for row, view in enumerate(("front", "back")):
            atlas.paste(tiny(os.path.join(RES, f"{n.lower()}_{view}.png"), clean=n in legends), (i * 16, row * 16))
    atlas.save(os.path.join(RES, "ow_critters.png"))
    # the legendaries also get a bigger 32x32 picture for standing in their sanctums (front view only)
    lnames = legend_order()
    big = Image.new("RGBA", (32 * len(lnames), 32), (0, 0, 0, 0))
    for i, n in enumerate(lnames):
        big.paste(tiny(os.path.join(RES, f"{n.lower()}_front.png"), size=30, canvas=32, colors=11, clean=True), (i * 32, 0))
    big.save(os.path.join(RES, "ow_legends.png"))
    print("ow_legends.png:", len(lnames), "legendaries")
    S = 4
    prev = Image.new("RGBA", (len(names) * 16 * S // 2 * 1 + 8, 32 * S + 8), (170, 220, 140, 255))
    big = atlas.resize((atlas.width * S // 2 * 1, atlas.height * S // 2 * 1), Image.NEAREST)
    big2 = atlas.resize((atlas.width * 3, atlas.height * 3), Image.NEAREST)
    prev = Image.new("RGBA", big2.size, (170, 220, 140, 255)); prev.alpha_composite(big2)
    prev.save(os.path.join(HERE, "ow_preview.png"))
    print("ow_critters.png:", len(names), "species")

if __name__ == "__main__":
    main()
