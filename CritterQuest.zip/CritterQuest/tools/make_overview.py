"""Stitches docs/maps/*.png into docs/world_overview.png (the picture at the top of MAPS.md).
Run `./run.sh maps` first (it redraws docs/maps), then this. Every map is scaled to the same cell width."""
import os, re
from PIL import Image, ImageDraw, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
DOCS = os.path.join(HERE, "..", "docs")
MAPS_KT = os.path.join(HERE, "..", "app", "src", "main", "java", "com", "example", "critterquest", "Maps.kt")
ORDER = ["home", "mossbrook", "lab", "route1", "briar", "leafshrine", "route2", "tidewatch", "tideshrine", "route3", "cinder",
         "embershrine", "route4", "keep", "heart", "grove", "grotto", "crater", "hollow"]
COLS, CELL, GAP, MARGIN, LABEL = 4, 242, 14, 14, 24

def font(size):
    p = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
    return ImageFont.truetype(p, size) if os.path.exists(p) else ImageFont.load_default()

def main():
    names = dict(re.findall(r'GameMap\("(\w+)", "([^"]+)"', open(MAPS_KT).read()))
    tiles = []
    for mid in ORDER:
        im = Image.open(os.path.join(DOCS, "maps", f"{mid}.png")).convert("RGB")
        tiles.append((names[mid], im.resize((CELL, max(1, round(im.height * CELL / im.width))), Image.LANCZOS)))
    rows = [tiles[i:i + COLS] for i in range(0, len(tiles), COLS)]
    top = 52
    height = top + sum(max(t[1].height for t in r) + LABEL + GAP for r in rows) + MARGIN
    sheet = Image.new("RGB", (MARGIN + COLS * (CELL + GAP), height), (22, 24, 38))
    d = ImageDraw.Draw(sheet)
    d.text((MARGIN, 14), "CRITTER QUEST  -  the Critterlands", font=font(22), fill=(255, 225, 120))
    y = top
    for r in rows:
        for c, (name, im) in enumerate(r):
            x = MARGIN + c * (CELL + GAP)
            d.text((x, y), name, font=font(14), fill=(225, 228, 240))
            sheet.paste(im, (x, y + LABEL))
        y += max(t[1].height for t in r) + LABEL + GAP
    out = os.path.join(DOCS, "world_overview.png"); sheet.save(out); print("wrote", out, sheet.size)

if __name__ == "__main__":
    main()
