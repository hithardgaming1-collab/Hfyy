#!/usr/bin/env python3
"""Draws the 16x24 pixel characters and writes app/.../res/drawable-nodpi/people.png (+ tools/people_preview.png).

The atlas is drawn in MARKER colours; the game recolours it for each person (hair, skin, top, legs) when it starts, see Sprites.kt.
Layout: one cell is 16x24. Column = frame (0 standing, 1 left foot forward, 2 right foot forward).
Row = outfit * 3 + direction (0 facing down, 1 facing up, 2 facing left; facing right is the left sprite mirrored).
Outfits: 0 plain, 1 cap, 2 lab coat, 3 hood, 4 robe (same numbers as K_PLAIN..K_ROBE in World.kt).

Proportions follow the chunky handheld look: a big 12-pixel head (cap or hair), a short 5-row body, arms that hang a little
away from the body, short legs and a near-black outline. The sprite fills rows 3..23 of the cell, feet on the bottom row.
"""
import os
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, "..", "app", "src", "main", "res", "drawable-nodpi")

def C(r, g, b, a=255): return (r, g, b, a)
# markers: the game replaces these exact colours
HAIR, HAIRS, HAIRL = C(255, 0, 0), C(190, 0, 0), C(255, 90, 90)
SKIN, SKINS = C(255, 0, 255), C(190, 0, 190)
TOP, TOPS, TOPL = C(0, 255, 0), C(0, 190, 0), C(120, 255, 120)
LEGS, LEGSS = C(0, 0, 255), C(0, 0, 190)
# fixed colours
INK = C(24, 20, 34); SHOE = C(58, 44, 52); SHOEL = C(110, 92, 92); EYE = C(24, 20, 30); WHITE = C(250, 250, 252)
CAP, CAPD, CAPL = C(222, 66, 52), C(150, 32, 40), C(250, 126, 98)
COATW, COATS, COATL = C(236, 238, 246), C(184, 190, 208), C(255, 255, 255)
EMBLEM = C(160, 80, 200)
BLUSH = C(255, 150, 150)
BAG, BAGS = C(236, 184, 64), C(176, 124, 40)

class S:
    def __init__(s):
        s.im = Image.new("RGBA", (16, 24), (0, 0, 0, 0)); s.px = s.im.load()
    def p(s, x, y, c):
        if 0 <= x < 16 and 0 <= y < 24: s.px[x, y] = c
    def r(s, x, y, w, h, c):
        for yy in range(y, y + h):
            for xx in range(x, x + w): s.p(xx, yy, c)
    def outline(s):
        src = s.im.copy(); sp = src.load()
        for y in range(24):
            for x in range(16):
                if sp[x, y][3] == 0:
                    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        nx, ny = x + dx, y + dy
                        if 0 <= nx < 16 and 0 <= ny < 24 and sp[nx, ny][3] > 0: s.px[x, y] = INK; break

# the head: a 12-wide rounded block, rows 4..13 (x ranges per row)
HEAD = {4: (5, 10), 5: (3, 12), 6: (2, 13), 7: (2, 13), 8: (2, 13), 9: (2, 13), 10: (2, 13), 11: (2, 13), 12: (3, 12), 13: (4, 11)}

def head_base(s):
    for y, (a, b) in HEAD.items():
        s.r(a, y, b - a + 1, 1, SKIN); s.p(b, y, SKINS)
    s.r(4, 13, 8, 1, SKINS)

def hair_rows(s, y0, y1):
    for y in range(y0, y1 + 1):
        a, b = HEAD[y]; s.r(a, y, b - a + 1, 1, HAIR); s.p(b, y, HAIRS)

def cap_rows(s, y0, y1):
    for y in range(y0, y1 + 1):
        a, b = HEAD[y]; s.r(a, y, b - a + 1, 1, CAP); s.p(b, y, CAPD)

def head_down(s, kind):
    head_base(s)
    if kind == 3:                                                    # hood: a face opening in a hood
        for y in range(4, 14):
            a, b = HEAD[y]; s.r(a, y, b - a + 1, 1, TOP); s.p(b, y, TOPS)
        s.r(4, 7, 8, 6, SKIN); s.r(4, 7, 8, 1, TOPS); s.r(11, 8, 1, 4, SKINS); s.r(4, 13, 8, 1, TOPS)
        s.r(5, 5, 3, 1, TOPL); s.r(5, 9, 1, 2, EYE); s.r(10, 9, 1, 2, EYE); s.p(4, 11, BLUSH); s.p(11, 11, BLUSH)
        return
    if kind == 1:                                                    # cap with a badge, hair at the sides
        cap_rows(s, 4, 7); s.r(3, 8, 10, 1, CAPD)
        s.r(5, 5, 3, 1, CAPL); s.r(7, 6, 2, 2, WHITE); s.p(8, 7, CAPL)
        s.r(2, 8, 1, 3, HAIR); s.r(13, 8, 1, 3, HAIRS); s.r(3, 9, 1, 1, HAIR); s.p(12, 9, HAIRS)
    else:
        hair_rows(s, 4, 7); s.r(5, 5, 3, 1, HAIRL)
        s.r(4, 8, 3, 1, HAIR); s.r(9, 8, 3, 1, HAIR); s.p(11, 8, HAIRS)
        s.r(2, 8, 2, 3, HAIR); s.r(12, 8, 2, 3, HAIR); s.r(13, 8, 1, 3, HAIRS)
    s.r(5, 10, 1, 2, EYE); s.r(10, 10, 1, 2, EYE)
    s.p(3, 12, BLUSH); s.p(12, 12, BLUSH)

def head_up(s, kind):
    head_base(s)
    if kind == 3:
        for y in range(4, 14):
            a, b = HEAD[y]; s.r(a, y, b - a + 1, 1, TOP); s.p(b, y, TOPS)
        s.r(5, 5, 3, 1, TOPL); s.r(7, 8, 2, 5, TOPS); s.r(4, 13, 8, 1, TOPS)
        return
    if kind == 1:
        cap_rows(s, 4, 9); s.r(3, 9, 10, 1, CAPD); s.r(5, 5, 3, 1, CAPL); s.r(7, 4, 2, 1, CAPD)
        s.r(3, 10, 10, 2, HAIR); s.r(12, 10, 1, 2, HAIRS); s.r(5, 12, 6, 1, SKIN); s.r(5, 13, 6, 1, SKINS)
        return
    hair_rows(s, 4, 11); s.r(5, 5, 3, 1, HAIRL); s.r(5, 8, 6, 1, HAIRS)
    s.r(4, 12, 8, 1, SKIN); s.r(4, 13, 8, 1, SKINS)

def head_left(s, kind):
    head_base(s)
    s.p(1, 10, SKIN)                                                 # the nose
    if kind == 3:
        for y in range(4, 14):
            a, b = HEAD[y]; s.r(a, y, b - a + 1, 1, TOP); s.p(b, y, TOPS)
        s.r(2, 7, 4, 6, SKIN); s.r(2, 7, 4, 1, TOPS); s.r(2, 13, 4, 1, TOPS); s.r(5, 8, 1, 4, SKINS)
        s.r(4, 5, 3, 1, TOPL); s.r(3, 9, 1, 2, EYE); s.p(1, 10, SKIN)
        return
    if kind == 1:
        cap_rows(s, 4, 7); s.r(1, 7, 3, 1, CAP); s.r(0, 8, 7, 1, CAPD); s.r(5, 8, 8, 1, CAPD)
        s.r(4, 5, 3, 1, CAPL); s.p(9, 6, WHITE)
        s.r(8, 9, 5, 3, HAIR); s.r(12, 9, 1, 3, HAIRS); s.r(7, 9, 1, 2, HAIR)
    else:
        hair_rows(s, 4, 7); s.r(4, 5, 3, 1, HAIRL)
        s.r(2, 8, 3, 1, HAIR); s.r(8, 8, 5, 4, HAIR); s.r(12, 8, 1, 4, HAIRS); s.r(7, 8, 1, 2, HAIR)
    s.r(3, 10, 1, 2, EYE); s.p(2, 12, BLUSH)

def body_front(s, direction, frame, kind):
    """Torso rows 14..18 with arms hanging a little away from it; coats and robes are longer."""
    back = direction == "up"
    coat = kind == 2; robe = kind == 4
    topc, tops, topl = (COATW, COATS, COATL) if coat else (TOP, TOPS, TOPL)
    end = 20 if coat else 21 if robe else 18
    la, ra = {0: (0, 0), 1: (-1, 1), 2: (1, -1)}[frame]             # arm swing: one hand forward, the other back
    if robe:
        s.r(4, 14, 8, 3, topc); s.r(3, 17, 10, end - 16, topc); s.r(11, 14, 1, 3, tops); s.r(12, 17, 1, end - 16, tops)
        s.r(5, 14, 1, 3, topl); s.r(4, 17, 1, end - 16, topl)
        s.r(3, end, 10, 1, tops); s.r(7, 15, 2, end - 14, tops) if not back else None
        for ax, aoff, sh in ((1, la, False), (13, ra, True)):        # wide sleeves
            s.r(ax, 14 + aoff, 2, 4, tops if sh else topc); s.r(ax, 18 + aoff, 2, 1, SKIN if not sh else SKINS)
        return
    s.r(4, 14, 8, end - 13, topc); s.r(11, 14, 1, end - 13, tops); s.r(5, 14, 1, 3, topl); s.r(4, end, 8, 1, tops)
    if coat:
        if not back: s.r(7, 14, 2, end - 13, COATS); s.p(7, 15, TOP); s.p(8, 15, TOP); s.r(6, 14, 1, 2, TOP); s.r(9, 14, 1, 2, TOP)
        else: s.r(7, 16, 2, end - 15, COATS)
    elif kind == 3 and not back:
        s.r(7, 15, 2, 2, EMBLEM)
    elif kind == 1 and back:
        s.r(5, 15, 6, 3, BAG); s.r(5, 17, 6, 1, BAGS); s.r(10, 15, 1, 3, BAGS); s.r(6, 15, 4, 1, C(255, 214, 110))
    elif kind == 0 and not back:
        s.r(6, 15, 4, 1, topl); s.r(7, 16, 2, 2, tops)
    for ax, aoff, left in ((2, la, True), (12, ra, False)):         # arms (2 wide) with a dark gap between them and the lower torso
        arm = topc if left else tops
        s.r(ax, 14 + aoff, 2, 4, arm); s.r(ax + (0 if left else 1), 14 + aoff, 1, 4, topl if left else tops)
        s.r(ax, 18 + aoff, 2, 1, SKIN if left else SKINS)
        if coat: s.r(ax, 17 + aoff, 2, 1, COATS)
    s.p(4, 16, INK); s.p(4, 17, INK); s.p(11, 16, INK); s.p(11, 17, INK)  # gap between arm and torso

def body_side(s, frame, kind):
    coat = kind == 2; robe = kind == 4
    topc, tops, topl = (COATW, COATS, COATL) if coat else (TOP, TOPS, TOPL)
    end = 20 if coat else 21 if robe else 18
    xa, xb = (4, 11) if robe else (5, 10)
    s.r(xa, 14, xb - xa + 1, end - 13, topc); s.r(xb, 14, 1, end - 13, tops); s.r(xa, end, xb - xa + 1, 1, tops)
    if kind == 3: s.r(5, 15, 1, 2, EMBLEM)
    if kind == 1: s.r(9, 15, 2, 3, BAG); s.r(10, 15, 1, 3, BAGS)       # the bag on the back
    sw = {0: 0, 1: -2, 2: 2}[frame]                                   # the near arm swings forwards and back
    ax = 6 + sw
    s.r(ax, 14, 3, 4, topc if not robe else topc); s.r(ax + 2, 14, 1, 4, tops); s.r(ax, 14, 1, 3, topl)
    s.r(ax, 18, 3, 1, SKIN)

def legs_front(s, direction, frame, kind):
    robe = kind == 4; coat = kind == 2
    if robe:
        a = 1 if frame == 1 else 0; b = 1 if frame == 2 else 0
        s.r(5, 22 - a, 3, 1 + a, SHOE); s.r(8, 22 - b, 3, 1 + b, SHOE); return
    top = 21 if coat else 19
    la = 1 if frame == 1 else 0; ra = 1 if frame == 2 else 0          # a raised foot is one row higher
    s.r(5, top, 3, 22 - top - la, LEGS); s.r(7, top, 1, 22 - top - la, LEGSS)
    s.r(8, top, 3, 22 - ra - top, LEGS); s.r(10, top, 1, 22 - top - ra, LEGSS)
    s.r(4, 21 - la, 4, 2, SHOE); s.r(8, 21 - ra, 4, 2, SHOE)
    if direction == "down":
        s.r(4, 21 - la, 4, 1, SHOEL); s.r(8, 21 - ra, 4, 1, SHOEL)

def legs_side(s, frame, kind):
    robe = kind == 4; coat = kind == 2
    if robe:
        s.r(5, 22, 3, 1, SHOE); s.r(8, 22, 3, 1, SHOE) if frame else s.r(8, 22, 2, 1, SHOE); return
    top = 21 if coat else 19
    if frame == 0:
        s.r(6, top, 4, 22 - top, LEGS); s.r(9, top, 1, 22 - top, LEGSS); s.r(5, 21, 6, 2, SHOE)
    elif frame == 1:                                                  # front (left) foot forward and up, back foot behind
        s.r(4, top, 3, 2, LEGS); s.r(3, 21, 4, 1, SHOE); s.r(3, 20, 2, 1, LEGS)
        s.r(9, top, 3, 3, LEGSS); s.r(9, 21, 4, 2, SHOE)
    else:
        s.r(5, top, 3, 3, LEGSS); s.r(4, 21, 4, 2, SHOE)
        s.r(9, top, 3, 2, LEGS); s.r(9, 21, 4, 1, SHOE); s.r(11, 20, 2, 1, LEGS)

def make(kind, direction, frame):
    s = S()
    if direction == "side":
        legs_side(s, frame, kind); body_side(s, frame, kind); head_left(s, kind)
    else:
        legs_front(s, direction, frame, kind); body_front(s, direction, frame, kind)
        (head_up if direction == "up" else head_down)(s, kind)
    s.outline()
    return s.im

def build():
    atlas = Image.new("RGBA", (3 * 16, 15 * 24), (0, 0, 0, 0))
    for kind in range(5):
        for di, d in enumerate(("down", "up", "side")):
            for f in range(3):
                atlas.paste(make(kind, d, f), (f * 16, (kind * 3 + di) * 24))
    return atlas

def recolor(im, skin, hair, top, legs):
    def sh(c, k): return tuple(max(0, min(255, int(v * k))) for v in c[:3]) + (255,)
    m = {HAIR: hair + (255,), HAIRS: sh(hair, .75), HAIRL: sh(hair, 1.35), SKIN: skin + (255,), SKINS: sh(skin, .82),
         TOP: top + (255,), TOPS: sh(top, .76), TOPL: sh(top, 1.25), LEGS: legs + (255,), LEGSS: sh(legs, .72)}
    out = im.copy(); px = out.load()
    for y in range(out.height):
        for x in range(out.width):
            if px[x, y] in m: px[x, y] = m[px[x, y]]
    return out

def main():
    atlas = build()
    atlas.save(os.path.join(RES, "people.png"))
    looks = [((236, 190, 150), (70, 45, 30), (220, 60, 60), (50, 60, 110)), ((236, 190, 150), (180, 110, 60), (240, 200, 50), (70, 70, 90)),
             ((236, 190, 150), (230, 230, 235), (60, 120, 80), (60, 60, 60)), ((236, 190, 150), (210, 210, 220), (240, 240, 245), (60, 70, 100)),
             ((236, 190, 150), (60, 50, 70), (110, 50, 150), (40, 40, 50))]
    S_ = 4
    sheet = Image.new("RGBA", (5 * 3 * 3 * 16 * S_ // 3 * 1, 1), (0, 0, 0, 0))
    W = 5 * (3 * 16 * 2 + 6) * 2 // 2
    sheet = Image.new("RGBA", (5 * 3 * 16 * S_ + 40, 6 * 24 * S_ // 1 + 10), (170, 220, 140, 255))
    # rows: facing down, left (side), up; each outfit one column group of 3 frames
    for kind in range(5):
        sk, ha, tp, lg = looks[kind]
        for fi in range(3):
            x = (kind * 3 + fi) * 16 * S_ + kind * 8
            for ri, di in enumerate((0, 2, 1)):
                cell = atlas.crop((fi * 16, (kind * 3 + di) * 24, fi * 16 + 16, (kind * 3 + di) * 24 + 24))
                cell = recolor(cell, sk, ha, tp, lg).resize((16 * S_, 24 * S_), Image.NEAREST)
                sheet.alpha_composite(cell, (x, ri * 24 * S_ + 4))
    sheet.crop((0, 0, sheet.width, 3 * 24 * S_ + 8)).save(os.path.join(HERE, "people_preview.png"))
    print("people.png", atlas.size)

if __name__ == "__main__":
    main()
