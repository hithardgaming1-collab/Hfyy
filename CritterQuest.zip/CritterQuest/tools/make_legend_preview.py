"""Labelled sheet of the legendary critters -> tools/legend_preview.png
For each legendary: battle front and back (64x64, shown 3x), the 32x32 sanctum picture (4x) and the 16x16 follower (6x).
Run after editing the legendary body plans in sprites_extra.py (and make_sprites.py / make_overworld.py)."""
import os, re
from PIL import Image, ImageDraw, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, "..", "app", "src", "main", "res", "drawable-nodpi")
SRC = os.path.join(HERE, "..", "app", "src", "main", "java", "com", "example", "critterquest", "Critters.kt")

def font(size, bold=True):
    for p in ("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",):
        if os.path.exists(p): return ImageFont.truetype(p, size)
    return ImageFont.load_default()

def legends():
    text = open(SRC).read()
    out = []
    for m in re.finditer(r'Species\("([A-Za-z]+)", T\.(\w+), (?:T\.(\w+)|null)(?:(?!\n    Species\().)*?catchRate = (\d+), rarity = Rarity\.LEGENDARY', text, re.S):
        out.append((m.group(1), m.group(2).title() + ("/" + m.group(3).title() if m.group(3) else ""), int(m.group(4))))
    return out

def main():
    L = legends()
    ow = Image.open(os.path.join(RES, "ow_critters.png")).convert("RGBA")
    big = Image.open(os.path.join(RES, "ow_legends.png")).convert("RGBA")
    names = re.findall(r'^\s*Species\("([A-Za-z]+)"', open(SRC).read(), re.M)
    CW, CH = 570, 330
    sheet = Image.new("RGB", (CW * 2 + 30, CH * 2 + 70), (22, 24, 38))
    d = ImageDraw.Draw(sheet)
    d.text((16, 12), "CRITTER QUEST  -  the four legendary critters", font=font(24), fill=(255, 225, 120))
    for i, (n, ty, cr) in enumerate(L):
        x0 = 10 + (i % 2) * (CW + 10); y0 = 54 + (i // 2) * (CH + 6)
        d.rounded_rectangle((x0, y0, x0 + CW, y0 + CH), 12, fill=(36, 40, 62), outline=(70, 78, 118))
        d.text((x0 + 14, y0 + 8), n, font=font(22), fill=(240, 244, 255))
        d.rounded_rectangle((x0 + 14 + 8 + d.textlength(n, font=font(22)), y0 + 10, x0 + 14 + 8 + d.textlength(n, font=font(22)) + 46, y0 + 32), 5, fill=(214, 150, 20))
        d.text((x0 + 14 + 14 + d.textlength(n, font=font(22)), y0 + 13), "LEG", font=font(15), fill=(255, 255, 255))
        d.text((x0 + 14, y0 + 38), f"{ty}   catch rate {cr}", font=font(14, False), fill=(170, 180, 215))
        for j, view in enumerate(("front", "back")):
            im = Image.open(os.path.join(RES, f"{n.lower()}_{view}.png")).convert("RGBA").resize((192, 192), Image.NEAREST)
            sheet.paste(im, (x0 + 10 + j * 196, y0 + 62), im)
        b = big.crop((i * 32, 0, i * 32 + 32, 32)).resize((128, 128), Image.NEAREST)
        sheet.paste(b, (x0 + 10 + 2 * 196 + 6, y0 + 62), b)
        k = names.index(n)
        s = ow.crop((k * 16, 0, k * 16 + 16, 16)).resize((96, 96), Image.NEAREST)
        sheet.paste(s, (x0 + 10 + 2 * 196 + 22, y0 + 196), s)
        d.text((x0 + 14 + 6, y0 + CH - 28), "battle front / back", font=font(12, False), fill=(130, 140, 180))
        d.text((x0 + 10 + 2 * 196 + 30, y0 + CH - 28), "world / follower", font=font(12, False), fill=(130, 140, 180))
    out = os.path.join(HERE, "legend_preview.png")
    sheet.save(out); print("wrote", out, f"({len(L)} legendaries)")

if __name__ == "__main__":
    main()
