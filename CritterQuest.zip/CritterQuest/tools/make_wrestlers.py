"""Wrestler template -> app/src/main/res/drawable-nodpi/wrestlers.png  (see ASSETS.md; used by WrestlerSprites in MatchArt.kt).

One sheet in MARKER colours, like people.png: the game recolours it for every wrestler from his WLook (Wrestlers.kt), so a new
wrestler never needs new art. Cells are 32x32. Columns are the poses in FRAMES below (same order as the WF constants in
MatchArt.kt); rows are the three body types: 0 normal, 1 big, 2 giant. The figures are built from the plain people.png sprites:
bare chest (SKIN), trunks (LEGS), boots (the people.png shoe colours), plus a MASK and a BEARD marker that the game fills with
skin colour when the wrestler has neither.
Run:  python3 tools/make_wrestlers.py     (needs Pillow; also writes tools/wrestlers_preview.png)"""
import os
from PIL import Image, ImageDraw

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, "..", "app", "src", "main", "res", "drawable-nodpi")
OUT = os.path.join(RES, "wrestlers.png")
CELL = 32

INK = (24, 20, 34); EYE = (24, 20, 30)
SKIN = (255, 0, 255); SKINS = (190, 0, 190)
LEGS = (0, 0, 255); LEGSS = (0, 0, 190)
MASK = (255, 255, 0); MASKS = (190, 190, 0)
BEARD = (0, 255, 255); BEARDS = (0, 190, 190)
SHOE = (58, 44, 52)
TOPS_ = {(0, 255, 0): SKIN, (0, 190, 0): SKINS, (120, 255, 120): SKIN}           # chest and arms: bare skin
WAIST = {(0, 255, 0): LEGS, (0, 190, 0): LEGSS, (120, 255, 120): LEGS}            # from the waist down: trunks

FRAMES = ["front0", "front1", "front2", "back", "r0", "r1", "r2", "l0", "l1", "l2", "cheer", "punch_r", "punch_l", "kick_r", "kick_l",
          "hurt_r", "hurt_l", "lie_r", "lie_l", "upside", "kneel_r", "kneel_l", "run_r1", "run_r2", "run_l1", "run_l2", "flex",
          "dive_r", "dive_l"]
BODIES = [(0, 0), (2, 1), (4, 2)]                                                   # (extra width, extra height)

people = Image.open(os.path.join(RES, "people.png")).convert("RGBA")


def rgba(c, a=255):
    return (c[0], c[1], c[2], a)


def widen(im, extra, grow, cols=(7, 8), body_row=16):
    w, h = im.size
    if extra:
        span = cols[1] - cols[0] + 1
        src = list(range(0, cols[1] + 1)) + [cols[0] + (i % span) for i in range(extra)] + list(range(cols[1] + 1, w))
        out = Image.new("RGBA", (len(src), h), (0, 0, 0, 0))
        for i, c in enumerate(src):
            out.alpha_composite(im.crop((c, 0, c + 1, h)), (i, 0))
        im = out
    if grow:
        w, h = im.size
        out = Image.new("RGBA", (w, h + grow), (0, 0, 0, 0))
        for y in range(h + grow):
            s = y if y <= body_row else (body_row if y <= body_row + grow else y - grow)
            out.alpha_composite(im.crop((0, s, w, s + 1)), (0, y))
        im = out
    return im


def base(face, frame, body):
    """The 16x24 plain person facing left/down/up as a wrestler, in marker colours, then made chunkier for bigger bodies."""
    row = {"down": 0, "up": 1, "left": 2}[face]
    im = people.crop((frame * 16, row * 24, frame * 16 + 16, row * 24 + 24)).copy()
    px = im.load()
    for y in range(24):
        for x in range(16):
            r, g, b, a = px[x, y]
            if a == 0:
                continue
            c = (r, g, b)
            if c in TOPS_:
                px[x, y] = rgba((WAIST if y >= 17 else TOPS_)[c])
            elif y < 14 and c == SKIN:
                px[x, y] = rgba(MASK)
            elif y < 14 and c == SKINS:
                px[x, y] = rgba(MASKS)
    beard = {"down": {11: (3, 12), 12: (3, 12), 13: (4, 11)}, "left": {11: (2, 6), 12: (3, 7), 13: (4, 8)}}.get(face)
    if beard:
        for y, (x0, x1) in beard.items():
            for x in range(x0, x1 + 1):
                r, g, b, a = px[x, y]
                if a and (r, g, b) not in (INK, EYE):
                    px[x, y] = rgba(BEARD if y < 13 else BEARDS)
        if face == "down":                                  # leave a mouth so it still reads as a face
            px[7, 12] = rgba(MASK); px[8, 12] = rgba(MASK)
    extra, grow = BODIES[body]
    return widen(im, extra, grow)


def mirror(im):
    return im.transpose(Image.FLIP_LEFT_RIGHT)


def lean(im, dx):
    """Shear: the top moves dx pixels sideways, the feet stay."""
    w, h = im.size
    out = Image.new("RGBA", (w + abs(dx) * 2, h), (0, 0, 0, 0))
    for y in range(h):
        s = int(round(dx * (h - 1 - y) / (h - 1)))
        out.alpha_composite(im.crop((0, y, w, y + 1)), (abs(dx) + s, y))
    return out


def rect(im, x, y, w, h, c):
    ImageDraw.Draw(im).rectangle((x, y, x + w - 1, y + h - 1), fill=rgba(c))


def arm(im, x0, y0, x1, y1, t=2):
    """A skin-coloured limb (horizontal or vertical bar) with an ink outline."""
    xa, xb = min(x0, x1), max(x0, x1); ya, yb = min(y0, y1), max(y0, y1)
    rect(im, xa - 1, ya - 1, xb - xa + 3, yb - ya + 3, INK)
    rect(im, xa, ya, xb - xa + 1, yb - ya + 1, SKIN)
    if xb - xa >= yb - ya:
        rect(im, xa, yb, xb - xa + 1, 1, SKINS)
    else:
        rect(im, xb, ya, 1, yb - ya + 1, SKINS)


def leg(im, x0, y0, x1, y1, t=3):
    """A trunks-coloured leg bar with a boot at its end (x1 or y1 end)."""
    xa, xb = min(x0, x1), max(x0, x1); ya, yb = min(y0, y1), max(y0, y1)
    rect(im, xa - 1, ya - 1, xb - xa + 3, yb - ya + 3, INK)
    rect(im, xa, ya, xb - xa + 1, yb - ya + 1, LEGS)
    rect(im, xa, yb, xb - xa + 1, 1, LEGSS)


def boot(im, x, y, w, h):
    rect(im, x - 1, y - 1, w + 2, h + 2, INK)
    rect(im, x, y, w, h, SHOE)


def cell(sprite, dx=0, dy=0):
    """Put a sprite on a 32x32 cell, feet on the bottom line, centred."""
    c = Image.new("RGBA", (CELL, CELL), (0, 0, 0, 0))
    c.alpha_composite(sprite, ((CELL - sprite.width) // 2 + dx, CELL - sprite.height + dy))
    return c


def frame(name, body):
    f = lambda face, fr=0: base(face, fr, body)
    if name.startswith("front"):
        return cell(f("down", int(name[-1])))
    if name == "back":
        return cell(f("up"))
    if name[0] in "rl" and name[1].isdigit():
        im = f("left", int(name[1])); return cell(mirror(im) if name[0] == "r" else im)
    if name == "cheer" or name == "flex":
        im = f("down"); c = cell(im); w = im.width; x0 = (CELL - w) // 2
        top = CELL - im.height
        if name == "cheer":
            arm(c, x0 - 4, top + 4, x0 - 3, top + 15); arm(c, x0 + w + 1, top + 4, x0 + w + 2, top + 15)
        else:                                                    # arms bent up like a strongman
            arm(c, x0 - 4, top + 8, x0 - 1, top + 9); arm(c, x0 - 4, top + 4, x0 - 3, top + 9)
            arm(c, x0 + w, top + 8, x0 + w + 3, top + 9); arm(c, x0 + w + 2, top + 4, x0 + w + 3, top + 9)
        return c
    if name.startswith("punch") or name.startswith("kick"):
        right = name.endswith("_r")
        im = f("left"); c = cell(im); w = im.width; x0 = (CELL - w) // 2; top = CELL - im.height
        if name.startswith("punch"):
            arm(c, x0 - 7, top + 14, x0 + 4, top + 15)           # facing left in the sheet: the arm shoots out to the left
            rect(c, x0 - 10, top + 12, 5, 6, INK); rect(c, x0 - 9, top + 13, 3, 4, SKIN)       # a fist
        else:
            leg(c, x0 - 8, top + 17, x0 + 5, top + 19)           # the raised leg straight out front
            boot(c, x0 - 11, top + 16, 3, 5)
        return mirror(c) if right else c
    if name.startswith("hurt"):
        im = lean(f("left"), 3); c = cell(im, -1)
        return mirror(c) if name.endswith("_r") else c
    if name.startswith("lie"):
        im = f("down").transpose(Image.ROTATE_90 if name.endswith("_l") else Image.ROTATE_270)
        return cell(im)
    if name == "upside":
        return cell(f("down").transpose(Image.ROTATE_180))
    if name.startswith("kneel"):                                 # sitting: back straight up, both legs out in front
        im = f("left"); body = im.crop((0, 0, im.width, 19)); w = body.width
        c = Image.new("RGBA", (w + 10, 26), (0, 0, 0, 0)); c.alpha_composite(body, (10, 4))
        leg(c, 1, 19, 12, 21); boot(c, 0, 18, 2, 5)
        cc = cell(c)
        return mirror(cc) if name.endswith("_r") else cc
    if name.startswith("run"):
        right = name[4] == "r"; n = int(name[-1])
        im = lean(f("left", n), 2); c = cell(im)
        return mirror(c) if right else c
    if name.startswith("dive"):
        right = name.endswith("_r")
        im = f("down").transpose(Image.ROTATE_270 if right else Image.ROTATE_90)
        c = cell(im, 0, -6); w, h = im.size; x0 = (CELL - w) // 2; y0 = CELL - h - 6
        if right:
            arm(c, x0 + w, y0 + 3, x0 + w + 6, y0 + 4)
        else:
            arm(c, x0 - 7, y0 + 3, x0 - 1, y0 + 4)
        return c
    raise ValueError(name)


def sheet():
    out = Image.new("RGBA", (CELL * len(FRAMES), CELL * len(BODIES)), (0, 0, 0, 0))
    for b in range(len(BODIES)):
        for i, n in enumerate(FRAMES):
            out.alpha_composite(frame(n, b), (i * CELL, b * CELL))
    return out


def recolor(img, skin=(240, 190, 150), hair=(60, 40, 30), trunks=(60, 80, 160), boots=(240, 240, 246), mask=None, beard=None, bald=False):
    """Same as the game's WrestlerSprites: used only for the preview picture."""
    def sh(c, k):
        return tuple(max(0, min(255, int(v * k))) for v in c)
    pal = {(255, 0, 0): hair, (190, 0, 0): sh(hair, .75), (255, 90, 90): sh(hair, 1.35), SKIN: skin, SKINS: sh(skin, .82),
           LEGS: trunks, LEGSS: sh(trunks, .72), MASK: mask or skin, MASKS: sh(mask or skin, .82),
           BEARD: beard or skin, BEARDS: sh(beard or skin, .82), SHOE: boots, (110, 92, 92): sh(boots, 1.5)}
    if bald:
        pal.update({(255, 0, 0): skin, (190, 0, 0): sh(skin, .82), (255, 90, 90): skin})
    out = img.copy(); px = out.load()
    for y in range(out.height):
        for x in range(out.width):
            r, g, b, a = px[x, y]
            if a and (r, g, b) in pal:
                px[x, y] = rgba(pal[(r, g, b)])
    return out


def main():
    s = sheet(); s.save(OUT); print("wrote", OUT, s.size, len(FRAMES), "frames x 3 bodies")
    looks = [dict(), dict(skin=(214, 160, 118), hair=(40, 28, 24), trunks=(40, 70, 150), beard=(50, 34, 26)),
             dict(hair=(112, 84, 196), trunks=(120, 70, 190), boots=(250, 210, 70), mask=(176, 156, 240))]
    pv = Image.new("RGBA", (CELL * len(FRAMES) * 2 + 16, CELL * 6 + 16), (96, 70, 60, 255))
    for b in range(3):
        row = recolor(s.crop((0, b * CELL, s.width, (b + 1) * CELL)), **looks[b])
        pv.alpha_composite(row.resize((row.width * 2, CELL * 2), Image.NEAREST), (8, 8 + b * CELL * 2))
    pv.save(os.path.join(HERE, "wrestlers_preview.png"))


if __name__ == "__main__":
    main()
