#!/usr/bin/env python3
"""Draws the world tiles as 16x16 pixel art (GBA style) and writes:
    app/src/main/res/drawable-nodpi/tiles.png      one row of cells per area theme (MEADOW, FOREST, SHORE, ASH, KEEP, INDOOR)
    app/src/main/java/.../TileAtlasData.kt         the cell numbers Art.kt uses (generated, do not edit)
    tools/tiles_preview.png                        every cell of every theme, enlarged, to check by eye

Edit a tile function or a palette below, run `python3 tools/make_tiles.py`, look at tools/tiles_preview.png.
Cells with transparent parts (edges, plank bridge, the glowing rest stone) are drawn on top of a base cell by Art.kt.
"""
import os
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, "..", "app", "src", "main", "res", "drawable-nodpi")
SRC = os.path.join(HERE, "..", "app", "src", "main", "java", "com", "example", "critterquest")

def C(r, g, b, a=255): return (r, g, b, a)
INK = C(30, 26, 44)

def mix(a, b, f):
    return tuple(int(round(a[i] + (b[i] - a[i]) * f)) for i in range(3)) + (255,)

THEMES = ["MEADOW", "FOREST", "SHORE", "ASH", "KEEP", "INDOOR"]

def pal(**kw):
    d = dict(
        # light mint meadow with white speckles; gD is the darker teal used for shrub / flower patches
        gA=C(189, 235, 214), gB=C(163, 226, 201), gC=C(240, 252, 248), gD=C(115, 202, 164),
        pA=C(232, 214, 168), pB=C(212, 192, 144), pC=C(246, 232, 192),
        sA=C(232, 216, 164), sB=C(206, 188, 138), sC=C(248, 236, 196),
        wA=C(74, 121, 222), wB=C(49, 97, 181), wC=C(80, 152, 232), wD=C(204, 228, 255),
        tM=C(132, 210, 99), tD=C(58, 146, 49), tL=C(189, 251, 140), tO=C(58, 89, 16), trunk=C(150, 100, 70), trunkD=C(88, 56, 64),
        bA=C(132, 88, 92), bB=C(88, 56, 72), bC=C(206, 160, 150),       # the rocky rim of a pond
        rA=C(200, 80, 64), rD=C(150, 52, 48), rL=C(232, 124, 100), rO=C(92, 30, 38),
        cream=C(240, 228, 200), shade=C(214, 200, 168), found=C(160, 148, 128), foundD=C(110, 100, 92), eave=C(88, 60, 44),
        woA=C(196, 148, 98), woB=C(184, 136, 88), woD=C(142, 100, 66), woL=C(214, 170, 120),
        kA=C(76, 70, 104), kB=C(70, 64, 96), kD=C(48, 42, 72),
        iwA=C(150, 106, 74), iwL=C(178, 132, 94), iwD=C(110, 76, 52),
        leafL=C(132, 210, 99), leafM=C(58, 146, 49), leafD=C(52, 112, 28), leafO=C(58, 89, 16),   # shrub / tall-grass leaves
        fenceA=C(144, 160, 184), fenceL=C(236, 240, 252), fenceD=C(120, 120, 140), fenceO=C(96, 96, 120),
        tallBg=None, rocky=True,
        dead=False, floor="wood",
    )
    d.update(kw)
    if "gE" not in kw: d["gE"] = mix(d["gA"], d["gD"], 0.42)
    if "gT" not in kw: d["gT"] = tuple(int(v * 0.62) for v in d["gD"][:3]) + (255,)
    if "gM" not in kw: d["gM"] = mix(d["gD"], d["gT"], 0.35)
    if d["tallBg"] is None: d["tallBg"] = d["gD"]
    return d

PALS = {
    "MEADOW": pal(gE=C(156, 227, 197), gT=C(25, 162, 107), gM=C(66, 178, 140)),
    "FOREST": pal(gA=C(150, 214, 176), gB=C(134, 204, 164), gC=C(190, 238, 210), gD=C(88, 176, 136), pA=C(196, 170, 124), pB=C(170, 144, 102), pC=C(214, 192, 148),
                  tM=C(96, 184, 84), tD=C(36, 112, 44), tL=C(150, 228, 120), tO=C(30, 68, 22),
                  leafM=C(40, 120, 52), leafD=C(26, 84, 40), leafL=C(110, 188, 88),
                  rA=C(76, 136, 90), rD=C(48, 98, 66), rL=C(116, 176, 124), rO=C(28, 60, 44)),
    "SHORE": pal(gA=C(232, 218, 168), gB=C(208, 190, 140), gC=C(248, 238, 198), gD=C(176, 156, 112), pA=C(246, 234, 204), pB=C(214, 198, 160), pC=C(255, 248, 224),
                 wA=C(70, 150, 224), wB=C(46, 112, 196), wC=C(128, 196, 248), rocky=False,
                 rA=C(66, 114, 200), rD=C(42, 80, 160), rL=C(110, 156, 232), rO=C(24, 44, 100)),
    "ASH": pal(gA=C(112, 102, 100), gB=C(92, 84, 84), gC=C(138, 128, 124), gD=C(64, 58, 60), pA=C(152, 140, 128), pB=C(124, 114, 104), pC=C(176, 164, 150),
               tM=C(70, 56, 52), tD=C(44, 34, 34), tL=C(104, 88, 80), tallBg=C(92, 84, 84),
               rA=C(98, 88, 112), rD=C(68, 60, 84), rL=C(132, 122, 150), rO=C(40, 34, 54),
               cream=C(184, 168, 156), shade=C(160, 146, 136), dead=True),
    "KEEP": pal(gA=C(66, 60, 90), gB=C(52, 46, 74), gC=C(88, 80, 118), gD=C(34, 30, 52), pA=C(96, 88, 122), pB=C(74, 68, 98), pC=C(118, 110, 146),
                tM=C(52, 46, 78), tD=C(30, 26, 50), tL=C(92, 84, 124), tallBg=C(52, 46, 74), floor="keep"),
    "INDOOR": pal(),
}


class Tile:
    def __init__(s):
        s.im = Image.new("RGBA", (16, 16), (0, 0, 0, 0)); s.px = s.im.load()
    def p(s, x, y, c):
        if c is not None and 0 <= x < 16 and 0 <= y < 16: s.px[x, y] = c
    def r(s, x, y, w, h, c):
        for yy in range(y, y + h):
            for xx in range(x, x + w): s.p(xx, yy, c)
    def fill(s, c): s.r(0, 0, 16, 16, c)
    def pts(s, lst, c):
        for x, y in lst: s.p(x, y, c)
    def disc(s, cx, cy, rad, c):
        for y in range(16):
            for x in range(16):
                if (x + .5 - cx) ** 2 + (y + .5 - cy) ** 2 <= rad * rad: s.p(x, y, c)
    def line(s, x0, y0, x1, y1, c):
        dx, dy = abs(x1 - x0), -abs(y1 - y0); sx = 1 if x0 < x1 else -1; sy = 1 if y0 < y1 else -1; e = dx + dy
        while True:
            s.p(x0, y0, c)
            if x0 == x1 and y0 == y1: break
            e2 = 2 * e
            if e2 >= dy: e += dy; x0 += sx
            if e2 <= dx: e += dx; y0 += sy
    def outline(s, col):
        src = s.im.copy(); sp = src.load()
        for y in range(16):
            for x in range(16):
                if sp[x, y][3] == 0:
                    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        nx, ny = x + dx, y + dy
                        if 0 <= nx < 16 and 0 <= ny < 16 and sp[nx, ny][3] > 0: s.px[x, y] = col; break
    def over(s, other):
        s.im.alpha_composite(other.im); s.px = s.im.load()
    def copy(s):
        t = Tile(); t.im = s.im.copy(); t.px = t.im.load(); return t


# ------------------------------------------------------------------------------------------ ground-like
def ground(P, v):
    """Light meadow: sparse pale dots and a few slightly darker flecks on a loose lattice (shifted per variant)."""
    t = Tile(); t.fill(P["gA"])
    ox, oy = (0, 0, 5, 9)[v % 4], (0, 7, 3, 12)[v % 4]
    for x, y in ((2, 1), (10, 5), (6, 9), (14, 12), (1, 13)): t.p((x + ox) % 16, (y + oy) % 16, P["gC"])
    for x, y in ((8, 0), (4, 5), (12, 9), (3, 12), (9, 14)): t.p((x + ox) % 16, (y + oy) % 16, P["gB"])
    return t

def sand(P, v):
    t = Tile(); t.fill(P["sA"])
    if v == 0: t.pts([(3, 4), (11, 9), (6, 13)], P["sB"]); t.pts([(13, 2), (8, 7)], P["sC"])
    else: t.pts([(2, 10), (7, 3), (12, 12), (14, 6)], P["sB"]); t.line(3, 7, 6, 7, P["sB"])
    return t

GRASS_FRAMES = 8      # sway frames per leaf pattern; Art.kt reads this back as GRASS_STEPS (via TA.TALL_FRAMES)

def tall(P, hv, f):
    """Tall grass: a fern-like clump (tapered blades fanning out from a dark knot, light on top, dark underneath) on the
    darker patch colour. [hv] 0..2 = blade pattern, [f] 0..GRASS_FRAMES-1 = sway frame (the blade tips swing)."""
    import math
    t = Tile(); t.fill(P["tallBg"])
    for x, y in ((1, 1), (12, 2), (2, 13), (13, 13)):
        t.p(x, y, P["gM"]); t.p(x + 1, y + 1, P["gM"]); t.p(x + 2, y, P["gM"])
    H, Hm, M, D, O = P["gE"], P["gM"], P["leafM"], P["leafD"], P["leafO"]
    if P["dead"]: H, Hm, M, D, O = C(176, 166, 124), C(150, 140, 104), C(124, 114, 86), C(86, 78, 60), C(46, 42, 34)
    if P["gA"][0] < 80 and P["gA"][2] > 80: H, Hm, M, D, O = C(150, 142, 200), C(120, 112, 170), C(100, 92, 150), C(70, 62, 112), C(30, 26, 56)
    sway = math.sin(2 * math.pi * f / GRASS_FRAMES)
    # left-half blades, lowest first (base x, base y, tip x, tip y, swing); the right half mirrors them
    pats = [[(6, 12, 0, 14, 0.2), (6, 10, 0, 9, 0.5), (6, 8, 1, 4, 0.8), (7, 7, 5, 1, 1.0)],
            [(6, 12, 1, 14, 0.2), (6, 10, 0, 8, 0.5), (6, 8, 2, 3, 0.8), (7, 7, 6, 1, 1.0)],
            [(6, 12, 0, 13, 0.2), (6, 10, 1, 10, 0.5), (6, 8, 0, 5, 0.8), (7, 7, 4, 2, 1.0)]][hv % 3]
    sp = Tile()
    for bx, by, tx, ty, w in pats:
        tx2 = max(0, min(7, tx + int(round(sway * w * 1.5))))
        for side in (0, 1):
            x0 = bx if side == 0 else 15 - bx; x1 = tx2 if side == 0 else 15 - tx2
            _blade(sp, x0, by, x1, ty, H, M, D, Hm)
    sp.r(6, 11, 4, 3, D); sp.r(7, 11, 2, 2, M); sp.r(7, 14, 2, 1, O); sp.p(6, 14, O); sp.p(9, 14, O)   # the knot the blades grow from
    t.over(sp)
    return t

def path_tile(P, v):
    t = Tile(); t.fill(P["pA"])
    if v == 0: t.pts([(3, 5), (4, 5), (10, 11), (12, 3)], P["pB"]); t.pts([(7, 8), (13, 13), (2, 12)], P["pC"])
    if v == 1: t.pts([(8, 3), (9, 3), (2, 10), (14, 8)], P["pB"]); t.pts([(5, 13), (11, 6), (6, 2)], P["pC"])
    if v == 2: t.pts([(5, 9), (6, 9), (12, 12), (1, 3)], P["pB"]); t.pts([(9, 5), (3, 14), (14, 14)], P["pC"])
    return t

def path_edge(P, side):
    t = Tile()
    for i in range(16):
        d0 = P["gA"] if i % 5 else P["gB"]
        coords = {"top": [(i, 0), (i, 1) if i % 2 == 0 else None, (i, 2) if i % 4 == 0 else None],
                  "bottom": [(i, 15), (i, 14) if i % 2 == 0 else None, (i, 13) if i % 4 == 2 else None],
                  "left": [(0, i), (1, i) if i % 2 == 0 else None, (2, i) if i % 4 == 0 else None],
                  "right": [(15, i), (14, i) if i % 2 == 0 else None, (13, i) if i % 4 == 2 else None]}[side]
        if coords[0]: t.p(*coords[0], d0)
        if coords[1]: t.p(*coords[1], P["gA"])
        if coords[2]: t.p(*coords[2], P["pB"])
    return t

def tree(P, v):
    t = ground(P, 0 if v == 0 else 2)
    sp = Tile()
    if P["dead"]:          # burnt, leafless tree
        sp.r(7, 6, 3, 10, C(66, 52, 48)); sp.r(7, 6, 1, 10, C(98, 82, 74))
        sp.line(8, 8, 3, 3, C(66, 52, 48)); sp.line(8, 9, 13, 4, C(66, 52, 48)); sp.line(8, 6, 6, 1, C(66, 52, 48)); sp.line(3, 3, 1, 3, C(66, 52, 48)); sp.line(13, 4, 14, 2, C(66, 52, 48))
        sp.outline(C(30, 22, 24)); t.over(sp); return t
    if P["gA"][0] < 80 and P["gA"][2] > 80:   # keep: a dark crystal spire
        for y in range(1, 16):
            w = 1 + (y - 1) // 3
            sp.r(8 - w, y, w * 2, 1, P["tM"])
        for y in range(1, 16): sp.p(8 - (1 + (y - 1) // 3), y, P["tL"])
        sp.r(5, 12, 6, 4, P["tD"]); sp.outline(C(18, 14, 34)); t.over(sp); return t
    sh = mix(P["gA"], P["gD"], 0.75)                                  # a small conifer in the same style as the big 2x2 one
    for y in range(16):
        for x in range(16):
            if ((x + .5 - 8) / 6.8) ** 2 + ((y + .5 - 14.0) / 1.9) ** 2 <= 1: sp.px[x, y] = sh
    sp.r(7, 12, 2, 3, P["trunk"]); sp.r(8, 12, 1, 3, P["trunkD"])
    sp.im.alpha_composite(_cone(P, 16, 8, 5, 12, 6.4, 2, 2)); sp.im.alpha_composite(_cone(P, 16, 8, 0, 7, 3.8, 1, 1)); sp.px = sp.im.load()
    t.over(sp); return t

def big_tree(P):
    """A 32x32 conifer (three stacked, dithered tiers, a dark ground shadow and a trunk stub) cut into 4 cells
    [top-left, top-right, bottom-left, bottom-right], drawn on the darker forest floor with a dithered shadow between neighbours."""
    if P["dead"] or (P["gA"][0] < 80 and P["gA"][2] > 80):          # burnt trees and crystal spires stay single tiles
        one = tree(P, 0); return [one.copy() for _ in range(4)]
    S = 32; cx = 16
    floor = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    for qy in (0, 1):
        for qx in (0, 1): floor.paste(ground_dark(P, qx + 2 * qy).im, (qx * 16, qy * 16))
    fp = floor.load()
    for bx in (0, 32):                                              # half-blobs of dithered shade where two trees meet
        for y in range(S):
            for x in range(S):
                d2 = (x + .5 - bx) ** 2 + (y + .5 - 22.5) ** 2
                if d2 <= 5.2 ** 2: fp[x, y] = P["gM"] if (x + y) % 2 == 0 else P["gD"]
                if d2 <= 3.0 ** 2: fp[x, y] = P["gT"] if (x + y) % 2 == 0 else P["gM"]
    base = Image.new("RGBA", (S, S), (0, 0, 0, 0)); bpx = base.load()
    for y in range(S):                                              # ground shadow under the tree
        for x in range(S):
            if ((x + .5 - cx) / 14.6) ** 2 + ((y + .5 - 28.8) / 3.2) ** 2 <= 1: bpx[x, y] = P["tD"]
            if ((x + .5 - cx) / 10.0) ** 2 + ((y + .5 - 29.4) / 2.0) ** 2 <= 1: bpx[x, y] = P["tO"]
    for y in range(28, 31):                                         # trunk stub
        for x in range(14, 18): bpx[x, y] = P["trunkD"] if x == 17 else (P["trunk"] if x > 14 else C(190, 136, 98))
    acc = base.copy()
    for top, bot, hw, lobes, depth, ex, bias, sc in ((18, 29, 14.2, 4, 3, 0.75, 0.16, True), (10, 24, 13.2, 3, 3, 0.7, 0.06, True), (0, 17, 11.5, 2, 2, 0.6, -0.1, False)):
        acc.alpha_composite(_cone(P, S, cx, top, bot, hw, lobes, depth, ex, acc, bias, sc))
    floor.alpha_composite(acc)
    cells = []
    for qy in (0, 1):
        for qx in (0, 1):
            t = Tile(); t.im = floor.crop((qx * 16, qy * 16, qx * 16 + 16, qy * 16 + 16)); t.px = t.im.load(); cells.append(t)
    return cells

# ------------------------------------------------------------------------------------------ water / bridge / lava
def water(P, f):
    """Open water: drifting diagonal wave strokes (light with a dark shade under them) on a mid blue."""
    t = Tile(); t.fill(P["wA"])
    for x0, y0, key in ((0, 3, "wC"), (9, 6, "wB"), (4, 9, "wC"), (12, 12, "wB"), (6, 14, "wC")):
        xs = (x0 + 4 * f) % 16
        for dx in range(7): t.p((xs + dx) % 16, (y0 - dx // 2) % 16, P[key])
    for x0, y0 in ((0, 3), (4, 9), (6, 14)):
        xs = (x0 + 4 * f) % 16
        for dx in range(1, 6): t.p((xs + dx) % 16, (y0 - dx // 2 + 1) % 16, P["wB"])
    t.p((5 + 5 * f) % 16, (1 + 3 * f) % 16, P["wD"]); t.p((12 + 3 * f) % 16, (10 + 5 * f) % 16, P["wD"])
    return t

def water_edge(P, side):
    """The rim of a pond: a brown rocky border 3 pixels thick (dark outer line, pebbled body, dark inner line) and, on the
    top and left sides, a darker band of shade on the water; or white foam for the sea shore."""
    t = Tile()
    for i in range(16):
        if P["rocky"]:
            rows = [P["bB"], P["bC"] if i % 4 == 1 else P["bA"], P["bB"] if i % 3 == 0 else P["bA"]]
            for k, col in enumerate(rows):
                xy = {"top": (i, k), "bottom": (i, 15 - k), "left": (k, i), "right": (15 - k, i)}[side]
                t.p(*xy, col)
            if side in ("top", "left"):
                xy = {"top": (i, 3), "left": (3, i)}[side]; t.p(*xy, P["wB"])
        else:
            pts = {"top": [(i, 0), (i, 1)], "bottom": [(i, 15), (i, 14)], "left": [(0, i), (1, i)], "right": [(15, i), (14, i)]}[side]
            t.p(*pts[0], P["wD"] if i % 3 else P["wC"]); t.p(*pts[1], P["wC"] if i % 2 == 0 else None)
    return t

def bridge(P):
    t = Tile()
    for y in range(16):
        base = C(168, 118, 70) if (y // 4) % 2 == 0 else C(156, 108, 64)
        t.r(2, y, 12, 1, base)
        if y % 4 == 3: t.r(2, y, 12, 1, C(110, 74, 42))
    t.r(1, 0, 1, 16, C(100, 66, 40)); t.r(14, 0, 1, 16, C(100, 66, 40)); t.r(0, 0, 1, 16, INK); t.r(15, 0, 1, 16, INK)
    t.pts([(3, 1), (3, 5), (11, 9), (11, 13)], C(210, 160, 104))
    return t

def lava(P, f):
    t = Tile(); t.fill(C(212, 64, 22))
    for i, (bx, by) in enumerate(((3, 4), (10, 9), (6, 12), (12, 3))):
        k = (f + i) % 4
        r = 1 + (k if k < 3 else 1)
        t.disc(bx, by, r + 0.5, C(255, 150, 40)); t.disc(bx, by, max(1, r - 1) + 0.2, C(255, 214, 90))
    t.pts([(1, 8), (8, 1), (14, 13)], C(236, 100, 30))
    return t

def lava_edge(P, side):
    t = Tile()
    for i in range(16):
        pts = {"top": [(i, 0), (i, 1)], "bottom": [(i, 15), (i, 14)], "left": [(0, i), (1, i)], "right": [(15, i), (14, i)]}[side]
        t.p(*pts[0], C(60, 26, 20)); t.p(*pts[1], C(96, 40, 24) if i % 2 == 0 else None)
    return t

# ------------------------------------------------------------------------------------------ houses
def roof(P, top, left, right):
    t = Tile(); t.fill(P["rA"])
    for band in range(4):
        y = band * 4
        t.r(0, y + 3, 16, 1, P["rD"])
        off = 2 if band % 2 == 0 else 6
        for x in range(off, 16, 8): t.r(x, y, 1, 3, P["rD"])
        t.pts([(x, y) for x in range(off + 2, 16, 4)], P["rL"])
    if top: t.r(0, 0, 16, 2, P["rL"]); t.r(0, 2, 16, 1, P["rA"]); t.r(0, 0, 16, 1, P["rO"])
    if left: t.r(0, 0, 1, 16, P["rO"])
    if right: t.r(15, 0, 1, 16, P["rO"])
    return t

def wall(P, eave, found, window):
    t = Tile(); t.fill(P["cream"])
    t.pts([(3, 6), (12, 9), (7, 12), (14, 5), (1, 10)], P["shade"])
    if eave: t.r(0, 0, 16, 2, P["eave"]); t.r(0, 2, 16, 1, C(150, 124, 100))
    if found: t.r(0, 13, 16, 3, P["found"]); t.r(0, 13, 16, 1, P["foundD"]); t.pts([(3, 14), (4, 14), (10, 15), (11, 15)], P["foundD"])
    if window:
        t.r(4, 4, 8, 8, C(104, 70, 46)); t.r(5, 5, 6, 6, C(146, 208, 244)); t.r(7, 5, 2, 6, C(104, 70, 46)); t.r(5, 7, 6, 1, C(104, 70, 46))
        t.pts([(5, 5), (6, 5), (5, 6), (9, 8), (10, 9)], C(220, 244, 255)); t.r(3, 12, 10, 1, C(86, 58, 40))
    return t

def door(P, eave):
    t = wall(P, eave, True, False)
    t.r(3, 2, 10, 14, C(70, 44, 30)); t.r(4, 3, 8, 13, C(150, 100, 60)); t.r(7, 3, 2, 13, C(112, 74, 44))
    t.r(4, 3, 8, 1, C(180, 128, 80)); t.pts([(5, 6), (10, 6), (5, 11), (10, 11)], C(186, 134, 84)); t.p(10, 9, C(250, 210, 80)); t.p(10, 10, C(190, 150, 40))
    t.r(2, 1, 12, 1, C(60, 38, 28))
    return t

# ------------------------------------------------------------------------------------------ small things
def flower(P, v):
    """A flower bed tile: a big blossom and a small one (four rounded petals, a bright centre) with leaves, on the dark patch colour."""
    t = Tile(); t.fill(P["tallBg"])
    for x, y in ((1, 1), (12, 2), (1, 13), (13, 12)):
        t.p(x, y, P["gM"]); t.p(x + 1, y + 1, P["gM"]); t.p(x + 2, y, P["gM"])
    cols = [(C(200, 48, 64), C(240, 128, 104), C(248, 192, 112)), (C(250, 250, 252), C(255, 255, 255), C(236, 170, 40)),
            (C(246, 130, 180), C(252, 190, 214), C(250, 214, 70)), (C(96, 140, 244), C(160, 190, 252), C(250, 250, 250))][v % 4]
    pet, hi, ctr = cols
    dark = (max(0, pet[0] - 80), max(0, pet[1] - 60), max(0, pet[2] - 60), 255)
    if pet[0] > 240 and pet[1] > 240: dark = P["fenceD"]
    sp = Tile()
    def leaf(x, y, w):
        for k in range(w): sp.p(x + k, y, P["gT"]); sp.p(x + k, y + 1, P["leafM"])
        sp.p(x, y, P["leafL"])
    leaf(1, 10, 4); leaf(4, 11, 4); leaf(8, 12, 4); leaf(11, 11, 4)
    def blossom(cx, cy, r):
        k = r * 0.5
        lobes = ((cx - k, cy - k * .7), (cx + k, cy - k * .7), (cx - k * .9, cy + k * .8), (cx + k * .9, cy + k * .8))
        tmp = Tile()
        for lx, ly in lobes: tmp.disc(lx, ly, r * 0.58, pet)
        for y in range(16):
            for x in range(16):
                if tmp.px[x, y][3]:
                    sp.px[x, y] = hi if (x + .5 < cx and y + .5 < cy - 0.2) else pet
        pd = tuple(int(v * 0.74) for v in pet[:3]) + (255,)           # thin darker seams between the four petals
        for y in range(16):
            for x in range(16):
                near_x = abs(x + .5 - cx) < 0.6; near_y = abs(y + .5 - cy) < 0.6
                if tmp.px[x, y][3] and near_x != near_y and (x + .5 - cx) ** 2 + (y + .5 - cy) ** 2 > 1.7 ** 2: sp.px[x, y] = pd
        sp.disc(cx, cy, max(1.0, r * 0.28), ctr)
    blossom(4.9, 5.4, 3.9); blossom(11.3, 8.3, 3.4)
    sp.outline(dark); t.over(sp)
    return t

def fence(P, mask):
    """A picket fence. mask: left 1, right 2, up 4, down 8 = which neighbours are also fence."""
    t = ground(P, 0)
    l, r, u, d = bool(mask & 1), bool(mask & 2), bool(mask & 4), bool(mask & 8)
    A, L, D, O = P["fenceA"], P["fenceL"], P["fenceD"], P["fenceO"]
    sp = Tile()
    def picket(x0, w=5, top=4):          # a picket with a rounded top and a light left edge
        sp.r(x0, top, w, 15 - top, A); sp.r(x0, top, 1, 15 - top, L); sp.r(x0 + w - 1, top, 1, 15 - top, D)
        sp.p(x0, top, None); sp.p(x0 + w - 1, top, None); sp.r(x0 + 1, top, w - 2, 1, L); sp.r(x0, 13, w, 1, D)
    horiz = l or r or not (u or d)
    if horiz:
        x_from = 0 if l else 2; x_to = 16 if r else 14
        sp.r(x_from, 7, x_to - x_from, 2, D); sp.r(x_from, 7, x_to - x_from, 1, A)      # the rail behind the pickets
        if l or not r: picket(1)
        if r or not l: picket(10)
        if not l and not r: picket(5, 6, 3)                                              # a lone post is a little taller
    if u or d:                           # a run going up or down the screen: a line of post tops
        y0 = 0 if u else 6; y1 = 16 if d else 14
        sp.r(6, y0, 4, y1 - y0, A); sp.r(6, y0, 1, y1 - y0, L); sp.r(9, y0, 1, y1 - y0, D)
        for yy in range(y0 + 3, y1, 8): sp.r(6, yy, 4, 1, D); sp.r(6, yy + 1, 4, 1, L)
        if not u: sp.r(6, 5, 4, 1, L); sp.p(6, 5, None); sp.p(9, 5, None)
    sp.outline(O); t.over(drop_shadow(sp, mix(P["gA"], P["gD"], 0.7))); t.over(sp); return t

def sign(P):
    t = ground(P, 3); sp = Tile()
    sp.r(7, 9, 2, 6, C(110, 74, 42)); sp.r(2, 2, 12, 8, C(176, 128, 76)); sp.r(3, 3, 10, 6, C(228, 194, 134))
    sp.r(4, 4, 8, 1, C(110, 74, 42)); sp.r(4, 6, 6, 1, C(110, 74, 42)); sp.r(3, 3, 10, 1, C(244, 216, 160))
    sp.outline(C(60, 40, 28)); t.over(sp); return t

def rock(P):
    t = ground(P, 1); sp = Tile()
    sp.disc(8, 10, 6.6, C(124, 124, 134))
    for y in range(16):
        for x in range(16):
            if sp.px[x, y][3]:
                if (x - 8) + (y - 10) >= 4: sp.px[x, y] = C(92, 92, 104)
                elif (x - 5) ** 2 + (y - 8) ** 2 <= 5: sp.px[x, y] = C(176, 176, 188)
    sp.pts([(10, 8), (11, 9), (7, 12)], C(78, 78, 92)); sp.outline(C(40, 38, 54)); t.over(sp); return t

def floor_tile(P, v):
    t = Tile()
    if P["floor"] == "keep":
        t.fill(P["kA"] if v != 0 else P["kB"]); t.r(0, 0, 16, 1, P["kD"]); t.r(0, 0, 1, 16, P["kD"])
        t.pts([(5, 6), (6, 6), (7, 6), (11, 11), (3, 12)], P["kD"] if v == 1 else P["kB"])
        return t
    t.fill(P["woA"] if v % 2 == 0 else P["woB"])
    t.r(0, 7, 16, 1, P["woD"]); t.r(0, 15, 16, 1, P["woD"])
    t.r((v * 4 + 3) % 16, 0, 1, 7, P["woD"]); t.r((v * 5 + 9) % 16, 8, 1, 7, P["woD"])
    t.pts([(2, 3), (10, 4), (6, 11), (13, 12)], P["woL"]); return t

def indoor_wall(P):
    t = Tile()
    if P["floor"] == "keep":
        t.fill(C(44, 40, 68))
        for i in range(4): t.r(0, i * 4 + 3, 16, 1, C(26, 22, 44))
        for i in range(4): t.r(((i % 2) * 8 + 5) % 16, i * 4, 1, 4, C(26, 22, 44))
        t.pts([(2, 1), (10, 5), (4, 9), (12, 13)], C(62, 56, 90)); return t
    t.fill(P["iwA"]); t.r(0, 0, 16, 3, P["iwL"]); t.r(0, 13, 16, 3, P["iwD"]); t.r(0, 12, 16, 1, C(86, 58, 40))
    t.r(7, 3, 1, 9, C(126, 88, 62)); t.r(8, 3, 1, 9, C(164, 120, 86)); return t

def furniture_base(P, v=0): return floor_tile(P, v)

def table(P):
    t = floor_tile(P, 0); sp = Tile()
    sp.r(1, 5, 14, 6, C(172, 118, 66)); sp.r(1, 5, 14, 2, C(214, 156, 98)); sp.r(1, 10, 14, 1, C(128, 86, 48))
    sp.r(2, 11, 2, 4, C(120, 80, 46)); sp.r(12, 11, 2, 4, C(120, 80, 46)); sp.outline(C(60, 38, 26)); t.over(sp); return t

def bed(P):
    t = floor_tile(P, 0); sp = Tile()
    sp.r(1, 1, 14, 14, C(122, 82, 48)); sp.r(2, 2, 12, 12, C(226, 90, 90)); sp.r(3, 3, 10, 4, C(250, 250, 250)); sp.r(3, 6, 10, 1, C(210, 214, 226))
    sp.r(2, 8, 12, 1, C(188, 60, 60)); sp.r(2, 12, 12, 2, C(196, 70, 70)); sp.outline(C(60, 38, 26)); t.over(sp); return t

def shelf(P, v):
    t = floor_tile(P, 0); sp = Tile()
    sp.r(0, 1, 16, 14, C(118, 80, 48)); cols = [C(200, 70, 70), C(70, 130, 200), C(230, 190, 70), C(80, 170, 100), C(160, 90, 190)]
    for row in range(2):
        sp.r(1, 2 + row * 7, 14, 6, C(70, 46, 28))
        x = 2
        for i in range(6):
            h = 4 + ((v + i + row) % 2); w = 2
            sp.r(x, 2 + row * 7 + (6 - h), w, h, cols[(v + i + row) % 5]); x += w
    sp.outline(C(50, 32, 22)); t.over(sp); return t

def stone(P, f):
    sp = Tile()
    g = (0, 40, 80, 40)[f]
    glow = C(120, 255, 230, g)
    sp.disc(8, 8, 8.4, glow) if g else None
    sp2 = Tile()
    sp2.r(4, 3, 8, 13, C(112, 124, 134)); sp2.r(5, 1, 6, 3, C(112, 124, 134)); sp2.r(6, 0, 4, 2, C(112, 124, 134))
    sp2.r(4, 3, 3, 13, C(146, 160, 170)); sp2.r(5, 1, 2, 3, C(146, 160, 170)); sp2.r(10, 6, 2, 10, C(88, 98, 110))
    rune = (C(150, 255, 235), C(190, 255, 245))[f % 2]
    sp2.r(8, 5, 1, 7, rune); sp2.r(6, 8, 5, 1, rune)
    sp2.outline(C(36, 44, 56))
    sp.over(sp2); return sp

def ground_for(P, v=0): return floor_tile(P, v) if P["floor"] == "keep" and P is PALS["KEEP"] and False else ground(P, v)


def drop_shadow(sp, col, dx=1, dy=1):
    """A hard one-pixel shadow of everything in sprite [sp] (draw it UNDER the sprite)."""
    sh = Tile()
    for y in range(16):
        for x in range(16):
            if sp.px[x, y][3] > 0:
                nx, ny = x + dx, y + dy
                if 0 <= nx < 16 and 0 <= ny < 16 and sp.px[nx, ny][3] == 0: sh.px[nx, ny] = col
    return sh

def ground_dark(P, v=0):
    """The darker teal floor under trees, flowers and tall grass, with tiny 'v' tuft marks."""
    t = Tile(); t.fill(P["gD"])
    ox, oy = (v * 5) % 7, (v * 3) % 5
    for x, y in ((2, 2), (10, 6), (5, 11)):
        X = x + ox; Y = y + oy
        t.p(X, Y, P["gM"]); t.p(X + 2, Y, P["gM"]); t.p(X + 1, Y + 1, P["gM"])
    return t

def feather(P, which):
    """Soft pale rim laid on a ground tile where it touches a dark patch (tall grass, flower bed, forest floor).
    which 0..3 = patch above / below / left / right; 4..7 = patch only on the diagonal TL / TR / BL / BR."""
    t = Tile(); E = P["gE"]
    if which < 4:
        for i in range(16):
            w = 2 if (i // 3) % 2 == 0 else 1
            for k in range(w):
                xy = [(i, k), (i, 15 - k), (k, i), (15 - k, i)][which]
                t.p(*xy, E)
            if w == 1 and i % 2 == 0:
                xy = [(i, 1), (i, 14), (1, i), (14, i)][which]; t.p(*xy, E)
    else:
        cx, cy = ((0, 0), (15, 0), (0, 15), (15, 15))[which - 4]
        sx = 1 if cx == 0 else -1; sy = 1 if cy == 0 else -1
        for dx, dy in ((0, 0), (1, 0), (0, 1)): t.p(cx + sx * dx, cy + sy * dy, E)
    return t

def _px_line(x0, y0, x1, y1):
    pts = []; dx, dy = abs(x1 - x0), -abs(y1 - y0); sx = 1 if x0 < x1 else -1; sy = 1 if y0 < y1 else -1; e = dx + dy
    while True:
        pts.append((x0, y0))
        if x0 == x1 and y0 == y1: break
        e2 = 2 * e
        if e2 >= dy: e += dy; x0 += sx
        if e2 <= dx: e += dx; y0 += sy
    return pts

def _cone(P, S, cx, top, bot, hw, lobes, depth, ex=0.8, under=None, bias=0.0, scales=False):
    """One tier of a conifer on an S x S canvas: a rounded cone that widens from a pointed tip at [top] to half-width [hw],
    a scalloped lower lip, light / mid / dark green with checkerboard dithering between the tones ([bias] > 0 = darker),
    a leafy speckle, optional scale marks, and a dark outline (a softer green line where it lies over the tier below, [under])."""
    import math
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0)); px = im.load(); h = bot - top
    L, M, D, O = P["tL"], P["tM"], P["tD"], P["tO"]
    for y in range(top, bot + 1):
        t = (y - top) / h
        half = hw * (t ** ex) + 0.6
        if y - top < 3 and S >= 32: half = min(half, 0.7 + (y - top) * 0.95)        # a small pointed nub at the very top
        for x in range(S):
            dx = x + .5 - cx
            if abs(dx) > half: continue
            u = ((dx + hw) / (2.0 * hw)) * lobes; fr = (u - math.floor(u)) * 2 - 1
            if y > bot - depth + depth * math.sqrt(max(0.0, 1 - fr * fr)) - 0.2: continue       # round lobes hanging down
            v = 0.5 * (dx / hw) + 0.75 * t - 0.56 + bias
            chk = (x + y) % 2 == 0
            if v < -0.26: col = L
            elif v < -0.06: col = L if chk else M
            elif v < 0.24: col = M
            elif v < 0.42: col = M if chk else D
            else: col = D
            k = (x + 2 * y) % 6
            if k == 0 and col == L: col = M                      # leafy speckle: a lighter dot in the dark, a darker one in the light
            elif k == 3 and col == M: col = L
            elif k == 0 and col == D: col = M
            px[x, y] = col
    src = im.copy(); sp_ = src.load()
    for y in range(S):                                              # dark underside along the lower lip
        for x in range(S):
            if not sp_[x, y][3]: continue
            if y + 1 >= S or sp_[x, y + 1][3] == 0: px[x, y] = D
            elif y + 2 < S and sp_[x, y + 2][3] == 0 and ((x + y) % 2 == 0 or x > cx): px[x, y] = D if px[x, y] != L else M
    if scales:                                                       # rows of little 'u' scale marks across the tier
        for row, y0 in enumerate((top + int(h * 0.30), top + int(h * 0.62))):
            for xs in range(int(cx - hw), int(cx + hw) + 1, 5):
                xx = xs + (2 if row else 0)
                for ddx, ddy in ((0, 0), (1, 1), (2, 1), (3, 0)):
                    X, Y = xx + ddx, y0 + ddy
                    if 0 <= X < S and 0 <= Y + 2 < S and sp_[X, Y][3] and sp_[X, Y + 2][3]: px[X, Y] = D
    o = im.copy(); opx = o.load()                                    # outline round the tier
    for y in range(S):
        for x in range(S):
            if px[x, y][3] == 0:
                for ddx, ddy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nx, ny = x + ddx, y + ddy
                    if 0 <= nx < S and 0 <= ny < S and px[nx, ny][3]:
                        opx[x, y] = D if (under is not None and under.getpixel((x, y))[3]) else O; break
    return o

def water_corner(P, which):
    """Rounds the outer corner of a pond (which 0..3 = TL, TR, BL, BR): meadow outside, a curved rocky rim inside."""
    t = Tile()
    if not P["rocky"]: return t
    R = 5.0
    for y in range(6):
        for x in range(6):
            d = ((x + .5 - R) ** 2 + (y + .5 - R) ** 2) ** .5
            X = x if which in (0, 2) else 15 - x; Y = y if which in (0, 1) else 15 - y
            if d > R: t.p(X, Y, P["gA"])
            elif d > R - 1: t.p(X, Y, P["bB"])
            elif d > R - 2: t.p(X, Y, P["bC"] if (x + y) % 3 == 0 else P["bA"])
            elif d > R - 3: t.p(X, Y, P["bB"] if (x + y) % 2 == 0 else P["bA"])
    return t

def _blade(sp, x0, y0, x1, y1, H, M, D, Hm=None):
    """A tapered grass blade from (x0, y0) to its tip (x1, y1): four pixels thick at the base (light, mid, mid, dark), then three, two, one."""
    pts = _px_line(x0, y0, x1, y1); n = len(pts); steep = abs(y1 - y0) > abs(x1 - x0)
    for i, (x, y) in enumerate(pts):
        u = i / max(1, n - 1)
        th = 4 if u < 0.32 else (3 if u < 0.62 else (2 if u < 0.88 else 1))
        hi = H if i % 2 == 0 else (Hm or H)
        cells = [(x - k, y) if steep else (x, y - k) for k in (1, 0, -1, -2)]       # light edge first, dark edge last
        if th == 4: cols = (hi, M, M, D)
        elif th == 3: cols = (hi, M, D, None)
        elif th == 2: cols = (M, D, None, None)
        else: cols = (M, None, None, None)
        start = 0 if th >= 3 else 1
        for k in range(4):
            if cols[k] is not None: sp.p(*cells[k + (0 if th >= 3 else 0)], cols[k])

# ------------------------------------------------------------------------------------------ layout of the atlas
def build_cells(P, theme):
    cells = []   # (group, index_in_group, Tile)
    def add(name, tiles): cells.append((name, tiles))
    add("GROUND", [ground(P, v) for v in range(4)])
    add("TALL", [tall(P, hv, f) for hv in range(3) for f in range(GRASS_FRAMES)])
    add("PATH", [path_tile(P, v) for v in range(3)])
    add("PATH_EDGE", [path_edge(P, s) for s in ("top", "bottom", "left", "right")])
    add("SAND", [sand(P, v) for v in range(2)])
    add("TREE", [tree(P, v) for v in range(2)])
    add("BIGTREE", big_tree(P))                                                                   # 2x2 tree: TL, TR, BL, BR
    add("WATER", [water(P, f) for f in range(4)])
    add("WATER_EDGE", [water_edge(P, s) for s in ("top", "bottom", "left", "right")])
    add("BRIDGE", [bridge(P)])
    add("LAVA", [lava(P, f) for f in range(4)])
    add("LAVA_EDGE", [lava_edge(P, s) for s in ("top", "bottom", "left", "right")])
    add("ROOF", [roof(P, top, l, r) for top in (0, 1) for l in (0, 1) for r in (0, 1)])      # index = top*4 + left*2 + right
    add("WALL", [wall(P, e, f, w) for w in (0, 1) for f in (0, 1) for e in (0, 1)])           # index = window*4 + found*2 + eave
    add("DOOR", [door(P, e) for e in (0, 1)])
    add("FLOWER", [flower(P, v) for v in range(4)])
    add("FENCE", [fence(P, m) for m in range(16)])                                               # mask: left 1, right 2, up 4, down 8
    add("SIGN", [sign(P)])
    add("ROCK", [rock(P)])
    add("FLOOR", [floor_tile(P, v) for v in range(3)])
    add("IWALL", [indoor_wall(P)])
    add("TABLE", [table(P)])
    add("BED", [bed(P)])
    add("SHELF", [shelf(P, v) for v in range(3)])
    add("STONE", [stone(P, f) for f in range(4)])
    add("FEATHER", [feather(P, w) for w in range(8)])                                            # 0..3 patch above/below/left/right, 4..7 diagonal TL/TR/BL/BR
    add("WATER_CORNER", [water_corner(P, w) for w in range(4)])                                  # TL, TR, BL, BR
    return cells


def main():
    starts = {}; counts = {}
    rows = []
    for theme in THEMES:
        P = PALS[theme]; cells = build_cells(P, theme)
        flat = []; n = 0
        for name, tiles in cells:
            if theme == THEMES[0]: starts[name] = n; counts[name] = len(tiles)
            n += len(tiles); flat += tiles
        rows.append(flat)
    ncol = max(len(r) for r in rows)
    atlas = Image.new("RGBA", (ncol * 16, len(rows) * 16), (0, 0, 0, 0))
    for ri, flat in enumerate(rows):
        for ci, t in enumerate(flat): atlas.paste(t.im, (ci * 16, ri * 16))
    os.makedirs(RES, exist_ok=True)
    atlas.save(os.path.join(RES, "tiles.png"))
    # Kotlin constants
    k = ["package com.example.critterquest", "", "// GENERATED by tools/make_tiles.py - do not edit.",
         "/** First cell of each tile group in tiles.png (one row of cells per Theme, in Theme order). */", "object TA {"]
    for name in starts: k.append(f"    const val {name} = {starts[name]}   // {counts[name]} cells")
    k.append(f"    const val TALL_FRAMES = {GRASS_FRAMES}   // sway frames per tall-grass pattern")
    k.append(f"    const val CELLS = {ncol}"); k.append("}")
    open(os.path.join(SRC, "TileAtlasData.kt"), "w").write("\n".join(k) + "\n")
    # preview: every theme, 5x
    S = 5
    prev = Image.new("RGBA", (ncol * 16 * S // 2 if False else 1600, 1), (0, 0, 0, 0))
    perrow = 40
    h = 0
    sheets = []
    for ri, theme in enumerate(THEMES):
        flat = rows[ri]; nr = (len(flat) + perrow - 1) // perrow
        sh = Image.new("RGBA", (perrow * 16 * 3, nr * 16 * 3), (255, 0, 255, 255))
        for ci, t in enumerate(flat):
            tt = t.im.resize((48, 48), Image.NEAREST)
            sh.alpha_composite(tt, ((ci % perrow) * 48, (ci // perrow) * 48))
        sheets.append(sh)
    H = sum(s.height + 6 for s in sheets)
    out = Image.new("RGBA", (sheets[0].width, H), (40, 40, 60, 255)); y = 0
    for s in sheets: out.paste(s, (0, y)); y += s.height + 6
    out.save(os.path.join(HERE, "tiles_preview.png"))
    print("tiles.png", atlas.size, "cells per theme:", ncol)

if __name__ == "__main__":
    main()
