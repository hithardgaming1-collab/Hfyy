"""Critter Station sprite -> app/src/main/res/drawable-nodpi/ow_station.png (two 16x24 frames side by side: light on, light off).
A small kiosk with a paw-print screen that stands in each town (see STATIONS in Cast.kt). Run, then ./run.sh shots / maps to refresh previews."""
import os
from PIL import Image, ImageDraw

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "app", "src", "main", "res", "drawable-nodpi", "ow_station.png")
W, H = 16, 24
INK = (34, 28, 48, 255)


def frame(on):
    im = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    wood, wood_d, wood_l = (168, 112, 64, 255), (120, 78, 46, 255), (208, 152, 94, 255)
    gold, gold_d = (246, 206, 96, 255), (196, 150, 52, 255)
    # post and foot
    d.rectangle((5, 16, 10, 22), fill=wood); d.rectangle((5, 16, 6, 22), fill=wood_l); d.rectangle((9, 16, 10, 22), fill=wood_d)
    d.rectangle((2, 21, 13, 23), fill=wood_d); d.rectangle((2, 21, 13, 21), fill=wood)
    # screen housing and screen
    d.rounded_rectangle((1, 5, 14, 16), 2, fill=(74, 64, 108, 255))
    d.rectangle((3, 7, 12, 14), fill=(58, 198, 188, 255))
    d.rectangle((3, 7, 12, 8), fill=(160, 246, 236, 255))
    # paw print: a pad and four toes
    paw = (22, 90, 100, 255)
    for x, y0, y1 in ((7, 11, 11), (6, 12, 13), (7, 12, 13), (8, 12, 13), (9, 12, 13)):
        d.rectangle((x, y0, x, y1), fill=paw)
    for x, y in ((4, 11), (5, 9), (10, 9), (11, 11)):
        d.rectangle((x, y, x, y + 1), fill=paw)
    # awning with stripes
    d.rectangle((0, 3, 15, 5), fill=gold); d.rectangle((0, 5, 15, 5), fill=gold_d)
    for x in (2, 6, 10, 14):
        d.rectangle((x, 3, x + 1, 4), fill=(230, 90, 70, 255))
    # antenna and light
    d.line((8, 1, 8, 2), fill=gold_d)
    d.rectangle((7, 0, 8, 1), fill=(255, 244, 150, 255) if on else (150, 112, 60, 255))
    # 1px dark outline around everything
    px = im.load(); out = im.copy(); op = out.load()
    for y in range(H):
        for x in range(W):
            if px[x, y][3] == 0 and any(0 <= x + dx < W and 0 <= y + dy < H and px[x + dx, y + dy][3] for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1))):
                op[x, y] = INK
    return out


def main():
    sheet = Image.new("RGBA", (W * 2, H), (0, 0, 0, 0))
    sheet.paste(frame(True), (0, 0)); sheet.paste(frame(False), (W, 0))
    sheet.save(OUT); print("wrote", OUT, sheet.size)
    big = Image.new("RGBA", (W * 2 * 8 + 16, H * 8 + 16), (120, 170, 100, 255)); big.alpha_composite(sheet.resize((W * 16, H * 8), Image.NEAREST), (8, 8))
    big.save(os.path.join(HERE, "station_preview.png"))


if __name__ == "__main__":
    main()
