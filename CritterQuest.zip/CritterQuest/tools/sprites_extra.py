#!/usr/bin/env python3
"""Sprites for the species added after the three starter lines (see make_sprites.py).

Same house style as the starters: 64x64, shaded blobs with a dark rim, a 1px outline, big round eyes.
Each species is a body plan ("template") plus a palette and a few options, all drawn with Pillow from
scratch - nothing third-party. make_sprites.py calls draw_extra() for every name in EXTRA.
"""
import math
from make_sprites import Pen, rgb, lighter, flame, leaf, W

WHITE = (255, 255, 255, 255)
INK = (30, 25, 45, 255)
BLUSH = (255, 120, 140, 200)
CREAM = (255, 236, 200, 255)
GOLD = (250, 200, 70, 255)
ICE = (190, 235, 250, 255)
ROCKC = (150, 140, 130, 255)


# ------------------------------------------------------------------ helpers
def eyes(p, cx, y, sep=6.5, r=3.6, style="cute", iris=None):
    for s in (-1, 1):
        ex = cx + s * sep
        if style == "sleepy":
            p.d.line([(round(ex - 3), round(y)), (round(ex), round(y + 2)), (round(ex + 3), round(y))], fill=INK, width=2)
            continue
        p.oval(ex, y + 1, r, r * 1.1, WHITE)
        if iris:
            p.oval(ex - s * 0.3, y + 1.4, r * 0.8, r * 0.95, iris)
            p.oval(ex - s * 0.3, y + 1.6, r * 0.45, r * 0.6, INK)
        else:
            p.oval(ex - s * 0.4, y + 1.6, r * 0.58, r * 0.72, INK)
        p.px([(round(ex - 1), round(y))], WHITE)
        if style == "fierce":
            p.d.line([(round(ex - s * 5), round(y - 4 - (0 if s < 0 else 0))), (round(ex + s * 3), round(y - 2))], fill=INK, width=2)


def smile(p, cx, y, w=3):
    p.px([(cx - 1, y), (cx, y)], INK)
    p.px([(cx - w, y + 1), (cx - w + 1, y + 2), (cx - 1, y + 2), (cx, y + 2), (cx + w - 1, y + 2), (cx + w, y + 1)], INK)


def stripe(p, y0, y1, f=0.55):
    """Darken the already-drawn pixels in rows y0..y1 (keeps the shading underneath)."""
    px = p.img.load()
    for y in range(max(0, int(y0)), min(W, int(y1) + 1)):
        for x in range(W):
            r, g, b, a = px[x, y]
            if a > 0:
                px[x, y] = (int(r * f), int(g * f), int(b * f), 255)


def cheeks(p, cx, y, dx=11.5, col=BLUSH, r=2.4):
    for s in (-1, 1):
        p.oval(cx + s * dx, y, r, r * 0.65, col)


def spike(p, x, y, w, h, col, tip_dx=0):
    p.poly([(x - w, y), (x + tip_dx, y - h), (x + w, y)], rgb(col, 0.75))
    p.poly([(x - w * 0.55, y), (x + tip_dx, y - h * 0.82), (x + w * 0.55, y)], col)


def bolt(p, x, y, s=1.0, col=(250, 215, 50, 255)):
    pts = [(x, y - 11 * s), (x - 5 * s, y + 1 * s), (x - 1 * s, y + 1 * s), (x - 4 * s, y + 11 * s),
           (x + 5 * s, y - 2 * s), (x + 1 * s, y - 2 * s), (x + 4 * s, y - 11 * s)]
    p.poly([(a, b) for a, b in pts], rgb(col, 0.78))
    p.poly([(x + (a - x) * 0.7, y + (b - y) * 0.7) for a, b in pts], col)


def tail_curve(p, pts, widths, col):
    """A tapering tail drawn as overlapping blobs along pts."""
    for (x, y), w in zip(pts, widths):
        p.blob(x, y, w, w * 0.9, col)


# ------------------------------------------------------------------ quadruped (fox / mouse / dog / foal)
def quad(p, back, P):
    body, belly, acc = P["body"], P["belly"], P.get("acc", P["belly"])
    s = P.get("size", 1.0)
    dark = rgb(body, 0.72)
    cx, hy = 32, 27
    bw, bh = 13 * s, 11 * s
    by = 47
    ears, tail, ex = P.get("ears", "round"), P.get("tail", "fluff"), P.get("extras", [])

    # tail behind body (front view)
    if not back:
        if tail == "fluff":
            p.blob(51, 44, 6.5 * s, 10 * s, body, 20); p.oval(52, 38, 3, 4, lighter(acc, 0.1))
        elif tail == "bolt":
            bolt(p, 52, 42, 1.25 * s, P.get("tailcol", GOLD))
        elif tail == "whip":
            tail_curve(p, [(47, 52), (51, 49), (54, 44), (53, 38)], [3.4, 3.1, 2.8, 2.6], body)
        elif tail == "flame":
            flame(p, 51, 44, 1.2 * s)
        elif tail == "ice":
            for i, a in enumerate((-30, 0, 30)):
                spike(p, 51 + a * 0.12, 50 - abs(a) * 0.05, 3.2, 14 - abs(a) * 0.08, ICE, a * 0.15)
        elif tail == "sweep":
            p.blob(51, 46, 6 * s, 8 * s, body, -35); p.oval(53, 42, 3, 4, acc)

    # ears behind head
    for sd in (-1, 1):
        ex_ = cx + sd * 10.5 * s
        if ears == "round":
            p.blob(ex_, hy - 9, 5.2 * s, 5.2 * s, body); p.oval(ex_, hy - 8.5, 2.8, 2.8, acc)
        elif ears == "point":
            p.poly([(cx + sd * 12 * s, hy - 3), (cx + sd * 15 * s, hy - 20 * s), (cx + sd * 4, hy - 11)], dark)
            p.poly([(cx + sd * 11 * s, hy - 5), (cx + sd * 13.5 * s, hy - 17 * s), (cx + sd * 6, hy - 10)], acc)
        elif ears == "long":
            p.blob(cx + sd * 8 * s, hy - 15, 3.8 * s, 10 * s, body, sd * 14); p.oval(cx + sd * 8 * s, hy - 14, 1.8, 6.5 * s, acc, sd * 14)
        elif ears == "floppy":
            p.blob(cx + sd * 12 * s, hy - 4, 4.4 * s, 8.5 * s, dark, sd * 38)
        elif ears == "crystal":
            spike(p, cx + sd * 9 * s, hy - 7, 4, 15 * s, ICE, sd * 2.5)
        elif ears == "flame":
            flame(p, cx + sd * 10 * s, hy - 12, 0.75 * s)
        elif ears == "small":
            p.blob(cx + sd * 11 * s, hy - 8, 3.8 * s, 3.8 * s, body)
    if "gem" in ex and not back:
        pass
    if "mane_flame" in ex:
        flame(p, cx, hy - 14, 1.1 * s); flame(p, cx - 8 * s, hy - 11, 0.75 * s); flame(p, cx + 8 * s, hy - 11, 0.75 * s)
    if "mane_ice" in ex:
        for dx in (-9, -3, 3, 9):
            spike(p, cx + dx * s, hy - 9 - (3 if abs(dx) < 5 else 0), 3.6, 13 * s, ICE, dx * 0.12)
    if "mane_spark" in ex:
        for dx, h in ((-11, 11), (-6, 15), (0, 18), (6, 15), (11, 11)):
            spike(p, cx + dx * s, hy - 7, 3.4, h * s, GOLD, dx * 0.3)
    if "curl_horns" in ex:
        for sd in (-1, 1):
            p.blob(cx + sd * 12.5 * s, hy - 5, 4.2 * s, 5.6 * s, (240, 228, 200, 255), sd * 20)
            p.blob(cx + sd * 16 * s, hy - 3, 3.2 * s, 3.6 * s, (240, 228, 200, 255), sd * 40)
            p.blob(cx + sd * 17 * s, hy + 2, 2.2 * s, 2.4 * s, (225, 210, 180, 255))
    if "horn" in ex:
        spike(p, cx, hy - 10, 3.2, 14 * s, (250, 240, 210, 255), 0)

    # feet, body
    p.blob(cx - 10 * s, 58, 6.5, 4, dark)
    p.blob(cx + 10 * s, 58, 6.5, 4, dark)
    p.blob(cx, by, bw + 1, bh, body)
    for sd in (-1, 1):
        p.blob(cx + sd * (bw - 1), 52, 4.3, 6.2, dark)
        if "claws" in ex and not back:
            for k in (-1, 0, 1):
                p.px([(round(cx + sd * (bw - 1) + k * 1.6), 58)], CREAM)
    if not back:
        p.oval(cx, 49.5, 7.5 * s, 7.5, belly)
        p.oval(cx - 1, 48.5, 6 * s, 6, lighter(belly, 0.4))
    if "stripes" in ex:
        for y0 in (40, 47):
            stripe(p, y0, y0 + 1, 0.7)

    if back:
        # tail comes toward the viewer
        if tail == "fluff" or tail == "sweep":
            p.blob(cx, 54, 8 * s, 6.5, body); p.oval(cx, 56, 4, 3, acc)
        elif tail == "bolt":
            bolt(p, cx, 52, 1.1 * s, P.get("tailcol", GOLD))
        elif tail == "whip":
            tail_curve(p, [(cx, 52), (cx + 4, 55), (cx + 7, 56)], [3, 2.8, 2.5], body)
        elif tail == "flame":
            flame(p, cx, 53, 1.4 * s)
        elif tail == "ice":
            for a in (-9, 0, 9):
                spike(p, cx + a, 59, 3.4, 11, ICE, a * 0.2)

    # head
    p.blob(cx, hy, (14.5 if back else 14) * s, (12 if back else 11.8) * s, body)
    if "gem" in ex:
        gc = P.get("gemcol", (230, 80, 200, 255))
        p.poly([(cx, hy - 11 * s), (cx - 3, hy - 7 * s), (cx, hy - 3.5 * s), (cx + 3, hy - 7 * s)], rgb(gc, 0.7))
        p.poly([(cx, hy - 10 * s), (cx - 2, hy - 7 * s), (cx, hy - 4.5 * s), (cx + 2, hy - 7 * s)], gc)
    if back:
        p.oval(cx, hy + 9, 9, 2.4, dark)
        if "stripes" in ex:
            stripe(p, hy - 5, hy - 4, 0.75)
        return
    # face
    eyes(p, cx, hy + 1, 6.5 * min(s, 1.1), 3.6, P.get("eyes", "cute"), P.get("iris"))
    cheeks(p, cx, hy + 7, 11.5 * min(s, 1.1), P.get("cheek", BLUSH))
    if "bolt_cheeks" in ex:
        for sd in (-1, 1):
            p.oval(cx + sd * 12, hy + 7, 3.4, 3.2, (235, 60, 50, 255))
    p.oval(cx, hy + 6, 1.6, 1.2, INK)
    smile(p, cx, hy + 8, 2)
    if "teeth" in ex:
        p.px([(cx - 2, hy + 10), (cx - 1, hy + 10), (cx - 2, hy + 11), (cx - 1, hy + 11), (cx, hy + 10), (cx + 1, hy + 10), (cx, hy + 11), (cx + 1, hy + 11)], WHITE)
    if "fangs" in ex:
        p.px([(cx - 4, hy + 10), (cx - 4, hy + 11), (cx + 4, hy + 10), (cx + 4, hy + 11)], WHITE)
    if "whiskers" in ex:
        for sd in (-1, 1):
            for dy in (-1, 2):
                p.d.line([(round(cx + sd * 13), round(hy + 6 + dy)), (round(cx + sd * 19), round(hy + 5 + dy * 2))], fill=INK, width=1)


# ------------------------------------------------------------------ bird
def bird(p, back, P):
    body, belly, wing = P["body"], P["belly"], P.get("wing", rgb(P["body"], 0.8))
    beak = P.get("beak", (250, 190, 60, 255))
    evo = P.get("evo", False)
    owl = P.get("owl", False)
    s = 1.12 if evo else 1.0
    dark = rgb(body, 0.72)
    cx, hy = 32, 27
    # tail feathers
    if not back:
        for a in (-12, 0, 12):
            p.poly([(cx + a * 0.4 - 3, 54), (cx + a, 63), (cx + a * 0.4 + 3, 54)], rgb(wing, 0.85))
    # crest / tufts behind head
    if P.get("crest"):
        for dx, h in ((-7, 14), (0, 18), (7, 14)):
            spike(p, cx + dx, hy - 8, 3.4, h, P.get("crestcol", wing), dx * 0.2)
    if owl:
        for sd in (-1, 1):
            p.poly([(cx + sd * 6, hy - 8), (cx + sd * 13, hy - 20), (cx + sd * 14, hy - 5)], rgb(body, 0.7))
            p.poly([(cx + sd * 7.5, hy - 8), (cx + sd * 12.5, hy - 17), (cx + sd * 13, hy - 6)], body)
    # legs
    for sd in (-1, 1):
        p.blob(cx + sd * 8, 59, 4.6, 3.2, P.get("leg", (240, 170, 60, 255)))
    # wings behind/side of body
    for sd in (-1, 1):
        p.blob(cx + sd * 16.5 * s, 45, 5.2 * s, 11 * s, wing, sd * 12)
    p.blob(cx, 46, 15 * s, 13.5, body)
    if not back:
        p.oval(cx, 49, 9 * s, 9, belly); p.oval(cx - 1, 48, 7 * s, 7, lighter(belly, 0.4))
    else:
        for sd in (-1, 1):
            p.blob(cx + sd * 12 * s, 47, 5 * s, 11, wing, sd * -8)
        for a in (-9, 0, 9):
            p.poly([(cx + a * 0.4 - 3.5, 52), (cx + a, 63), (cx + a * 0.4 + 3.5, 52)], rgb(wing, 0.85))
            p.poly([(cx + a * 0.4 - 2, 52), (cx + a, 60), (cx + a * 0.4 + 2, 52)], wing)
    # head
    p.blob(cx, hy, 13.5 * s if not back else 14 * s, 12 * s, body)
    if back:
        p.oval(cx, hy + 9, 9, 2.4, dark)
        return
    if owl:
        for sd in (-1, 1):
            p.oval(cx + sd * 6.5, hy + 1, 5.6, 5.8, lighter(P.get("disc", belly), 0.15))
        eyes(p, cx, hy + 1, 6.5, 4.2, "cute", P.get("iris"))
    else:
        eyes(p, cx, hy + 1, 6.5, 3.6, "fierce" if evo and not P.get("soft") else "cute")
    p.poly([(cx - 3.5, hy + 5), (cx, hy + 12), (cx + 3.5, hy + 5)], rgb(beak, 0.78))
    p.poly([(cx - 2.2, hy + 5), (cx, hy + 9.6), (cx + 2.2, hy + 5)], beak)
    cheeks(p, cx, hy + 6.5, 10.5)
    if P.get("gem"):
        gc = P["gem"]
        p.poly([(cx, hy - 10), (cx - 2.6, hy - 6.5), (cx, hy - 3.5), (cx + 2.6, hy - 6.5)], rgb(gc, 0.7))
        p.poly([(cx, hy - 9), (cx - 1.6, hy - 6.5), (cx, hy - 4.5), (cx + 1.6, hy - 6.5)], gc)


# ------------------------------------------------------------------ bugs: larva / cocoon / butterfly / bee
def bug(p, back, P):
    kind = P["kind"]
    body, belly = P["body"], P["belly"]
    dark = rgb(body, 0.72)
    cx = 32
    if kind == "larva":
        for i, (y, r) in enumerate(((54, 10), (45, 10.5), (36, 10))):
            p.blob(cx, y, r + 2, r - 1, body if i % 2 == 0 else lighter(body, 0.15))
        for sd in (-1, 1):
            p.blob(cx + sd * 9, 57, 3.5, 3, dark)
            p.blob(cx + sd * 10, 46, 3, 3.6, dark)
        hy = 24
        for sd in (-1, 1):
            p.d.line([(round(cx + sd * 6), hy - 9), (round(cx + sd * 10), hy - 18)], fill=dark, width=2)
            p.oval(cx + sd * 10, hy - 18, 2.4, 2.4, P.get("tip", (230, 90, 90, 255)))
        p.blob(cx, hy, 13.5, 12, body)
        if back:
            for k in (-1, 0, 1):
                p.oval(cx + k * 6, hy - 3, 1.8, 2.4, dark)
            return
        eyes(p, cx, hy + 1, 6.5, 4.0)
        cheeks(p, cx, hy + 7, 10.5); smile(p, cx, hy + 8, 3)
        p.oval(cx, 49, 6.5, 5, belly)
    elif kind == "cocoon":
        p.blob(cx, 40, 15.5, 22, body)
        for y in (30, 38, 46, 54):
            stripe(p, y, y, 0.78)
        p.poly([(cx - 5, 22), (cx, 10), (cx + 5, 22)], rgb(body, 0.72)); p.poly([(cx - 3.5, 22), (cx, 13), (cx + 3.5, 22)], lighter(body, 0.1))
        p.blob(cx, 58, 9, 3.6, dark)
        if back:
            p.oval(cx, 36, 7, 12, rgb(body, 0.85))
            return
        for sd in (-1, 1):
            p.oval(cx + sd * 6, 30, 3.2, 3.4, WHITE); p.oval(cx + sd * 6, 30.6, 1.9, 2.3, INK)
        p.px([(cx - 1, 37), (cx, 37), (cx + 1, 37)], INK)
        cheeks(p, cx, 35, 10.5)
    elif kind == "butterfly":
        wing, spot = P["wing"], P.get("spot", (255, 230, 120, 255))
        for sd in (-1, 1):
            p.blob(cx + sd * 18, 27, 13, 16, wing, sd * 28)
            p.blob(cx + sd * 15, 47, 9.5, 11, rgb(wing, 0.88), sd * -20)
            if not back:
                p.oval(cx + sd * 19, 24, 4, 5, spot, sd * 28); p.oval(cx + sd * 19, 24, 2, 2.6, INK, sd * 28)
                p.oval(cx + sd * 15, 47, 3, 3.6, spot)
        p.blob(cx, 44, 7, 15, body)
        for y in (38, 44, 50):
            stripe(p, y, y, 0.75)
        hy = 24
        for sd in (-1, 1):
            p.d.line([(round(cx + sd * 4), hy - 7), (round(cx + sd * 9), hy - 18), (round(cx + sd * 13), hy - 20)], fill=INK, width=1)
            p.oval(cx + sd * 13, hy - 20, 1.8, 1.8, spot)
        p.blob(cx, hy, 10.5, 9.5, body)
        if not back:
            eyes(p, cx, hy, 5, 3.4, "cute", P.get("iris"))
            smile(p, cx, hy + 6, 2)
    elif kind == "bee":
        evo = P.get("evo", False)
        s = 1.12 if evo else 1.0
        wing = (200, 235, 250, 255)
        for sd in (-1, 1):
            p.blob(cx + sd * 17 * s, 34, 6.5 * s, 11 * s, wing, sd * 28)
        p.blob(cx, 47, 14 * s, 12.5 * s, body)
        for y0 in (40, 47, 54):
            stripe(p, y0, y0 + 2, 0.45)
        if not back:
            p.poly([(cx - 3, 56), (cx, 63), (cx + 3, 56)], INK)
        else:
            p.poly([(cx - 4, 54), (cx, 63), (cx + 4, 54)], rgb(P.get("sting", (60, 50, 70, 255)), 0.8))
        for sd in (-1, 1):
            p.blob(cx + sd * 8, 59, 3.4, 3, dark)
        if evo:
            for sd in (-1, 1):  # lances
                p.blob(cx + sd * 17 * s, 46, 4, 6, dark)
                p.poly([(cx + sd * 17 * s - 2, 50), (cx + sd * 17 * s + sd * 1, 62), (cx + sd * 17 * s + 2, 50)], (230, 230, 240, 255))
        hy = 26
        for sd in (-1, 1):
            p.d.line([(round(cx + sd * 5), hy - 9), (round(cx + sd * 9), hy - 17)], fill=INK, width=1)
            p.oval(cx + sd * 9, hy - 17, 1.8, 1.8, INK)
        p.blob(cx, hy, 11.5 * s, 10.5 * s, body)
        if back:
            return
        eyes(p, cx, hy + 1, 5.6, 3.5, "fierce" if evo else "cute")
        cheeks(p, cx, hy + 6, 9.5); smile(p, cx, hy + 7, 2)


# ------------------------------------------------------------------ rock golem
def rock(p, back, P):
    body, acc = P["body"], P.get("acc", (190, 150, 90, 255))
    evo = P.get("evo", False)
    s = 1.18 if evo else 1.0
    dark = rgb(body, 0.7)
    cx = 32
    # back plates / spikes
    if evo:
        for dx, y, h in ((-12, 22, 12), (-4, 17, 14), (5, 17, 14), (13, 22, 12)):
            spike(p, cx + dx, y + 8, 4.2, h, rgb(body, 0.85), dx * 0.1)
    p.blob(cx - 11, 58, 7, 4, dark); p.blob(cx + 11, 58, 7, 4, dark)
    p.blob(cx, 42, 17 * s, 16 * s, body)
    # lumps for a rocky silhouette
    for dx, dy, r in ((-13, 33, 4.5), (12, 31, 5), (0, 27, 5.5), (-5, 29, 4)):
        p.blob(cx + dx * s, dy, r * s, r * s, lighter(body, 0.05))
    for sd in (-1, 1):
        p.blob(cx + sd * 19 * s, 47, 5.5 * s, 8 * s, dark)
        p.blob(cx + sd * 19 * s, 55, 5 * s, 4.5 * s, rgb(body, 0.62))
    # mud / earth band
    if P.get("earth"):
        px = p.img.load()
        for y in range(52, 60):
            for x in range(W):
                if px[x, y][3] > 0 and y > 53 + (x % 5 == 0):
                    px[x, y] = acc[:3] + (255,)
    # cracks
    for pts in (((cx - 8, 34), (cx - 5, 39), (cx - 7, 44)), ((cx + 9, 50), (cx + 6, 54), (cx + 8, 58))):
        p.d.line([(round(a), round(b)) for a, b in pts], fill=dark, width=1)
    if back:
        for dx, dy in ((-8, 40), (6, 36), (0, 48)):
            p.blob(cx + dx, dy, 4.5, 4, rgb(body, 0.85))
        return
    p.oval(cx, 44, 10 * s, 7.5, lighter(body, 0.18))
    eyes(p, cx, 36, 7 * s, 3.8 if not evo else 3.6, "fierce" if evo else "cute")
    p.oval(cx, 43, 1.8, 1.2, dark)
    smile(p, cx, 46, 3)
    cheeks(p, cx, 43, 13 * s)


# ------------------------------------------------------------------ snake / serpent
def snake(p, back, P):
    body, belly = P["body"], P["belly"]
    evo = P.get("evo", False)
    wings = P.get("wings", False)
    s = 1.1 if evo else 1.0
    dark = rgb(body, 0.72)
    cx, hy = 32, 22
    acc = P.get("acc", (250, 220, 90, 255))
    if wings:
        for sd in (-1, 1):
            p.poly([(cx + sd * 6, 34), (cx + sd * 27, 20), (cx + sd * 25, 34), (cx + sd * 22, 40), (cx + sd * 6, 42)], rgb(P["wing"], 0.78))
            p.poly([(cx + sd * 8, 36), (cx + sd * 24, 24), (cx + sd * 23, 34), (cx + sd * 20, 38), (cx + sd * 8, 40)], P["wing"])
    if evo and P.get("hood"):
        for sd in (-1, 1):
            pass
        p.blob(cx, 28, 19, 12, rgb(body, 0.9))
        if not back:
            for sd in (-1, 1):
                p.oval(cx + sd * 12, 28, 2.6, 2.6, acc); p.oval(cx + sd * 12, 28, 1.2, 1.2, INK)
    # coils
    for y, rx, ry, c in ((56, 17, 5.8, dark), (50, 14, 5.4, body), (44, 11, 5.2, lighter(body, 0.08))):
        p.blob(cx, y, rx * s, ry, c)
    # tail tip
    tail_curve(p, [(cx + 15, 57), (cx + 21, 54), (cx + 24, 49)], [3.2, 2.6, 2.0], dark)
    # neck
    p.blob(cx, 35, 7.5 * s, 9, body)
    if not back:
        p.oval(cx, 38, 4.6, 8, belly)
    # head
    p.blob(cx, hy, 12 * s, 10 * s, body)
    if wings:
        for sd in (-1, 1):
            spike(p, cx + sd * 9, hy - 7, 3.2, 11, P["wing"], sd * 4)
        spike(p, cx, hy - 9, 3.6, 12, P["wing"], 0)
    if back:
        for k in (-1, 0, 1):
            p.oval(cx + k * 5, hy - 2, 1.8, 2.4, dark)
        return
    for sd in (-1, 1):
        ex = cx + sd * 6
        p.oval(ex, hy, 3.3, 3.8, (255, 240, 120, 255) if P.get("slit", True) else WHITE)
        p.oval(ex, hy + 0.4, 1.0, 3.0, INK)
        p.px([(round(ex - 1), round(hy - 1))], WHITE)
    cheeks(p, cx, hy + 5.5, 9.5)
    smile(p, cx, hy + 6, 3)
    p.px([(cx - 3, hy + 9), (cx - 3, hy + 10), (cx + 3, hy + 9), (cx + 3, hy + 10)], WHITE)
    if P.get("tongue", True):
        p.d.line([(cx, hy + 9), (cx, hy + 12)], fill=(230, 60, 90, 255), width=1)


# ------------------------------------------------------------------ plant
def plant(p, back, P):
    body, petal = P["body"], P["petal"]
    evo = P.get("evo", False)
    s = 1.12 if evo else 1.0
    dark = rgb(body, 0.72)
    cx = 32
    if not back:
        pass
    # bloom / bud behind the face
    if evo:
        for i in range(7):
            a = i / 7 * math.tau
            p.blob(cx + math.cos(a) * 12, 19 + math.sin(a) * 9, 6.5, 6.5, petal if i % 2 else lighter(petal, 0.12))
        p.blob(cx, 19, 6.5, 5.5, P.get("centre", (250, 215, 80, 255)))
    else:
        p.poly([(cx - 9, 24), (cx - 6, 8), (cx, 3), (cx + 6, 8), (cx + 9, 24)], rgb(petal, 0.72))
        p.poly([(cx - 7, 24), (cx - 4.5, 10), (cx, 6), (cx + 4.5, 10), (cx + 7, 24)], petal)
        for sd in (-1, 1):
            leaf(p, cx + sd * 12, 22, 3.4, 9, sd * 55, (95, 190, 90, 255))
    p.blob(cx - 11, 58, 7, 4, dark); p.blob(cx + 11, 58, 7, 4, dark)
    p.blob(cx, 44, 16 * s, 14 * s, body)
    for sd in (-1, 1):
        p.blob(cx + sd * 17 * s, 46, 3.8, 6, dark)
    for sd in (-1, 1):  # vine arms
        leaf(p, cx + sd * 20 * s, 40, 3, 8, sd * -30, (80, 170, 80, 255))
    p.oval(cx, 49, 9 * s, 8, lighter(body, 0.45)) if not back else None
    if back:
        for dy in (36, 44, 52):
            stripe(p, dy, dy, 0.8)
        return
    eyes(p, cx, 38, 7, 3.7, "fierce" if evo else "cute")
    cheeks(p, cx, 44, 12.5)
    p.oval(cx, 43, 1.5, 1.1, INK)
    smile(p, cx, 45, 3)
    if evo:
        p.px([(cx - 4, 49), (cx - 4, 50), (cx + 4, 49), (cx + 4, 50)], WHITE)


# ------------------------------------------------------------------ ghost
def ghost(p, back, P):
    body = P["body"]
    evo = P.get("evo", False)
    s = 1.15 if evo else 1.0
    dark = rgb(body, 0.62)
    glow = P.get("glow", (210, 170, 255, 255))
    cx = 32
    # wispy tail
    for i, (y, r) in enumerate(((52, 6), (57, 4.2), (61, 2.6))):
        p.blob(cx + (4 if i == 1 else -3 if i == 2 else 0), y, r * s, r * 0.8, rgb(body, 0.9 - i * 0.12))
    # horns for the evolved one, a little wisp flame for the small one
    if evo:
        for sd in (-1, 1):
            spike(p, cx + sd * 10, 18, 4, 14, P.get("horn", (150, 220, 100, 255)), sd * 3)
        spike(p, cx, 17, 3.4, 15, P.get("horn", (150, 220, 100, 255)), 0)
    else:
        for dx, h in ((-5, 9), (0, 14), (5, 9)):
            spike(p, cx + dx, 24, 3.2, h, glow, dx * 0.25)
    p.blob(cx, 36, 16 * s, 15 * s, body)
    # inner glow
    p.oval(cx, 38, 11 * s, 10 * s, lighter(body, 0.2))
    if evo:
        for sd in (-1, 1):
            p.blob(cx + sd * 19 * s, 44, 5, 6, lighter(body, 0.1), sd * -20)
            for k in (-1, 0, 1):
                p.px([(round(cx + sd * 19 * s + k * 2), 49)], rgb(body, 0.6))
    else:
        for sd in (-1, 1):
            p.blob(cx + sd * 16, 45, 3.6, 4.6, body, sd * -20)
    if back:
        for pts in (((cx - 7, 30), (cx, 26), (cx + 7, 31)), ((cx - 8, 42), (cx, 46), (cx + 8, 41))):
            p.d.line([(round(a), round(b)) for a, b in pts], fill=dark, width=1)
        return
    for sd in (-1, 1):
        ex = cx + sd * 7
        p.oval(ex, 33, 4.2, 4.6, glow)
        p.oval(ex - sd * 0.5, 33.6, 2.3, 3.0, INK)
        p.px([(round(ex - 1), 32)], WHITE)
    p.px([(cx - 7, 41), (cx - 5, 42), (cx - 3, 43), (cx - 1, 43), (cx + 1, 43), (cx + 3, 43), (cx + 5, 42), (cx + 7, 41)], INK)
    p.px([(cx - 4, 44), (cx - 4, 45), (cx, 44), (cx, 45), (cx + 4, 44), (cx + 4, 45)], WHITE)


# ------------------------------------------------------------------ biped (fighter / bear / sleeper)
def biped(p, back, P):
    body, belly = P["body"], P["belly"]
    evo = P.get("evo", False)
    sleepy = P.get("sleepy", False)
    s = P.get("size", 1.18 if evo else 1.0)
    dark = rgb(body, 0.72)
    cx, hy = 32, 26 if not sleepy else 27
    acc = P.get("acc", (220, 60, 60, 255))
    ears = P.get("ears", "none")
    # ears
    if ears == "round":
        for sd in (-1, 1):
            p.blob(cx + sd * 11 * s, hy - 9, 5.2 * s, 5.2 * s, body); p.oval(cx + sd * 11 * s, hy - 8.5, 2.6, 2.6, belly)
    # feet and body
    p.blob(cx - 10 * s, 58, 7.5, 4.2, dark); p.blob(cx + 10 * s, 58, 7.5, 4.2, dark)
    bw = (20 if sleepy else 15) * s if not sleepy else 21
    bh = 15 if sleepy else 13 * s
    p.blob(cx, 45 if not sleepy else 43, bw, bh, body)
    for sd in (-1, 1):
        if P.get("fists"):
            p.blob(cx + sd * (bw + 1), 47, 5.2 * s, 7 * s, dark)
            p.blob(cx + sd * (bw + 1), 55, 5.8 * s, 5.2 * s, acc)
        else:
            p.blob(cx + sd * (bw + 0.5), 47, 3.8 * s, 6 * s, dark)
    if not back:
        p.oval(cx, 48, (10 if sleepy else 8) * s, 8 if not sleepy else 10, belly)
        p.oval(cx - 1, 47, (8.5 if sleepy else 6.5) * s, 6.5 if not sleepy else 8.5, lighter(belly, 0.4))
    # head
    p.blob(cx, hy, (14 if not sleepy else 13) * s if not sleepy else 14, 11.8 * s if not sleepy else 11, body)
    if P.get("band"):
        stripe_y = hy - 5
        p.poly([(cx - 14 * s, stripe_y - 1), (cx + 14 * s, stripe_y - 1), (cx + 14 * s, stripe_y + 3), (cx - 14 * s, stripe_y + 3)], acc)
        p.poly([(cx + 13 * s, stripe_y), (cx + 22 * s, stripe_y - 5), (cx + 20 * s, stripe_y + 3)], acc)
        p.poly([(cx + 13 * s, stripe_y + 1), (cx + 21 * s, stripe_y + 6), (cx + 18 * s, stripe_y - 1)], rgb(acc, 0.8))
    if back:
        p.oval(cx, hy + 9, 9, 2.4, dark)
        return
    eyes(p, cx, hy + 1, 6.5 * min(s, 1.1), 3.6, "sleepy" if sleepy else ("fierce" if evo else "cute"))
    cheeks(p, cx, hy + 7, 11.5 * min(s, 1.1))
    if ears == "round":
        p.oval(cx, hy + 6, 5.5, 4, belly)
        p.oval(cx, hy + 4.6, 2.0, 1.4, INK)
        smile(p, cx, hy + 8, 2)
    else:
        smile(p, cx, hy + 8, 3)
    if sleepy:
        p.d.text((cx + 12, hy - 10), "z", fill=(250, 250, 250, 255))
    if P.get("scar"):
        p.d.line([(cx + 5, hy - 6), (cx + 9, hy + 1)], fill=dark, width=1)


# ------------------------------------------------------------------ fish (flopfin)
def fish(p, back, P):
    body, belly, fin = P["body"], P["belly"], P["fin"]
    cx = 32
    # tail fin
    for sd in (-1, 1):
        p.blob(cx + sd * 6, 58, 6, 4, fin, sd * 30)
    # side fins
    for sd in (-1, 1):
        p.blob(cx + sd * 19, 44, 6.5, 4, fin, sd * 35)
    spike(p, cx, 26, 6, 14, fin, 0)
    p.blob(cx, 42, 17, 18, body)
    if not back:
        p.oval(cx, 50, 10, 9, belly)
    stripe(p, 36, 37, 0.8); stripe(p, 44, 45, 0.85)
    if back:
        return
    for sd in (-1, 1):
        p.oval(cx + sd * 8, 33, 4.6, 5, WHITE); p.oval(cx + sd * 8 - sd * 0.5, 33.6, 2.6, 3.2, INK)
        p.px([(cx + sd * 8 - 1, 32)], WHITE)
    p.oval(cx, 43, 6.5, 3.4, (150, 40, 50, 255))
    p.oval(cx, 42, 5.5, 2.4, (235, 90, 100, 255))
    for sd in (-1, 1):
        p.px([(cx + sd * 3, 41), (cx + sd * 3, 40)], WHITE)
    cheeks(p, cx, 40, 13.5)


# ------------------------------------------------------------------ species table
# ------------------------------------------------------------------ legendary body plans
# Bigger than the everyday critters (they fill most of the 64x64 sprite) and each wears a gem and a ring of sparkles.
# The sparkles are drawn AFTER the outline pass (see draw_extra), so they stay thin and bright.
def sparkle_at(p, x, y, s=2, col=GOLD):
    p.post.append((x, y, s, col))


def aura(p, pts, col=GOLD):
    for x, y, s in pts:
        sparkle_at(p, x, y, s, col)


def stag(p, back, P):
    """Verdarch: a forest elder. Deer body, a crown of branching antlers tipped with leaves, a psychic gem on the brow."""
    body, belly, ant, tip, gem, mane = P["body"], P["belly"], P["antler"], P["tip"], P["gem"], P["mane"]
    cx = 32
    dark = rgb(body, 0.62)
    # antlers first (behind the head)
    for sd in (-1, 1):
        beam = [(cx + sd * 5, 17), (cx + sd * 9, 10), (cx + sd * 16, 6), (cx + sd * 22, 7)]
        p.d.line([(round(a), round(b)) for a, b in beam], fill=rgb(ant, 0.7), width=4)
        p.d.line([(round(a), round(b)) for a, b in beam], fill=ant, width=2)
        for (tx, ty, ex, ey) in ((cx + sd * 9, 10, cx + sd * 8, 2), (cx + sd * 16, 6, cx + sd * 17, 1), (cx + sd * 13, 8, cx + sd * 14, 14)):
            p.d.line([(round(tx), round(ty)), (round(ex), round(ey))], fill=ant, width=2)
        for (lx, ly, rot) in ((cx + sd * 23, 8, sd * 25), (cx + sd * 8, 2, sd * -15), (cx + sd * 17, 2, sd * 15)):
            leaf(p, lx, ly, 4.2, 2.2, rot, tip)
    # legs and hooves
    for sd in (-1, 1):
        p.blob(cx + sd * 10, 53, 5.2, 7, rgb(body, 0.92))
        p.oval(cx + sd * 10, 59.5, 4.4, 2.2, rgb(ant, 0.55))
    # body
    p.blob(cx, 42, 17.5, 15.5, body)
    if back:
        for k, (dx, dy, rot) in enumerate(((-7, 37, -35), (7, 37, 35), (-9, 45, -50), (9, 45, 50), (0, 41, 0), (0, 49, 0))):
            leaf(p, cx + dx, dy, 4.4, 2.3, rot, mane)
        p.blob(cx, 56, 5, 4, lighter(mane, 0.35))   # tail tuft
    else:
        p.oval(cx, 46, 10.5, 9.5, belly)
    # leafy mane around the neck
    for dx, dy, rot in ((-12, 31, -60), (-7, 33, -25), (7, 33, 25), (12, 31, 60)):
        leaf(p, cx + dx, dy, 5, 2.6, rot, mane)
    # head, ears
    for sd in (-1, 1):
        p.blob(cx + sd * 13.5, 20, 3.4, 7.5, body, sd * 38)
        if not back:
            p.oval(cx + sd * 13.2, 20.5, 1.6, 4.6, (255, 190, 200, 255), sd * 38)
    p.blob(cx, 25, 11.5, 10.5, body)
    p.oval(cx, 19.5, 2.7, 3.3, gem)
    p.oval(cx - 0.8, 18.5, 0.9, 1.2, WHITE)
    if back:
        aura(p, [(7, 24, 2), (57, 30, 2), (12, 52, 1), (53, 50, 1), (32, 3, 1)], (150, 255, 150, 255))
        return
    eyes(p, cx, 23, sep=5.6, r=3.3, iris=P.get("iris", (240, 190, 70, 255)))
    p.oval(cx, 29.5, 2.4, 1.6, INK)
    smile(p, cx, 31, 2)
    cheeks(p, cx, 29, dx=8.5, r=2.0)
    aura(p, [(6, 26, 2), (58, 32, 2), (10, 50, 1), (54, 48, 1), (32, 3, 1), (4, 12, 1)], (150, 255, 150, 255))


def leviathan(p, back, P):
    """Maelarch: a sea sovereign. Broad whale body, a crown of ice crystals, a pearl on the brow, riding the waves."""
    body, belly, fin, ice, gem = P["body"], P["belly"], P["fin"], P["ice"], P["gem"]
    cx = 32
    # flippers behind the body
    for sd in (-1, 1):
        p.blob(cx + sd * 25, 42, 9, 5, fin, sd * -28)
        p.blob(cx + sd * 29, 36, 4.5, 3, lighter(fin, 0.2), sd * -50)
    # tail fluke curling over the back (seen from behind) / water base (from the front)
    # body
    p.blob(cx, 40, 23, 17.5, body)
    if back:
        for i in range(5):
            spike(p, cx - 12 + i * 6, 26 + (abs(i - 2) * 2), 3, 9 - abs(i - 2), ice, 0)
        p.blob(cx - 7, 56, 8, 3.6, fin, 24); p.blob(cx + 7, 56, 8, 3.6, fin, -24)
        for y in (36, 43, 49):
            p.d.line([(cx - 14, y), (cx, y + 2), (cx + 14, y)], fill=rgb(body, 0.62), width=1)
    else:
        p.oval(cx, 47, 17.5, 9.5, belly)
        for y in (44, 48, 52):
            p.d.line([(cx - 12, y), (cx + 12, y)], fill=rgb(belly, 0.86), width=1)
    # crown of ice crystals
    for dx, h, tdx in ((-13, 11, -3), (-7, 15, -1.5), (0, 19, 0), (7, 15, 1.5), (13, 11, 3)):
        spike(p, cx + dx, 24 + abs(dx) * 0.25, 3.3 if dx == 0 else 2.8, h, ice, tdx)
    p.oval(cx, 25, 3.0, 3.4, gem)
    p.oval(cx - 0.8, 24, 1.0, 1.2, WHITE)
    # waves at the base
    for k, x in enumerate((8, 22, 36, 50)):
        p.blob(x, 59.5, 7, 2.6, (200, 235, 255, 255) if k % 2 == 0 else (150, 205, 245, 255))
    if back:
        aura(p, [(5, 22, 2), (59, 24, 2), (4, 50, 1), (60, 48, 1), (32, 4, 1)], (170, 235, 255, 255))
        return
    eyes(p, cx, 32, sep=8.5, r=3.7, iris=P.get("iris", (60, 200, 235, 255)))
    smile(p, cx, 40, 5)
    cheeks(p, cx, 38, dx=14.5)
    aura(p, [(5, 24, 2), (59, 26, 2), (4, 52, 1), (60, 50, 1), (32, 3, 1), (13, 6, 1)], (170, 235, 255, 255))


def phoenix(p, back, P):
    """Pyrarch: a dawn bird. Wings of flame-tipped feathers, a crest of three flames, a long burning tail, a sun gem."""
    body, belly, gold, gem = P["body"], P["belly"], P["gold"], P["gem"]
    cx = 32
    red = rgb(body, 0.8)
    # tail flames behind everything
    for x, y, s in ((cx - 11, 56, 1.0), (cx + 11, 56, 1.0), (cx - 5, 59, 1.15), (cx + 5, 59, 1.15), (cx, 58, 1.3)):
        flame(p, x, y, s, 1)
    # wings: a fan of feathers
    for sd in (-1, 1):
        feathers = [((cx + sd * 12, 30), (cx + sd * 29, 9), (cx + sd * 18, 40)),
                    ((cx + sd * 12, 34), (cx + sd * 30, 22), (cx + sd * 18, 44)),
                    ((cx + sd * 12, 38), (cx + sd * 30, 35), (cx + sd * 18, 48)),
                    ((cx + sd * 12, 42), (cx + sd * 28, 47), (cx + sd * 17, 52))]
        for k, (a, b, c2) in enumerate(feathers):
            p.poly([a, b, c2], rgb(body, 0.66))
            p.poly([(a[0], a[1] + 1), ((a[0] + b[0]) / 2 + sd * 1, (a[1] + b[1]) / 2 + 1), ((a[0] + c2[0]) / 2, (a[1] + c2[1]) / 2 + 1)], body)
            tipx = b[0] - sd * 2; tipy = b[1] + 2
            p.poly([b, (tipx, tipy + 4), (tipx - sd * 4, tipy + 1)], (255, 170, 50, 255))
            p.px([(round(b[0] - sd), round(b[1] + 1))], (255, 235, 130, 255))
    # body
    p.blob(cx, 39, 14.5, 16, body)
    if not back:
        p.oval(cx, 43, 9.5, 10.5, belly)
        p.oval(cx, 41, 3.1, 3.4, gem)
        p.oval(cx - 0.8, 40, 1.0, 1.2, WHITE)
    else:
        for y in (34, 40, 46):
            p.d.line([(cx - 8, y), (cx, y + 2), (cx + 8, y)], fill=red, width=1)
    # talons
    for sd in (-1, 1):
        p.oval(cx + sd * 6, 55, 3.6, 2.0, gold)
    # head and crest
    p.blob(cx, 22, 10.5, 10, body)
    for dx, y, s in ((-6, 13, 0.75), (0, 9, 1.0), (6, 13, 0.75)):
        flame(p, cx + dx, y, s, 1 if dx >= 0 else -1)
    if back:
        aura(p, [(5, 20, 2), (59, 24, 2), (6, 56, 1), (58, 54, 1), (32, 2, 1)], (255, 225, 120, 255))
        return
    p.poly([(cx - 3.6, 25), (cx + 3.6, 25), (cx, 31.5)], gold)
    p.poly([(cx - 2.2, 25), (cx + 2.2, 25), (cx, 28.5)], lighter(gold, 0.35))
    eyes(p, cx, 20, sep=5.4, r=3.2, style="fierce", iris=P.get("iris", (255, 190, 60, 255)))
    aura(p, [(4, 18, 2), (60, 22, 2), (6, 54, 1), (58, 52, 1), (32, 2, 1), (15, 4, 1)], (255, 225, 120, 255))


def bellghost(p, back, P):
    """Tollwraith: the echo of the Heart Bell. A floating bell with a ring on top, a glowing face and a golden clapper-gem."""
    body, glow, gold, gem = P["body"], P["glow"], P["gold"], P["gem"]
    cx = 32
    dark = rgb(body, 0.6)
    # drifting hands
    for sd in (-1, 1):
        p.blob(cx + sd * 27, 41, 4.4, 5.4, lighter(body, 0.28), sd * -15)
        for k in (-1, 0, 1):
            p.px([(round(cx + sd * 27 + k * 2), 47)], rgb(body, 0.55))
    # skirt of the bell, then the dome
    p.poly([(cx - 14, 30), (cx - 24, 52), (cx + 24, 52), (cx + 14, 30)], dark)
    p.poly([(cx - 13, 30), (cx - 22, 51), (cx + 22, 51), (cx + 13, 30)], body)
    p.poly([(cx - 10, 32), (cx - 14, 50), (cx - 6, 50), (cx - 3, 32)], lighter(body, 0.14))
    for x in (-20, -10, 0, 10, 20):
        p.blob(cx + x, 52, 5.6, 3.6, rgb(body, 0.92))
    p.d.line([(cx - 23, 49), (cx + 23, 49)], fill=gold, width=2)
    p.blob(cx, 29, 14.5, 13.5, body)
    # ring on top
    p.oval(cx, 13.5, 5.2, 4.2, rgb(gold, 0.7))
    p.oval(cx, 13.5, 3.8, 2.8, gold)
    p.oval(cx, 13.5, 1.8, 1.2, (0, 0, 0, 0))
    p.d.line([(cx, 17), (cx, 19)], fill=rgb(gold, 0.7), width=2)
    # clapper gem hanging in the mouth of the bell
    p.d.line([(cx, 50), (cx, 54)], fill=rgb(gold, 0.7), width=1)
    p.oval(cx, 57, 4.4, 4.6, gold)
    p.oval(cx, 57, 2.6, 2.8, gem)
    p.oval(cx - 0.9, 56, 0.9, 1.1, WHITE)
    if back:
        for k in range(8):
            a = math.tau * k / 8
            p.px([(round(cx + math.cos(a) * 7), round(30 + math.sin(a) * 6.5))], gold)
        p.px([(cx, 30), (cx - 1, 30), (cx + 1, 30)], gold)
        aura(p, [(6, 22, 2), (58, 24, 2), (5, 56, 1), (59, 54, 1), (32, 3, 1)], (210, 190, 255, 255))
        return
    for sd in (-1, 1):
        ex = cx + sd * 6.5
        p.oval(ex, 29, 4.4, 4.8, glow)
        p.oval(ex - sd * 0.6, 29.6, 2.4, 3.1, INK)
        p.px([(round(ex - 1), 28)], WHITE)
        p.d.line([(round(ex - sd * 6), 23), (round(ex + sd * 2), 25)], fill=dark, width=2)
    p.px([(cx - 4, 37), (cx - 2, 38), (cx, 38), (cx + 2, 38), (cx + 4, 37)], INK)
    aura(p, [(5, 24, 2), (59, 26, 2), (5, 56, 1), (59, 54, 1), (32, 3, 1), (12, 6, 1)], (210, 190, 255, 255))


def C(r, g, b, a=255):
    return (r, g, b, a)


EXTRA = {
    # name: (template, options)
    "pipwing": ("bird", dict(body=C(205, 170, 120), belly=C(250, 235, 205), wing=C(160, 120, 80), soft=True)),
    "swoopwing": ("bird", dict(body=C(190, 140, 90), belly=C(250, 235, 205), wing=C(130, 90, 60), crest=True, crestcol=C(220, 90, 70), evo=True)),
    "nibblet": ("quad", dict(body=C(180, 150, 200), belly=C(240, 225, 245), acc=C(240, 190, 210), ears="round", tail="whip", extras=["teeth", "whiskers"])),
    "gnawfang": ("quad", dict(body=C(150, 120, 170), belly=C(235, 220, 240), acc=C(230, 170, 200), ears="round", tail="whip", size=1.12, eyes="fierce", extras=["teeth", "whiskers", "fangs"])),
    "wrigglet": ("bug", dict(kind="larva", body=C(150, 205, 70), belly=C(225, 245, 170))),
    "cocovex": ("bug", dict(kind="cocoon", body=C(200, 195, 90), belly=C(240, 235, 160))),
    "glimmerwing": ("bug", dict(kind="butterfly", body=C(120, 90, 150), belly=C(200, 170, 220), wing=C(190, 120, 225), spot=C(255, 230, 120), iris=C(230, 80, 120))),
    "hivelet": ("bug", dict(kind="bee", body=C(240, 205, 60), belly=C(255, 235, 150))),
    "stingmaw": ("bug", dict(kind="bee", evo=True, body=C(215, 150, 60), belly=C(245, 210, 130), sting=C(150, 60, 190))),
    "zapling": ("quad", dict(body=C(85, 105, 195), belly=C(255, 240, 160), acc=C(250, 215, 80), ears="small", tail="bolt", cheek=C(255, 225, 80, 230), extras=["mane_spark"])),
    "voltmunk": ("quad", dict(body=C(60, 75, 165), belly=C(255, 235, 140), acc=C(250, 215, 80), ears="small", tail="bolt", size=1.12, eyes="fierce", cheek=C(255, 225, 80, 230), extras=["mane_spark", "claws"])),
    "pebblit": ("rock", dict(body=C(150, 140, 130), acc=C(190, 150, 90), earth=True)),
    "boulderback": ("rock", dict(body=C(120, 110, 100), acc=C(170, 130, 80), earth=True, evo=True)),
    "dustpup": ("quad", dict(body=C(210, 170, 100), belly=C(250, 232, 190), acc=C(160, 110, 60), ears="floppy", tail="whip", extras=["claws"])),
    "sandjaw": ("quad", dict(body=C(180, 130, 70), belly=C(240, 215, 165), acc=C(120, 80, 40), ears="floppy", tail="whip", size=1.12, eyes="fierce", extras=["claws", "fangs"])),
    "hissle": ("snake", dict(body=C(150, 100, 190), belly=C(235, 215, 120))),
    "coilfang": ("snake", dict(body=C(120, 70, 160), belly=C(235, 205, 110), evo=True, hood=True)),
    "budling": ("plant", dict(body=C(100, 190, 150), petal=C(225, 120, 190))),
    "bloomfang": ("plant", dict(body=C(70, 150, 120), petal=C(200, 80, 170), evo=True)),
    "mindle": ("quad", dict(body=C(240, 200, 120), belly=C(255, 240, 200), acc=C(200, 120, 200), ears="point", tail="sweep", extras=["gem"], gemcol=C(230, 80, 200))),
    "seerowl": ("bird", dict(body=C(200, 150, 230), belly=C(245, 230, 250), wing=C(140, 90, 190), owl=True, evo=True, gem=C(250, 100, 210), iris=C(230, 90, 190), disc=C(255, 240, 255), soft=True)),
    "wispet": ("ghost", dict(body=C(120, 130, 210), glow=C(190, 245, 255))),
    "haunthorn": ("ghost", dict(body=C(75, 80, 150), evo=True, glow=C(190, 255, 120), horn=C(150, 230, 110))),
    "scrappit": ("biped", dict(body=C(205, 150, 100), belly=C(250, 225, 185), band=True, fists=True, acc=C(220, 60, 60))),
    "brawlbear": ("biped", dict(body=C(165, 95, 65), belly=C(235, 200, 150), ears="round", fists=True, evo=True, scar=True, acc=C(220, 150, 50))),
    "frostkit": ("quad", dict(body=C(170, 220, 240), belly=C(245, 252, 255), acc=C(120, 190, 235), ears="crystal", tail="ice")),
    "glacifox": ("quad", dict(body=C(125, 185, 230), belly=C(240, 250, 255), acc=C(90, 150, 215), ears="crystal", tail="ice", size=1.12, eyes="fierce", extras=["mane_ice"])),
    "flopfin": ("fish", dict(body=C(235, 120, 95), belly=C(255, 215, 170), fin=C(250, 170, 90))),
    "tempestail": ("snake", dict(body=C(60, 120, 200), belly=C(215, 235, 250), evo=True, wings=True, wing=C(130, 200, 235), slit=True)),
    "cinderfoal": ("quad", dict(body=C(240, 150, 60), belly=C(255, 225, 170), acc=C(255, 190, 80), ears="floppy", tail="flame", extras=["mane_flame", "curl_horns"])),
    "pyrestrider": ("quad", dict(body=C(205, 85, 50), belly=C(250, 200, 140), acc=C(255, 170, 60), ears="floppy", tail="flame", size=1.12, eyes="fierce", extras=["mane_flame", "curl_horns", "claws"])),
    "fluffnap": ("biped", dict(body=C(110, 150, 160), belly=C(235, 245, 235), ears="round", sleepy=True, size=1.25)),
    # ---- legendary critters (fixed encounters, see Legends.kt): one per Archon + the Bell's echo
    "verdarch": ("stag", dict(body=C(70, 150, 95), belly=C(225, 245, 200), antler=C(190, 140, 80), tip=C(130, 230, 120), gem=C(240, 90, 190), mane=C(150, 220, 120))),
    "maelarch": ("leviathan", dict(body=C(50, 115, 205), belly=C(225, 242, 255), fin=C(95, 165, 235), ice=C(175, 235, 252), gem=C(255, 240, 250))),
    "pyrarch": ("phoenix", dict(body=C(215, 70, 45), belly=C(255, 215, 130), gold=C(250, 200, 70), gem=C(255, 240, 150))),
    "tollwraith": ("bellghost", dict(body=C(98, 72, 170), glow=C(170, 245, 255), gold=C(250, 200, 70), gem=C(250, 100, 200))),
}

TEMPLATES = dict(quad=quad, bird=bird, bug=bug, rock=rock, snake=snake, plant=plant, ghost=ghost, biped=biped, fish=fish,
                 stag=stag, leviathan=leviathan, phoenix=phoenix, bellghost=bellghost)


def draw_extra(name, back):
    tpl, opts = EXTRA[name]
    p = Pen()
    p.post = []                       # sparkles of the legendary plans: drawn after the outline pass
    TEMPLATES[tpl](p, back, opts)
    img = p.finish()
    for x, y, r, col in p.post:
        for dx, dy in ((0, 0), (1, 0), (-1, 0), (0, 1), (0, -1)) + tuple((dx * k, dy * k) for k in range(2, r + 1) for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1))):
            if 0 <= x + dx < W and 0 <= y + dy < W:
                img.putpixel((x + dx, y + dy), WHITE if (dx, dy) == (0, 0) else col)
    return img


if __name__ == "__main__":
    from PIL import Image
    names = list(EXTRA)
    cols = 8
    rows = (len(names) + cols - 1) // cols
    sheet = Image.new("RGBA", (W * 2 * 2 * cols, W * 2 * rows), (200, 235, 160, 255))
    for i, n in enumerate(names):
        for j, back in enumerate((False, True)):
            s = draw_extra(n, back).resize((W * 2, W * 2), Image.NEAREST)
            sheet.alpha_composite(s, ((i % cols) * W * 4 + j * W * 2, (i // cols) * W * 2))
    sheet.save("/tmp/extra_preview.png")
    print(len(names), "species rendered")
