#!/usr/bin/env python3
"""Draws the game's pixel font (GBA style, 7-pixel capitals) and writes app/.../PixelFontData.kt + tools/font_preview.png.

Each glyph is (first_row, [rows]) on a 9-row grid: capitals sit on rows 0-6 (the baseline is row 6), small letters on rows 2-6,
tails of g j p q y on rows 7-8. Widths are whatever the rows need (1 pixel gap is added when drawing).
Edit a glyph here and run `python3 tools/make_font.py`.
"""
import os, sys
G = {}
def g(ch, start, rows): G[ch] = (start, rows)

# capitals
g('A',0,[".XXX.","X...X","X...X","XXXXX","X...X","X...X","X...X"])
g('B',0,["XXXX.","X...X","X...X","XXXX.","X...X","X...X","XXXX."])
g('C',0,[".XXX.","X...X","X....","X....","X....","X...X",".XXX."])
g('D',0,["XXXX.","X...X","X...X","X...X","X...X","X...X","XXXX."])
g('E',0,["XXXXX","X....","X....","XXXX.","X....","X....","XXXXX"])
g('F',0,["XXXXX","X....","X....","XXXX.","X....","X....","X...."])
g('G',0,[".XXX.","X...X","X....","X.XXX","X...X","X...X",".XXX."])
g('H',0,["X...X","X...X","X...X","XXXXX","X...X","X...X","X...X"])
g('I',0,["XXX",".X.",".X.",".X.",".X.",".X.","XXX"])
g('J',0,["..XXX","...X.","...X.","...X.","...X.","X..X.",".XX.."])
g('K',0,["X...X","X..X.","X.X..","XX...","X.X..","X..X.","X...X"])
g('L',0,["X....","X....","X....","X....","X....","X....","XXXXX"])
g('M',0,["X...X","XX.XX","X.X.X","X.X.X","X...X","X...X","X...X"])
g('N',0,["X...X","XX..X","X.X.X","X..XX","X...X","X...X","X...X"])
g('O',0,[".XXX.","X...X","X...X","X...X","X...X","X...X",".XXX."])
g('P',0,["XXXX.","X...X","X...X","XXXX.","X....","X....","X...."])
g('Q',0,[".XXX.","X...X","X...X","X...X","X.X.X","X..X.",".XX.X"])
g('R',0,["XXXX.","X...X","X...X","XXXX.","X.X..","X..X.","X...X"])
g('S',0,[".XXXX","X....","X....",".XXX.","....X","....X","XXXX."])
g('T',0,["XXXXX","..X..","..X..","..X..","..X..","..X..","..X.."])
g('U',0,["X...X","X...X","X...X","X...X","X...X","X...X",".XXX."])
g('V',0,["X...X","X...X","X...X","X...X","X...X",".X.X.","..X.."])
g('W',0,["X...X","X...X","X...X","X.X.X","X.X.X","XX.XX","X...X"])
g('X',0,["X...X","X...X",".X.X.","..X..",".X.X.","X...X","X...X"])
g('Y',0,["X...X","X...X",".X.X.","..X..","..X..","..X..","..X.."])
g('Z',0,["XXXXX","....X","...X.","..X..",".X...","X....","XXXXX"])
# digits
g('0',0,[".XXX.","X...X","X..XX","X.X.X","XX..X","X...X",".XXX."])
g('1',0,["..X..",".XX..","..X..","..X..","..X..","..X..",".XXX."])
g('2',0,[".XXX.","X...X","....X","...X.","..X..",".X...","XXXXX"])
g('3',0,["XXXX.","....X","....X",".XXX.","....X","....X","XXXX."])
g('4',0,["...X.","..XX.",".X.X.","X..X.","XXXXX","...X.","...X."])
g('5',0,["XXXXX","X....","XXXX.","....X","....X","X...X",".XXX."])
g('6',0,[".XXX.","X....","X....","XXXX.","X...X","X...X",".XXX."])
g('7',0,["XXXXX","....X","...X.","..X..",".X...",".X...",".X..."])
g('8',0,[".XXX.","X...X","X...X",".XXX.","X...X","X...X",".XXX."])
g('9',0,[".XXX.","X...X","X...X",".XXXX","....X","....X",".XXX."])
# small letters
g('a',2,[".XXX.","....X",".XXXX","X...X",".XXXX"])
g('b',0,["X....","X....","XXXX.","X...X","X...X","X...X","XXXX."])
g('c',2,[".XXX.","X...X","X....","X...X",".XXX."])
g('d',0,["....X","....X",".XXXX","X...X","X...X","X...X",".XXXX"])
g('e',2,[".XXX.","X...X","XXXXX","X....",".XXX."])
g('f',0,["..XX",".X..","XXX.",".X..",".X..",".X..",".X.."])
g('g',2,[".XXXX","X...X","X...X","X...X",".XXXX","....X",".XXX."])
g('h',0,["X....","X....","XXXX.","X...X","X...X","X...X","X...X"])
g('i',1,[".X.","...","XX.",".X.",".X.","XXX"])
g('j',1,["..X","...",".XX","..X","..X","..X","X.X",".X."])
g('k',0,["X....","X....","X..X.","X.X..","XX...","X.X..","X..X."])
g('l',0,["XX.",".X.",".X.",".X.",".X.",".X.","XXX"])
g('m',2,["XX.X.","X.X.X","X.X.X","X.X.X","X.X.X"])
g('n',2,["XXXX.","X...X","X...X","X...X","X...X"])
g('o',2,[".XXX.","X...X","X...X","X...X",".XXX."])
g('p',2,["XXXX.","X...X","X...X","X...X","XXXX.","X....","X...."])
g('q',2,[".XXXX","X...X","X...X","X...X",".XXXX","....X","....X"])
g('r',2,["X.XX","XX..","X...","X...","X..."])
g('s',2,[".XXXX","X....",".XXX.","....X","XXXX."])
g('t',1,[".X..",".X..","XXX.",".X..",".X..","..XX"])
g('u',2,["X...X","X...X","X...X","X..XX",".XX.X"])
g('v',2,["X...X","X...X","X...X",".X.X.","..X.."])
g('w',2,["X...X","X...X","X.X.X","X.X.X",".X.X."])
g('x',2,["X...X",".X.X.","..X..",".X.X.","X...X"])
g('y',2,["X...X","X...X","X...X",".XXXX","....X","X...X",".XXX."])
g('z',2,["XXXXX","...X.","..X..",".X...","XXXXX"])
# punctuation
g(' ',0,["..."])
g('!',0,["X","X","X","X","X","","X"])
g('"',0,["X.X","X.X"])
g('#',0,[".X.X.","XXXXX",".X.X.",".X.X.","XXXXX",".X.X."])
g('%',0,["XX..X","XX..X","...X.","..X..",".X...","X..XX","X..XX"])
g('&',0,[".XX..","X..X.","X.X..",".X...","X.X.X","X..X.",".XX.X"])
g("'",0,["X","X"])
g('(',0,[".X","X.","X.","X.","X.","X.",".X"])
g(')',0,["X.",".X",".X",".X",".X",".X","X."])
g('*',1,["X.X.X",".XXX.","XXXXX",".XXX.","X.X.X"])
g('+',2,["..X..","..X..","XXXXX","..X..","..X.."])
g(',',6,[".X","X."])
g('-',4,["XXXX"])
g('.',6,["X"])
g('/',0,["....X","...X.","..X..","..X..",".X...","X....","X...."])
g(':',2,["X","","","","X"])
g(';',2,["X","","","","X","X"])
g('<',2,["..X.",".X..","X...",".X..","..X."])
g('=',3,["XXXXX","","XXXXX"])
g('>',2,["X...",".X..","..X.",".X..","X..."])
g('?',0,[".XXX.","X...X","....X","...X.","..X..","","..X.."])
g('@',0,[".XXX.","X...X","X.XXX","X.X.X","X.XXX","X....",".XXX."])
g('[',0,["XX","X.","X.","X.","X.","X.","XX"])
g('\\',0,["X....",".X...","..X..","..X..","...X.","....X","....X"])
g(']',0,["XX",".X",".X",".X",".X",".X","XX"])
g('^',0,[".X.","X.X"])
g('_',8,["XXXXX"])
g('{',0,["..X",".X.",".X.","X..",".X.",".X.","..X"])
g('}',0,["X..",".X.",".X.","..X",".X.",".X.","X.."])
g('|',0,["X","X","X","X","X","X","X","X"])
g('~',3,[".X..X","X.XX."])
g('$',0,["..X..",".XXXX","X.X..",".XXX.","..X.X","XXXX.","..X.."])
g('`',0,["X.",".X"])
# extras used by dialogue: ellipsis, em dash, curly quotes map to ASCII in the game; heart + arrows
g('\u2665',1,[".X.X.","XXXXX","XXXXX",".XXX.","..X.."])
g('\u2026',6,["X.X.X"])

def width(rows): return max(len(r) for r in rows)

def preview():
    from PIL import Image
    scale = 4
    lines = ["ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz", "0123456789 !?.,:;'\"-+/()%&*=<>#@[]",
             "The Heart Bell of Mossbrook has not rung", "Wild Glimmerwing used Psybeam! It's super effective!"]
    W = 600; H = len(lines) * 14 + 8
    im = Image.new("RGB", (W, H), (255, 255, 255)); px = im.load()
    y = 4
    for ln in lines:
        x = 4
        for ch in ln:
            if ch not in G: ch = '?'
            start, rows = G[ch]
            for ry, r in enumerate(rows):
                for rx, c in enumerate(r):
                    if c == 'X' and x + rx < W: px[x + rx, y + start + ry] = (30, 30, 60)
            x += width(rows) + 1 if ch != ' ' else 4
        y += 14
    im = im.resize((W * scale // 2, H * scale // 2), Image.NEAREST)
    im.save(os.path.join(os.path.dirname(__file__), "font_preview.png"))

def kotlin():
    out = ["package com.example.critterquest", "",
           "// GENERATED by tools/make_font.py - edit the glyphs there, not here.", "",
           "/** char -> (first row, pixel rows). X = lit pixel. */",
           "val PIXEL_GLYPHS: Map<Char, Pair<Int, List<String>>> = mapOf("]
    items = []
    for ch, (start, rows) in G.items():
        key = "'\\\\'" if ch == '\\' else "'\\''" if ch == "'" else "'\\u%04x'" % ord(ch) if ord(ch) > 126 or ch == '$' else "'%s'" % ch
        rs = ", ".join('"%s"' % r for r in rows)
        items.append(f"    {key} to ({start} to listOf({rs}))")
    out.append(",\n".join(items))
    out.append(")")
    here = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(here, "..", "app", "src", "main", "java", "com", "example", "critterquest", "PixelFontData.kt")
    open(path, "w").write("\n".join(out) + "\n")

if __name__ == "__main__":
    preview(); kotlin(); print(len(G), "glyphs")
