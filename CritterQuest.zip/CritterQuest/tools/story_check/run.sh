#!/bin/sh
# Re-runs the automatic story checks after you edit maps, NPCs or dialogue.
# Needs: a JDK (17+) and the Kotlin compiler (kotlinc / kotlin on PATH, version 1.9+).
#   ./run.sh            validate every map + run every NPC script
#   ./run.sh play       also play the whole game with a bot for all 3 starters
#   ./run.sh balance    boss win-rate tables
#   ./run.sh maps       re-render docs/maps/*.png and rewrite MAPS.md
#   ./run.sh dex        rewrite CRITTERS.md (species, moves, type chart) from the real data
#   ./run.sh fuzz       thousands of random battles: moves, status, swaps, catching, learning (finds crashes)
#   ./run.sh demo       print two sample battles as text (to read the messages and turn order)
#   ./run.sh walk       draw the walk cycle sheet to docs/walk.png (check animation by eye)
#   ./run.sh cache      only the map-cache check (also part of the plain ./run.sh)
#   ./run.sh shots     screenshot the real game screens (title, town, dialogue, battle...) to docs/shots/ with a stand-in Android
#   ./run.sh uifuzz     a bot that mashes buttons / taps on the REAL GameView (menus, battles, swaps, learn prompts) and checks the game stays sane
#                       optional: ./run.sh uifuzz <runs> <actions> <screenWidth> <screenHeight>
#   ./run.sh textfit    harvest every battle message (all species pairs) and check each fits the battle text box at 4:3 ... 21:9 widths
#   ./run.sh infofit    check the battle name / level / status / type / HP plate for text running into text at those widths
#   ./run.sh battleshot out.png [w h species level status]   screenshot the real battle menu at any screen size (e.g. 1280 960 for 4:3)
#   ./run.sh typecheck  compile the WHOLE app (GameView, MainActivity...) against stand-in Android classes in stubs/ (no SDK needed; every command does this)
set -e
cd "$(dirname "$0")"
SRC=../../app/src/main/java/com/example/critterquest
OUT=${TMPDIR:-/tmp}/critterquest_check
export JAVA_OPTS="${JAVA_OPTS:--Xmx2g}"   # the whole app in one compile needs more than the default heap
rm -rf "$OUT"; mkdir -p "$OUT"
# the R stub is rebuilt from the real sprite folder so new species never need a manual edit
RES=../../app/src/main/res/drawable-nodpi
{ echo "package com.example.critterquest"; echo "object R { object drawable {"; i=1
  for f in $RES/*.png; do echo " const val $(basename "$f" .png)=$i"; i=$((i+1)); done
  echo " const val banner=$i } }"
  echo "object RNames { val map = mapOf("; i=1
  for f in $RES/*.png; do echo " $i to \"$(basename "$f" .png)\","; i=$((i+1)); done
  echo " $i to \"banner\") }"; } > stubs/R.kt
# the whole app is compiled every time (GameView and MainActivity too) against stand-in Android classes in stubs/
kotlinc -nowarn -d "$OUT" $SRC/*.kt stubs/*.kt *.kt
if [ "$1" = "typecheck" ]; then
    echo "typecheck: the whole app compiles"
elif [ "$1" = "dex" ]; then
    kotlin -cp "$OUT" com.example.critterquest.DexDocs ../../CRITTERS.md
elif [ "$1" = "walk" ]; then
    kotlin -cp "$OUT" com.example.critterquest.WalkSheet ../../docs/walk.png
elif [ "$1" = "shots" ]; then
    kotlin -cp "$OUT" com.example.critterquest.Shots ../../docs/shots
elif [ "$1" = "uifuzz" ]; then
    shift; kotlin -cp "$OUT" com.example.critterquest.UiFuzz "$@"
elif [ "$1" = "textfit" ]; then
    kotlin -cp "$OUT" com.example.critterquest.TextFit
elif [ "$1" = "infofit" ]; then
    kotlin -cp "$OUT" com.example.critterquest.InfoFit
elif [ "$1" = "battleshot" ]; then
    shift; kotlin -cp "$OUT" com.example.critterquest.BattleShot "$@"
elif [ "$1" = "cache" ]; then
    kotlin -cp "$OUT" com.example.critterquest.CacheCheck
elif [ "$1" = "maps" ]; then
    kotlin -cp "$OUT" com.example.critterquest.Preview ../../docs/maps 32
    kotlin -cp "$OUT" com.example.critterquest.Docs ../../MAPS.md
else
    kotlin -cp "$OUT" com.example.critterquest.Check "$@"
fi
