package com.example.critterquest

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.SystemClock
import android.view.KeyEvent
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Checks the catch-odds readout, coins and the Market:
 *  - the odds the battle menu shows are EXACT: they match a million simulated throws, rise as a critter is weakened or put to sleep, and read 100% when it cannot fail;
 *  - winning pays coins (trainer by its toughest critter, leaders double; wild by level and rarity), losing / fleeing / catching pays nothing;
 *  - coins stay SCARCE (Economy.kt): the whole story pays a fixed sum, a wild win pays next to nothing, orbs and tickets are expensive;
 *  - coins survive a save and a tampered save cannot go below 0;
 *  - at a station's Market a bot buys Critter Orbs: it can only afford what it has, can only carry ORB_CAP, and a Rest Stone keeps the extra orbs;
 *  - the real battle menu and Journal draw with the new text at wide and narrow sizes.
 */
object EconomyCheck {
    private var bad = 0
    private fun need(c: Boolean, m: String) { if (!c) { println("  ECONOMY CHECK FAILED: $m"); bad++ } }

    fun run(): Int {
        bad = 0
        odds(); prizes(); budget(); flow(); saves(); market(); screens()
        println(if (bad == 0) "economy check: ok (exact catch odds, coin prizes, scarce coins, saves, Market purchases, screens)" else "economy check: $bad problems")
        return bad
    }

    // ---- the odds shown are the odds that happen ----
    private fun odds() {
        val rnd = Random(11)
        val picks = listOf(NIBBLET, PIPWING, DEX.indexOfFirst { it.name == "Glimmerwing" }, FLUFFNAP, BLAZEHORN, VERDARCH, TOLLWRAITH)
        var worst = 0.0
        for (sp in picks) for (frac in listOf(1.0, 0.5, 0.15, 0.0)) for (st in listOf<St?>(null, St.BRN, St.SLP)) {
            val m = Mon(DEX[sp], 20); m.hp = maxOf(1, (m.maxHp * frac).toInt()); m.status = st
            val p = Rules.catchChance(m)
            need(p in 0.0..1.0, "${m.s.name}: odds $p out of range")
            var ok = 0; val n = 30000
            repeat(n) { if (Rules.catchShakes(m, rnd) >= 4) ok++ }
            val obs = ok / n.toDouble(); val tol = 0.012 + 3.5 * sqrt(p * (1 - p) / n)
            worst = maxOf(worst, Math.abs(obs - p))
            need(Math.abs(obs - p) <= tol, "${m.s.name} hp ${m.hp}/${m.maxHp} $st: shown ${"%.1f".format(p * 100)}% but ${"%.1f".format(obs * 100)}% of throws caught it")
        }
        println("  odds: shown chance vs ${picks.size * 12 * 30000} simulated throws, worst difference ${"%.2f".format(worst * 100)} points")
        // weaker is easier; sleep helps; some critters cannot be failed
        val f = Mon(DEX[PIPWING], 10)
        val full = Rules.catchChance(f); f.hp = f.maxHp / 2; val half = Rules.catchChance(f); f.hp = 1; val one = Rules.catchChance(f)
        need(full < half && half < one, "odds do not rise as it is weakened: $full $half $one")
        f.status = St.SLP; need(Rules.catchChance(f) > one, "sleep does not help the odds")
        val easy = Mon(DEX[NIBBLET], 5); easy.hp = 1
        need(Rules.catchChance(easy) in 0.9..0.999, "a weakened Nibblet should be very likely but not certain (${Rules.catchChance(easy)})")
        easy.status = St.SLP   // asleep and weakened, an easy critter cannot escape at all
        need(Rules.catchChance(easy) == 1.0 && Rules.oddsText(1.0) == "100%", "a sleeping, weakened Nibblet should be a sure catch (${Rules.catchChance(easy)})")
        need(Rules.oddsText(0.0004) == "<1%" && Rules.oddsText(0.344) == "34%" && Rules.oddsText(0.9996) == "99%", "oddsText wrong: ${Rules.oddsText(0.0004)} ${Rules.oddsText(0.344)} ${Rules.oddsText(0.9996)}")
        need(Odds.of(0.01) == Odds.HOPELESS && Odds.of(0.10) == Odds.UNLIKELY && Odds.of(0.30) == Odds.FAIR && Odds.of(0.60) == Odds.GOOD && Odds.of(1.0) == Odds.EXCELLENT, "odds words wrong")
        // the real Battle reports the same number, and a trainer's critter cannot be caught
        val foe = Mon(DEX[FLUFFNAP], 12); foe.hp = 3
        val b = Battle(listOf(Mon(DEX[PYRESTRIDER], 20)), listOf(foe), null, 2, 8, { 0L }, rnd)
        need(b.catchOdds == Rules.catchChance(foe) && b.menuEnabled(M_CATCH), "Battle.catchOdds differs or Catch disabled in a wild fight")
        val tb = Battle(listOf(Mon(DEX[PYRESTRIDER], 20)), listOf(Mon(DEX[NIBBLET], 4)), T_TOBI, 2, 8, { 0L }, rnd)
        need(!tb.menuEnabled(M_CATCH), "Catch is enabled against a trainer")
    }

    // ---- what a win pays ----
    private fun prizes() {
        val w = { sp: Int, lv: Int -> Mon(DEX[sp], lv) }
        need(Rules.prize(null, listOf(w(NIBBLET, 4))) == 1, "Lv4 common wild should pay 1, pays ${Rules.prize(null, listOf(w(NIBBLET, 4)))}")
        need(Rules.prize(null, listOf(w(DEX.indexOfFirst { it.name == "Glimmerwing" }, 17))) == 10, "Lv17 rare wild should pay 10")
        need(Rules.prize(null, listOf(w(DEX.indexOfFirst { it.name == "Cocovex" }, 10))) == 4, "Lv10 uncommon wild should pay 4")
        need(Rules.prize(T_TOBI, listOf(w(NIBBLET, 4), w(WRIGGLET, 4))) == 20, "a Lv4 plain trainer should pay 20")
        need(Rules.prize(T_WILLOW, listOf(w(BUDLING, 7), w(THORNPAW, 8))) == 80, "Warden Willow (leader, top Lv8) should pay 80")
        need(Rules.prize(T_GLOAM, listOf(w(BLAZEHORN, 27), w(TIDALON, 27), w(THORNPAW, 28))) == 280, "Baron Gloam should pay 280")
        need(Rules.prize(null, emptyList()) == 0, "no foes should pay nothing")
        // every trainer pays something, and a leader pays double what a plain trainer of that level would
        for (n in NPCS) n.trainer?.let { t -> val team = t.team(Game(Random(1)).also { it.newGame(); it.chooseStarter(0) }).map { Mon(DEX[it.first], it.second) }
            need(Rules.prize(t, team) >= TRAINER_PAY_PER_LEVEL * team.maxOf { it.lvl }, "${t.name} pays only ${Rules.prize(t, team)} coins")
            need(!t.smart || Rules.prize(t, team) == 2 * TRAINER_PAY_PER_LEVEL * team.maxOf { it.lvl }, "${t.name} is a leader and should pay double") }
    }

    // ---- coins stay scarce: this is what "a stable economy" means here ----
    private fun budget() {
        val g = Game(Random(1)).also { it.newGame(); it.chooseStarter(0) }
        val trainers = NPCS.mapNotNull { it.trainer }.distinctBy { it.id }
        val pay = trainers.map { t -> t to Rules.prize(t, t.team(g).map { Mon(DEX[it.first], it.second) }) }
        val total = pay.sumOf { it.second }
        println("  economy: ${trainers.size} trainers pay $total coins in all (= ${total / ORB_PRICE} orbs at $ORB_PRICE, or ${total / TICKET_PRICE} tickets at $TICKET_PRICE; each can only be beaten once)")
        need(TICKET_PRICE >= 2 * ORB_PRICE, "a ticket ($TICKET_PRICE) should cost at least two orbs ($ORB_PRICE each)")
        need(total >= 20 * ORB_PRICE, "all trainers together pay only $total coins: under 20 orbs' worth, money would be out of reach")
        need(total <= 60 * ORB_PRICE, "all trainers together pay $total coins: over 60 orbs' worth, money is no longer scarce")
        need(total / TICKET_PRICE in 8..30, "all trainers together buy ${total / TICKET_PRICE} tickets (want 8 to 30)")
        need(pay.filter { !it.first.smart }.all { it.second < TICKET_PRICE }, "a plain trainer pays a whole ticket on its own")
        // wild critters: farming the grass must not be a way to get rich
        for (m in MAPS.values) if (m.wild.isNotEmpty()) {
            val wsum = m.wild.sumOf { it.weight }.toDouble(); var avg = 0.0; var best = 0
            for (w in m.wild) {
                val p = (w.lo..w.hi).map { lv -> Rules.prize(null, listOf(Mon(DEX[w.sp], lv))) }
                avg += p.average() * w.weight / wsum; best = maxOf(best, p.max())
            }
            println("  wild ${m.id}: an average win pays ${"%.1f".format(avg)} coins (best ${best}) = about ${(ORB_PRICE / avg).toInt()} wins per orb")
            need(best <= ORB_PRICE / 4, "${m.id}: one wild win can pay $best coins (more than a quarter of an orb)")
            need(avg <= ORB_PRICE / 8.0, "${m.id}: an average wild win pays ${"%.1f".format(avg)} coins (fewer than 8 wins per orb)")
        }
    }

    // ---- when it is paid ----
    private fun flow() {
        fun fresh(): Game { val bot = Bot(0, 3); val g = bot.g; g.newGame(); bot.settle(); g.chooseStarter(0); return g }   // settle: dismiss the opening dialogue first
        // a trainer: coins, and the message comes BEFORE their parting words
        run {
            val g = fresh(); g.battleReq = BattleReq(T_TOBI, null); g.battleDone(1, null, 20)
            need(g.coins == 20, "trainer win paid ${g.coins}, want 20")
            val c = g.cur; need(c is Step.Say && c.text.contains("paid you 20 coins"), "no 'paid you 20 coins' message first: ${(c as? Step.Say)?.text}")
        }
        // a wild win: coins and a short note, no dialogue
        run {
            val g = fresh(); g.battleReq = BattleReq(null, Mon(DEX[NIBBLET], 12)); g.battleDone(1, null, 4)
            need(g.coins == 4 && g.prizeNote == "+4 coins", "wild win: coins ${g.coins} note '${g.prizeNote}'")
            val h = fresh(); h.battleReq = BattleReq(null, Mon(DEX[NIBBLET], 4)); h.battleDone(1, null, 1)
            need(h.coins == 1 && h.prizeNote == "+1 coin", "one-coin wild win: coins ${h.coins} note '${h.prizeNote}'")
        }
        // nothing for running, losing, or catching
        for (res in listOf(2, 3, 4)) {
            val g = fresh(); g.coins = 50; g.battleReq = BattleReq(null, Mon(DEX[NIBBLET], 4)); g.battleDone(res, if (res == 4) Mon(DEX[NIBBLET], 4) else null, 99)
            need(g.coins == 50 && g.prizeNote.isEmpty(), "result $res changed coins (${g.coins})")
        }
        // the Battle itself reports the right prize for what was fought
        run {
            val foe = Mon(DEX[PIPWING], 9)
            need(Battle(listOf(Mon(DEX[PYRESTRIDER], 20)), listOf(foe), null, 0, 0, { 0L }, Random(1)).prize == Rules.prize(null, listOf(foe)), "Battle.prize differs from Rules.prize")
        }
    }

    private fun saves() {
        val g = Game(Random(4)); g.newGame(); g.chooseStarter(0); g.coins = 1234; g.orbs = 21
        val text = g.serialize()
        val g2 = Game(Random(5)); need(g2.load(text), "save does not load")
        need(g2.coins == 1234 && g2.orbs == 21, "coins/orbs lost by save: ${g2.coins} ${g2.orbs}")
        val g3 = Game(Random(6)); need(g3.load(text.lines().joinToString("\n") { if (it.startsWith("coins=")) "coins=-50" else it }), "tampered save does not load")
        need(g3.coins == 0, "negative coins loaded as ${g3.coins}")
        val g4 = Game(Random(7)); need(g4.load(text.lines().filter { !it.startsWith("coins=") }.joinToString("\n")), "old save does not load")
        need(g4.coins == 0, "a save from before money existed should start with 0 coins")
    }

    // ---- the Market, through real conversations at a station ----
    private fun market() {
        val st = STATIONS.first { it.map == "mossbrook" }
        fun setup(coins: Int, orbs: Int): Pair<Bot, Game> {
            val bot = StationCheck.newGame(55); val g = bot.g; g.coins = coins; g.orbs = orbs
            bot.goMap(st.map)
            bot.go({ it.m == st.map && Math.abs(it.x - st.x) + Math.abs(it.y - st.y) == 1 }, "beside the station")
            val dir = when { st.y > g.py -> DOWN; st.y < g.py -> UP; st.x < g.px -> LEFT; else -> RIGHT }
            bot.now += 200; g.step(dir, bot.now); bot.now += 200; g.tick(bot.now)
            return bot to g
        }
        // buying: exact prices, and only what you can afford
        run {
            val (bot, g) = setup(2 * ORB_PRICE + 10, 8); need(g.interact(bot.now), "no station")
            val seen = StationCheck.converse(g, bot, listOf("Market", "Critter Orb", "Buy 1", "Buy 5", "Back", "Back", "Done"))
            need(g.coins == 10 && g.orbs == 10, "after Buy 1 then Buy 5 with ${2 * ORB_PRICE + 10} coins: coins ${g.coins} (want 10), orbs ${g.orbs} (want 10)")
            need(seen.any { it.startsWith("Bought 1 Critter Orb for $ORB_PRICE") } && seen.any { it.contains("Bought 1 Critter Orb for $ORB_PRICE coins. That is all you can afford") }, "purchase messages wrong: $seen")
            need(seen.any { it.startsWith("You have ${2 * ORB_PRICE + 10} coins. What would you like?") }, "market window did not show the coins: $seen")
        }
        // too poor: nothing happens
        run {
            val (bot, g) = setup(10, 8); g.interact(bot.now)
            val seen = StationCheck.converse(g, bot, listOf("Market", "Critter Orb", "Buy 1", "Back", "Back", "Done"))
            need(g.coins == 10 && g.orbs == 8 && seen.any { it.startsWith("A Critter Orb costs $ORB_PRICE coins. You have 10") }, "buying without the money changed something: coins ${g.coins} orbs ${g.orbs}")
        }
        // the carry cap
        run {
            val (bot, g) = setup(1000, ORB_CAP - 1); g.interact(bot.now)
            val seen = StationCheck.converse(g, bot, listOf("Market", "Critter Orb", "Buy 10", "Buy 1", "Back", "Back", "Done"))
            need(g.orbs == ORB_CAP && g.coins == 1000 - ORB_PRICE, "cap: orbs ${g.orbs} (want $ORB_CAP), coins ${g.coins} (want ${1000 - ORB_PRICE})")
            need(seen.any { it.contains("That is all you can carry") } && seen.any { it.startsWith("You can't carry any more Critter Orbs") }, "cap messages wrong: $seen")
        }
        // Back leaves the Market without buying, and Mom's box does not offer it
        run {
            val (bot, g) = setup(500, 8); g.interact(bot.now)
            StationCheck.converse(g, bot, listOf("Market", "Back", "Done")); need(g.coins == 500 && g.orbs == 8, "backing out spent something")
            g.play(g.boxHome()); val opts = (g.cur as? Step.Ask)?.opts; need(opts != null && "Market" !in opts, "Mom offers the Market: $opts"); StationCheck.converse(g, bot, emptyList())
            g.interact(bot.now); val so = (g.cur as? Step.Ask)?.opts; need(so != null && "Market" in so && so.last() == "Done", "the station menu lacks Market: $so"); StationCheck.converse(g, bot, emptyList())
        }
        // a Rest Stone refills to 8 but never takes away what you bought
        run {
            val g = Game(Random(8)); g.newGame(); g.chooseStarter(0)
            g.orbs = 21; g.healAll(); need(g.orbs == 21, "a Rest Stone took away bought orbs (21 -> ${g.orbs})")
            g.orbs = 2; g.healAll(); need(g.orbs == MAX_ORBS, "a Rest Stone did not refill to $MAX_ORBS (${g.orbs})")
        }
    }

    // ---- the real screens ----
    private fun screens() {
        for ((sw, sh) in listOf(960 to 540, 1280 to 960)) {
            val tag = "${sw}x$sh"
            val screen = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888); val canvas = Canvas(screen)
            val view = GameView(Context()); view.onSizeChanged(sw, sh, 0, 0)
            fun fld(n: String) = GameView::class.java.getDeclaredField(n).also { it.isAccessible = true }
            fun frame(n: Int = 2) { repeat(n) { SystemClock.fake += 34; view.onDraw(canvas) } }
            val bot = StationCheck.newGame(9); val g = bot.g; g.coins = 12345
            val enter = Game::class.java.getDeclaredMethod("enter", String::class.java, Int::class.javaPrimitiveType, Int::class.javaPrimitiveType, Int::class.javaPrimitiveType)
            enter.isAccessible = true; enter.invoke(g, "route1", 14, 7, RIGHT)
            fld("game").set(view, g); fld("scene").set(view, 1); fld("lastMapId").set(view, ""); fld("pauseSel").set(view, -1)
            frame(40); var guard = 0; while (g.cur != null && guard++ < 50) { g.advance(); frame(2) }
            fun key(k: Int) { view.onKeyDown(k, KeyEvent(k, KeyEvent.ACTION_DOWN, 0)); view.onKeyUp(k, KeyEvent(k, KeyEvent.ACTION_UP, 0)); frame() }
            // a wild battle: open the menu, put the cursor on Catch
            g.battleReq = BattleReq(null, Mon(DEX[FLUFFNAP], 12)); frame(6)
            var n = 0; while (n++ < 80) { frame(30); val b: Battle? = fld("battle").get(view) as Battle?; if (b != null && b.menuOn) break }
            val b = fld("battle").get(view) as Battle; need(b.menuOn, "$tag: the battle menu never opened")
            key(KeyEvent.KEYCODE_DPAD_DOWN); key(KeyEvent.KEYCODE_DPAD_RIGHT); frame(3)
            need(b.menu == M_CATCH, "$tag: cursor is on ${b.menu}, not Catch")
            frame(5)
            // a trainer battle: Catch is greyed and says why
            b.use(M_RUN); n = 0; while (b.over == 0 && n++ < 400) b.pump(); frame(70)
            // the Journal with coins
            view.onKeyDown(KeyEvent.KEYCODE_BACK, KeyEvent(KeyEvent.KEYCODE_BACK, KeyEvent.ACTION_DOWN, 0)); view.onKeyUp(KeyEvent.KEYCODE_BACK, KeyEvent(KeyEvent.KEYCODE_BACK, KeyEvent.ACTION_UP, 0)); frame(70)
        }
    }
}
