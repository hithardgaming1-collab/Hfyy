package com.example.critterquest

import android.content.res.Resources
import android.graphics.BitmapFactory

/** The pixel-art sheets for the PC tools (they read the PNG files in res/drawable-nodpi). */
fun toolSprites() = Sprites { BitmapFactory.decodeResource(Resources(), it) }
