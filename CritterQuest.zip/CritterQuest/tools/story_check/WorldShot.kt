// Screenshot of the REAL world view at any map and tile (e.g. the legendary sanctums):
//   (run from tools/story_check)  kotlin -cp <classes> com.example.critterquest.WorldShot out.png map x y [width height]
package com.example.critterquest

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.SystemClock
import java.io.File
import javax.imageio.ImageIO

object WorldShot {
    @JvmStatic fun main(args: Array<String>) {
        System.setProperty("java.awt.headless", "true")
        val out = File(args[0]); val map = args[1]; val x = args[2].toInt(); val y = args[3].toInt()
        val sw = args.getOrNull(4)?.toInt() ?: 960; val sh = args.getOrNull(5)?.toInt() ?: 540
        val screen = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888); val canvas = Canvas(screen)
        val view = GameView(Context()); view.onSizeChanged(sw, sh, 0, 0)
        fun fld(n: String) = GameView::class.java.getDeclaredField(n).also { it.isAccessible = true }
        fun frame(n: Int) { repeat(n) { SystemClock.fake += 34; view.onDraw(canvas) } }
        val g = Game(); g.newGame(); g.chooseStarter(0); g.saveHook = null; g.set("starter"); g.set("labDone")
        val enter = Game::class.java.getDeclaredMethod("enter", String::class.java, Int::class.javaPrimitiveType, Int::class.javaPrimitiveType, Int::class.javaPrimitiveType)
        enter.isAccessible = true; enter.invoke(g, map, x, y, UP); g.px = x; g.py = y; g.fromX = x; g.fromY = y
        fld("game").set(view, g); fld("scene").set(view, 1); fld("lastMapId").set(view, ""); fld("pauseSel").set(view, -1)
        frame(60)
        ImageIO.write(screen.img, "png", out); println("wrote $out")
    }
}
