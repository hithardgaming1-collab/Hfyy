// Screenshots of the REAL game screens (GameView, Art, Battle...) drawn on a laptop with the stand-in Android classes.
//   ./run.sh shots   ->  docs/shots/*.png   (01-12 the base game, 13-17 rarity and the legendary critters, 18 PP cost of a heavy move, 19 the run lock, 20-21 the Critters menu, 22 a Critter Station, 23-26 catch odds, the Market, prize money)
package com.example.critterquest

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.SystemClock
import android.view.KeyEvent
import java.io.File
import javax.imageio.ImageIO

object Shots {
    private const val SW = 1920; private const val SH = 1080
    private lateinit var view: GameView
    private val screen = Bitmap.createBitmap(SW, SH, Bitmap.Config.ARGB_8888)
    private val canvas = Canvas(screen)
    private lateinit var out: File

    private fun fld(name: String) = GameView::class.java.getDeclaredField(name).also { it.isAccessible = true }
    @Suppress("UNCHECKED_CAST") private fun <T> get(name: String): T = fld(name).get(view) as T
    private fun set(name: String, v: Any?) = fld(name).set(view, v)

    fun frame(ms: Long = 34, n: Int = 1) { repeat(n) { SystemClock.fake += ms; view.onDraw(canvas) } }
    fun press(code: Int, holdMs: Long = 60) {
        view.onKeyDown(code, KeyEvent(code, KeyEvent.ACTION_DOWN)); frame(holdMs.coerceAtLeast(34), 1)
        view.onKeyUp(code, KeyEvent(code, KeyEvent.ACTION_UP)); frame(34, 1)
    }
    fun ok() = press(KeyEvent.KEYCODE_DPAD_CENTER)
    fun shot(name: String) { frame(34, 2); ImageIO.write(screen.img, "png", File(out, "$name.png")); println("  $name") }

    private fun enter(g: Game, map: String, x: Int, y: Int, face: Int = DOWN) {
        val m = Game::class.java.getDeclaredMethod("enter", String::class.java, Int::class.javaPrimitiveType, Int::class.javaPrimitiveType, Int::class.javaPrimitiveType)
        m.isAccessible = true; m.invoke(g, map, x, y, face)
        g.px = x; g.py = y; g.fromX = x; g.fromY = y
    }

    private fun world(g: Game) {
        g.saveHook = null
        set("game", g); set("scene", 1); set("lastMapId", ""); set("pauseSel", -1)
        frame(34, 6); var guard = 0; while (g.cur != null && guard++ < 40) { ok(); frame(34, 3) }
        frame(34, 30) // let the fade-in finish
    }

    @JvmStatic fun main(args: Array<String>) {
        System.setProperty("java.awt.headless", "true")
        out = File(args.getOrNull(0) ?: "../../docs/shots"); out.mkdirs()
        view = GameView(Context())
        view.onSizeChanged(SW, SH, 0, 0)
        println("screens:")
        frame(34, 5); shot("01_title")

        val g = Game(); g.newGame(); g.chooseStarter(0)
        g.addToParty(AQUAFIN, 7); g.addToParty(SPROUTLE, 6)
        g.set("starter"); g.set("labDone")
        enter(g, "mossbrook", 11, 8, RIGHT); world(g)
        shot("02_town")
        enter(g, "route1", 14, 7, RIGHT); world(g); shot("03_route1")
        enter(g, "route1", 14, 9, DOWN); world(g); shot("04_tall_grass")
        enter(g, "home", 4, 6, UP); world(g); shot("05_indoors")
        enter(g, "mossbrook", 11, 8, RIGHT); world(g)
        g.play(listOf(Step.Say("Mom", "Take care out there, sweetheart. Wild critters hide in the tall grass, so keep your partner close!")))
        frame(34, 80); shot("06_dialogue")
        while (g.cur != null) { ok(); frame(34, 3) }
        set("journal", true); frame(34, 3); shot("07_journal"); set("journal", false)
        set("pauseSel", 0); frame(34, 3); shot("08_pause"); set("pauseSel", -1)

        enter(g, "route1", 10, 6, RIGHT); world(g)
        press(KeyEvent.KEYCODE_DPAD_RIGHT, 1100); frame(34, 3)
        press(KeyEvent.KEYCODE_DPAD_DOWN, 700); frame(34, 20); shot("12_follower")

        // a wild battle
        enter(g, "route1", 14, 7, RIGHT); world(g)
        g.battleReq = BattleReq(null, Mon(DEX[NIBBLET], 4)); frame(34, 4)
        frame(34, 40); shot("09_battle_intro")
        for (i in 0 until 60) { frame(34, 30); val b: Battle? = get("battle"); if (b == null || b.menuOn) break }
        shot("10_battle_menu")
        press(KeyEvent.KEYCODE_DPAD_CENTER); frame(34, 3); shot("11_battle_moves")

        // ---- rarity and the legendary critters (each on a fresh view, so no battle is left open from above)
        fun fresh() { view = GameView(Context()); view.onSizeChanged(SW, SH, 0, 0) }
        fresh()
        val gl = Game(); gl.newGame(); gl.chooseStarter(0)
        gl.party.clear(); gl.addToParty(PYRESTRIDER, 30); gl.addToParty(BLOOMFANG, 28)
        listOf("starter", "labDone", "sigil_leaf", "sigil_tide", "sigil_ember", "gate_open").forEach(gl::set)
        enter(gl, "grove", 6, 6, UP); world(gl); shot("13_legend_sanctum")
        enter(gl, "grove", 6, 3, UP); world(gl); ok(); frame(34, 90); shot("14_legend_dialogue")   // OK in front of Verdarch
        while (gl.cur != null) { val c = gl.cur; if (c is Step.Ask) gl.advance(1) else gl.advance(); frame(34, 3) }   // "Back away"
        fresh(); enter(gl, "crater", 6, 3, UP); world(gl)
        gl.battleReq = BattleReq(null, Mon(DEX[PYRARCH], 27)); frame(34, 4); frame(34, 40); shot("15_legend_battle")   // note the gold LEG tag
        fresh(); gl.battleReq = null; enter(gl, "route4", 12, 8, UP); world(gl)
        gl.battleReq = BattleReq(null, Mon(DEX[DEX.indexOfFirst { it.name == "Glimmerwing" }], 17)); frame(34, 4); frame(34, 40); shot("16_rare_battle")   // RAR tag, "A rare ... appears!"
        fresh(); gl.battleReq = null; gl.coins = 340; gl.set("leg_verdarch"); gl.set("leg_pyrarch")
        enter(gl, "mossbrook", 11, 8, RIGHT); world(gl)
        set("journal", true); frame(34, 3); shot("17_journal_legends")   // two legend discs lit
        // ---- PP: a critter that knows a heavy hitter; the move list shows "PP 8/8 x2" (2 PP per use)
        fresh(); gl.battleReq = null
        val heavy = DEX.indices.first { i -> !DEX[i].legendary && Mon(DEX[i], 30).moves.any { it.move.cost > 1 } }
        gl.party.clear(); gl.party.add(Mon(DEX[heavy], 30).also { m -> m.moves.first { it.move.cost > 1 }.pp = 5 })   // 5 of 8 PP left: PP is being spent
        enter(gl, "route1", 14, 7, UP); world(gl)
        gl.battleReq = BattleReq(null, Mon(DEX[NIBBLET], 4)); frame(34, 4)
        for (i in 0 until 60) { frame(34, 30); val b: Battle? = get("battle"); if (b == null || b.menuOn) break }
        press(KeyEvent.KEYCODE_DPAD_CENTER); frame(34, 3)
        run { val b: Battle = get("battle")!!; b.moveSel = b.me.moves.indexOfFirst { it.move.cost > 1 } }
        shot("18_battle_moves_heavy")
        // ---- remote: key 5 locks running on (a gold RUN tag stays in the corner, plus a short toast)
        fresh(); gl.battleReq = null; enter(gl, "mossbrook", 11, 8, RIGHT); world(gl)
        press(KeyEvent.KEYCODE_5); frame(34, 3); shot("19_run_lock")
        // ---- the Critters menu: everything you own (party, then Mom's box); pick any critter to be your lead
        fresh(); gl.battleReq = null
        gl.party.clear(); gl.box.clear()
        listOf(PYRESTRIDER to 30, BLOOMFANG to 28, TEMPESTAIL to 25, SEEROWL to 24, GLACIFOX to 22, BOULDERBACK to 20).forEach { (sp, lv) -> gl.party.add(Mon(DEX[sp], lv)) }
        gl.party[2].hp = 0
        listOf(VERDARCH to 20, DEX.indexOfFirst { it.name == "Glimmerwing" } to 17, FLUFFNAP to 12, NIBBLET to 6).forEach { (sp, lv) -> gl.box.add(Mon(DEX[sp], lv)) }
        enter(gl, "mossbrook", 11, 8, RIGHT); world(gl)
        press(KeyEvent.KEYCODE_BACK); frame(34, 2); press(KeyEvent.KEYCODE_DPAD_DOWN); press(KeyEvent.KEYCODE_DPAD_DOWN); press(KeyEvent.KEYCODE_DPAD_CENTER); frame(34, 3)
        repeat(6) { press(KeyEvent.KEYCODE_DPAD_DOWN) }; frame(34, 3); shot("20_critter_menu")          // Verdarch waits in Mom's box
        press(KeyEvent.KEYCODE_DPAD_CENTER); frame(34, 3); shot("21_critter_lead_question")              // the party is full: it would swap with the lead
        // ---- a Critter Station in town: OK in front of the kiosk opens the box (take / leave / choose my lead)
        fresh(); gl.battleReq = null; enter(gl, "mossbrook", 9, 11, UP); world(gl); ok(); frame(34, 90); shot("22_critter_station")
        while (gl.cur != null) { val c = gl.cur; if (c is Step.Ask) gl.advance(c.opts.size - 1) else gl.advance(); frame(34, 3) }   // end the station conversation ("Done") so it does not leak into later shots
        // ---- catching: the exact odds on the battle menu (a weakened, sleeping wild critter)
        fresh(); gl.battleReq = null; gl.party.clear(); gl.addToParty(PYRESTRIDER, 30); gl.coins = 340; gl.orbs = 8
        enter(gl, "route1", 14, 7, UP); world(gl)
        gl.battleReq = BattleReq(null, Mon(DEX[FLUFFNAP], 12).also { it.hp = 1; it.status = St.SLP }); frame(34, 4)
        for (i in 0 until 60) { frame(34, 30); val b: Battle? = get("battle"); if (b == null || b.menuOn) break }
        press(KeyEvent.KEYCODE_DPAD_DOWN); press(KeyEvent.KEYCODE_DPAD_RIGHT); frame(34, 3); shot("23_catch_odds")
        // ---- the Market of a Critter Station (answers are given to the game directly, so the picture does not depend on key timing)
        fresh(); gl.battleReq = null; enter(gl, "mossbrook", 9, 11, UP); world(gl); ok(); frame(34, 110)
        gl.advance(3); frame(34, 120); shot("24_market")                                                   // "Market"
        gl.advance(0); frame(34, 140); fld("askSel").setInt(view, 1); frame(34, 2); shot("25_market_buy")   // "Critter Orb", cursor on "Buy 5"
        // ---- winning pays: a trainer hands over coins (first end the Market conversation by answering its last option)
        while (gl.cur != null) { val c = gl.cur; if (c is Step.Ask) gl.advance(c.opts.size - 1) else gl.advance(); frame(34, 3) }
        fresh(); enter(gl, "route1", 14, 7, UP); world(gl)
        gl.battleReq = BattleReq(T_TOBI, null); gl.battleDone(1, null, 32); frame(34, 90); shot("26_prize")
        println("done: $out")
    }
}
