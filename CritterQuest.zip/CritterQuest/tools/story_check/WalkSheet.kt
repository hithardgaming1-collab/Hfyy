// Draws a sheet of the walk cycle (4 directions x stand / mid-step / next foot) for a few looks, to check animation by eye.
//   ./run.sh walk   ->  docs/walk.png
package com.example.critterquest

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import java.awt.image.BufferedImage
import java.io.File
import javax.imageio.ImageIO

object WalkSheet {
    @JvmStatic fun main(args: Array<String>) {
        System.setProperty("java.awt.headless", "true")
        val out = args.getOrNull(0) ?: "../../docs/walk.png"
        val art = Art(Paint(), toolSprites())
        val looks = listOf(PLAYER_LOOK, NPCS.first { it.look.kind == K_ROBE }.look, NPCS.first { it.look.kind == K_COAT }.look)
        // columns: stand, step start, mid-step, step end (left foot), mid-step (right foot)
        val cols = listOf(Triple(false, 0f, 0), Triple(true, 0.2f, 0), Triple(true, 0.5f, 0), Triple(true, 0.8f, 0), Triple(true, 0.5f, 1))
        val ts = 64f; val cw = 96; val ch = 112
        val img = BufferedImage(cols.size * cw, looks.size * 4 * ch, BufferedImage.TYPE_INT_ARGB)
        val c = Canvas(img); c.drawColor(Color.rgb(120, 190, 100))
        for ((li, lk) in looks.withIndex()) for ((fi, face) in listOf(DOWN, LEFT, RIGHT, UP).withIndex()) for ((ci, col) in cols.withIndex()) {
            val x = ci * cw + cw / 2f; val y = (li * 4 + fi) * ch + ch - 16f
            val (mv, ph, foot) = col
            art.person(c, lk, x, y, ts, face, mv, ph, 0.6f, foot, 0)
        }
        File(out).parentFile?.mkdirs(); ImageIO.write(img, "png", File(out)); println("wrote $out")
    }
}
