package com.example.critterquest

import kotlin.math.pow
import kotlin.random.Random

/**
 * Checks the rarity system and the legendary critters:
 *  - the encounter odds each route really gives (from the rarity weights) look sane, and no legendary is in the grass;
 *  - catch odds per orb are in a playable band (weak = catchable, full health = almost hopeless);
 *  - every sanctum entrance is locked until its condition is met;
 *  - a bot walks the real maps to each legendary, backs away once, flees once, then fights it: it must never faint
 *    ("holds on" at 1 HP), and the bot throws orbs (refilling at the Rest Stone) until it is caught, after which its spot
 *    is empty for good, it is in the party / box / dex, and it survives a save and load.
 */
object LegendCheck {
    private var bad = 0
    private fun err(m: String) { println("  LEGEND CHECK FAILED: $m"); bad++ }
    private fun need(c: Boolean, m: String) { if (!c) err(m) }

    fun run(): Int {
        bad = 0
        rarityTable()
        oddsTable()
        gating()
        for (s in SPOTS) walkAndCatch(s)
        println(if (bad == 0) "legend check: ok (${SPOTS.size} legendaries caught by the bot at their fixed spots)" else "legend check: $bad problems")
        return bad
    }

    // ---- rarity: the chance of each critter on each route ----
    private fun rarityTable() {
        val rnd = Random(1)
        for ((id, m) in MAPS) if (m.wild.isNotEmpty()) {
            val total = m.wild.sumOf { it.weight }
            val rare = m.wild.filter { DEX[it.sp].rarity == Rarity.RARE }.sumOf { it.weight } * 100.0 / total
            val line = m.wild.joinToString(" ") { "${DEX[it.sp].name}${Math.round(it.weight * 100.0 / total)}%" }
            println("  rarity $id: $line")
            need(rare <= 20.0, "$id: Rare critters make up ${rare.toInt()}% of the grass (max 20%)")
            for (w in m.wild) { val p = w.weight * 100.0 / total; need(p in 1.0..40.0, "$id: ${DEX[w.sp].name} has a ${p.toInt()}% chance (want 1-40%)") }
            need(m.wild.any { DEX[it.sp].rarity == Rarity.COMMON }, "$id has no Common critter")
        }
        // the weights really are the rarity weights, and the tiers are ordered
        need(Rarity.COMMON.weight > Rarity.UNCOMMON.weight && Rarity.UNCOMMON.weight > Rarity.RARE.weight && Rarity.RARE.weight > Rarity.LEGENDARY.weight, "rarity weights are not in order")
        // walk back and forth on real tall grass: the species the game really rolls must follow the weights
        for (id in listOf("route1", "route4")) {
            val m = MAPS.getValue(id); val tot = m.wild.sumOf { it.weight }
            val bot = Bot(0, 5); val g = bot.g; g.newGame(); bot.settle(); g.chooseStarter(0)   // settle: dismiss the opening dialogue, or steps are ignored
            var gx = -1; var gy = -1
            for (y in 0 until m.h) for (x in 0 until m.w - 1) if (gx < 0 && m.tile(x, y) == Tl.TALL && m.tile(x + 1, y) == Tl.TALL) { gx = x; gy = y }
            need(gx >= 0, "$id has no two neighbouring tall-grass tiles")
            val enter = Game::class.java.getDeclaredMethod("enter", String::class.java, Int::class.javaPrimitiveType, Int::class.javaPrimitiveType, Int::class.javaPrimitiveType)
            enter.isAccessible = true; enter.invoke(g, id, gx, gy, RIGHT)
            val seen = HashMap<Int, Int>(); var n = 0; var now = bot.now + 1000L; var right = true
            repeat(120000) {
                now += 400; g.step(if (right) RIGHT else LEFT, now); right = !right; now += 400; g.tick(now)
                g.battleReq?.let { r -> seen.merge(DEX.indexOf(r.wild!!.s), 1, Int::plus); n++; g.battleReq = null }
            }
            println("  real grass $id: $n encounters in 120000 steps (${"%.1f".format(n * 100.0 / 120000)}% per step)")
            need(n in 12000..21000, "$id: $n encounters in 120000 steps (expected about 14%)")
            for (w in m.wild) {
                val obs = seen.getOrDefault(w.sp, 0) * 100.0 / n; val exp = w.weight * 100.0 / tot
                need(Math.abs(obs - exp) < 1.8, "$id ${DEX[w.sp].name}: ${"%.1f".format(obs)}% seen vs ${"%.1f".format(exp)}% expected")
            }
            need(seen.keys.none { DEX[it].legendary }, "$id rolled a legendary in the grass")
        }
    }

    // ---- catch odds ----
    private fun oddsTable() {
        val rnd = Random(7)
        fun p(sp: Species, lvl: Int, hp: Int?, st: St?): Double {
            var ok = 0
            repeat(20000) { val f = Mon(sp, lvl); if (hp != null) f.hp = hp; f.status = st; if (Rules.catchShakes(f, rnd) >= 4) ok++ }
            return ok / 20000.0
        }
        for (s in SPOTS) {
            val sp = DEX[s.species]
            val awake = p(sp, s.lvl, 1, null); val burnt = p(sp, s.lvl, 1, St.BRN); val asleep = p(sp, s.lvl, 1, St.SLP); val full = p(sp, s.lvl, null, null)
            fun eight(x: Double) = (1 - (1 - x).pow(8)) * 100
            println("  catch ${sp.name.padEnd(11)} per orb at 1 HP: awake ${"%.1f".format(awake * 100)}%  burnt ${"%.1f".format(burnt * 100)}%  asleep ${"%.1f".format(asleep * 100)}%   8 orbs: ${eight(awake).toInt()}% / ${eight(asleep).toInt()}%   full health ${"%.1f".format(full * 100)}%")
            need(awake in 0.025..0.14, "${sp.name}: ${"%.1f".format(awake * 100)}% per orb when weakened (want 2.5-14%)")
            need(asleep > awake && burnt > awake, "${sp.name}: sleep / burn should help")
            need(full < 0.05, "${sp.name}: ${"%.1f".format(full * 100)}% at full health is too easy (want < 5%)")
            need(eight(asleep) >= 40.0, "${sp.name}: even asleep, 8 orbs catch it only ${eight(asleep).toInt()}% of the time")
        }
    }

    // ---- locked entrances ----
    private fun gating() {
        val fresh = Game(Random(3)); fresh.newGame(); fresh.chooseStarter(0)
        val ready = Game(Random(3)); ready.newGame(); ready.chooseStarter(0)
        listOf("sigil_leaf", "sigil_tide", "sigil_ember", "gate_open", "ending").forEach(ready::set)
        val partial = Game(Random(3)); partial.newGame(); partial.chooseStarter(0); partial.set("sigil_leaf"); partial.set("sigil_tide")
        for (s in SPOTS) for (o in MAPS.values.filter { it.id != s.map }) for (w in o.warps.filter { it.to == s.map }) {
            val gate = w.need ?: continue
            need(!gate.invoke(fresh), "${s.id}: entrance is open in a brand new game")
            need(gate.invoke(ready), "${s.id}: entrance stays shut for a finished game")
            if (s.id != "tollwraith") need(!gate.invoke(partial), "${s.id}: entrance opens with only two Sigils")
            need(w.deny.isNotBlank(), "${s.id}: entrance has no 'it is locked' message")
        }
    }

    // ---- the bot ----
    private fun drain(bot: Bot) { bot.settle() }

    private fun walkAndCatch(spot: Spot) {
        val sp = DEX[spot.species]
        val bot = Bot(0, 21 + spot.species); val g = bot.g
        g.newGame(); bot.settle(); g.chooseStarter(0)
        for (n in NPCS) n.trainer?.let { g.set("t_" + it.id) }
        listOf("lab_intro", "t_kit1", "t_kit2", "t_kit3", "sigil_leaf", "sigil_tide", "sigil_ember", "gate_open", "ending").forEach(g::set)
        g.party.clear()
        listOf(PYRESTRIDER, BLOOMFANG, TEMPESTAIL, SEEROWL, GLACIFOX, BOULDERBACK).forEach { g.party.add(Mon(DEX[it], 30)) }
        g.healAll()

        fun approach() {
            bot.goMap(spot.map)
            if (!(g.px == spot.x && g.py == spot.y + 1)) bot.go({ it.m == spot.map && it.x == spot.x && it.y == spot.y + 1 }, "the front of ${spot.id}")
            bot.now += 200; g.step(UP, bot.now); bot.now += 200; g.tick(bot.now)    // face it (the step is blocked by the critter itself)
        }
        /** Press OK and read the introduction; [choice] answers "Challenge?" (0) or backs away (1). Returns true if a fight began. */
        fun talk(choice: Int): Boolean {
            need(g.interact(bot.now), "${spot.id}: OK in front of it does nothing")
            var guard = 0
            while (g.battleReq == null && guard++ < 50) {
                g.tick(bot.now)
                val c = g.cur
                when { c is Step.Say -> g.advance(); c is Step.Ask -> g.advance(choice); else -> break }
            }
            return g.battleReq != null
        }

        approach()
        need(g.map.id == spot.map, "${spot.id}: bot could not reach ${spot.map}")
        need(g.solid(spot.x, spot.y), "${spot.id}: its tile is not solid")
        // 1. back away: nothing happens, it stays
        need(!talk(1), "${spot.id}: 'Back away' started a fight"); bot.settle()
        need(g.spotAt(spot.x, spot.y) != null && !g.f(spot.flag), "${spot.id}: backing away changed something")

        // 2. flee: it stays
        need(talk(0), "${spot.id}: 'Challenge' did not start a fight")
        run {
            val req = g.battleReq!!; val foe = req.wild!!
            need(foe.s === sp && foe.lvl == spot.lvl, "${spot.id}: wrong critter or level (${foe.s.name} Lv${foe.lvl})")
            val b = Battle(g.party, listOf(foe), null, g.heals, g.orbs, { bot.now }, bot.rnd)
            need(b.text.startsWith("The legendary ${sp.name}"), "${spot.id}: intro text is '${b.text}'")
            var guard = 0
            while (b.over == 0 && guard++ < 400) { b.pump(); if (b.menuOn) b.use(M_RUN) }
            need(b.over == 3, "${spot.id}: could not run away (over=${b.over})")
            g.heals = b.heals; g.orbs = b.orbs; g.battleDone(b.over, b.caught); bot.settle()
            need(g.spotAt(spot.x, spot.y) != null && !g.f(spot.flag), "${spot.id}: fleeing removed the legendary")
        }

        // 3. fight and catch: it must never faint; the bot weakens it, throws orbs and rests at the Rest Stone when they run out
        var attempts = 0; var thrown = 0; var heldMessage = false; var caught = false
        while (!caught && attempts < 25) {
            attempts++
            g.healAll()                                       // a trip to the Rest Stone: party healed, orbs refilled
            if (!(g.map.id == spot.map && g.px == spot.x && g.py == spot.y + 1)) approach()
            need(talk(0), "${spot.id}: could not start the fight (attempt $attempts)")
            val foe = g.battleReq!!.wild!!
            val b = Battle(g.party, listOf(foe), null, g.heals, g.orbs, { bot.now }, bot.rnd)
            var guard = 0; var stuckOut = false
            while (b.over == 0 && guard++ < 6000) {
                b.pump()
                if (b.text.contains("holding on")) heldMessage = true
                need(foe.hp >= 1, "${spot.id}: fainted / hp=${foe.hp}"); need(b.over != 1, "${spot.id}: the battle was WON (it must not faint)")
                autoLearn(b)
                if (b.menuOn && b.learnFor == null) {
                    when {
                        b.swapping -> bot.act(b)
                        foe.hp <= 1 && b.orbs > 0 -> { b.use(M_CATCH); thrown++ }
                        foe.hp <= 1 -> { stuckOut = true; b.use(M_RUN) }
                        else -> bot.act(b)
                    }
                }
            }
            need(b.over != 0, "${spot.id}: the battle never ended")
            need(b.over != 1, "${spot.id}: the battle ended as WON")
            g.heals = b.heals; g.orbs = b.orbs
            g.battleDone(b.over, b.caught); bot.settle()
            if (b.over == 4) caught = true
            if (!caught) need(g.spotAt(spot.x, spot.y) != null, "${spot.id}: gone although not caught (attempt $attempts, over=${b.over})")
            if (stuckOut) need(b.over == 3, "${spot.id}: out of orbs but could not run")
        }
        need(caught, "${spot.id}: not caught in $attempts attempts")
        need(heldMessage, "${spot.id}: never showed the 'holding on' message")
        println("  caught ${sp.name} Lv${spot.lvl} at ${spot.map} after $attempts Rest-Stone trips and $thrown orbs")

        // 4. afterwards
        need(g.f(spot.flag) && g.legendsCaught == 1, "${spot.id}: flag not set")
        need(spot.species in g.dexCaught, "${spot.id}: not in the Critterdex")
        need(g.party.any { it.s === sp } || g.box.any { it.s === sp }, "${spot.id}: not in the party or Mom's box")
        need(g.spotAt(spot.x, spot.y) == null && !g.solid(spot.x, spot.y), "${spot.id}: its place is not empty after the catch")
        need(!g.interact(bot.now) || g.cur == null, "${spot.id}: still answers OK after being caught")
        val g2 = Game(Random(5)); need(g2.load(g.serialize()), "${spot.id}: save does not load")
        need(g2.f(spot.flag) && spot.species in g2.dexCaught && g2.spotAt(spot.x, spot.y) == null, "${spot.id}: not remembered after save and load")
    }
}
