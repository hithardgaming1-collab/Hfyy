package android.graphics

import java.awt.AlphaComposite
import java.awt.BasicStroke
import java.awt.Graphics2D
import java.awt.RenderingHints
import java.awt.geom.AffineTransform
import java.awt.geom.Arc2D
import java.awt.geom.Ellipse2D
import java.awt.geom.Path2D
import java.awt.geom.RoundRectangle2D
import java.awt.image.BufferedImage

// Java2D stand-in for the parts of android.graphics the game uses, so Art.kt and GameView.kt can run (and be screenshotted)
// on a laptop. It only needs to look right, not to be fast.

object Color {
    const val WHITE = -1; const val BLACK = 0xFF000000.toInt(); const val GRAY = 0xFF888888.toInt(); const val YELLOW = 0xFFFFFF00.toInt()
    const val TRANSPARENT = 0
    fun rgb(r: Int, g: Int, b: Int): Int = (0xFF shl 24) or (r.coerceIn(0, 255) shl 16) or (g.coerceIn(0, 255) shl 8) or b.coerceIn(0, 255)
    fun argb(a: Int, r: Int, g: Int, b: Int): Int = (a.coerceIn(0, 255) shl 24) or (r.coerceIn(0, 255) shl 16) or (g.coerceIn(0, 255) shl 8) or b.coerceIn(0, 255)
    fun red(c: Int) = (c shr 16) and 255
    fun green(c: Int) = (c shr 8) and 255
    fun blue(c: Int) = c and 255
    fun alpha(c: Int) = (c ushr 24) and 255
}

class Path {
    val p = Path2D.Float()
    fun reset() { p.reset() }
    fun moveTo(x: Float, y: Float) { p.moveTo(x.toDouble(), y.toDouble()) }
    fun lineTo(x: Float, y: Float) { p.lineTo(x.toDouble(), y.toDouble()) }
    fun close() { p.closePath() }
}

class Typeface { companion object { val DEFAULT = Typeface(); val DEFAULT_BOLD = Typeface(); val MONOSPACE = Typeface() } }

open class Shader { enum class TileMode { CLAMP, REPEAT, MIRROR } }
class LinearGradient(val x0: Float, val y0: Float, val x1: Float, val y1: Float, val c0: Int, val c1: Int, val tile: Shader.TileMode) : Shader()

class Paint() {
    constructor(flags: Int) : this()
    enum class Style { FILL, STROKE, FILL_AND_STROKE }
    enum class Cap { BUTT, ROUND, SQUARE }
    enum class Align { LEFT, CENTER, RIGHT }
    companion object { const val ANTI_ALIAS_FLAG = 1; const val FILTER_BITMAP_FLAG = 2 }
    var color = 0; var style = Style.FILL; var strokeWidth = 1f; var strokeCap = Cap.BUTT
    var textSize = 12f; var textAlign = Align.LEFT
    var isAntiAlias = false; var isFilterBitmap = false; var isDither = false
    var typeface: Typeface? = null; var shader: Shader? = null
    var alpha: Int
        get() = Color.alpha(color)
        set(v) { color = (color and 0x00FFFFFF) or (v.coerceIn(0, 255) shl 24) }
    fun measureText(s: String): Float {
        val f = java.awt.Font("SansSerif", java.awt.Font.BOLD, textSize.toInt().coerceAtLeast(1))
        return java.awt.Canvas().getFontMetrics(f).stringWidth(s).toFloat()
    }
}

class Rect() {
    var left = 0; var top = 0; var right = 0; var bottom = 0
    constructor(l: Int, t: Int, r: Int, b: Int) : this() { set(l, t, r, b) }
    fun set(l: Int, t: Int, r: Int, b: Int) { left = l; top = t; right = r; bottom = b }
    fun width() = right - left
    fun height() = bottom - top
}
class RectF() {
    var left = 0f; var top = 0f; var right = 0f; var bottom = 0f
    constructor(l: Float, t: Float, r: Float, b: Float) : this() { set(l, t, r, b) }
    fun set(l: Float, t: Float, r: Float, b: Float) { left = l; top = t; right = r; bottom = b }
    fun contains(x: Float, y: Float) = x >= left && x < right && y >= top && y < bottom
}

class Bitmap(val img: BufferedImage) {
    enum class Config { ARGB_8888 }
    val width get() = img.width
    val height get() = img.height
    fun setHasAlpha(b: Boolean) {}
    fun recycle() {}
    fun getPixel(x: Int, y: Int) = img.getRGB(x, y)
    fun setPixel(x: Int, y: Int, c: Int) { img.setRGB(x, y, c) }
    fun getPixels(a: IntArray, off: Int, stride: Int, x: Int, y: Int, w: Int, h: Int) { img.getRGB(x, y, w, h, a, off, stride) }
    fun setPixels(a: IntArray, off: Int, stride: Int, x: Int, y: Int, w: Int, h: Int) { img.setRGB(x, y, w, h, a, off, stride) }
    companion object {
        fun createBitmap(w: Int, h: Int, c: Config): Bitmap = Bitmap(BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB))
    }
}

/** Resource ids -> png names come from the generated R stub (RNames). */
object BitmapFactory {
    class Options { var inScaled = true }
    var resDir = java.io.File("../../app/src/main/res/drawable-nodpi")
    fun decodeResource(r: android.content.res.Resources, id: Int, o: Options? = null): Bitmap? {
        val name = com.example.critterquest.RNames.map[id] ?: return null
        val f = java.io.File(resDir, "$name.png")
        if (!f.exists()) return null
        return Bitmap(javax.imageio.ImageIO.read(f).let { src ->
            val out = BufferedImage(src.width, src.height, BufferedImage.TYPE_INT_ARGB); out.graphics.drawImage(src, 0, 0, null); out })
    }
}

class Canvas(val img: BufferedImage) {
    constructor(b: Bitmap) : this(b.img)
    val g: Graphics2D = img.createGraphics()
    private var aa = false
    private val stack = ArrayList<Pair<AffineTransform, java.awt.Shape?>>()
    val width get() = img.width
    val height get() = img.height
    private fun use(p: Paint) {
        val on = p.isAntiAlias
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, if (on) RenderingHints.VALUE_ANTIALIAS_ON else RenderingHints.VALUE_ANTIALIAS_OFF)
        g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE)
        val sh = p.shader
        if (sh is LinearGradient) g.paint = java.awt.GradientPaint(sh.x0, sh.y0, java.awt.Color(sh.c0, true), sh.x1, sh.y1, java.awt.Color(sh.c1, true))
        else g.color = java.awt.Color(p.color, true)
        if (p.style != Paint.Style.FILL) g.stroke = BasicStroke(p.strokeWidth, if (p.strokeCap == Paint.Cap.ROUND) BasicStroke.CAP_ROUND else BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER)
    }
    private fun fillOrDraw(s: java.awt.Shape, p: Paint) { use(p); if (p.style == Paint.Style.FILL) g.fill(s) else g.draw(s) }
    fun drawRect(l: Float, t: Float, r: Float, b: Float, p: Paint) = fillOrDraw(java.awt.geom.Rectangle2D.Float(l, t, r - l, b - t), p)
    fun drawOval(l: Float, t: Float, r: Float, b: Float, p: Paint) = fillOrDraw(Ellipse2D.Float(l, t, r - l, b - t), p)
    fun drawCircle(cx: Float, cy: Float, r: Float, p: Paint) = fillOrDraw(Ellipse2D.Float(cx - r, cy - r, 2 * r, 2 * r), p)
    fun drawRoundRect(l: Float, t: Float, r: Float, b: Float, rx: Float, ry: Float, p: Paint) = fillOrDraw(RoundRectangle2D.Float(l, t, r - l, b - t, rx * 2, ry * 2), p)
    fun drawLine(x0: Float, y0: Float, x1: Float, y1: Float, p: Paint) {
        use(p); g.stroke = BasicStroke(p.strokeWidth, if (p.strokeCap == Paint.Cap.ROUND) BasicStroke.CAP_ROUND else BasicStroke.CAP_BUTT, BasicStroke.JOIN_ROUND)
        g.draw(java.awt.geom.Line2D.Float(x0, y0, x1, y1))
    }
    fun drawPath(path: Path, p: Paint) = fillOrDraw(path.p, p)
    fun drawArc(l: Float, t: Float, r: Float, b: Float, start: Float, sweep: Float, useCenter: Boolean, p: Paint) =
        fillOrDraw(Arc2D.Float(l, t, r - l, b - t, -start, -sweep, if (useCenter) Arc2D.PIE else Arc2D.OPEN), p)
    fun drawColor(c: Int) { g.composite = AlphaComposite.Src; g.color = java.awt.Color(c, true); g.fillRect(0, 0, img.width, img.height); g.composite = AlphaComposite.SrcOver }
    fun drawText(s: String, x: Float, y: Float, p: Paint) {
        use(p); g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON)
        g.font = java.awt.Font("SansSerif", java.awt.Font.BOLD, p.textSize.toInt().coerceAtLeast(1))
        val w = g.fontMetrics.stringWidth(s)
        val dx = when (p.textAlign) { Paint.Align.CENTER -> -w / 2f; Paint.Align.RIGHT -> -w.toFloat(); else -> 0f }
        g.drawString(s, x + dx, y)
    }
    fun drawBitmap(b: Bitmap, x: Float, y: Float, p: Paint?) { g.drawImage(b.img, Math.round(x), Math.round(y), null) }
    fun drawBitmap(b: Bitmap, src: Rect?, dst: Rect, p: Paint?) = blit(b, src, dst.left.toFloat(), dst.top.toFloat(), dst.right.toFloat(), dst.bottom.toFloat(), p)
    fun drawBitmap(b: Bitmap, src: Rect?, dst: RectF, p: Paint?) = blit(b, src, dst.left, dst.top, dst.right, dst.bottom, p)
    private fun blit(b: Bitmap, src: Rect?, dl: Float, dt: Float, dr: Float, db: Float, p: Paint?) {
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, if (p?.isFilterBitmap == true) RenderingHints.VALUE_INTERPOLATION_BILINEAR else RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR)
        val sl = src?.left ?: 0; val st = src?.top ?: 0; val sr = src?.right ?: b.width; val sb = src?.bottom ?: b.height
        g.drawImage(b.img, Math.round(dl), Math.round(dt), Math.round(dr), Math.round(db), sl, st, sr, sb, null)
    }
    fun save(): Int { stack.add(g.transform.let { AffineTransform(it) } to g.clip); return stack.size }
    fun restore() { if (stack.isNotEmpty()) { val (t, c) = stack.removeAt(stack.size - 1); g.transform = t; g.clip = c } }
    fun rotate(deg: Float, px: Float, py: Float) { g.rotate(Math.toRadians(deg.toDouble()), px.toDouble(), py.toDouble()) }
    fun rotate(deg: Float) { g.rotate(Math.toRadians(deg.toDouble())) }
    fun translate(x: Float, y: Float) { g.translate(x.toDouble(), y.toDouble()) }
    fun scale(x: Float, y: Float) { g.scale(x.toDouble(), y.toDouble()) }
    fun clipRect(l: Float, t: Float, r: Float, b: Float): Boolean { g.clipRect(Math.floor(l.toDouble()).toInt(), Math.floor(t.toDouble()).toInt(), Math.ceil((r - l).toDouble()).toInt(), Math.ceil((b - t).toDouble()).toInt()); return true }
}
