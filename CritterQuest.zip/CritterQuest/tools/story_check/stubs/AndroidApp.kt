package android.content

class SharedPreferences {
    private val m = HashMap<String, Any>()
    fun contains(k: String) = m.containsKey(k)
    fun getString(k: String, d: String?): String? = m[k] as? String ?: d
    fun getInt(k: String, d: Int): Int = m[k] as? Int ?: d
    fun edit(): Editor = Editor(m)
    class Editor(private val m: HashMap<String, Any>) {
        fun putString(k: String, v: String): Editor { m[k] = v; return this }
        fun putInt(k: String, v: Int): Editor { m[k] = v; return this }
        fun remove(k: String): Editor { m.remove(k); return this }
        fun apply() {}
    }
}

open class Context {
    val resources: android.content.res.Resources = android.content.res.Resources()
    private val prefs = HashMap<String, SharedPreferences>()
    fun getSharedPreferences(n: String, mode: Int): SharedPreferences = prefs.getOrPut(n) { SharedPreferences() }
    companion object { const val MODE_PRIVATE = 0 }
}
