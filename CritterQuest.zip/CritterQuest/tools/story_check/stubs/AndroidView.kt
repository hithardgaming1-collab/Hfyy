package android.view

import android.content.Context
import android.graphics.Canvas

class KeyEvent(val keyCode: Int = 0, val action: Int = 0, val repeatCount: Int = 0) {
    companion object {
        const val ACTION_DOWN = 0; const val ACTION_UP = 1
        const val KEYCODE_DPAD_UP = 19; const val KEYCODE_DPAD_DOWN = 20; const val KEYCODE_DPAD_LEFT = 21; const val KEYCODE_DPAD_RIGHT = 22
        const val KEYCODE_DPAD_CENTER = 23; const val KEYCODE_ENTER = 66; const val KEYCODE_BACK = 4; const val KEYCODE_ESCAPE = 111
        const val KEYCODE_BUTTON_A = 96; const val KEYCODE_BUTTON_B = 97; const val KEYCODE_SPACE = 62; const val KEYCODE_W = 51
        const val KEYCODE_A = 29; const val KEYCODE_S = 47; const val KEYCODE_D = 32; const val KEYCODE_Z = 54; const val KEYCODE_X = 52
        const val KEYCODE_BUTTON_START = 108; const val KEYCODE_MENU = 82; const val KEYCODE_J = 38; const val KEYCODE_K = 39
        const val KEYCODE_BUTTON_X = 99; const val KEYCODE_BUTTON_Y = 100; const val KEYCODE_NUMPAD_ENTER = 160; const val KEYCODE_I = 37; const val KEYCODE_TAB = 61
    }
}

class MotionEvent(val action: Int = 0, val x: Float = 0f, val y: Float = 0f) {
    val actionMasked get() = action
    val pointerCount = 1; val actionIndex = 0
    fun getX(i: Int) = x; fun getY(i: Int) = y; fun getPointerId(i: Int) = 0; fun findPointerIndex(id: Int) = 0
    fun getAxisValue(a: Int) = 0f
    companion object {
        const val ACTION_DOWN = 0; const val ACTION_UP = 1; const val ACTION_MOVE = 2; const val ACTION_CANCEL = 3
        const val ACTION_POINTER_DOWN = 5; const val ACTION_POINTER_UP = 6; const val AXIS_X = 0; const val AXIS_Y = 1; const val AXIS_HAT_X = 15; const val AXIS_HAT_Y = 16
    }
}

open class View(val context: Context) {
    val resources get() = context.resources
    open fun onDraw(canvas: Canvas) {}
    fun invalidate() {}
    fun postInvalidateDelayed(ms: Long) {}
    fun postInvalidateOnAnimation() {}
    var isFocusable = false; var isFocusableInTouchMode = false
    fun requestFocus(): Boolean = true
    val width = 0; val height = 0
    open fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean = false
    open fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean = false
    open fun onTouchEvent(event: MotionEvent): Boolean = false
    open fun onGenericMotionEvent(event: MotionEvent): Boolean = false
    open fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {}
    fun post(r: Runnable): Boolean = true
}

class Window {
    fun addFlags(f: Int) {}
    fun setBackgroundDrawable(d: Any?) {}
}
class WindowManager { class LayoutParams { companion object { const val FLAG_KEEP_SCREEN_ON = 128 } } }
