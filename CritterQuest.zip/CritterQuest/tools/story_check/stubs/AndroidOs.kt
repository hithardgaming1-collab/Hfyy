package android.os

/** A clock the screenshot tool can advance by hand. */
object SystemClock {
    var fake = 100000L
    fun uptimeMillis(): Long = fake
    fun elapsedRealtime(): Long = fake
}
class Bundle
