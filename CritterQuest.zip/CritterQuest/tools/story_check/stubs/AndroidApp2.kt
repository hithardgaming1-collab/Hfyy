package android.app

import android.content.Context
import android.view.View
import android.view.Window

open class Activity : Context() {
    val window = Window()
    open fun onCreate(b: android.os.Bundle?) {}
    fun setContentView(v: View) {}
}
