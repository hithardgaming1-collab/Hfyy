package com.example.critterquest

import android.graphics.Bitmap
import android.graphics.Canvas
import kotlin.math.abs
import kotlin.random.Random

/**
 * Checks KJPW: the roster and move list are well formed, and the bout engine finishes every match it starts.
 *   roster()  every wrestler and move is valid (stats, names, move lists, finishers, looks, lines)
 *   bouts()   thousands of seeded bouts: all end, nothing is left unsaid, nobody is hopeless or unbeatable
 *   world()   the road from Mossbrook, the ticket machine, the pass at the arena door, the usher and the announcer, walked by a bot
 *   saves()   tickets survive a save, old saves load with none, tampered saves are clamped
 *   menus()   every menu fits the dialogue box and reaches all the wrestlers
 *   show()    every beat of thousands of bouts has a sane animation, and the match screen draws at every screen shape and ends
 */
object ArenaCheck {
    private var bad = 0
    private fun need(c: Boolean, m: String) { if (!c) { println("  ARENA CHECK FAILED: $m"); bad++ } }

    @JvmStatic fun main(args: Array<String>) { if (run() != 0) System.exit(1) }

    fun run(): Int {
        bad = 0
        roster()
        bouts()
        world()
        saves()
        menus()
        show()
        println(if (bad == 0) "arena check: ok (${ROSTER.size} wrestlers, ${WMOVES.size} moves, bouts always finish, tickets, pass door, menus, match screen)" else "arena check: $bad problems")
        return bad
    }

    private fun roster() {
        need(ROSTER.size >= 24, "the roster has ${ROSTER.size} wrestlers (24 or more expected)")
        need(ROSTER.map { it.id }.toSet().size == ROSTER.size, "two wrestlers share an id")
        need(ROSTER.map { it.name }.toSet().size == ROSTER.size, "two wrestlers share a name")
        need(WMOVES.map { it.name }.toSet().size == WMOVES.size, "two wrestling moves share a name")
        need(WMOVES.size >= 100, "only ${WMOVES.size} wrestling moves")
        for (m in WMOVES) {
            need(m.line.contains("{A}"), "move ${m.name} never says who does it")
            need(m.power in 0..10 && m.cost in 0..10, "move ${m.name} has odd power/cost")
            need(m.kind != WKind.TAUNT == (m.power > 0), "move ${m.name}: only taunts hit for nothing")
            need(m.finisher == (m in FINISHERS), "move ${m.name} finisher flag")
            need(m.kind != WKind.HOLD || m.anim == WAnim.HOLD, "hold ${m.name} should use the hold picture")
        }
        val fins = HashSet<String>()
        for (w in ROSTER) {
            val s = "wrestler ${w.name}"
            need(w.name.length <= 16, "$s: name too long for the plate")
            need(listOf(w.pow, w.spd, w.tech, w.tough, w.sta, w.charm).all { it in 1..10 }, "$s: stats must be 1..10")
            need(w.moves.size in 5..8, "$s knows ${w.moves.size} moves")
            need(w.moves.toSet().size == w.moves.size, "$s lists a move twice")
            for (n in w.moves) need(wmoveOrNull(n)?.finisher == false, "$s: '$n' is not a basic move")
            need(wmoveOrNull(w.finisher)?.finisher == true, "$s: '${w.finisher}' is not a finisher")
            need(fins.add(w.finisher), "$s shares the finisher ${w.finisher}")
            val kit = w.kit
            need(kit.any { it.needs == WNeed.STAND && it.kind != WKind.TAUNT }, "$s has nothing to use on a standing opponent")
            need(kit.any { it.needs == WNeed.DOWN }, "$s has nothing to use on a fallen opponent")
            need(w.look.body in 0..2, "$s: body must be 0, 1 or 2")
            need(w.look.boots != 0 && w.look.trunks != 0 && w.look.skin != 0 && w.look.hair != 0, "$s: a colour is missing")
            need(w.entrance.length in 10..80 && w.bio.length in 10..110, "$s: entrance/bio length")
            need(w.from.isNotBlank(), "$s has no home town")
        }
        for (st in WStyle.values()) need(ROSTER.any { it.style == st }, "no wrestler has the style ${st.label}")
    }

    /** Plays one whole bout, returns its beats. Fails the check if text is left unfilled or the numbers go wrong. */
    fun play(a: Wrestler, b: Wrestler, seed: Int): Pair<Bout, List<Beat>> {
        val bout = Bout(a, b, seed); val beats = ArrayList<Beat>()
        while (true) { val bt = bout.next() ?: break; beats.add(bt); if (beats.size > 400) break }
        return bout to beats
    }

    private fun bouts() {
        val rnd = Random(77)
        val wins = IntArray(ROSTER.size); val games = IntArray(ROSTER.size)
        var total = 0; var beatsSum = 0; var longest = 0; var forced = 0; var pins = 0; var taps = 0
        var shortest = 999; var kickouts = 0; var counters = 0; var finishers = 0; var longLine = 0
        val trials = 4000
        for (t in 0 until trials) {
            val i = rnd.nextInt(ROSTER.size); var j = rnd.nextInt(ROSTER.size - 1); if (j >= i) j++
            val (bout, beats) = play(ROSTER[i], ROSTER[j], t)
            total++; beatsSum += beats.size; longest = maxOf(longest, beats.size); shortest = minOf(shortest, beats.size)
            need(bout.over && beats.isNotEmpty() && beats.last().kind.let { it == BeatKind.WIN || it == BeatKind.TAP }, "bout $t (${ROSTER[i].id} v ${ROSTER[j].id}) did not end with a result")
            need(beats.count { it.kind == BeatKind.WIN || it.kind == BeatKind.TAP } == 1, "bout $t has more than one result")
            need(bout.winner in 0..1, "bout $t has no winner")
            if (bout.how.startsWith("the referee")) forced++
            if (bout.how.startsWith("pinfall")) pins++ else if (bout.how.startsWith("submission")) taps++
            games[i]++; games[j]++; wins[if (bout.winner == 0) i else j]++
            for (b in beats) {
                if (b.text.contains('{') || b.text.contains('}')) need(false, "unfilled text in bout $t: ${b.text}")
                if (b.text.length > 150) longLine++
                need(b.hp.all { it >= 0 } && b.hp[0] <= ROSTER[i].maxHp && b.hp[1] <= ROSTER[j].maxHp, "hp out of range in bout $t")
                need(b.sp.all { it in 0..100 }, "spirit out of range in bout $t")
                when (b.kind) { BeatKind.KICKOUT -> kickouts++; BeatKind.COUNTER -> counters++; else -> {} }
                if (b.move?.finisher == true && b.kind == BeatKind.MOVE) finishers++
            }
            // the winner of a pin or a tap was never counted out before: the last beat belongs to the winner
            need(beats.last().who == bout.winner || beats.last().kind == BeatKind.TAP, "bout $t: last beat is by the loser")
        }
        println("  bouts: $total played, beats per bout avg ${"%.1f".format(beatsSum.toDouble() / total)} (shortest $shortest, longest $longest), " +
            "pins $pins, submissions $taps, stopped by the referee $forced; kick-outs/bout ${"%.2f".format(kickouts.toDouble() / total)}, " +
            "reversals/bout ${"%.2f".format(counters.toDouble() / total)}, finishers/bout ${"%.2f".format(finishers.toDouble() / total)}, long lines $longLine")
        need(forced * 100 <= total, "$forced of $total bouts hit the beat limit (1% allowed)")
        need(beatsSum.toDouble() / total in 18.0..60.0, "bouts are too short or too long: ${beatsSum.toDouble() / total} beats")
        val rates = ROSTER.indices.map { wins[it].toDouble() / games[it].coerceAtLeast(1) }
        val order = ROSTER.indices.sortedByDescending { rates[it] }
        println("  win rate (random opponents): " + order.joinToString("  ") { "${ROSTER[it].id} ${(rates[it] * 100).toInt()}" })
        for (k in ROSTER.indices) need(rates[k] in 0.20..0.80, "${ROSTER[k].name} wins ${(rates[k] * 100).toInt()}% of his bouts (should be between 20% and 80%)")
    }

    // ---- the world side, walked by a bot ----
    private fun world() {
        for (id in listOf("plaza", "hall", "arena")) need(MAPS.containsKey(id), "map $id is missing")
        fun goes(from: String) = MAPS.getValue(from).warps.map { it.to }.toSet()
        need("plaza" in goes("mossbrook"), "Mossbrook has no road west to the plaza")
        need(goes("plaza") == setOf("mossbrook", "hall") && goes("hall") == setOf("plaza", "arena") && goes("arena") == setOf("hall"), "the plaza, hall and arena doors do not connect as planned")
        need(ARENA_MAPS == setOf("hall", "arena"), "ARENA_MAPS should be the hall and the arena")
        need(TICKET_MACHINES.all { tm -> MAPS.getValue(tm.map).tile(tm.x, tm.y).let { !it.solid } }, "a ticket machine stands on a solid tile")
        val gate = MAPS.getValue("hall").warpAt(21, 3)
        need(gate?.need != null && gate.deny.contains("usher", ignoreCase = true), "the arena doors need a pass and say who gives it")
        need(MAPS.getValue("arena").warps.none { it.need != null }, "you can always walk out of the arena")

        val bot = StationCheck.newGame(91); val g = bot.g
        g.coins = 2 * TICKET_PRICE + 20 + TICKET_PRICE; g.tickets = 0; val start = g.coins
        bot.goMap("plaza"); need(g.map.id == "plaza", "the bot could not walk west from Mossbrook to the plaza")
        need(!g.f(PASS_FLAG), "a pass before any ticket")
        // the ticket machine
        val tm = TICKET_MACHINES.first()
        fun faceMachine() { val d = (0..3).first { DX[it] == tm.x - g.px && DY[it] == tm.y - g.py }; bot.now += 200; g.step(d, bot.now); bot.now += 200; g.tick(bot.now) }
        bot.go({ it.m == tm.map && abs(it.x - tm.x) + abs(it.y - tm.y) == 1 }, "the ticket machine"); faceMachine()
        need(g.px != tm.x || g.py != tm.y, "the bot walked through the ticket machine")
        need(g.interact(bot.now), "no ticket machine to use")
        var seen = StationCheck.converse(g, bot, listOf("Buy 1", "Leave"))
        need(g.tickets == 1 && g.coins == start - TICKET_PRICE, "Buy 1: tickets ${g.tickets}, coins ${g.coins} (want 1 and ${start - TICKET_PRICE})")
        need(seen.any { it.startsWith("Bought 1 ticket for $TICKET_PRICE coins") }, "buy message wrong: $seen")
        need(seen.first().contains("$TICKET_PRICE coins each") && seen.first().contains("You hold 0 tickets and $start coins"), "the machine did not show the price and what you have: ${seen.first()}")
        g.interact(bot.now); seen = StationCheck.converse(g, bot, listOf("Buy 10", "Leave"))
        need(g.tickets == 3 && g.coins == start - 3 * TICKET_PRICE, "Buy 10 with money for two: tickets ${g.tickets}, coins ${g.coins}")
        need(seen.any { it.contains("That is all you can afford") }, "no 'all you can afford' message: $seen")
        val left = g.coins
        g.interact(bot.now); seen = StationCheck.converse(g, bot, listOf("Buy 1", "Leave"))
        need(g.tickets == 3 && g.coins == left && seen.any { it.startsWith("A ticket costs $TICKET_PRICE coins. You have $left") }, "buying without the money changed something: tickets ${g.tickets}, coins ${g.coins}")
        run { val h = StationCheck.newGame(93).g; h.coins = 100 * TICKET_PRICE; h.tickets = TICKET_CAP - 1
            h.play(h.ticketScript()); StationCheck.converse(h, StationCheck.newGame(94), listOf("Buy 5", "Buy 1", "Leave"))
            need(h.tickets == TICKET_CAP && h.coins == 100 * TICKET_PRICE - TICKET_PRICE, "the ticket cap: tickets ${h.tickets} (want $TICKET_CAP), coins ${h.coins}") }
        // the hall: the arena doors stay shut without a pass
        bot.goMap("hall"); need(g.map.id == "hall", "the bot could not enter the hall")
        need(bot.path { it.m == "arena" } == null, "the bot found a way into the arena without a pass")
        need(gate!!.need!!.invoke(g).not(), "the arena door is open without a pass")
        // the usher takes a ticket and gives the pass
        fun beside(id: String, map: String) { val n = NPCS.first { it.id == id }
            bot.go({ it.m == map && abs(it.x - n.x) + abs(it.y - n.y) == 1 }, id)
            val d = (0..3).first { DX[it] == n.x - g.px && DY[it] == n.y - g.py }; bot.now += 200; g.step(d, bot.now); bot.now += 200; g.tick(bot.now) }
        beside("ar_usher", "hall"); need(g.interact(bot.now), "no usher")
        StationCheck.converse(g, bot, listOf("Not yet"))
        need(g.tickets == 3 && !g.f(PASS_FLAG), "the usher took a ticket for nothing")
        need(g.interact(bot.now), "no usher (2)"); seen = StationCheck.converse(g, bot, listOf("Show a ticket"))
        need(g.tickets == 2 && g.f(PASS_FLAG), "showing a ticket: tickets ${g.tickets}, pass ${g.f(PASS_FLAG)}")
        need(g.interact(bot.now), "no usher (3)"); seen = StationCheck.converse(g, bot, emptyList())
        need(g.tickets == 2 && seen.any { it.contains("ticket is good") }, "a second visit with a pass took another ticket: ${g.tickets} $seen")
        // the arena: the announcer puts on a bout, and the winner is announced afterwards
        bot.goMap("arena"); need(g.map.id == "arena" && g.f(PASS_FLAG), "the bot could not enter the arena with a pass")
        beside("ar_announcer", "arena"); need(g.interact(bot.now), "no announcer")
        seen = StationCheck.converse(g, bot, listOf("A surprise bout"))
        val req = g.matchReq
        need(req != null && ROSTER_BY_ID.containsKey(req.a) && ROSTER_BY_ID.containsKey(req.b) && req.a != req.b, "the surprise bout did not ask for two different wrestlers")
        need(seen.any { it.startsWith("From ") && it.contains("Ring the bell") }, "the bout was not announced: $seen")
        g.matchDone("Anchor Abe|pinfall")
        seen = StationCheck.converse(g, bot, listOf("Not now"))
        need(g.matchReq == null && seen.any { it.startsWith("Anchor Abe wins by pinfall") } && seen.any { it.startsWith("Another bout?") }, "after the bout: ${seen}")
        g.interact(bot.now); seen = StationCheck.converse(g, bot, listOf("A surprise bout")); g.matchDone("")
        need(StationCheck.converse(g, bot, listOf("Not now")).any { it.startsWith("Leaving the ring already?") }, "a bout left early was not handled")
        // walking out into the square ends the night
        bot.goMap("hall"); need(g.f(PASS_FLAG), "the pass was lost between the arena and the hall")
        bot.goMap("plaza"); need(!g.f(PASS_FLAG) && g.tickets == 2, "leaving the hall: pass ${g.f(PASS_FLAG)}, tickets ${g.tickets} (want no pass and 2 tickets)")
        // a pass is never kept in a save-less way: loading a save drops it with the other flags only if it was not saved
        need(g.coins >= 0, "negative coins")
    }

    private fun saves() {
        val g = Game(Random(3)); g.newGame(); g.chooseStarter(0); g.tickets = 7
        val text = g.serialize()
        val g2 = Game(Random(4)); need(g2.load(text) && g2.tickets == 7, "tickets lost by save: ${g2.tickets}")
        val g3 = Game(Random(5)); g3.tickets = 5; need(g3.load(text.lines().filter { !it.startsWith("tickets=") }.joinToString("\n")) && g3.tickets == 0, "a save from before KJPW should have no tickets (${g3.tickets})")
        val g4 = Game(Random(6)); need(g4.load(text.lines().joinToString("\n") { if (it.startsWith("tickets=")) "tickets=999" else it }) && g4.tickets == TICKET_CAP, "tickets=999 loaded as ${g4.tickets}")
        val g5 = Game(Random(7)); need(g5.load(text.lines().joinToString("\n") { if (it.startsWith("tickets=")) "tickets=-4" else it }) && g5.tickets == 0, "tickets=-4 loaded as ${g5.tickets}")
        val g6 = Game(Random(8)); need(g6.load(text.lines().joinToString("\n") { if (it.startsWith("tickets=")) "tickets=many" else it }) && g6.tickets == 0, "tickets=many loaded as ${g6.tickets}")
        g.newGame(); need(g.tickets == 0 && g.matchReq == null, "a new game keeps tickets (${g.tickets})")
    }

    // ---- every menu fits the dialogue box (7 rows at most) and reaches every wrestler ----
    private fun menus() {
        val bot = StationCheck.newGame(92); val g = bot.g
        g.play(g.announcerTalk())
        var ask = g.cur as? Step.Ask; need(ask != null && ask.opts.size in 2..7, "announcer menu has ${ask?.opts?.size} options")
        need(ask!!.opts == listOf("A surprise bout", "Pick the fighters", "Who's who?", "Not now"), "announcer options changed: ${ask.opts}")
        for (which in listOf("Pick the fighters", "Who's who?")) {
            g.advance(ask!!.opts.indexOf(which))
            val names = HashSet<String>(); var pages = 0
            while (true) {
                val a = g.cur as? Step.Ask ?: break
                need(a.opts.size <= 7, "$which: a roster page has ${a.opts.size} options (7 fit)")
                a.opts.filter { it != "More..." && it != "Back" }.forEach { names.add(it) }
                if (++pages > 5) break
                g.advance(a.opts.indexOf("More..."))
            }
            need(names == ROSTER.map { it.name }.toSet(), "$which: the pages show ${names.size} of ${ROSTER.size} wrestlers")
            need(pages == 6, "$which: the roster menu has ${pages - 1} pages and then wraps (want 5)")
            // pick the first name of the page we are on, and see what happens
            val page = g.cur as Step.Ask
            if (which == "Who's who?") {
                g.advance(0); val first = ROSTER.sortedBy { it.name }[0]
                val seen = ArrayList<String>(); var guard = 0
                while (guard++ < 20) { val c = g.cur; if (c is Step.Say) { seen.add(c.text); g.advance() } else break }
                need(seen.size == 2 && seen[0].startsWith(first.name) && seen[1].startsWith("Finisher: the ${first.finisher}"), "the card of ${first.name} reads wrong: $seen")
            } else {
                g.advance(0)      // the first red-corner name, then the second menu
                val second = g.cur as? Step.Ask; need(second != null && second.text.startsWith("And who faces"), "no second-fighter menu: ${second?.text}")
                val me = ROSTER.sortedBy { it.name }[0]
                g.advance(0)      // the same wrestler again: refused, and asked again
                val say = g.cur as? Step.Say; need(say != null && say.text.contains("cannot fight"), "a wrestler can fight himself: ${(g.cur as? Step.Say)?.text}")
                g.advance(); need(g.cur is Step.Ask, "no menu after the refusal")
                g.advance(1)      // someone else
                var guard = 0; while (g.cur is Step.Say && guard++ < 5) g.advance()
                need(g.matchReq != null && g.matchReq!!.a == me.id && g.matchReq!!.b != me.id, "the picked bout is wrong: ${g.matchReq?.a} v ${g.matchReq?.b}")
                g.matchDone("")
                var guard2 = 0; while (g.cur != null && guard2++ < 20) { val c = g.cur; if (c is Step.Ask) g.advance(c.opts.size - 1) else g.advance() }
                need(g.cur == null && g.matchReq == null, "the announcer's talk did not end")
            }
            g.play(g.announcerTalk()); ask = g.cur as? Step.Ask
        }
        // the plate names fit their half of the screen, and so does the text of each wrestler
        for (w in ROSTER) need(PixelFont.width(w.name) <= (213 - 12) / 2 - 14, "${w.name} is too wide for the match plate (${PixelFont.width(w.name)} px)")
    }

    /** One beat's animation is sane: it lasts a while, its keys are in order, and nobody is thrown off the screen (a walk-in starts off it). */
    private fun checkAnim(b: Beat, prev: Beat?, last: Boolean) {
        val an = MatchAnims.build(b, prev, last)
        need(an.ms in 300..6000, "a ${b.kind} beat (${b.move?.name}) lasts ${an.ms} ms")
        need(an.keys.isNotEmpty() && an.keys.zipWithNext().all { (p, q) -> p.t <= q.t } && an.keys.all { it.t in 0f..1.001f }, "a ${b.kind} beat (${b.move?.name}) has its keys out of order")
        val limit = if (b.kind == BeatKind.INTRO) 320f else 160f
        for (tt in floatArrayOf(0f, 0.25f, 0.5f, 0.75f, 1f)) {
            val pz = MatchAnims.sample(an, tt)
            need(pz.size == 2 && pz.all { !it.dx.isNaN() && !it.dy.isNaN() && abs(it.dx) < limit && abs(it.dy) < 100f }, "a ${b.kind} beat (${b.move?.name}) puts a wrestler off the screen at t=$tt")
        }
    }

    // ---- the show: every beat can be animated, and the match screen draws at every screen shape and ends ----
    private fun show() {
        val rnd = Random(21); val anims = HashSet<WAnim>(); val kinds = HashSet<BeatKind>(); var beatsSeen = 0
        for (t in 0 until 300) {
            val i = rnd.nextInt(ROSTER.size); var j = rnd.nextInt(ROSTER.size - 1); if (j >= i) j++
            val (_, beats) = play(ROSTER[i], ROSTER[j], 5000 + t)
            var prev: Beat? = null
            for ((k, b) in beats.withIndex()) {
                checkAnim(b, prev, k == beats.size - 1); beatsSeen++
                kinds.add(b.kind); b.move?.let { anims.add(it.anim) }
                prev = b
            }
        }
        // and every single move, hit or miss, thrown from either side (a bout may never happen to use some of them)
        for (m in WMOVES) for (who in 0..1) for (hit in listOf(true, false)) {
            checkAnim(Beat(BeatKind.MOVE, who, m, "x", intArrayOf(50, 50), intArrayOf(50, 50), arrayOf(WPos.STAND, WPos.DOWN), hit, 5), null, false); beatsSeen++
            anims.add(m.anim)
        }
        need(anims == WAnim.values().toSet(), "no move uses the pictures for ${WAnim.values().toSet() - anims}")
        need(kinds == BeatKind.values().toSet(), "bouts never showed ${BeatKind.values().toSet() - kinds}")
        // the match screen: no sprite sheet at all must still draw; OK skips along, and the show ends by itself
        val sprites = WrestlerSprites { null }
        for ((w, h) in listOf(213 to 160, 284 to 160, 320 to 180, 427 to 180, 570 to 160)) {
            val c = Canvas(Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888))
            for (seed in listOf(11, 12)) {
                val mv = MatchView(ROSTER[seed % ROSTER.size], ROSTER[(seed * 5 + 3) % ROSTER.size], seed, sprites, 0L)
                var now = 0L; var guard = 0
                while (!mv.done && guard++ < 30000) {
                    now += 34; mv.update(now); mv.draw(c, w.toFloat(), h.toFloat())
                    if (guard % 30 == 0) mv.input(4)
                    if (guard == 200) { mv.input(RIGHT); mv.cycleSpeed() }
                }
                need(mv.done && mv.finished && mv.winnerName.isNotEmpty() && mv.how.isNotEmpty(), "the match screen at ${w}x$h did not finish a bout (done ${mv.done}, finished ${mv.finished})")
            }
        }
        println("  show: $beatsSeen beats animated, ${anims.size} move pictures, ${kinds.size} kinds of beat, the match screen drawn at 5 screen shapes")
    }
}
