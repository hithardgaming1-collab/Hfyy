// Screenshots of KJPW on the REAL game (GameView, Art, MatchView...) drawn on a laptop with the stand-in Android classes:
// the plaza, the ticket machine, the hallway, the arena, the announcer, and one whole match in several poses.
//   ./run.sh arenashots   ->  docs/arena/*.png
package com.example.critterquest

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.SystemClock
import android.view.KeyEvent
import java.io.File
import javax.imageio.ImageIO

object ArenaShots {
    private const val SW = 1920; private const val SH = 1080
    private lateinit var view: GameView
    private val screen = Bitmap.createBitmap(SW, SH, Bitmap.Config.ARGB_8888)
    private val canvas = Canvas(screen)
    private lateinit var out: File

    private fun fld(name: String) = GameView::class.java.getDeclaredField(name).also { it.isAccessible = true }
    @Suppress("UNCHECKED_CAST") private fun <T> get(name: String): T = fld(name).get(view) as T
    private fun set(name: String, v: Any?) = fld(name).set(view, v)
    private fun mf(name: String) = MatchView::class.java.getDeclaredField(name).also { it.isAccessible = true }

    private fun frame(ms: Long = 34, n: Int = 1) { repeat(n) { SystemClock.fake += ms; view.onDraw(canvas) } }
    private fun press(code: Int, holdMs: Long = 60) {
        view.onKeyDown(code, KeyEvent(code, KeyEvent.ACTION_DOWN)); frame(holdMs.coerceAtLeast(34), 1)
        view.onKeyUp(code, KeyEvent(code, KeyEvent.ACTION_UP)); frame(34, 1)
    }
    private fun ok() = press(KeyEvent.KEYCODE_DPAD_CENTER)
    private fun shot(name: String) { frame(34, 2); ImageIO.write(screen.img, "png", File(out, "$name.png")); println("  $name") }

    private fun enter(g: Game, map: String, x: Int, y: Int, face: Int = DOWN) {
        val m = Game::class.java.getDeclaredMethod("enter", String::class.java, Int::class.javaPrimitiveType, Int::class.javaPrimitiveType, Int::class.javaPrimitiveType)
        m.isAccessible = true; m.invoke(g, map, x, y, face)
        g.px = x; g.py = y; g.fromX = x; g.fromY = y
    }

    private fun world(g: Game) {
        g.saveHook = null
        set("game", g); set("scene", 1); set("lastMapId", ""); set("pauseSel", -1)
        frame(34, 6); var guard = 0; while (g.cur != null && guard++ < 40) { ok(); frame(34, 3) }
        frame(34, 30)
    }

    /** Finish whatever conversation is open (answering the last option of every menu). */
    private fun endTalk(g: Game) {
        var guard = 0
        while (g.cur != null && guard++ < 60) { val c = g.cur; if (c is Step.Ask) g.advance(c.opts.size - 1) else g.advance(); frame(34, 3) }
    }

    /** A bout that shows off a lot (a finisher, a dive, a slam, a hold, a cover and kick-out), found by looking at seeded bouts. */
    private fun pickBout(): Triple<Wrestler, Wrestler, Int> {
        val slam = setOf(WAnim.SLAM, WAnim.SUPLEX, WAnim.SPIKE, WAnim.BOMB, WAnim.SPIN, WAnim.DROP)
        val ids = listOf("meteor", "abe", "duke", "tess", "owl", "reef", "crash", "doc")
        for (seed in 1..80) for (ai in ids) for (bi in ids) if (ai != bi) {
            val a = ROSTER_BY_ID.getValue(ai); val b = ROSTER_BY_ID.getValue(bi)
            val (_, beats) = ArenaCheck.play(a, b, seed)
            if (beats.size in 26..48 && beats.any { it.move?.finisher == true && it.kind == BeatKind.MOVE } && beats.any { it.move?.anim == WAnim.DIVE }
                && beats.any { it.move?.anim in slam } && beats.any { it.kind == BeatKind.HOLD } && beats.any { it.kind == BeatKind.KICKOUT } && beats.any { it.kind == BeatKind.COUNTER }) return Triple(a, b, seed)
        }
        return Triple(ROSTER_BY_ID.getValue("meteor"), ROSTER_BY_ID.getValue("abe"), 7)
    }

    @JvmStatic fun main(args: Array<String>) {
        System.setProperty("java.awt.headless", "true")
        out = File(args.getOrNull(0) ?: "../../docs/arena"); out.mkdirs()
        view = GameView(Context()); view.onSizeChanged(SW, SH, 0, 0)
        val g = Game(); g.newGame(); g.chooseStarter(0); g.addToParty(AQUAFIN, 7)
        g.set("starter"); g.set("labDone"); g.coins = 480
        println("screens:")
        // the road west of Mossbrook, the plaza, the machine
        enter(g, "mossbrook", 3, 7, LEFT); world(g); shot("01_mossbrook_west_road")
        enter(g, "plaza", 11, 8, UP); world(g); shot("02_plaza")
        enter(g, "plaza", 14, 7, UP); world(g); ok(); frame(34, 90); shot("03_ticket_machine")        // OK in front of the machine
        g.advance(0); frame(34, 100); shot("04_ticket_bought"); endTalk(g)                              // Buy 1
        // the hallway: posters, wrestlers, the usher
        enter(g, "hall", 3, 5, UP); world(g); shot("05_hallway")
        enter(g, "hall", 7, 2, UP); world(g); ok(); frame(34, 90); shot("06_poster"); endTalk(g)
        enter(g, "hall", 17, 3, RIGHT); world(g); shot("07_hallway_usher_side")
        g.tickets = 2; enter(g, "hall", 20, 3, UP); world(g); ok(); frame(34, 90); shot("08_usher"); g.advance(0); frame(34, 90); shot("09_pass"); endTalk(g)
        // the arena
        g.set(PASS_FLAG); enter(g, "arena", 12, 13, UP); world(g); shot("10_arena_door")
        enter(g, "arena", 12, 7, DOWN); world(g); shot("11_arena_ring")
        enter(g, "arena", 12, 11, UP); world(g); ok(); frame(34, 90); shot("12_announcer"); endTalk(g)
        // a whole match, played by the real show and photographed at the right moments
        val (a, b, seed) = pickBout()
        println("  bout: ${a.name} v ${b.name} (seed $seed)")
        enter(g, "arena", 12, 11, UP); world(g)
        g.play(listOf(say("Announcer", "From ${a.from}, ${a.name}! And from ${b.from}, ${b.name}! Ring the bell!"), act { matchReq = MatchReq(a.id, b.id, seed) }, act { play(afterBout()) }))
        var guard = 0; while (g.cur != null && guard++ < 10) { ok(); frame(34, 3) }
        frame(34, 10)
        val slam = setOf(WAnim.SLAM, WAnim.SUPLEX, WAnim.SPIKE, WAnim.BOMB, WAnim.SPIN, WAnim.DROP)
        class Want(val name: String, val delay: Float, val test: (Beat) -> Boolean)
        val wants = listOf(
            Want("13_match_walkin", 700f) { it.kind == BeatKind.INTRO },
            Want("14_match_bell", 350f) { it.kind == BeatKind.BELL },
            Want("15_match_strike", 420f) { it.kind == BeatKind.MOVE && (it.move?.anim == WAnim.STRIKE || it.move?.anim == WAnim.KICK) },
            Want("16_match_slam", 560f) { it.kind == BeatKind.MOVE && it.move?.anim in slam && it.move?.finisher == false },
            Want("17_match_dive", 640f) { it.kind == BeatKind.MOVE && it.move?.anim == WAnim.DIVE },
            Want("18_match_hold", 500f) { it.kind == BeatKind.HOLD },
            Want("19_match_finisher", 640f) { it.kind == BeatKind.MOVE && it.move?.finisher == true },
            Want("20_match_cover", 450f) { it.kind == BeatKind.COVER },
            Want("21_match_kickout", 450f) { it.kind == BeatKind.KICKOUT },
        )
        val taken = HashSet<String>(); var endedAt = -1f; var tries = 0; var fast = false
        while (tries++ < 9000) {
            frame(34, 1)
            val m: MatchView = get("match") ?: break
            if (!fast && tries > 30) { m.input(RIGHT); m.input(RIGHT); fast = true }
            val beat = mf("cur").get(m) as Beat?; val vt = mf("vt").getFloat(m); val t0 = mf("beatT0").getFloat(m)
            if (beat != null) for (w in wants) if (w.name !in taken && w.test(beat) && vt - t0 >= w.delay) { shot(w.name); taken.add(w.name) }
            if (mf("ended").getBoolean(m)) {
                if (endedAt < 0f) endedAt = vt
                if ("22_match_result" !in taken && vt - endedAt >= 1500f) { shot("22_match_result"); taken.add("22_match_result"); break }
            }
        }
        println("  match photographed: ${taken.sorted()}")
        ok(); frame(34, 40)                                                                               // OK leaves the match screen
        if (get<Any?>("match") != null) { ok(); frame(34, 40) }
        frame(34, 60); shot("23_after_bout"); endTalk(g)
        println("done: $out")
    }
}
