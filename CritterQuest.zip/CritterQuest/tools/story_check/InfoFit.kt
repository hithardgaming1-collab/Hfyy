package com.example.critterquest

/**
 * Checks GameView.infoBox (the name / level / HP plate in battle) for text that runs into other text, using the same
 * rules the game draws with (Ui.infoWidth, Ui.statusBesideName, Ui.chipWidth). Run:
 *   kotlin -cp <classes> com.example.critterquest.InfoFit
 */
object InfoFit {
    private val WIDTHS = listOf(160, 213, 240, 256, 291, 320, 347)   // 160 = a square screen, far narrower than any real phone / tablet
    private const val MIN_BAR = 24f                                 // the shortest HP bar that still reads as a bar

    @JvmStatic fun main(args: Array<String>) {
        var bad = 0
        for (w in WIDTHS) {
            val iw = Ui.infoWidth(w.toFloat())
            val nameRow = ArrayList<String>(); val hpRow = ArrayList<String>(); val typeRow = ArrayList<String>(); var moved = 0
            val lvW = PixelFont.width("Lv$MAX_LVL")
            for (sp in DEX) {
                val m = Mon(sp, MAX_LVL)
                val nameW = PixelFont.width(sp.name)
                if (8f + nameW + 3f > iw - 8f - lvW) nameRow.add(sp.name)                       // name runs into "Lv30"
                for (st in St.values()) {
                    if (Ui.statusBesideName(sp.name, st.tag, MAX_LVL, iw)) continue            // chip beside the name: it fits by construction
                    moved++                                                                    // chip goes in front of the HP bar: is there still a bar?
                    val bar = (iw - 10f) - (23f + Ui.chipWidth(st.tag) + 2f)
                    if (bar < MIN_BAR) hpRow.add("${sp.name}+${st.tag} bar ${bar.toInt()}px")
                }
                var cx = 8f
                for (ty in sp.types) cx += Ui.chipWidth(ty.label) + 2f
                val hpStart = iw - 8f - PixelFont.width("${m.maxHp}/${m.maxHp}")
                if (cx > hpStart) typeRow.add("${sp.name}(${sp.types.joinToString("/") { it.label }}) ${m.maxHp}/${m.maxHp}")
            }
            println("width $w (box ${iw.toInt()}px): name/level ${nameRow.size}, type-chips/HP ${typeRow.size}, HP bar too short ${hpRow.size}  (status chip moved to HP row in $moved of ${DEX.size * St.values().size} combos)")
            nameRow.take(3).forEach { println("    name row : $it") }; typeRow.take(3).forEach { println("    type row : $it") }; hpRow.take(3).forEach { println("    hp row   : $it") }
            bad += nameRow.size + typeRow.size + hpRow.size
        }
        println(if (bad == 0) "info box fit: ok" else "info box fit: $bad problems")
    }
}
