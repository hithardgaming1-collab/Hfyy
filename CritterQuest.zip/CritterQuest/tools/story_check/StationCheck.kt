package com.example.critterquest

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.SystemClock
import kotlin.math.abs

/**
 * Checks the Critter Stations (the kiosk in every town): a bot walks the real maps to each one, presses OK in front of it and
 * talks to it like a player: leaves a critter in the box, takes it back, is refused for the only partner / the only fighter,
 * and asks for "Choose my lead" (which opens the Critters screen). Mom's box uses the same script, so it is checked too.
 */
object StationCheck {
    private var bad = 0
    private fun need(c: Boolean, m: String) { if (!c) { println("  STATION CHECK FAILED: $m"); bad++ } }

    fun run(): Int {
        bad = 0
        for (st in STATIONS) visit(st)
        mom()
        draws()
        println(if (bad == 0) "station check: ok (${STATIONS.size} stations: leave, take, refusals, lead chooser; Mom's box shares the script)" else "station check: $bad problems")
        return bad
    }

    /** Answers a conversation: each entry is the start of the option to pick, in order (leftovers pick the last option). Returns every text shown. */
    internal fun converse(g: Game, bot: Bot, answers: List<String>): List<String> {
        val queue = ArrayDeque(answers); val seen = ArrayList<String>(); var guard = 0
        while (g.cur != null && guard++ < 300) {
            bot.now += 60; g.tick(bot.now)
            when (val c = g.cur) {
                is Step.Say -> { seen.add(c.text); g.advance() }
                is Step.Ask -> {
                    seen.add(c.text)
                    val want = queue.removeFirstOrNull()
                    val i = if (want == null) c.opts.size - 1 else c.opts.indexOfFirst { it.startsWith(want) }
                    need(i >= 0, "no option starting with '$want' in ${c.opts}")
                    g.advance(if (i < 0) c.opts.size - 1 else i)
                }
                else -> break
            }
        }
        need(g.cur == null, "the conversation did not end")
        return seen
    }

    internal fun newGame(seed: Int): Bot {
        val bot = Bot(0, seed); val g = bot.g
        g.newGame(); bot.settle(); g.chooseStarter(0)
        for (n in NPCS) n.trainer?.let { g.set("t_" + it.id) }
        listOf("lab_intro", "t_kit1", "t_kit2", "t_kit3", "sigil_leaf", "sigil_tide", "sigil_ember", "gate_open", "ending").forEach(g::set)
        g.party.clear(); listOf(PYRESTRIDER, BLOOMFANG, SEEROWL).forEach { g.party.add(Mon(DEX[it], 20)) }; g.box.clear(); g.healAll()
        return bot
    }

    private fun visit(st: Station) {
        val bot = newGame(31 + st.x); val g = bot.g
        bot.goMap(st.map)
        bot.go({ it.m == st.map && abs(it.x - st.x) + abs(it.y - st.y) == 1 }, "beside the station on ${st.map}")
        val dir = when { st.y > g.py -> DOWN; st.y < g.py -> UP; st.x < g.px -> LEFT; else -> RIGHT }
        bot.now += 200; g.step(dir, bot.now); bot.now += 200; g.tick(bot.now)             // face it (the step is blocked by the kiosk)
        val tag = "${st.map} (${st.x},${st.y})"
        need(g.solid(st.x, st.y), "$tag: the station is not solid")

        // leave Bloomfang in the box
        need(g.interact(bot.now), "$tag: OK in front of the station does nothing")
        val seen = converse(g, bot, listOf("Leave one here", "Bloomfang", "Done"))
        need(seen.any { it.startsWith("Your critters are safe here") }, "$tag: no station greeting: $seen")
        need(g.party.map { it.s.name } == listOf("Pyrestrider", "Seerowl") && g.box.map { it.s.name } == listOf("Bloomfang"), "$tag: leaving a critter went wrong: party ${g.party.map { it.s.name }} box ${g.box.map { it.s.name }}")
        need(seen.any { it.contains("was put in the box") }, "$tag: no 'put in the box' message")
        // take it back
        need(g.interact(bot.now), "$tag: second visit failed")
        converse(g, bot, listOf("Take one with me", "Bloomfang", "Done"))
        need(g.party.map { it.s.name } == listOf("Pyrestrider", "Seerowl", "Bloomfang") && g.box.isEmpty(), "$tag: taking a critter went wrong: party ${g.party.map { it.s.name }} box ${g.box.size}")
        // an empty box says so
        g.interact(bot.now); val e = converse(g, bot, listOf("Take one with me", "Done"))
        need(e.any { it.startsWith("No critters are waiting") }, "$tag: empty box not mentioned: $e")
        // the only fighter cannot be left behind
        g.party[0].hp = 0; g.party[1].hp = 0
        g.interact(bot.now); val f = converse(g, bot, listOf("Leave one here", "Bloomfang", "Done"))
        need(f.any { it.contains("only partner who can still fight") } && g.party.size == 3 && g.box.isEmpty(), "$tag: the only fighter was left behind: $f")
        // ... and neither can the only partner
        g.party.removeAll { it.s.name != "Seerowl" }
        g.interact(bot.now); val o = converse(g, bot, listOf("Leave one here", "Done"))
        need(o.any { it.startsWith("You can't leave your only partner") } && g.party.size == 1, "$tag: the only partner was left behind: $o")
        // choose my lead: the script ends and the screen is requested
        g.interact(bot.now); converse(g, bot, listOf("Choose my lead"))
        need(g.openCritters, "$tag: 'Choose my lead' did not request the Critters screen")
        g.openCritters = false
    }

    /** Mom's box runs on the same script: the lines are hers, and it has no lead chooser. */
    private fun mom() {
        val bot = newGame(77); val g = bot.g
        g.play(g.boxHome())
        val seen = converse(g, bot, listOf("Leave one here", "Seerowl", "Done"))
        need(seen.any { it.startsWith("I look after your extra critters") } && seen.any { it.contains("will stay with Mom") }, "Mom's box lines changed: $seen")
        need(g.box.map { it.s.name } == listOf("Seerowl") && g.party.size == 2, "Mom's box: leaving went wrong")
        g.play(g.boxHome()); val s2 = converse(g, bot, emptyList())
        need(s2.size == 2 && s2.last().startsWith("They're happy here"), "Mom's menu should greet, then say goodbye on Done: $s2")
        val c = g.cur; need(c == null, "Mom's script did not end")
        g.play(g.boxHome()); val k = (g.cur as? Step.Ask)?.opts
        need(k != null && "Choose my lead" !in k, "Mom's box offers the lead chooser: $k")
        g.cur?.let { converse(g, bot, emptyList()) }
    }

    /** Every station is drawn (art loaded, no exception) and the lead chooser really opens the screen in the view. */
    private fun draws() {
        val screen = Bitmap.createBitmap(960, 540, Bitmap.Config.ARGB_8888); val canvas = Canvas(screen)
        val view = GameView(Context()); view.onSizeChanged(960, 540, 0, 0)
        fun fld(n: String) = GameView::class.java.getDeclaredField(n).also { it.isAccessible = true }
        fun frame(n: Int = 2) { repeat(n) { SystemClock.fake += 34; view.onDraw(canvas) } }
        val bot = newGame(5); val g = bot.g
        val enter = Game::class.java.getDeclaredMethod("enter", String::class.java, Int::class.javaPrimitiveType, Int::class.javaPrimitiveType, Int::class.javaPrimitiveType)
        enter.isAccessible = true
        fld("game").set(view, g); fld("scene").set(view, 1); fld("pauseSel").set(view, -1)
        for (st in STATIONS) {
            enter.invoke(g, st.map, st.x, st.y + 1, UP); fld("lastMapId").set(view, ""); frame(8)
        }
        g.openCritters = true; frame(3)
        need(fld("critters").getBoolean(view), "the view did not open the Critters screen when asked")
        need(!g.openCritters, "the request was not consumed")
    }
}
