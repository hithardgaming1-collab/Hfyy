package com.example.critterquest

import kotlin.random.Random

/**
 * Harvests every message the battle screen can show (all species pairs, wild and trainer, every move, status, catch, swap...)
 * and checks that GameView's battle text box can show it. The box wraps to a width and shows at most 2 lines, so a
 * longer message is silently cut off. Run:  kotlin -cp <classes> com.example.critterquest.TextFit
 */
object TextFit {
    // logical widths GameView can end up with (lw = screenW / zoom, zoom = screenH / 160): 4:3, 3:2, 16:10, 16:9, 18:9 and wider
    private val WIDTHS = listOf(213, 240, 256, 288, 320, 347)
    private const val MENU_RESERVE = 152f   // GameView: the text box next to the command menu is (w - 122 - 30) wide
    private const val FULL_RESERVE = 34f    // GameView: the full-width text box is (w - 34) wide

    @JvmStatic fun main(args: Array<String>) {
        val rnd = Random(3)
        val msgs = LinkedHashSet<String>()
        val trainers = listOf("Warden Willow", "Disciple Bramble", "Lieutenant Vex", "Baron Gloam", "Guild Grunt", "Swimmer Lyra", "Hiker Brock")
        var battles = 0
        for (a in DEX.indices) for (bIdx in DEX.indices) for (kind in 0..1) {
            val party = listOf(Mon(DEX[a], 30), Mon(DEX[(a + 7) % DEX.size], 30))
            val foe = Mon(DEX[bIdx], 20 + rnd.nextInt(10))
            val tr = if (kind == 0) null else Trainer("t", trainers[(a + bIdx) % trainers.size], rnd.nextBoolean()) { emptyList() }
            val team = if (tr == null) listOf(foe) else listOf(foe, Mon(DEX[(bIdx + 3) % DEX.size], 25))   // the game only starts wild fights with ONE foe
            val b = Battle(party, team, tr, 2, 3, { 0L }, rnd)
            var guard = 0
            while (b.over == 0 && guard++ < 4000) {
                b.pump()
                if (b.text.isNotEmpty()) msgs.add(b.text)
                if (b.learnFor != null) b.answerLearn(rnd.nextInt(5) - 1)
                if (b.menuOn && b.learnFor == null) {
                    if (b.swapping) b.swap(rnd.nextInt(party.size))
                    else when (rnd.nextInt(14)) {
                        0 -> b.use(M_SWAP); 1 -> b.use(M_REST); 2 -> b.use(M_CATCH); 3 -> b.use(M_RUN)
                        else -> { b.use(M_FIGHT); b.fightWith(rnd.nextInt(4)) }
                    }
                }
            }
            battles++
        }
        println("harvested ${msgs.size} distinct battle messages from $battles battles")

        var bad = 0
        for (w in WIDTHS) {
            val fullW = (w - FULL_RESERVE).toInt(); val menuW = (w - MENU_RESERVE).toInt()
            val squeezed = msgs.filter { PixelFont.wrap(it, fullW).size == 3 }
            val cut = msgs.filter { PixelFont.wrap(it, fullW).size > 3 }
            val prompts = DEX.map { "What will ${it.name} do?" }
            val promptSqueezed = prompts.count { PixelFont.wrap(it, menuW).size == 3 }
            val promptCut = prompts.filter { PixelFont.wrap(it, menuW).size > 3 }
            println("width $w: full box ${fullW}px -> ${squeezed.size} messages use 3 lines, ${cut.size} would be cut; menu box ${menuW}px -> $promptSqueezed/${DEX.size} prompts use 3 lines, ${promptCut.size} would be cut")
            (cut + promptCut).take(4).forEach { println("    CUT: $it") }
            bad += cut.size + promptCut.size
        }
        // the 3-line layout must fit the 44px box: first line at 6, pitch 11, glyphs 9 rows tall
        val f = Ui.fitText("one two three four five six seven eight nine ten eleven twelve", 40)
        check(f.lines.size == 3 && f.top + 2 * f.pitch + 9f <= 42f) { "3-line layout does not fit the box" }
        check(f.lines.last().endsWith("...")) { "over-long text must end in an ellipsis" }
        // an unbreakable word wider than the box would overflow it sideways instead of wrapping
        val widest = msgs.flatMap { it.split(' ') }.maxByOrNull { PixelFont.width(it) }!!
        println("widest single word: '$widest' = ${PixelFont.width(widest)}px")
        println(if (bad == 0) "text fit: ok" else "text fit: $bad problems")
    }
}
