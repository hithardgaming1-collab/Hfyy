// Frames of the Critter Orb throw, drawn by the REAL GameView / Battle with the stand-in Android classes.
//   ./run.sh throw                ->  docs/shots/27..31_throw_*.png  (in the air, the hit, a wobble, caught, bursting open)
//   ./run.sh throw - 1280 960     ->  the same at another screen size (4:3 here); a "-" instead of a folder means no small pictures
//   ./run.sh throw some/folder    ->  the same, and also a small picture every ~50 ms of one catch and one near miss in some/folder/caught and
//                                     some/folder/broke (turn those into a GIF with any tool you like)
package com.example.critterquest

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.SystemClock
import android.view.KeyEvent
import java.awt.RenderingHints
import java.awt.image.BufferedImage
import java.io.File
import javax.imageio.ImageIO
import kotlin.random.Random

object ThrowShot {
    private var SW = 1920; private var SH = 1080
    private lateinit var view: GameView
    private lateinit var screen: Bitmap
    private lateinit var canvas: Canvas
    private lateinit var out: File
    private var gifDir: File? = null; private var gifN = 0; private var gifT = 0L

    private fun fld(name: String) = GameView::class.java.getDeclaredField(name).also { it.isAccessible = true }
    @Suppress("UNCHECKED_CAST") private fun <T> get(name: String): T = fld(name).get(view) as T
    private fun set(name: String, v: Any?) = fld(name).set(view, v)
    private fun battle(): Battle? = get("battle")

    /** Advance the clock by [ms], draw a frame, and keep a small copy about every 50 ms when a GIF folder is set. */
    private fun step(ms: Long, n: Int = 1) {
        repeat(n) {
            SystemClock.fake += ms; view.onDraw(canvas)
            val d = gifDir
            if (d != null && SystemClock.fake - gifT >= 50) { gifT = SystemClock.fake; small(File(d, "f%03d.png".format(gifN++))) }
        }
    }
    private fun small(f: File) {
        val o = BufferedImage(SW / 3, SH / 3, BufferedImage.TYPE_INT_RGB)
        val g = o.createGraphics(); g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR)
        g.drawImage(screen.img, 0, 0, SW / 3, SH / 3, null); g.dispose(); ImageIO.write(o, "png", f)
    }
    private fun snap(name: String) { ImageIO.write(screen.img, "png", File(out, "$name.png")); println("  $name") }
    private fun press(code: Int) {
        view.onKeyDown(code, KeyEvent(code, KeyEvent.ACTION_DOWN)); step(60)
        view.onKeyUp(code, KeyEvent(code, KeyEvent.ACTION_UP)); step(34)
    }

    private fun enter(g: Game, map: String, x: Int, y: Int, face: Int = DOWN) {
        val m = Game::class.java.getDeclaredMethod("enter", String::class.java, Int::class.javaPrimitiveType, Int::class.javaPrimitiveType, Int::class.javaPrimitiveType)
        m.isAccessible = true; m.invoke(g, map, x, y, face)
        g.px = x; g.py = y; g.fromX = x; g.fromY = y
    }
    private fun world(g: Game) {
        g.saveHook = null
        set("game", g); set("scene", 1); set("lastMapId", ""); set("pauseSel", -1)
        step(34, 6); var guard = 0; while (g.cur != null && guard++ < 40) { press(KeyEvent.KEYCODE_DPAD_CENTER); step(34, 3) }
        step(34, 30)
    }

    /** One whole catch attempt against a sleeping, nearly beaten Fluffnap; [shakes] picks how many times the orb wobbles (4 = caught). */
    private fun scenario(shakes: Int, snaps: List<Triple<Int, Long, String>>, gif: File?) {
        view = GameView(Context()); view.onSizeChanged(SW, SH, 0, 0)
        val g = Game(); g.newGame(); g.chooseStarter(0); g.party.clear(); g.addToParty(PYRESTRIDER, 30)
        listOf("starter", "labDone").forEach(g::set); g.coins = 340; g.orbs = 8
        enter(g, "route1", 14, 7, UP); world(g)
        val foe = Mon(DEX[FLUFFNAP], 12).also { it.hp = 1; it.status = St.SLP }
        var seed = 0; while (Rules.catchShakes(foe, Random(seed)) != shakes) seed++          // a seed that gives exactly this many wobbles
        g.battleReq = BattleReq(null, foe); step(34, 4)
        val old: Battle = battle()!!
        set("battle", Battle(old.party, old.team, old.trainer, old.heals, old.orbs, { SystemClock.uptimeMillis() }, Random(seed)))
        for (i in 0 until 80) { step(33); if (battle()!!.menuOn) break }
        gif?.let { it.deleteRecursively(); it.mkdirs(); gifDir = it; gifN = 0; gifT = SystemClock.fake - 50 }
        step(33, 6)
        press(KeyEvent.KEYCODE_DPAD_DOWN); press(KeyEvent.KEYCODE_DPAD_RIGHT); step(33, 8)    // the cursor goes to Catch
        press(KeyEvent.KEYCODE_DPAD_CENTER)
        val done = BooleanArray(snaps.size); var guard = 0
        while (guard++ < 600) {
            step(17)
            val b = battle() ?: break
            if (b.orbStage == ORB_BREAK && SystemClock.fake - b.orbT0 > 1300) break
            for ((i, s) in snaps.withIndex()) if (!done[i] && b.orbStage == s.first && SystemClock.fake - b.orbT0 >= s.second) { done[i] = true; snap(s.third) }
        }
        step(33, 12); gifDir = null
    }

    @JvmStatic fun main(args: Array<String>) {
        System.setProperty("java.awt.headless", "true")
        out = File(args.getOrNull(0) ?: "../../docs/shots"); out.mkdirs()
        val gifs = args.getOrNull(1)?.takeIf { it != "-" }?.let { File(it) }
        SW = args.getOrNull(2)?.toInt() ?: 1920; SH = args.getOrNull(3)?.toInt() ?: 1080
        screen = Bitmap.createBitmap(SW, SH, Bitmap.Config.ARGB_8888); canvas = Canvas(screen)
        println("throw:")
        scenario(4, listOf(Triple(ORB_THROW, 330L, "27_throw_fly"), Triple(ORB_THROW, 600L, "28_throw_hit"), Triple(ORB_WOBBLE, 270L, "29_throw_wobble"), Triple(ORB_CAUGHT, 760L, "30_throw_caught")), gifs?.let { File(it, "caught") })
        scenario(2, listOf(Triple(ORB_BREAK, 200L, "31_throw_break")), gifs?.let { File(it, "broke") })
        println("done: $out")
    }
}
