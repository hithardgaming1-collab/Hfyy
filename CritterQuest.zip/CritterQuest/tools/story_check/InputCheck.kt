package com.example.critterquest

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.SystemClock
import android.view.KeyEvent

/**
 * Checks the remote-control run lock on the real GameView: key 5 (or numpad 5) switches running on and it STAYS on
 * until 5 is pressed again; holding the key does not flip it back and forth; the old hold-to-run keys still work;
 * and a locked run really makes steps quick (RUN_MS instead of MOVE_MS).
 */
object InputCheck {
    private var bad = 0
    private fun need(c: Boolean, m: String) { if (!c) { println("  INPUT CHECK FAILED: $m"); bad++ } }

    fun run(): Int {
        bad = 0
        val screen = Bitmap.createBitmap(960, 540, Bitmap.Config.ARGB_8888); val canvas = Canvas(screen)
        val view = GameView(Context()); view.onSizeChanged(960, 540, 0, 0)
        fun fld(n: String) = GameView::class.java.getDeclaredField(n).also { it.isAccessible = true }
        fun frame(n: Int = 2) { repeat(n) { SystemClock.fake += 34; view.onDraw(canvas) } }
        val g = Game(); g.newGame(); g.chooseStarter(0); g.saveHook = null; g.set("starter"); g.set("labDone")
        val enter = Game::class.java.getDeclaredMethod("enter", String::class.java, Int::class.javaPrimitiveType, Int::class.javaPrimitiveType, Int::class.javaPrimitiveType)
        enter.isAccessible = true; enter.invoke(g, "route1", 14, 7, RIGHT)
        fld("game").set(view, g); fld("scene").set(view, 1); fld("lastMapId").set(view, ""); fld("pauseSel").set(view, -1)
        frame(40)
        var guard = 0; while (g.cur != null && guard++ < 50) { g.advance(); frame(2) }   // the opening dialogue
        fun down(k: Int, repeat: Int = 0) = view.onKeyDown(k, KeyEvent(k, KeyEvent.ACTION_DOWN, repeat))
        fun up(k: Int) = view.onKeyUp(k, KeyEvent(k, KeyEvent.ACTION_UP, 0))
        fun tap(k: Int): Boolean { val a = down(k); val b = up(k); frame(); return a && b }

        need(!g.wantRun, "running is on before any key was pressed")
        need(tap(KeyEvent.KEYCODE_5), "key 5 was not consumed")
        need(g.wantRun, "key 5 did not switch running on")
        frame(30); need(g.wantRun, "the run lock did not stay on")
        down(KeyEvent.KEYCODE_5, 1); down(KeyEvent.KEYCODE_5, 2); down(KeyEvent.KEYCODE_5, 3); up(KeyEvent.KEYCODE_5); frame()
        need(g.wantRun, "holding key 5 (key repeat) flipped the lock")
        // locked running is quick
        run {
            val t0 = SystemClock.fake + 1000; g.tick(t0)
            val ok = g.step(RIGHT, t0)
            need(ok && g.stepMs == RUN_MS, "a locked-run step took ${g.stepMs} ms (want $RUN_MS)")
            g.tick(t0 + 400)
        }
        need(tap(KeyEvent.KEYCODE_5) && !g.wantRun, "pressing 5 again did not turn running off")
        run {
            val t0 = SystemClock.fake + 3000; g.tick(t0)
            val ok = g.step(LEFT, t0)
            need(ok && g.stepMs == MOVE_MS, "an unlocked step took ${g.stepMs} ms (want $MOVE_MS)")
            g.tick(t0 + 400)
        }
        need(tap(KeyEvent.KEYCODE_NUMPAD_5) && g.wantRun, "numpad 5 did not switch running on")
        // hold-to-run keys must not cancel the lock
        down(KeyEvent.KEYCODE_X); frame(); up(KeyEvent.KEYCODE_X); frame()
        need(g.wantRun, "releasing the hold-to-run key cancelled the lock")
        tap(KeyEvent.KEYCODE_NUMPAD_5); need(!g.wantRun, "numpad 5 did not turn running off")
        // ... and still work on their own
        down(KeyEvent.KEYCODE_X); frame(); need(g.wantRun, "holding X no longer runs"); up(KeyEvent.KEYCODE_X); frame(); need(!g.wantRun, "releasing X did not stop running")
        // key 5 is harmless in every other scene (battle, pause menu, title)
        fld("scene").set(view, 0); need(tap(KeyEvent.KEYCODE_5), "key 5 not consumed on the title screen"); tap(KeyEvent.KEYCODE_5)
        fld("scene").set(view, 2); need(down(KeyEvent.KEYCODE_5) && up(KeyEvent.KEYCODE_5), "key 5 not consumed in a battle"); down(KeyEvent.KEYCODE_5); up(KeyEvent.KEYCODE_5)   // no frames: there is no battle to draw
        fld("scene").set(view, 1)
        println(if (bad == 0) "input check: ok (key 5 locks running on and off, key repeat ignored, hold-to-run still works)" else "input check: $bad problems")
        return bad
    }
}
