package com.example.critterquest

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.SystemClock
import android.view.KeyEvent
import kotlin.random.Random

/**
 * Checks the Critters menu (pause menu -> Critters): any critter you own, in the party or at Mom's, can become the lead.
 * Rules: reordering keeps everybody; a boxed critter joins the front, or swaps with the lead when the party is full; nobody is
 * healed by it; it is refused if nobody left in the party could fight; the order survives a save. Then a bot opens the real
 * screen with the keys of a remote, makes a boxed critter the lead, and draws the screen at wide and narrow sizes.
 */
object CrittersCheck {
    private var bad = 0
    private fun need(c: Boolean, m: String) { if (!c) { println("  CRITTERS CHECK FAILED: $m"); bad++ } }

    private fun mon(i: Int, lvl: Int = 10 + i) = Mon(DEX[i % DEX.size], lvl)

    fun run(): Int {
        bad = 0
        rules()
        screen()
        println(if (bad == 0) "critters check: ok (any critter can be made the lead from the pause menu)" else "critters check: $bad problems")
        return bad
    }

    private fun game(party: Int, box: Int): Game {
        val g = Game(Random(1)); g.newGame(); g.chooseStarter(0)
        g.party.clear(); g.box.clear()
        repeat(party) { g.party.add(mon(it)) }
        repeat(box) { g.box.add(mon(20 + it)) }
        return g
    }

    private fun rules() {
        // 1. a party critter moves to the front, nobody is lost
        run {
            val g = game(4, 0); val a = g.party.toList()
            need(g.makeLead(2), "makeLead(2) refused")
            need(g.party.size == 4 && g.party[0] === a[2] && g.party.drop(1) == listOf(a[0], a[1], a[3]), "party order is wrong after makeLead(2): ${g.party.map { it.s.name }}")
            need(!g.makeLead(0) && g.leadProblem(0)!!.contains("already"), "the lead cannot be made the lead again")
            need(!g.makeLead(9) && g.leadProblem(-1) != null, "an index that does not exist was accepted")
        }
        // 2. a boxed critter joins the front when the party has room
        run {
            val g = game(3, 3); val boxed = g.box[1]; val before = g.party.toList()
            need(g.makeLead(3 + 1), "makeLead of a boxed critter refused")
            need(g.party.size == 4 && g.party[0] === boxed && g.party.drop(1) == before && g.box.size == 2 && boxed !in g.box, "boxed critter did not join the front of the party")
        }
        // 3. full party: the lead and the boxed critter trade places, nobody is healed
        run {
            val g = game(MAX_PARTY, 3); val oldLead = g.party[0]; val boxed = g.box[2]
            oldLead.hp = 1; boxed.hp = boxed.maxHp
            val rest = g.party.drop(1)
            need(g.makeLead(MAX_PARTY + 2), "swap refused")
            need(g.party.size == MAX_PARTY && g.party[0] === boxed && g.party.drop(1) == rest, "party wrong after the swap")
            need(g.box.size == 3 && g.box[2] === oldLead, "the old lead did not take the box critter's place")
            need(oldLead.hp == 1, "the swap healed the old lead (hp=${oldLead.hp}): that would be a free heal anywhere")
        }
        // 4. refused when nobody else could fight; allowed when somebody could
        run {
            val g = game(MAX_PARTY, 1)
            g.party.drop(1).forEach { it.hp = 0 }; g.box[0].hp = 0
            need(g.leadProblem(MAX_PARTY) != null, "swapping in a fainted critter with an all-fainted party was allowed")
            val snapshot = g.party.toList(); need(!g.makeLead(MAX_PARTY) && g.party == snapshot && g.box.size == 1, "a refused swap changed something")
            g.party[3].hp = 5
            need(g.leadProblem(MAX_PARTY) == null && g.makeLead(MAX_PARTY), "swap refused although a party critter could still fight")
        }
        // 5. the order survives a save and load
        run {
            val g = game(5, 4); g.makeLead(3); g.makeLead(6)
            val names = g.allCritters.map { it.s.name + it.lvl }
            val g2 = Game(Random(2)); need(g2.load(g.serialize()), "save does not load")
            need(g2.allCritters.map { it.s.name + it.lvl } == names, "the lead order was lost by save/load: ${g2.allCritters.map { it.s.name }} vs ${g.allCritters.map { it.s.name }}")
        }
        // 6. random use: everybody stays owned exactly once, the party never grows past 6 or loses all its fighters
        run {
            val rnd = Random(9)
            repeat(300) {
                val g = game(rnd.nextInt(1, MAX_PARTY + 1), rnd.nextInt(0, 12))
                g.allCritters.forEach { if (rnd.nextInt(4) == 0) it.hp = 0 }
                if (g.party.none { it.hp > 0 }) g.party[0].hp = 1
                val owned = g.allCritters.toSet(); val n = g.allCritters.size
                repeat(25) {
                    g.makeLead(rnd.nextInt(-1, n + 1))
                    need(g.allCritters.size == n && g.allCritters.toSet() == owned, "a critter was lost or duplicated")
                    need(g.party.size in 1..MAX_PARTY && g.party.any { it.hp > 0 }, "party size ${g.party.size} / nobody can fight")
                }
            }
        }
    }

    private fun screen() {
        for ((sw, sh) in listOf(960 to 540, 1280 to 960)) {   // wide (details panel) and 4:3 narrow (list only)
            val screen = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888); val canvas = Canvas(screen)
            val view = GameView(Context()); view.onSizeChanged(sw, sh, 0, 0)
            fun fld(n: String) = GameView::class.java.getDeclaredField(n).also { it.isAccessible = true }
            fun frame(n: Int = 2) { repeat(n) { SystemClock.fake += 34; view.onDraw(canvas) } }
            val g = game(MAX_PARTY, 14)
            g.party.forEachIndexed { i, m -> if (i == 2) m.hp = 0 }
            g.saveHook = null; g.set("starter"); g.set("labDone")
            val enter = Game::class.java.getDeclaredMethod("enter", String::class.java, Int::class.javaPrimitiveType, Int::class.javaPrimitiveType, Int::class.javaPrimitiveType)
            enter.isAccessible = true; enter.invoke(g, "route1", 14, 7, RIGHT)
            fld("game").set(view, g); fld("scene").set(view, 1); fld("lastMapId").set(view, ""); fld("pauseSel").set(view, -1)
            frame(40)
            var guard = 0; while (g.cur != null && guard++ < 50) { g.advance(); frame(2) }
            fun key(k: Int) { view.onKeyDown(k, KeyEvent(k, KeyEvent.ACTION_DOWN, 0)); view.onKeyUp(k, KeyEvent(k, KeyEvent.ACTION_UP, 0)); frame() }
            val tag = "${sw}x$sh"
            fun open(): Boolean = fld("critters").getBoolean(view)
            fun sel(): Int = fld("crSel").getInt(view)
            fun pause(): Int = fld("pauseSel").getInt(view)

            key(KeyEvent.KEYCODE_BACK); need(pause() == 0, "$tag: BACK did not open the pause menu")
            key(KeyEvent.KEYCODE_DPAD_UP); need(pause() == 4, "$tag: the pause menu does not wrap to its 5th item (got ${pause()})")
            key(KeyEvent.KEYCODE_DPAD_DOWN); key(KeyEvent.KEYCODE_DPAD_DOWN); key(KeyEvent.KEYCODE_DPAD_DOWN); need(pause() == 2, "$tag: cannot reach 'Critters' in the pause menu (got ${pause()})")
            key(KeyEvent.KEYCODE_DPAD_CENTER); need(open() && pause() == -1, "$tag: OK on Critters did not open the screen")
            frame(5)
            // walk the whole list: the cursor wraps, scrolling keeps it on screen, drawing never fails
            val n = g.allCritters.size
            repeat(n + 3) { key(KeyEvent.KEYCODE_DPAD_DOWN) }
            need(sel() == 3 % n, "$tag: cursor did not wrap (at ${sel()})")
            key(KeyEvent.KEYCODE_DPAD_UP); key(KeyEvent.KEYCODE_DPAD_UP); key(KeyEvent.KEYCODE_DPAD_UP); key(KeyEvent.KEYCODE_DPAD_UP); need(sel() == n - 1, "$tag: cursor did not wrap upwards (at ${sel()})")
            key(KeyEvent.KEYCODE_DPAD_RIGHT); key(KeyEvent.KEYCODE_DPAD_LEFT)
            // pick a boxed critter (the party is full, so it swaps with the lead)
            val oldLead = g.party[0]; val target = g.allCritters[MAX_PARTY + 4]
            while (sel() != MAX_PARTY + 4) key(KeyEvent.KEYCODE_DPAD_UP)
            key(KeyEvent.KEYCODE_DPAD_CENTER)                                  // the question
            frame(3)
            key(KeyEvent.KEYCODE_DPAD_DOWN); key(KeyEvent.KEYCODE_DPAD_UP)     // moving between the answers must not do anything
            need(g.party[0] === oldLead, "$tag: the lead changed before the question was answered")
            key(KeyEvent.KEYCODE_DPAD_CENTER)                                  // answer: do it
            need(g.party[0] === target && g.box.contains(oldLead) && g.party.size == MAX_PARTY, "$tag: the boxed critter did not become the lead")
            need(sel() == 0, "$tag: the cursor did not jump to the new lead")
            frame(5)
            // pick a party critter, then cancel: nothing changes
            key(KeyEvent.KEYCODE_DPAD_DOWN); val second = g.party[1]; key(KeyEvent.KEYCODE_DPAD_CENTER); key(KeyEvent.KEYCODE_BACK)
            need(g.party[0] === target && g.party[1] === second, "$tag: cancelling changed the party")
            // the lead itself cannot be picked again; a fainted critter can still be made the lead
            key(KeyEvent.KEYCODE_DPAD_UP); key(KeyEvent.KEYCODE_DPAD_CENTER); frame(3)
            key(KeyEvent.KEYCODE_BACK); need(!open(), "$tag: BACK did not close the screen")
            // and the normal game carries on: walking works
            val t0 = SystemClock.fake + 1000; g.tick(t0); need(g.step(LEFT, t0) || g.step(RIGHT, t0), "$tag: cannot walk after closing the menu")
        }
    }
}
