// Screenshot of the REAL battle menu at any screen size, to check the layout on 4:3 tablets, small phones, TVs...
//   (run it from tools/story_check: the stand-in Android finds the sprites by relative path)
//   kotlin -cp <classes> com.example.critterquest.BattleShot out.png [width height species level status foe foeLevel]
package com.example.critterquest

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.SystemClock
import java.io.File
import javax.imageio.ImageIO

object BattleShot {
    @JvmStatic fun main(args: Array<String>) {
        System.setProperty("java.awt.headless", "true")
        val out = File(args.getOrNull(0) ?: "battle.png")
        val sw = args.getOrNull(1)?.toInt() ?: 1280; val sh = args.getOrNull(2)?.toInt() ?: 960
        val lead = DEX.indexOfFirst { it.name.equals(args.getOrNull(3) ?: "Glimmerwing", true) }.also { check(it >= 0) { "unknown species" } }
        val screen = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888); val canvas = Canvas(screen)
        val view = GameView(Context()); view.onSizeChanged(sw, sh, 0, 0)
        fun fld(n: String) = GameView::class.java.getDeclaredField(n).also { it.isAccessible = true }
        fun frame(n: Int) { repeat(n) { SystemClock.fake += 34; view.onDraw(canvas) } }
        val g = Game(); g.newGame(); g.chooseStarter(0)
        val lvl = args.getOrNull(4)?.toInt() ?: 12
        g.party.clear(); g.party.add(Mon(DEX[lead], lvl).also { m -> args.getOrNull(5)?.takeIf { it.isNotBlank() }?.let { t -> m.status = St.values().first { it.tag.equals(t, true) } } })
        g.saveHook = null; g.set("starter"); g.set("labDone")
        val enter = Game::class.java.getDeclaredMethod("enter", String::class.java, Int::class.javaPrimitiveType, Int::class.javaPrimitiveType, Int::class.javaPrimitiveType)
        enter.isAccessible = true; enter.invoke(g, "route1", 14, 7, RIGHT); g.px = 14; g.py = 7; g.fromX = 14; g.fromY = 7
        fld("game").set(view, g); fld("scene").set(view, 1); fld("lastMapId").set(view, ""); fld("pauseSel").set(view, -1)
        frame(40)
        val foeIdx = args.getOrNull(6)?.let { n -> DEX.indexOfFirst { it.name.equals(n, true) } } ?: NIBBLET
        g.battleReq = BattleReq(null, Mon(DEX[foeIdx], args.getOrNull(7)?.toInt() ?: 4)); frame(44)
        for (i in 0 until 60) { frame(30); val b = fld("battle").get(view) as Battle?; if (b == null || b.menuOn) break }
        frame(30)
        ImageIO.write(screen.img, "png", out)
        val lw = sw / maxOf(1, sh / 160)
        println("wrote $out  (${sw}x$sh, zoom ${maxOf(1, sh / 160)}, logical width $lw, lead ${DEX[lead].name})")
    }
}
