package com.example.critterquest

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.SystemClock
import android.view.KeyEvent
import android.view.MotionEvent
import kotlin.random.Random

/**
 * Plays the REAL GameView like a very bored person: random d-pad / OK / BACK / run presses and random screen taps,
 * with extra battles forced in with odd parties and KJPW wrestling matches forced in (the match screen). After every action it checks that the game is still sane.
 *   args: <seeds> <actionsPerSeed> [width height]
 */
object UiFuzz {
    class Fail(msg: String) : Exception(msg)

    private lateinit var view: GameView
    private lateinit var screen: Bitmap
    private lateinit var canvas: Canvas
    private var W = 960; private var H = 540
    private val log = ArrayDeque<String>()
    val cov = java.util.TreeMap<String, Int>()
    private fun hit(k: String) { cov[k] = (cov[k] ?: 0) + 1 }
    private var prevScene = -1; private var prevOver = 0
    private val speciesAtStart = HashMap<Mon, Int>()

    private fun fld(name: String) = GameView::class.java.getDeclaredField(name).also { it.isAccessible = true }
    @Suppress("UNCHECKED_CAST") private fun <T> get(name: String): T = fld(name).get(view) as T
    private fun set(name: String, v: Any?) = fld(name).set(view, v)

    private fun note(s: String) { log.addLast(s); if (log.size > 40) log.removeFirst() }
    private fun frame(ms: Long = 34, n: Int = 1) { repeat(n) { SystemClock.fake += ms; view.onDraw(canvas) } }

    private val KEYS = intArrayOf(
        KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT,
        KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_BACK)
    private val KEYNAME = mapOf(19 to "UP", 20 to "DOWN", 21 to "LEFT", 22 to "RIGHT", 23 to "OK", 4 to "BACK", 52 to "RUN")

    private fun press(code: Int, holdMs: Long) {
        note("key ${KEYNAME[code] ?: code} hold=$holdMs")
        view.onKeyDown(code, KeyEvent(code, KeyEvent.ACTION_DOWN)); frame(34, 1)
        frame(holdMs.coerceAtLeast(34), 1)
        view.onKeyUp(code, KeyEvent(code, KeyEvent.ACTION_UP)); frame(34, 1)
    }

    private fun tap(x: Float, y: Float) {
        note("tap ${x.toInt()},${y.toInt()}")
        view.onTouchEvent(MotionEvent(MotionEvent.ACTION_DOWN, x, y)); frame(34, 1)
        view.onTouchEvent(MotionEvent(MotionEvent.ACTION_UP, x, y)); frame(34, 1)
    }

    private fun scene(): Int = get("scene")
    private fun game(): Game = get("game")
    private fun battle(): Battle? = get("battle")

    // ---------------- invariants ----------------
    private fun fail(msg: String): Nothing = throw Fail(msg)

    private fun checkMon(m: Mon, where: String) {
        if (m.lvl !in 1..MAX_LVL) fail("$where: ${m.s.name} level ${m.lvl} out of range")
        if (m.hp !in 0..m.maxHp) fail("$where: ${m.s.name} hp ${m.hp}/${m.maxHp} out of range")
        if (m.moves.size !in 1..4) fail("$where: ${m.s.name} has ${m.moves.size} moves")
        if (m.moves.map { it.move }.toSet().size != m.moves.size) fail("$where: ${m.s.name} knows a move twice: ${m.moves.map { it.move.name }}")
        for (s in m.moves) if (s.pp !in 0..s.move.pp) fail("$where: ${m.s.name} ${s.move.name} pp ${s.pp}/${s.move.pp}")
        if (m.xp < 0) fail("$where: ${m.s.name} negative xp ${m.xp}")
        if (m.lvl < MAX_LVL && m.xp >= Rules.xpNeed(m.lvl)) fail("$where: ${m.s.name} L${m.lvl} holds ${m.xp} xp, enough for the next level")
    }

    private fun check() {
        val g = game()
        if (g.party.size !in 1..MAX_PARTY) fail("party size ${g.party.size}")
        for (m in g.party) checkMon(m, "party")
        for (m in g.box) checkMon(m, "box")
        if (g.heals !in 0..MAX_HEALS) fail("heals ${g.heals}")
        if (g.orbs !in 0..MAX_ORBS) fail("orbs ${g.orbs}")
        when (scene()) {
            1 -> {
                if (g.px !in 0 until g.map.w || g.py !in 0 until g.map.h) fail("player off the map ${g.map.id} ${g.px},${g.py}")
                val t = g.map.tile(g.px, g.py)
                if (t.solid && !(t == Tl.GATE && g.f("gate_open"))) fail("player standing inside solid $t at ${g.map.id} ${g.px},${g.py}")
                if (g.npcAt(g.px, g.py) != null) fail("player and ${g.npcAt(g.px, g.py)!!.id} share a tile at ${g.map.id} ${g.px},${g.py}")
            }
            4 -> {
                val m: MatchView = get("match") ?: fail("scene is MATCH but match is null")
                if (m.speed !in intArrayOf(1, 2, 4)) fail("match speed ${m.speed}")
                if (g.matchReq == null) fail("the match screen is up but the game asked for no match")
            }
            2 -> {
                val b = battle() ?: fail("scene is BATTLE but battle is null")
                if (b.cur !in b.party.indices) fail("battle cur ${b.cur}")
                if (b.menu !in 0 until b.items) fail("battle menu ${b.menu} of ${b.items}")
                if (b.fighting && b.moveSel !in b.me.moves.indices) fail("moveSel ${b.moveSel} of ${b.me.moves.size}")
                if (b.swapping && b.swapSel !in b.party.indices) fail("swapSel ${b.swapSel}")
                if (b.swapping && b.party[b.swapSel].hp <= 0 && b.party.any { it.hp > 0 }) fail("swap cursor on a fainted critter")
                if (b.learnFor != null && b.learnSel !in 0..4) fail("learnSel ${b.learnSel}")
                if (b.menuOn && !b.swapping && b.over == 0 && b.me.hp <= 0) fail("menu open while the critter that is out has fainted")
                if (b.idx !in b.team.indices) fail("foe idx ${b.idx}")
                for (m in b.party) checkMon(m, "battle party")
            }
        }
    }

    // ---------------- forced oddities ----------------
    private fun randomMon(rnd: Random, lo: Int = 1, hi: Int = MAX_LVL): Mon {
        val m = Mon(DEX[rnd.nextInt(DEX.size)], lo + rnd.nextInt(hi - lo + 1))
        return m
    }

    private fun shufflePartyAndForceBattle(rnd: Random) {
        val g = game()
        if (g.cur != null || g.battleReq != null || scene() != 1) return
        // odd party: 1..6 critters, some hurt / fainted (at least one alive), some out of PP, some one kill from a level-up
        val size = 1 + rnd.nextInt(MAX_PARTY)
        g.party.clear()
        repeat(size) {
            val m = randomMon(rnd, 3, 29)
            if (rnd.nextInt(3) == 0) m.moves.forEach { it.pp = rnd.nextInt(2) }
            if (rnd.nextInt(3) == 0) m.hp = 1 + rnd.nextInt(m.maxHp)
            if (rnd.nextInt(2) == 0) m.xp = Rules.xpNeed(m.lvl) - 1 - rnd.nextInt(3)
            g.party.add(m)
        }
        for (i in 1 until g.party.size) if (rnd.nextInt(4) == 0) g.party[i].hp = 0
        if (g.party.none { it.hp > 0 }) g.party[0].hp = 1
        g.dexCaught.addAll(g.party.map { DEX.indexOf(it.s) })
        g.heals = rnd.nextInt(MAX_HEALS + 1); g.orbs = rnd.nextInt(MAX_ORBS + 1)
        if (rnd.nextBoolean()) {
            val w = randomMon(rnd, 1, 12); if (rnd.nextBoolean()) w.hp = 1
            g.battleReq = BattleReq(null, w); note("FORCED wild ${w.s.name} L${w.lvl}, party ${g.party.joinToString { it.s.name + it.lvl + "/" + it.hp }}")
        } else {
            val n = 1 + rnd.nextInt(3); val team = List(n) { DEX.indexOf(randomMon(rnd).s) to (1 + rnd.nextInt(10)) }
            val tr = Trainer("fz${rnd.nextInt(99)}", "Fuzzer", rnd.nextBoolean()) { team }
            g.battleReq = BattleReq(tr, null); note("FORCED trainer team $team, party ${g.party.joinToString { it.s.name + it.lvl + "/" + it.hp }}")
        }
    }

    /** A KJPW bout from nowhere, between two random wrestlers: the match screen must take every button and tap, and always let us out. */
    private fun forceMatch(rnd: Random) {
        val g = game()
        if (g.cur != null || g.battleReq != null || g.matchReq != null || scene() != 1) return
        val a = ROSTER[rnd.nextInt(ROSTER.size)]; var b = ROSTER[rnd.nextInt(ROSTER.size)]; while (b === a) b = ROSTER[rnd.nextInt(ROSTER.size)]
        g.matchReq = MatchReq(a.id, b.id, rnd.nextInt(1 shl 30)); note("FORCED match ${a.id} v ${b.id}")
    }

    // ---------------- one run ----------------
    private fun run(seed: Int, actions: Int): Boolean {
        val rnd = Random(seed)
        log.clear()
        view = GameView(Context())
        screen = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888); canvas = Canvas(screen)
        view.onSizeChanged(W, H, 0, 0)
        frame(34, 5)
        press(KeyEvent.KEYCODE_DPAD_CENTER, 60)           // New Game
        var lastSig = ""; var sameFor = 0
        try {
            for (i in 0 until actions) {
                val r = rnd.nextInt(100)
                when {
                    r < 62 -> press(KEYS[rnd.nextInt(KEYS.size)], listOf(34L, 60L, 200L, 600L)[rnd.nextInt(4)])
                    r < 70 -> press(KeyEvent.KEYCODE_X, 400)
                    r < 80 -> tap(rnd.nextFloat() * W, rnd.nextFloat() * H)
                    r < 83 -> shufflePartyAndForceBattle(rnd)
                    r < 85 -> forceMatch(rnd)
                    else -> frame(34, 1 + rnd.nextInt(40))
                }
                frame(34, 1 + rnd.nextInt(6))
                check()
                run {
                    val sc = scene(); val bb = battle()
                    hit("frames-in-scene-$sc")
                    if (sc != prevScene) { hit("enter-scene-$sc"); prevScene = sc }
                    if (sc == 2 && bb != null) {
                        if (bb.swapping) hit("battle:swap-list-open")
                        if (bb.swapping && bb.me.hp <= 0) hit("battle:forced-swap")
                        if (bb.fighting) hit("battle:move-list-open")
                        if (bb.learnFor != null) hit("battle:learn-prompt")
                        if (bb.over != 0) hit("battle:over-${bb.over}")
                        if (bb.trainer != null) hit("battle:trainer") else hit("battle:wild")
                        if (bb.party.size == 6) hit("battle:party-of-6")
                        if (bb.me.moves.none { it.pp > 0 }) hit("battle:out-of-pp")
                        for (m in bb.party) { val d = DEX.indexOf(m.s); val st = speciesAtStart.getOrPut(m) { d }; if (st != d) { hit("battle:EVOLVED"); speciesAtStart[m] = d } }
                    }
                    if (sc == 1 && game().cur != null) hit("world:dialogue-open")
                    if (sc == 4) hit(if (get<MatchView?>("match")?.finished == true) "match:finished" else "match:running")
                }
                // watchdog: a battle that never shows its menu again while we only wait
                val b = battle()
                if (scene() == 2 && b != null) {
                    val sig = "${b.text}|${b.menuOn}|${b.swapping}|${b.fighting}|${b.learnFor != null}|${b.over}|${b.party.sumOf { it.hp }}|${b.team.sumOf { it.hp }}"
                    if (sig == lastSig) sameFor++ else { sameFor = 0; lastSig = sig }
                    if (sameFor == 0) { /* progressing */ }
                }
            }
            // after the random part: leave every battle by waiting (no keys) and make sure it finishes or shows a menu
            for (k in 0 until 4000) {
                val b = battle(); if (scene() != 2 || b == null) break
                if (b.menuOn || b.learnFor != null) break
                frame(34, 1)
            }
            // a match must always be skippable: OK until it is over, then OK to leave
            if (scene() == 4) { var k = 0; while (scene() == 4 && k++ < 1500) { press(KeyEvent.KEYCODE_DPAD_CENTER, 34); frame(34, 4) }
                if (scene() == 4) fail("the match screen never let us out after 1500 presses of OK") }
            if (scene() != 4 && game().matchReq != null && battle() == null && scene() == 1 && game().cur == null) { frame(34, 3); if (game().matchReq != null && scene() == 1) fail("a match was asked for but the screen never showed it") }
            val b = battle()
            if (scene() == 2 && b != null && !b.menuOn && b.learnFor == null && b.over == 0) fail("battle stuck: no menu after 4000 idle frames, text='${b.text}'")
            if (scene() == 2 && b != null && b.over != 0) { for (k in 0 until 400) { frame(34, 1); if (scene() != 2) break }; if (scene() == 2) fail("battle over=${b.over} but the scene never left BATTLE") }
        } catch (e: Throwable) {
            println("  !! seed $seed failed: ${e.javaClass.simpleName}: ${e.message}")
            if (e !is Fail) e.printStackTrace(System.out)
            println("  last actions: " + log.takeLast(14).joinToString(" | "))
            return false
        }
        return true
    }

    @JvmStatic fun main(args: Array<String>) {
        System.setProperty("java.awt.headless", "true")
        val seeds = args.getOrNull(0)?.toInt() ?: 10
        val actions = args.getOrNull(1)?.toInt() ?: 1500
        if (args.size >= 4) { W = args[2].toInt(); H = args[3].toInt() }
        var bad = 0
        for (s in 1..seeds) { if (!run(s, actions)) bad++ }
        println("coverage: $cov")
        println("ui fuzz: $seeds runs x $actions actions at ${W}x$H, failures=$bad")
    }
}
