package com.example.critterquest

import kotlin.random.Random

/**
 * Checks the PP rules: pool sizes by move strength, heavy hitters cost 2 PP, the last PP still pays for a heavy move,
 * Struggle when everything is empty, a legendary that is down to Struggle cannot knock itself out with recoil,
 * and a save from before the PP change (bigger stored PP) loads clamped to the new maximum.
 */
object PpCheck {
    private var bad = 0
    private fun need(c: Boolean, m: String) { if (!c) { println("  PP CHECK FAILED: $m"); bad++ } }

    fun run(): Int {
        bad = 0
        // 1. the table
        for (m in MOVES) {
            need(m.pp in 4..15, "${m.name}: pool ${m.pp} is outside 4..15")
            val heavy = m.power >= HEAVY_POWER && !m.levelDmg
            need(m.cost == (if (heavy) 2 else 1), "${m.name}: cost ${m.cost} (power ${m.power})")
            if (heavy) need(m.pp == 8, "${m.name}: heavy hitters have 8 PP (has ${m.pp})")
            if (m.power in 1..HEAVY_POWER - 1 && !m.levelDmg) need(m.pp >= 8, "${m.name}: a normal damaging move should have at least 8 PP")
        }
        need(STRUGGLE.cost == 1, "Struggle must cost 1")
        val avg = DEX.map { s -> Mon(s, 20).moves.sumOf { it.move.pp } }.average()
        println("  pp: ${MOVES.size} moves, a Lv20 critter averages ${"%.1f".format(avg)} PP over its moves")
        need(avg in 30.0..55.0, "average PP pool $avg is outside 30..55")

        // 2. spending: normal move 1, heavy move 2, last PP still pays for a heavy move, then Struggle
        val rnd = Random(4)
        fun fight(slotName: String, startPp: Int): Int {
            val me = Mon(DEX[MAELARCH], 30); val foe = Mon(DEX[BOULDERBACK], 30)
            foe.moves.clear(); foe.moves.add(MoveSlot(mv("Growl")))      // a harmless foe: nothing can stop the move
            val slot = me.moves.indexOfFirst { it.move.name == slotName }
            need(slot >= 0, "Maelarch Lv30 should know $slotName"); if (slot < 0) return -1
            me.moves[slot].pp = startPp
            val b = Battle(listOf(me), listOf(foe), null, 0, 0, { 0L }, rnd)
            var g = 0
            while (!b.menuOn && g++ < 100) b.pump()
            b.use(M_FIGHT); b.fightWith(slot)
            g = 0
            while (!b.menuOn && b.over == 0 && g++ < 400) b.pump()
            return me.moves[slot].pp
        }
        need(fight("Ice Beam", 8) == 7, "a normal move should spend 1 PP")
        need(fight("Blizzard", 8) == 6, "a heavy move should spend 2 PP")
        need(fight("Blizzard", 1) == 0, "the last PP should still pay for a heavy move (and not go below 0)")

        // 3. Struggle: a critter with no PP left still acts
        run {
            val me = Mon(DEX[PYRESTRIDER], 30); me.moves.forEach { it.pp = 0 }
            val foe = Mon(DEX[BOULDERBACK], 30)
            foe.moves.clear(); foe.moves.add(MoveSlot(mv("Growl")))
            val b = Battle(listOf(me), listOf(foe), null, 0, 0, { 0L }, rnd)
            var g = 0; while (!b.menuOn && g++ < 100) b.pump()
            val before = foe.hp
            b.use(M_FIGHT); b.fightWith(-1)
            g = 0; while (!b.menuOn && b.over == 0 && g++ < 400) b.pump()
            need(foe.hp < before, "Struggle did no damage")
        }

        // 3b. Struggle is typeless: it hurts a Ghost (Normal moves normally cannot), so two critters with no PP left can never stalemate
        run {
            val me = Mon(DEX[PYRESTRIDER], 30); me.moves.forEach { it.pp = 0 }
            val foe = Mon(DEX[TOLLWRAITH], 30)
            foe.moves.clear(); foe.moves.add(MoveSlot(mv("Growl")))
            need(Rules.eff(T.NORMAL, foe.s) == 0f, "test setup: Tollwraith should be immune to Normal")
            val b = Battle(listOf(me), listOf(foe), null, 0, 0, { 0L }, rnd)
            var g = 0; while (!b.menuOn && g++ < 100) b.pump()
            val before = foe.hp
            b.use(M_FIGHT); b.fightWith(-1)
            g = 0; while (!b.menuOn && b.over == 0 && g++ < 400) b.pump()
            need(foe.hp < before || b.over == 1, "Struggle did no damage to a Ghost")
        }

        // 4. a legendary with no PP left: Struggle recoil must never knock it out
        for (sp in listOf(VERDARCH, TOLLWRAITH)) {
            val party = listOf(PYRESTRIDER, BLOOMFANG, TEMPESTAIL, SEEROWL, GLACIFOX, BOULDERBACK).map { Mon(DEX[it], 30) }
            val foe = Mon(DEX[sp], 20)
            foe.moves.forEach { it.pp = 0 }
            val b = Battle(party, listOf(foe), null, 5, 8, { 0L }, rnd)
            var turns = 0; var g = 0; var struggled = false
            while (b.over == 0 && turns < 80 && g++ < 20000) {
                b.pump()
                if (b.text.contains("hurt by recoil")) struggled = true
                need(foe.hp >= 1 && b.over != 1, "${DEX[sp].name} was knocked out (hp ${foe.hp}, over ${b.over})")
                autoLearn(b)
                if (b.menuOn && b.learnFor == null) { turns++; if (b.swapping) b.swap(party.indexOfFirst { it.hp > 0 }) else { b.use(M_FIGHT); b.fightWith(0) } }
            }
            need(struggled, "${DEX[sp].name} never used Struggle")
            need(foe.hp >= 1 && b.over != 1, "${DEX[sp].name} fainted from Struggle recoil")
        }

        // 5. a save written before the PP change (25 PP stored on 15-PP moves) loads clamped
        run {
            val g = Game(Random(2)); g.newGame(); g.chooseStarter(0)
            val old = g.serialize().replace(Regex("/\\d+(?=[,;]|$)", RegexOption.MULTILINE), "/99")
            need(old != g.serialize(), "test setup: nothing to rewrite in the save")
            val g2 = Game(Random(3))
            need(g2.load(old), "old-style save does not load")
            need(g2.party.all { m -> m.moves.all { it.pp == it.move.pp } }, "stored PP was not clamped to each move's maximum")
        }
        println(if (bad == 0) "pp check: ok" else "pp check: $bad problems")
        return bad
    }
}
